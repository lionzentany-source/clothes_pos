TUIBDataDriverEh is a data driver for firebird/interbase data acces components "Unified InterBase" (UIB)

UIB download: http://sourceforge.net/projects/uib/files/
UIB SVN: https://uib.svn.sourceforge.net/svnroot/uib

Bug reports and requests for changes send to olegenty@gmail.com