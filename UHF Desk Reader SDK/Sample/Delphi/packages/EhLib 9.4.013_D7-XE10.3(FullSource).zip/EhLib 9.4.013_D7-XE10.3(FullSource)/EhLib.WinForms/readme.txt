EhLib.WinForms 0.98 Build 0.98.073 Professional Edition.
----------------------------------------------

EhLib.WinForms library contains components and classes for 
Microsoft Visual Studio version 2012, 2015 and 2017.
(Beta version)

Binary library files (dll) compiled in the 
mode of compatibility with ".NET Framework 4".

Table of CONTENTS
-----------------
1. Where to start.
2. Overview
3. Installing the library
4. Demonstration projects
5. Registration and prices
6. Contacts


-----------------
1. Where to start.
-----------------

Start overview of the library EhLib.WinForms with a demo application 
.\Demos\MainDemo\bin\Release\MainDemo.Exe.
(Compiled Demo files are available in the Trial version of the library
or in the "EhLib Compiled Demo" archive  which can be downloaded to 
the following address http://www.ehlib.com/en/downloads)

The main Demonstration library project is 
.\Demos\MainDemo\MainDemo.csproj

Opening, compiling and running the Demo projects in the folder Demos
should work without install the library in Visual Studio IDE.

To install the library in the IDE read the Chapter 2 (Installing libraries)

If during the installation you have problems, email to our support team 
to address support@ehlib.com

For thr full instruction of the library components, read the file
".\Doc\ENU\EhLib.WinForms - Developers Guide.doc"

--------
2. Overview
--------

The library contains several controls and classes for working with 
tabular data.

The basic controls of the library is DataGridEh and DataVertGridEh.

The DataGridEh control 
----------------------

The DataGridEh control is a visual component (control) to display and edit data 
in a tabular format.
You can configure DataGridEh using grid properties, and expand writing 
event handlers or creating new types of columns, cells and other elements
the grid.
As data source can be used a different kinds of data.
Grid can'n work in unbound mode.

DataGridEh has the following features:
  - Allows to select records, columns and rectangle.
  - Allows you to copy the selected area to the clipboard and fill 
    the contents of the grid from the clipboard.
  - Allows you to create complex headers (MultiTitle),
    that may occupy the space above a number of columns.
  - Allows you to create a footer (footer), where you can 
    show amount/quantity/ etc. aggregated values of the fields.
  - Allows to automatically change the size of columns so that the total width
    columns always match the width of the visible part of the window grid.
  - Allows you to adjust the height of the rows and headers using properties.
  - Allows you to automatically transfer a single-line column headings and 
    the data in the row, the multi-line with automatic extension of the height of the rows.
  - Allows you to sort the data by clicking the column header.
  - Allows to set fixed neproroschennye columns in the left and right 
    part of the grid.
  - Allows you to display ScreenTips (ToolTips) for text that 
    does not fit in a grid cell.
  - Allows you to visually search the data in the data source using
    visual built-in SearchBox.
  - Allow to filter and select items to filter through 
    built-in visual element TitleFilter.
  - Allows you to create columns dynamically based on list properties 
    the source of data.
  - Allows you to create static columns of the following types
      DataGridTextColumn column to view the data as text.
      DataGridComboBoxColumn column to view data as text 
        a drop-down list.
      DataGriButtonColumn - the column with the button. 
      DataGridCheckBoxColumn column to view the data in the form element
        CheckBox.
      DataGridRadioButtonColumn - the column to display in the item view
        RadioButton.
      DataGridImageColumn - the column to view the data in the form of pictures.
      DataGridProgressBarColumn - the column to view the data in the form 
        of the progress bar.
  - Has a procedure to save/restore the columns
    (visible columns, columns order, column width, sort order) 
    to/from classes, which can then be serialized into a textual representation 
    to save the settings file.
  - Has methods for print and preview grid before printing.

The DataVertGridEh control
--------------------------

The control DataVertGridEh is a visual component (control) 
to display and edit data in a tabular format.
Unlike DataGridEh, DataVertGridEh displays the contents of one record in
a vertical view.
In the current version of the library DataVertGridEh can simultaneously display only
one record on the screen.
DataVertGridEh visually similar to Windows.Forms.PropertyGrid.
DataVertGridEh can'n work in unbound mode.

DataVertGridEh has the following features:
  - Allows to automatically change the size of columns so that the total width
    columns always match the width of the visible part of the window grid.
  - Allows you to adjust the height of the rows and headers using properties.
  - Allows you to automatically transfer a single-line column headings and 
    the data in the row, the multi-line with automatic extension of the height of the rows.
  - Allows you to display ScreenTips (ToolTips) for text that 
    does not fit in a grid cell.
  - Allows you to create rows dynamically based on the property list 
    the source of data.
  - Allows you to create a static string of the following types
      DataVertGridTextRow - line to view the data as text.
      DataGridImageRow - line to view data in the form of pictures.

----------------------
3 Installing The Library
----------------------

3.1 Automatic installation of the Libraries
----------------------------------------

The current version has no facility for automatic 
install assemblies in Visual Studio.

3.2 Manual installation of the Library
--------------------------------

Please note that to run the demo projects folder
.\Demos\Data
installing library in the Visual Studio IDE is not required.

Installing library in Visual Studio is a 
the process of adding the component library window the Toolbox for later 
move them to create shapes for your projects.

Adding components to the Toolbox window
-----

To add a component to the Toolbox window, do the following:
  - Start Visual Studio.
  - Open the Toolbox window (View-Toolbox).
  - In the Toolbox on right click open context menu 
      select "Choose items..."
  - In the dialog "Choose Toolbox Items" on the ".NET Framework Components" tab
      click "Browse..."
  - In the dialog "Open", locate and select the Assembly "EhLib.WinForms.dll" from 
      unpacked archive library and click "Open".
  - In the window "Choose Toolbox Items" you should see the new items 
      library DataGridEh, DataVertGridEh etc. 
  - Tick in the first column opposite the items must be in 
      the status "Checked".
  - In the window "Choose Toolbox Items" click "Ok".
  - Open or create new project of type WinForms.
  - Open any form in design mode and check that the components 
      library DataGridEh, DataVertGridEh, etc. are visible in the "Toolbox".
      Components should appear on the General tab.
    - If your projects use many third-party components then,
����� for convenience, you can create a new tab in the "Toolbox" window
����� with the name "EhLib" and move the library components to it.

Adding references to library assemblies in the References section of your project:
----

After creating the project, add links to the EhLib.WinForms.dll and
EhLib.WinForms.Design.dll in the References section of your project. For assembly
EhLib.WinForms.Design.dll in the assembly properties, specify the property "Copy Local" = "False"
since this assembly is not needed during the run-time.
This prevents the assembly from being copied to the application startup folder
bin\Debug (or bin\Release).

To test the work of the components in design-time and correct operation
of links to assemblies, move the DataGridEh control to the Form of your project
and recompile the project.


The absence of the EhLib.WinForms.Design.dll assembly in the Project References section
-----

If you do not add links to the EhLib.WinForms.dll and EhLib.WinForms.Design.dll assemblies
manually and transfer to the project form one of the components of the library,
then the IDE add the link manually, but only on one assembly - EhLib.WinForms.dll.
In this case, you will not get the Design-Time functionality. You can understand what happened
this is the situation when trying to select the DataGridEh component in Design-Time and
open the drop-down window Smart Tags (smart tags).
If there is no icon in the EhLib.WinForms.Design.dll link to open the Smart Tags on the
the DataGridEh component will be absent.
Also, when you add library controls to a form, they will appear
under the form, in the section of non-visual components, and not on the form as it should be.

-----------------------------
4. Demonstration Projects
-----------------------------

Demonstration Projects are in the folder 
.\Demos
The demo examples use tables from the folder
.\Demos\DataFiles.

---------------------
5. Registration and Prices
---------------------

The current version of EhLib library.WinForms ships with 
EhLib library for Delphi/C++ Builder (EhLib.VCL).

----
You can read detailed information about registration and prices 
the home page of the library 
http://www.ehlib.com/en/buy

----
After registering, you will receive the address (only by email.mail)
to download files and the password to unzip.

Registering the library, you also get the following benefits:

  1. You will receive the new version free of charge during the year from the date of purchase.
  2. You will receive technical support library any level of complexity is unlimited in time.
  3. By purchasing a legal version, you contribute to the further development of the library.


6. Contacts
--------

If you have questions, comments 
or suggestions, please contact the developers at the following addresses.
www: http://www.ehlib.com
EMail: support@ehlib.com
Skype support: ehlib.support