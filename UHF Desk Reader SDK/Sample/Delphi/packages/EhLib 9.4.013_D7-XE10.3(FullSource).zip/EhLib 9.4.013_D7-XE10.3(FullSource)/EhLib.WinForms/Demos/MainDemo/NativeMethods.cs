﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MainDemo
{
  internal static class NativeMethods
  {
    public const int
        HTNOWHERE = 0,
        HTCLIENT = 1,
        HTCAPTION = 2,

        WM_NCHITTEST = 0x0084
        ;

  }
}
