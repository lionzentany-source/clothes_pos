﻿namespace MainDemo
{


  partial class NorthwindDataSet
  {
    partial class PolyCellColumnTableDataTable
    {
    }
  }
}
