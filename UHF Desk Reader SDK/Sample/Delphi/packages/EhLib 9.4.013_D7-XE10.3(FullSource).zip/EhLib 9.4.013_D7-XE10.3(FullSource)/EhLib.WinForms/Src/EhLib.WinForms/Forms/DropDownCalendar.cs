﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  public partial class DropDownCalendar : DropDownForm
  {

    #region constructor
    public DropDownCalendar()
    {
      InitializeComponent();

      FormElements = 0;
      DropDownBorder = false;
      monthCalendar1.HandleCreated += CalendarHandleCreated;
      monthCalendar1.DateSelected += CalendarDateSelected;
    }
    #endregion constructor

    #region run-time properties
    public DateTime Value
    {
      get
      {
        return monthCalendar1.SelectionStart;
      }

      set
      {
        monthCalendar1.SelectionStart = value;
      }
    }

    //public bool ReadOnly
    //{
    //  get
    //  {
    //    return monthCalendar1.ReadOnly;
    //  }

    //  set
    //  {
    //    monthCalendar1.ReadOnly = value;
    //  }
    //}
    #endregion run-time properties

    #region methods
    public new void CreateHandle()
    {
      base.CreateHandle();
    }
    protected override void OnHandleCreated(EventArgs e)
    {
      base.OnHandleCreated(e);
    }

    private void CalendarHandleCreated(object sender, EventArgs e)
    {
    }

    protected override void OnLayout(LayoutEventArgs e)
    {
      base.OnLayout(e);
      if (monthCalendar1 != null && IsHandleCreated)
      {
      //  IntPtr handle = monthCalendar1.Handle;
      //  //monthCalendar1.Visible = true;
      //  //monthCalendar1.CreateControl();
        ClientSize = monthCalendar1.Size;
      }
    }

    private void DropDownCalendar_KeyDown(object sender, KeyEventArgs e)
    {
      if (e.KeyData == Keys.Escape)
      {
        DialogResult = DialogResult.Cancel;
        Close();
      }
      else if (e.KeyData == Keys.Enter)
      {
        DialogResult = DialogResult.OK;
        Close();
      }
    }

    private void CalendarDateSelected(object sender, DateRangeEventArgs e)
    {
      //MonthCalendar.HitTestInfo htInfo = monthCalendar1.HitTest(e.Location);
      //if (htInfo.HitArea == MonthCalendar.HitArea.Date)
      {
        DialogResult = DialogResult.OK;
        Close();
      }
    }

    #endregion methods
  }
}
