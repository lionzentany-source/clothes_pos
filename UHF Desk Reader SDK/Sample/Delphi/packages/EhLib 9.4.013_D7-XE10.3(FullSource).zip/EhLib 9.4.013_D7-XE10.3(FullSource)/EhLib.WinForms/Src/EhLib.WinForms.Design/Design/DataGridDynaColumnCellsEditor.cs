﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.ComponentModel;
using System.Collections;

namespace EhLib.WinForms.Design
{
  public class MultiTypedCollectionEditor : CollectionEditor
  {
    private Type[] returnedTypes;

    public MultiTypedCollectionEditor(Type type) : base(type)
    {
    }

    protected override Type[] CreateNewItemTypes()
    {
      return returnedTypes;
    }

    protected virtual Type CollectionItemBaseType()
    {
      return null;
    }

    protected virtual Type CollectionItemVisibleAttributeType()
    {
      return null;
    }

    protected virtual bool ExcludeBaseCollectionItemType()
    {
      return true;
    }

    public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value)
    {
      if (returnedTypes == null)
      {
        returnedTypes = GetReturnedTypes(provider);
        //MessageBox.Show("EditValue - " + returnedTypes.Length.ToString());
      }
      return base.EditValue(context, provider, value);
    }

    private Type[] GetReturnedTypes(IServiceProvider provider)
    {
      List<Type> result = new List<Type>();
      bool excludeType;

      ITypeDiscoveryService tds = (ITypeDiscoveryService)provider.GetService(typeof(ITypeDiscoveryService));

      if (tds != null)
      {
        ICollection allCellTypes = tds.GetTypes(CollectionItemBaseType(), false);
        Type gridDataCellDesignTimeVisibleAttributeType = CollectionItemVisibleAttributeType();
        foreach (Type cellManType in allCellTypes)
        {
          Attribute attr = TypeDescriptor.GetAttributes(cellManType)[gridDataCellDesignTimeVisibleAttributeType];
          var visAttr = attr as DesignTimeCollectionEditorItemVisibleAttribute;
          if ((visAttr == null) ||
              (visAttr != null && !visAttr.Visible))
          {
            continue;
          }

          if (ExcludeBaseCollectionItemType() && cellManType == CollectionItemBaseType())
            excludeType = true;
          else
            excludeType = false;

          if (!result.Contains(cellManType) && !excludeType)
          {
            result.Add(cellManType);
          }
        }
      }

      return result.ToArray();
    }

    protected override object CreateInstance(Type itemType)
    {
      return base.CreateInstance(itemType);
    }

    protected override CollectionForm CreateCollectionForm()
    {
      CollectionForm form = base.CreateCollectionForm();
      return form;
    }

  }

  public class DataGridDynaColumnCellsEditor : MultiTypedCollectionEditor
  {
    public DataGridDynaColumnCellsEditor(Type type) : base(type)
    {
    }

    protected override Type CollectionItemBaseType()
    {
      return typeof(BaseDataCellManager);
    }

    protected override Type CollectionItemVisibleAttributeType()
    {
      //return typeof(DataGridDataCellDesignTimeVisibleAttribute);
      return typeof(DataCellDesignTimeVisibleAttribute);
    }
  }

  public class DataVertGridDynaColumnCellsEditor : MultiTypedCollectionEditor
  {
    public DataVertGridDynaColumnCellsEditor(Type type) : base(type)
    {
    }

    protected override Type CollectionItemBaseType()
    {
      return typeof(BaseDataCellManager);
    }

    protected override Type CollectionItemVisibleAttributeType()
    {
      //return typeof(DataVertGridDataCellDesignTimeVisibleAttribute);
      return typeof(DataCellDesignTimeVisibleAttribute);
    }
  }
}
