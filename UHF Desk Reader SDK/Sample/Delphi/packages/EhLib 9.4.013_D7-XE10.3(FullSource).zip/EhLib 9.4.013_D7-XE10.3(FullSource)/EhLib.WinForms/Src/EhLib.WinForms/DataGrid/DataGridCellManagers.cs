﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Base class for cell managers classes that participate in the DataGridEh component
  /// </summary>
  [ToolboxItem(false)]
  public class DataGridBaseCellMan : BaseGridCellManager
  {
    #region privates
    #endregion privates

    public DataGridBaseCellMan()
    {
    }

    #region properties
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public new DataGridEh BoundGrid
    {
      get { return (DataGridEh)base.BoundGrid; }
      set { base.BoundGrid = value; }
    }
    #endregion

    #region methods
    protected internal override void OnPaintBackground(BaseGridCellPaintEventArgs e)
    {
      using (
        SolidBrush fillBrush = new SolidBrush(BoundGrid.BackColor))
      {
        if ((BasePaintCellStates.Selected & e.State) != 0)
        {
          if (BoundGrid.IsActiveControl())
            fillBrush.Color = SystemColors.Highlight;
          else
            fillBrush.Color = SystemColors.ButtonShadow;
        }

        BoundGrid.PaintingFillRectangle(e.Graphics, fillBrush, e.ClientRect);
      }
    }

    public override string GetDisplayText(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      return "GetDisplayText is not implemented";
    }

    protected internal override void OnGetCellBorderParams(BaseGridCellBorderEventArgs e)
    {
      e.Style = DashStyle.Solid;

      if ((e.BorderType == GridCellBorderSide.Left) || (e.BorderType == GridCellBorderSide.Right))
      {
        e.Visible = BoundGrid.LineOptions.VertLines;
        e.IsExtent = true;
      }
      else
      {
        e.Visible = BoundGrid.LineOptions.HorzLines;
        e.IsExtent = true;
      }

      //e.Color = SystemColors.ButtonFace;
      //return;

      if ((e.BorderType == GridCellBorderSide.Top || e.BorderType == GridCellBorderSide.Left) &&
         ((e.ColIndex == BoundGrid.ColCount) || (e.RowIndex == BoundGrid.RowCount)))
        e.Color = BoundGrid.LineOptions.DarkColor;
      else if (e.ColIndex < 0 || e.RowIndex < 0)
        e.Color = BoundGrid.LineOptions.BrightColor;
      else if ((e.ColIndex < BoundGrid.FixedColCount - BoundGrid.FrozenColCount) ||
               (e.RowIndex < BoundGrid.FixedRowCount - BoundGrid.FrozenRowCount))
        e.Color = BoundGrid.LineOptions.DarkColor;
      else if ((e.ColIndex == BoundGrid.FixedColCount - 1) && (e.BorderType == GridCellBorderSide.Right))
        e.Color = BoundGrid.LineOptions.DarkColor;
      else if ((e.ColIndex == BoundGrid.FixedRowCount - 1) && (e.BorderType == GridCellBorderSide.Bottom))
        e.Color = BoundGrid.LineOptions.DarkColor;
      else if ((e.RowIndex > BoundGrid.RowCount - 1) && (e.BorderType == GridCellBorderSide.Bottom))
      {
        e.Color = BoundGrid.Footer.HorzLine.Color;
        e.Style = BoundGrid.Footer.HorzLine.Style;
      }
      else
      {
        if (e.BorderType == GridCellBorderSide.Left ||
            e.BorderType == GridCellBorderSide.Right
            )
        {
          e.Visible = BoundGrid.ColumnOptions.VertLine.Visible;
          e.IsExtent = true;
          e.Color = BoundGrid.ColumnOptions.VertLine.Color;
          e.Style = BoundGrid.ColumnOptions.VertLine.Style;
        }
        else
        {
          e.Visible = BoundGrid.RowOptions.HorzLine.Visible;
          e.IsExtent = true;
          e.Color = BoundGrid.RowOptions.HorzLine.Color;
          e.Style = BoundGrid.RowOptions.HorzLine.Style;
        }
      }
    }

    protected internal override void OnContextMenuStripNeeded(BaseGridCellContextMenuStripNeededEventArgs e)
    {
      e.ContextMenuStrip = BoundGrid.GetDefaultContextMenuStrip();
    }
    #endregion
  }

  public class DataGridEmptyTitleCellMan : DataGridBaseCellMan
  {
    public override string GetDisplayText(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      return null;
    }
  }

  public class DataGridEmptyDataCellMan : BaseDataCellManager
  {

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public new DataGridEh BoundGrid
    {
      get { return (DataGridEh)base.BoundGrid; }
      set { base.BoundGrid = value; }
    }

    public override string GetDisplayText(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      return null;
    }

    protected internal override void OnPaintBackground(BaseGridCellPaintEventArgs e)
    {
      using (
        SolidBrush fillBrush = new SolidBrush(BoundGrid.BackColor))
      {
        if ((BasePaintCellStates.Selected & e.State) != 0)
        {
          if (BoundGrid.IsActiveControl())
            fillBrush.Color = SystemColors.Highlight;
          else
            fillBrush.Color = SystemColors.ButtonShadow;
        }

        BoundGrid.PaintingFillRectangle(e.Graphics, fillBrush, e.ClientRect);
      }
    }

    protected internal override void OnPaintEmptyArea(BaseGridCellPaintEventArgs e)
    {
      Color color;
      Color backColor = BoundGrid.BackColor;
      int alpha;

      if (e.ColIndex == -1 &&
          e.RowIndex >= 0 &&
          BoundGrid.VisibleColumns.Count > 0 &&
          BoundGrid.VisibleRows.Count > 0 &&
          e.AreaRowIndex < BoundGrid.VisibleRows.Count)
      {
        DataGridColumn col = BoundGrid.VisibleColumns[BoundGrid.VisibleColumns.Count - 1];
        DataGridRow row = BoundGrid.VisibleRows[e.AreaRowIndex];

        int areaColIndex;
        int areaRowIndex;
        BaseGridCellManager cellLeft = BoundGrid.CellManByColRow(BoundGrid.ColCount-1, e.RowIndex, out areaColIndex, out areaRowIndex);
        Debug.Assert(cellLeft != null, "BaseGridControl.PaintCell Cell = null");

        DataAxisGridDataCellFormatParamsNeededEventArgs fe = CreateFormatParamsNeededEventArgs(BoundGrid, null, row);
        ProcessFormatParamsNeeded(fe);

        backColor = fe.BackColor;

        //BaseGridCellPaintEventArgs pea = cellLeft.GetCellPaintParams(e.Grid, e.Graphics, 
        //  -1, e.RowIndex, e.CellRect, e.CellRect, 0, -1, areaRowIndex, new Point(-1, -1));
        //DataAxisGridDataCellPaintEventArgs dpea = pea as DataAxisGridDataCellPaintEventArgs;
        //if (dpea != null)
        //{
        //  backColor = dpea.BackColor;
        //}

      }

      if (BoundGrid.Background.Visible)
      {
        if (backColor == BoundGrid.BackColor)
          backColor = Color.Empty;
        else if (backColor.A == 255)
          backColor = Color.FromArgb(BoundGrid.Background.GridOpacityOptions.CellsOpacity, backColor);
      }

      if (backColor != Color.Empty)
      {
        using (SolidBrush fillBrush = new SolidBrush(backColor))
        {
          BoundGrid.PaintingFillRectangle(e.Graphics, fillBrush, e.CellRect);
        }
      }

      if ((BasePaintCellStates.CurrentRow & e.State) != 0)
      {
        alpha = 255 / 6 / 2;
        if (BoundGrid.IsActiveControl())
          color = SystemColors.Highlight;
        else
          color = SystemColors.ButtonShadow;
        using (SolidBrush fillBrush = new SolidBrush(Color.FromArgb(alpha, color)))
        {
          BoundGrid.PaintingFillRectangle(e.Graphics, fillBrush, e.CellRect);
        }
      }
    }

    //protected virtual DataAxisGridDataCellFormatParamsNeededEventArgs CreateFormatParamsNeededEventArgs(
    //  DataAxisGrid grid, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    //{
    //  return new DataAxisGridDataCellFormatParamsNeededEventArgs(grid, propAxisBar, listItemBar, this);
    //}

    protected internal override void OnGetCellBorderParams(BaseGridCellBorderEventArgs e)
    {
      base.OnGetCellBorderParams(e);

      if (e.BorderType == GridCellBorderSide.Right)
      {
        GridLine gl = BoundGrid.ColumnOptions.VertLine;
        e.Visible = gl.Visible;
        e.Color = gl.Color;
        e.Style = gl.Style;
        e.IsExtent = true;
      }
      else if (e.BorderType == GridCellBorderSide.Bottom)
      {
        DataGridRow row = null;

        e.Visible = BoundGrid.RowOptions.HorzLine.Visible;
        e.IsExtent = true;
        e.Color = BoundGrid.RowOptions.HorzLine.Color;
        e.Style = BoundGrid.RowOptions.HorzLine.Style;

        if (e.AreaRowIndex >= 0 && e.AreaRowIndex < BoundGrid.VisibleRows.Count)
          row = BoundGrid.VisibleRows[e.AreaRowIndex];

        var hlpe = new DataGridHorzLineParamsNeededEventArgs(null, row);
        hlpe.Visible = e.Visible;
        hlpe.Color = e.Color;
        hlpe.Style = e.Style;

        BoundGrid.OnHorzLineParamsNeeded(hlpe);

        e.Visible = hlpe.Visible;
        e.Color = hlpe.Color;
        e.Style = hlpe.Style;
      }

      if (e.Visible && BoundGrid.Background.Visible)
        e.Color = Color.FromArgb(BoundGrid.Background.GridOpacityOptions.LinesOpacity, e.Color);
    }

    //public override void GridCellPosToAreaCellPos(int gridColIndex, int gridRowIndex, out int areaColIndex, out int areaRowIndex)
    //{
    //  areaColIndex = gridColIndex - Grid.StartDataColIndex;
    //  areaRowIndex = gridRowIndex - Grid.FixedRowCount;
    //}

    //public override void AreaCellPosToGridCellPos(int areaColIndex, int areaRowIndex, out int gridColIndex, out int gridRowIndex)
    //{
    //  gridColIndex = areaColIndex + Grid.StartDataColIndex;
    //  gridRowIndex = areaRowIndex + Grid.FixedRowCount;
    //}

  }

  public class DataGridBaseIndicatorCellMan : DataGridBaseCellMan
  {
    protected BaseGridFillFixedCellEventArgs StyledPaintArgs = new BaseGridFillFixedCellEventArgs();

    protected internal override void OnGetCellBorderParams(BaseGridCellBorderEventArgs e)
    {
      if ((e.BorderType == GridCellBorderSide.Left) || (e.BorderType == GridCellBorderSide.Right))
      {
        e.Visible = BoundGrid.IndicatorColumn.VertLine.Visible;
        e.IsExtent = true;
      }
      else
      {
        e.Visible = BoundGrid.IndicatorColumn.HorzLine.Visible;
        e.IsExtent = true;
      }

      if (e.BorderType == GridCellBorderSide.Top || e.BorderType == GridCellBorderSide.Bottom)
      {
        e.Color = BoundGrid.IndicatorColumn.HorzLine.Color;
        e.Style = BoundGrid.IndicatorColumn.HorzLine.Style;
      }
      else
      {
        e.Color = BoundGrid.IndicatorColumn.VertLine.Color;
        e.Style = BoundGrid.IndicatorColumn.VertLine.Style;
      }
    }

    protected internal override bool IsSelected(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      if (BoundGrid.Selection.SelectionType == GridSelectionType.All)
        return true;
      else
        return false;
    }

    protected internal virtual bool IsPressed(int col, int row,
        Rectangle paintRect,
        BasePaintCellStates state,
        int dataColIndex, int dataRowIndex)
    {
      return false;
    }

    protected internal override void OnPaintBackground(BaseGridCellPaintEventArgs e)
    {

      Color backColor = BoundGrid.FixedBackColor;

      StyledPaintArgs.CellRect = e.ClientRect;
      StyledPaintArgs.Graphics = e.Graphics;
      StyledPaintArgs.IsHot = false;
      StyledPaintArgs.IsPressed = IsPressed(e.ColIndex, e.RowIndex, e.ClientRect, e.State, e.AreaColIndex, e.AreaRowIndex);
      StyledPaintArgs.IsSelected = (e.State & BasePaintCellStates.Selected) != 0;
      StyledPaintArgs.BackColor = backColor;
      StyledPaintArgs.FillStyle = BoundGrid.FixedBackFiller.FillStyle;
      StyledPaintArgs.InnerBorder = BoundGrid.FixedBackFiller.InnerBorder;
      StyledPaintArgs.FillColor = BoundGrid.FixedBackFiller.Color;
      StyledPaintArgs.SecondFillColor = BoundGrid.FixedBackFiller.SecondColor;

      BoundGrid.DrawStyle.FillTitleCell(BoundGrid, StyledPaintArgs);
    }
  }

  //[DataGridDataCellDesignTimeVisible(true)]
  //public class DataGridBlankDataCellManager : DataGridBaseDataCellManager, ICellBackFillerOwner
  //{
  //  #region privates
  //  private readonly CellBackFiller backFiller;
  //  #endregion

  //  #region constructor
  //  public DataGridBlankDataCellManager()
  //  {
  //    backFiller = new CellBackFiller(this);
  //  }
  //  #endregion

  //  #region properties
  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
  //  public CellBackFiller BackFiller
  //  {
  //    get
  //    {
  //      return backFiller;
  //    }
  //  }
  //  #endregion

  //  #region public methods
  //  public override string GetDisplayText(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    return null;
  //  }
  //  #endregion

  //  #region internal methods
  //  //ICellBackFillerOwner
  //  void ICellBackFillerOwner.BackFillerChanged(CellBackFiller backFiller)
  //  {
  //    if (Grid != null)
  //      Grid.Invalidate();
  //  }

  //  Color ICellBackFillerOwner.BackFillerDefaultColor(CellBackFiller backFiller)
  //  {
  //    if (Grid != null)
  //      return Grid.FixedBackFiller.Color;
  //    else
  //      return SystemColors.ButtonFace;
  //  }

  //  Color ICellBackFillerOwner.BackFillerDefaultSecondColor(CellBackFiller backFiller)
  //  {
  //    if (Grid != null)
  //      return Grid.FixedBackFiller.SecondColor;
  //    else
  //      return SystemColors.ButtonFace;
  //  }

  //  CellFillStyle ICellBackFillerOwner.BackFillerDefaultFillStyle(CellBackFiller backFiller)
  //  {
  //    if (Grid != null)
  //      return Grid.FixedBackFiller.FillStyle;
  //    else
  //      return CellFillStyle.Solid;
  //  }

  //  CellInnerBorderStyle ICellBackFillerOwner.BackFillerDefaultInnerBorder(CellBackFiller backFiller)
  //  {
  //    if (Grid != null)
  //      return Grid.FixedBackFiller.InnerBorder;
  //    else
  //      return CellInnerBorderStyle.RaisedTopLeft;
  //  }

  //  //Other
  //  protected override void PaintBackground(DataAxisGridDataCellPaintEventArgs e)
  //  {
  //    if (!e.IsPaintBackground) return;

  //    Color backColor = BackFiller.Color;

  //    BaseGridFillFixedCellEventArgs styledPaintArgs = new BaseGridFillFixedCellEventArgs();

  //    styledPaintArgs.CellRect = e.CellRect;
  //    styledPaintArgs.Graphics = e.Graphics;
  //    styledPaintArgs.IsHot = false;
  //    styledPaintArgs.IsPressed = false;
  //    styledPaintArgs.IsSelected = (e.State & BasePaintCellStates.Selected) != 0 || IsSelected(e.AreaColIndex, e.AreaRowIndex);
  //    styledPaintArgs.BackColor = backColor;
  //    styledPaintArgs.FillColor = BackFiller.Color;
  //    styledPaintArgs.SecondFillColor = BackFiller.SecondColor;
  //    styledPaintArgs.FillStyle = BackFiller.FillStyle;
  //    styledPaintArgs.InnerBorder = BackFiller.InnerBorder;

  //    Grid.DrawStyle.FillFixedCell(Grid, styledPaintArgs);
  //  }

  //  protected override void PaintForeground(DataAxisGridDataCellPaintEventArgs e)
  //  {
  //    base.PaintForeground(e);
  //  }
  //  #endregion
  //}

  //[DataGridDataCellDesignTimeVisible(true)]
  //public class DataGridBlankDataCellManager : BlankDataCellManager
  //{
  //  #region privates
  //  #endregion

  //  #region constructor
  //  public DataGridBlankDataCellManager()
  //  {
  //  }
  //  #endregion

  //  #region events
  //  public event EventHandler<DataGridDataCellPaintEventArgs> Paint
  //  {
  //    add
  //    {
  //      this.Events.AddHandler(EventKeyPaint, value);
  //    }
  //    remove
  //    {
  //      this.Events.RemoveHandler(EventKeyPaint, value);
  //    }
  //  }

  //  public event EventHandler<DataGridDataCellPaintEventArgs> CustomAreaPaint
  //  {
  //    add
  //    {
  //      this.Events.AddHandler(EventKeyCustomAreaPaint, value);
  //    }
  //    remove
  //    {
  //      this.Events.RemoveHandler(EventKeyCustomAreaPaint, value);
  //    }
  //  }

  //  public event EventHandler<DataGridDataCellClientAreaNeededEventArgs> ClientAreaNeeded
  //  {
  //    add
  //    {
  //      this.Events.AddHandler(EventKeyClientAreaNeeded, value);
  //    }
  //    remove
  //    {
  //      this.Events.RemoveHandler(EventKeyClientAreaNeeded, value);
  //    }
  //  }

  //  public event EventHandler<DataGridDataCellDisplayValueNeededEventArgs> DisplayValueNeeded
  //  {
  //    add
  //    {
  //      this.Events.AddHandler(EventKeyDisplayValueNeeded, value);
  //    }
  //    remove
  //    {
  //      this.Events.RemoveHandler(EventKeyDisplayValueNeeded, value);
  //    }
  //  }
  //  #endregion

  //  #region properties
  //  #endregion

  //  #region public methods
  //  #endregion

  //  #region internal methods
  //  protected internal override DataAxisGridDataCellPaintEventArgs CreateDataCellPaintParams(BaseGridCellManager cellManager, Graphics graphics,
  //      int colIndex, int rowIndex, Rectangle paintRect, BasePaintCellStates state, int areaColIndex, int areaRowIndex,
  //      Point inCellMousePos, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, DataAxisGridListAxisItemViewState listAxisItemViewState)
  //  {
  //    return new DataGridDataCellPaintEventArgs(this, graphics, colIndex, rowIndex, paintRect, state,
  //        areaColIndex, areaRowIndex, inCellMousePos, propAxisBar, listItemBar, listAxisItemViewState);
  //  }

  //  protected internal override DataAxisGridDataCellClientAreaNeededEventArgs CreateDataCellClientAreaNeededEventArgs(PropertyAxisBar propAxisBar,
  //      DataAxisGridListItemBar listItemBar, Rectangle cellRect, BaseDataCellManager cellMan)
  //  {
  //    return new DataGridDataCellClientAreaNeededEventArgs(propAxisBar, listItemBar, cellRect, cellMan);
  //  }

  //  protected override DataAxisGridDataCellDisplayValueNeededEventArgs CreateDisplayValueNeededEventArgs(
  //    PropertyAxisBar propAxisBar, object value)
  //  {
  //    return new DataGridDataCellDisplayValueNeededEventArgs(propAxisBar, this, value);
  //  }

  //  protected override void HandleDisplayValueNeededEvent(DataAxisGridDataCellDisplayValueNeededEventArgs e)
  //  {
  //    var eh = this.Events[EventKeyDisplayValueNeeded] as EventHandler<DataGridDataCellDisplayValueNeededEventArgs>;
  //    if (eh != null)
  //      eh(this, (DataGridDataCellDisplayValueNeededEventArgs)e);
  //    //eh.Invoke()
  //  }

  //  protected override void HandlePaintEvent(DataAxisGridDataCellPaintEventArgs e)
  //  {
  //    var eh = this.Events[EventKeyPaint] as EventHandler<DataGridDataCellPaintEventArgs>;
  //    if (eh != null)
  //      eh(this, (DataGridDataCellPaintEventArgs)e);
  //  }

  //  protected internal override void HandleCustomAreaPaintEvent(DataAxisGridDataCellPaintEventArgs e)
  //  {
  //    var eh = this.Events[EventKeyCustomAreaPaint] as EventHandler<DataGridDataCellPaintEventArgs>;
  //    if (eh != null)
  //      eh(this, (DataGridDataCellPaintEventArgs)e);
  //  }

  //  protected override void HandleClientAreaNeededEvent(DataAxisGridDataCellClientAreaNeededEventArgs e)
  //  {
  //    var eh = this.Events[EventKeyClientAreaNeeded] as EventHandler<DataGridDataCellClientAreaNeededEventArgs>;
  //    if (eh != null)
  //    {
  //      eh(this, (DataGridDataCellClientAreaNeededEventArgs)e);
  //    }
  //  }
  //  #endregion
  //}

}
