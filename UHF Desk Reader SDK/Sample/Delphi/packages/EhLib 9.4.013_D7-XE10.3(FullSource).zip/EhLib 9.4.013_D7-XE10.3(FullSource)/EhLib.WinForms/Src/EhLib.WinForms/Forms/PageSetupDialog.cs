﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Net.Mime;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  // TODO: Postpone. Convert values from Inches to Metrics depending on Local settings.

  public partial class PageSetupDialog : Form
  {

    private BasePrintServiceComponent printService;

    public PageSetupDialog()
    {
      InitializeComponent();
    }

    public BasePrintServiceComponent PrintService
    {
      get { return printService; }
    }
    
    public bool Execute(BasePrintServiceComponent printService)
    {
      this.printService = printService;

      BasePrintServiceComponent ps = printService;

      if (ps.Orientation == PageOrientation.Landscape)
        rbLandscape.Checked = true;
      else
        rbPortrait.Checked = true;

      if (ps.Scaling.ScalingMode == ScalingMode.AdjustToScale)
        rbAdjustTo.Checked = true;
      else
        rbFitTo.Checked = true;

      nudUpDownScale.Value = ps.Scaling.Scale;
      nudFitToWide.Value = ps.Scaling.FitToPagesWide;
      nudFitToTall.Value = ps.Scaling.FitToPagesTall;

      nudMarginsTop.Value = (decimal)ps.PageMargins.Top;
      nudMarginsHeader.Value = (decimal)ps.PageMargins.Header;
      nudMarginsRight.Value = (decimal)ps.PageMargins.Right;
      nudMarginsFooter.Value = (decimal)ps.PageMargins.Footer;
      nudMarginsBottom.Value = (decimal)ps.PageMargins.Bottom;
      nudMarginsLeft.Value = (decimal)ps.PageMargins.Left;

      rtbPageHeaderLeft.Rtf = ps.PageHeader.LeftTextAsRtf;
      SetRichTextBoxAlignment(rtbPageHeaderLeft, HorizontalAlignment.Left);
      rtbPageHeaderCenter.Rtf = ps.PageHeader.CenterTextAsRtf;
      SetRichTextBoxAlignment(rtbPageHeaderCenter, HorizontalAlignment.Center);
      rtbPageHeaderRight.Rtf = ps.PageHeader.RightTextAsRtf;
      SetRichTextBoxAlignment(rtbPageHeaderRight, HorizontalAlignment.Right);
      rtbPageFooterLeft.Rtf = ps.PageFooter.LeftTextAsRtf;
      SetRichTextBoxAlignment(rtbPageFooterLeft, HorizontalAlignment.Left);
      rtbPageFooterCenter.Rtf = ps.PageFooter.CenterTextAsRtf;
      SetRichTextBoxAlignment(rtbPageFooterCenter, HorizontalAlignment.Center);
      rtbPageFooterRight.Rtf = ps.PageFooter.RightTextAsRtf;
      SetRichTextBoxAlignment(rtbPageFooterRight, HorizontalAlignment.Right);

      if (ShowDialog() == DialogResult.OK)
      {
        if (rbLandscape.Checked)
          ps.Orientation = PageOrientation.Landscape;
        else
          ps.Orientation = PageOrientation.Portrait;

        if (rbAdjustTo.Checked)
          ps.Scaling.ScalingMode = ScalingMode.AdjustToScale;
        else
          ps.Scaling.ScalingMode = ScalingMode.FitToPages;

        ps.Scaling.Scale = (int)nudUpDownScale.Value;
        ps.Scaling.FitToPagesWide = (int)nudFitToWide.Value;
        ps.Scaling.FitToPagesTall = (int)nudFitToTall.Value;

        ps.PageMargins.Top = (float)nudMarginsTop.Value;
        ps.PageMargins.Header = (float)nudMarginsHeader.Value;
        ps.PageMargins.Right = (float)nudMarginsRight.Value;
        ps.PageMargins.Footer = (float)nudMarginsFooter.Value;
        ps.PageMargins.Bottom = (float)nudMarginsBottom.Value;
        ps.PageMargins.Left = (float)nudMarginsLeft.Value;

        if (String.IsNullOrEmpty(rtbPageHeaderLeft.Text))
          ps.PageHeader.LeftText = null;
        else
          ps.PageHeader.LeftText = rtbPageHeaderLeft.Rtf;

        if (String.IsNullOrEmpty(rtbPageHeaderCenter.Text))
          ps.PageHeader.CenterText = null;
        else
          ps.PageHeader.CenterText = rtbPageHeaderCenter.Rtf;

        if (String.IsNullOrEmpty(rtbPageHeaderRight.Text))
          ps.PageHeader.RightText = null;
        else
          ps.PageHeader.RightText = rtbPageHeaderRight.Rtf;

        if (String.IsNullOrEmpty(rtbPageFooterLeft.Text))
          ps.PageFooter.LeftText = null;
        else
          ps.PageFooter.LeftText = rtbPageFooterLeft.Rtf;

        if (String.IsNullOrEmpty(rtbPageFooterCenter.Text))
          ps.PageFooter.CenterText = null;
        else
          ps.PageFooter.CenterText = rtbPageFooterCenter.Rtf;

        if (String.IsNullOrEmpty(rtbPageFooterRight.Text))
          ps.PageFooter.RightText = null;
        else
          ps.PageFooter.RightText = rtbPageFooterRight.Rtf;

        return true;
      }
      else
        return false;
    }

    private void SetRichTextBoxAlignment(RichTextBox richTextBox, HorizontalAlignment align)
    {
      richTextBox.SelectAll();
      richTextBox.SelectionAlignment = align;
      richTextBox.DeselectAll();
    }

    private void bInsertPageNo_Click(object sender, System.EventArgs e)
    {
      var textBox = ActiveControl as RichTextBox;
      if (textBox != null)
      {
        textBox.SelectedText = "&[Page]";
      }
    }

    private void bInsertPages_Click(object sender, System.EventArgs e)
    {
      var textBox = ActiveControl as RichTextBox;
      if (textBox != null)
      {
        textBox.SelectedText = "&[Pages]";
      }
    }

    private void bInsertDate_Click(object sender, System.EventArgs e)
    {
      var textBox = ActiveControl as RichTextBox;
      if (textBox != null)
      {
        textBox.SelectedText = "&[Date]";
      }
    }

    private void bInsertShortDate_Click(object sender, System.EventArgs e)
    {
      var textBox = ActiveControl as RichTextBox;
      if (textBox != null)
      {
        textBox.SelectedText = "&[ShortDate]";
      }
    }

    private void bInsertLongDate_Click(object sender, System.EventArgs e)
    {
      var textBox = ActiveControl as RichTextBox;
      if (textBox != null)
      {
        textBox.SelectedText = "&[LongDate]";
      }
    }

    private void bInsertTime_Click(object sender, System.EventArgs e)
    {
      var textBox = ActiveControl as RichTextBox;
      if (textBox != null)
      {
        textBox.SelectedText = "&[Time]";
      }
    }

    private void bSetFont_Click(object sender, System.EventArgs e)
    {
      var re = ActiveControl as RichTextBox;
      if (re != null)
      {
        fontDialog1.Font = re.SelectionFont;
        fontDialog1.Color = re.SelectionColor;

        if (fontDialog1.ShowDialog() != DialogResult.Cancel)
        {
          re.SelectionFont = fontDialog1.Font;
          re.SelectionColor = fontDialog1.Color;
        }
      }
    }
  }
}
