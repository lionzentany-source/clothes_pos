﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of column in a DataGridEh control that displays a text.
  /// </summary>
  [DataGridColumnDesignTimeVisible(true)]
  public class DataGridTextColumn : DataGridColumn
  {
    #region> privates
    #endregion< privates

    public DataGridTextColumn()
    {
    }

    #region> Properties
    [Browsable(false)]
    public new TextDataCellManager DataCell
    {
      get { return (TextDataCellManager)base.InternalCellManager; }
    }

    [DefaultValue(CellTextWrapMode.Auto)]
    public CellTextWrapMode WrapMode
    {
      get { return DataCell.WrapMode; }
      set { DataCell.WrapMode = value; }
    }

    [DefaultValue(false)]
    public bool CellDataIsLink
    {
      get { return DataCell.CellDataIsLink; }
      set { DataCell.CellDataIsLink = value; }
    }

    public new bool AllowShowEditor
    {
      get { return base.AllowShowEditor; }
      set { base.AllowShowEditor = value; }
    }

    [DefaultValue("")]
    public string FormatString
    {
      get { return DataCell.FormatString; }
      set { DataCell.FormatString = value; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public TextAutoCompleting AutoCompleting
    {
      get
      {
        return DataCell.AutoCompleting;
      }
    }
    #endregion<

    #region> methods
    ////AllowShowEditor
    //protected internal override bool ShouldSerializeAllowShowEditor()
    //{
    //  return base.ShouldSerializeAllowShowEditor();
    //}

    //public override void ResetAllowShowEditor()
    //{
    //  base.ResetAllowShowEditor();
    //}

    //Other
    protected override BaseDataCellManager CreateTemplateCell()
    {
      return new TextDataCellManager();
      //return new InternalTextDataCellManager();
    }
    #endregion<

  }

}
