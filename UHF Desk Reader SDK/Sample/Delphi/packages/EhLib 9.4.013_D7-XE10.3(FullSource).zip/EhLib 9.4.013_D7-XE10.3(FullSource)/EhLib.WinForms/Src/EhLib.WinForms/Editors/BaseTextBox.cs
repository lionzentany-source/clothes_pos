﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Design;
using System.Reflection;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  public delegate void WndProcDelegate(ref Message m);

  /// <summary>
  /// Provides the base class for a <see cref = "ComboBoxEh" />, <see cref = "MaskedTextBoxEh" /> and 
  /// <see cref = "TextBoxEh" /> controls.
  /// </summary>
  [DesignerCategory("Code")]
  public class BaseTextBoxEh : BaseEditBoxEh
  {

    #region >consts
    //private const int ThemedBorderWidth = 1; // width of custom border we draw when themed
    #endregion <consts

    #region >internal fields
    private bool codeTextChanging;
    //private bool userTextChanged;

    private readonly TextAutoCompleting autoCompleting;
    private TextAutoCompletingManager completingManager;
    #endregion <internal fields

    #region >constructor
    public BaseTextBoxEh()
    {

      InitData();
      //SetStyle(ControlStyles.Selectable, false);
      DataBindings.CollectionChanged += DataBindings_CollectionChanged;
      autoCompleting = new TextAutoCompleting();
      autoCompleting.CollectionChanged += AutoCompleting_CollectionChanged;
    }

    private void InitData()
    {
      SetStyle(ControlStyles.FixedHeight, AutoHeight());
    }

    protected override void Dispose(bool disposing)
    {
      UnboundDataBindings();
      base.Dispose(disposing);
    }
    #endregion <constructor

    #region >design-time properties

    //[Description("TextBoxMultilineDescr")]
    [Category("Behavior")]
    [DefaultValue(false)]
    [Localizable(true)]
    [RefreshProperties(RefreshProperties.All)]
    protected bool Multiline
    {
      get
      {
        return TextBoxControl.Multiline;
      }
      set
      {
        if (value != Multiline)
        {
          TextBoxControl.Multiline = value;
          UpdateFixedHeight();
        }
      }
    }

    /// <summary>
    ///    Gets or sets the current text in the text box.
    /// </summary>
    //[Editor("System.ComponentModel.Design.MultilineStringEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(UITypeEditor))]
    //[Editor(typeof(EhLib. Design.InEditControlEditor), typeof(UITypeEditor))]
    [Localizable(true)]
    public override string Text
    {
      get
      {
        return TextBoxControl.Text;
      }
      set
      {
        codeTextChanging = true;
        try
        {
          TextBoxControl.Text = value;
        }
        finally
        {
          codeTextChanging = false;
        }
      }
    }

    [DefaultValue(false)]
    protected bool AcceptsTab
    {
      get
      {
        return TextBoxControl.AcceptsTab;
      }
      set
      {
        TextBoxControl.AcceptsTab = value;
      }
    }

    public override Color BackColor
    {
      get
      {
        return TextBoxControl.BackColor;
      }
      set
      {
        TextBoxControl.BackColor = value;
      }
    }

    public override Color ForeColor
    {
      get
      {
        return TextBoxControl.ForeColor;
      }
      set
      {
        base.ForeColor = value;
        TextBoxControl.ForeColor = value;
      }
    }

    [DefaultValue(true)]
    protected bool HideSelection
    {
      get
      {
        return TextBoxControl.HideSelection;
      }
      set
      {
        TextBoxControl.HideSelection = value;
      }
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Editor("System.Windows.Forms.Design.StringArrayEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(UITypeEditor))]
    [Localizable(true)]
    [MergableProperty(false)]
    protected string[] Lines
    {
      get
      {
        return TextBoxControl.Lines;
      }
      set
      {
        TextBoxControl.Lines = value;
      }
    }

    [DefaultValue(32767)]
    [Localizable(true)]
    public virtual int MaxLength
    {
      get
      {
        return TextBoxControl.MaxLength;
      }
      set
      {
        TextBoxControl.MaxLength = value;
      }
    }

    //[Browsable(false)]
    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    //[EditorBrowsable(EditorBrowsableState.Never)]
    //public Padding Padding { get; set; }

    public override int PreferredHeight
    {
      get
      {
        if (TextBoxControl == null)
        {
          return base.PreferredHeight;
        }
        else
        {
          int result = TextBoxControl.PreferredHeight;
          if (Border.Style != ControlBorderStyle.None)
            result = result + SystemInformation.BorderSize.Height * 4;
          result = result + Padding.Top + Padding.Bottom;
          return result;
        }
      }
    }

    [DefaultValue(false)]
    [RefreshProperties(RefreshProperties.Repaint)]
    public override bool ReadOnly
    {
      get
      {
        return TextBoxControl.ReadOnly;
      }
      set
      {
        TextBoxControl.ReadOnly = value;
      }
    }

    [DefaultValue(true)]
    public virtual bool ShortcutsEnabled
    {
      get
      {
        return TextBoxControl.ShortcutsEnabled;
      }
      set
      {
        TextBoxControl.ShortcutsEnabled = value;
      }
    }

    /// <summary>
    /// Indicates whether a multiline text box control automatically wraps words to the beginning of 
    /// the next line when necessary.
    /// </summary>
    [DefaultValue(true)]
    [Localizable(true)]
    protected bool WordWrap
    {
      get
      {
        return TextBoxControl.WordWrap;
      }
      set
      {
        TextBoxControl.WordWrap = value;
      }
    }
    #endregion <design-time properties

    #region >run-time properties
    [Browsable(false)]
    [DefaultValue(true)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    [Localizable(true)]
    [RefreshProperties(RefreshProperties.Repaint)]
    public override bool AutoSize
    {
      get
      {
        return TextBoxControl.AutoSize;
      }
      set
      {
        if (TextBoxControl.AutoSize != value)
        {
          TextBoxControl.AutoSize = value;
          if (!Multiline)
          {
            SetStyle(ControlStyles.FixedHeight, value);
            AdjustHeight(false);
          }
        }
      }
    }

    [Browsable(false)]
    public virtual int TextLength
    {
      get
      {
        return TextBoxControl.TextLength;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected bool CanUndo
    {
      get
      {
        return TextBoxControl.CanUndo;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool Modified
    {
      get
      {
        return TextBoxControl.Modified;
      }
      set
      {
        TextBoxControl.Modified = value;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public virtual string SelectedText
    {
      get
      {
        return TextBoxControl.SelectedText;
      }
      set
      {
        TextBoxControl.SelectedText = value;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public virtual int SelectionLength
    {
      get
      {
        return TextBoxControl.SelectionLength;
      }
      set
      {
        TextBoxControl.SelectionLength = value;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int SelectionStart
    {
      get
      {
        return TextBoxControl.SelectionStart;
      }
      set
      {
        TextBoxControl.SelectionStart = value;
      }
    }

    protected internal TextBoxBase TextBoxControl
    {
      get
      {
        return (TextBoxBase)EditControl;
      }
    }

    protected override Padding DefaultPadding
    {
      get
      {
        if (Border != null && Border.Style == ControlBorderStyle.None)
          return Padding.Empty;
        else
          return new Padding(1, 1, 1, 2);
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public override bool Focused
    {
      get
      {
        return TextBoxControl.Focused;
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    protected internal TextAutoCompleting AutoCompleting
    {
      get
      {
        return autoCompleting;
      }
    }

    protected virtual TextAutoCompletingManager CreateCompletingManager()
    {
      return new TextAutoCompletingManager();
    }

    protected internal TextAutoCompletingManager CompletingManager
    {
      get
      {
        if (completingManager == null)
        {
          completingManager = CreateCompletingManager();
          completingManager.ClosedUp += CompletingManager_ClosedUp;
        }
        return completingManager;
      }
      set
      {
        if (completingManager != value)
        {
          if (completingManager != null)
            completingManager.ClosedUp -= CompletingManager_ClosedUp;
          completingManager = value;
        }
      }
    }

    //[Browsable(false)]
    //public bool UserTextChanged
    //{
    //  get { return userTextChanged; }
    //}
    #endregion

    #region >internal properties
    #endregion

    #region >public methods
    public void AppendText(string text)
    {
      TextBoxControl.AppendText(text);
    }

    public override void Clear()
    {
      TextBoxControl.Clear();
    }

    public void ClearUndo()
    {
      TextBoxControl.ClearUndo();
    }

    /// <devdoc>
    ///     EhLib devdoc. Copies the current selection in the text box to the Clipboard.
    /// </devdoc>
    /// 
    /// <summary>
    ///     EhLib summary. Copies the current selection in the text box to the Clipboard.
    /// </summary>
    public override void Copy()
    {
      TextBoxControl.Copy();
    }

    public override void Cut()
    {
      TextBoxControl.Cut();
    }

    public override void Paste()
    {
      TextBoxControl.Paste();
    }

    public void DeselectAll()
    {
      TextBoxControl.DeselectAll();
    }

    /// <summary>
    ///    Retrieves the character that is closest to the specified location within the control.
    /// </summary>
    ///  <returns>
    ///    The zero-based character index at the specified location.
    /// </returns>
    public virtual char GetCharFromPosition(Point pos)
    {
      return TextBoxControl.GetCharFromPosition(pos);
    }

    /// <summary>
    ///    Retrieves the index of the character nearest to the specified location.
    /// </summary>
    ///  <returns>
    ///    The zero-based character index at the specified location.
    /// </returns>
    public virtual int GetCharIndexFromPosition(Point pos)
    {
      return TextBoxControl.GetCharIndexFromPosition(pos);
    }

    public int GetFirstCharIndexFromLine(int lineNumber)
    {
      return TextBoxControl.GetFirstCharIndexFromLine(lineNumber);
    }

    public int GetFirstCharIndexOfCurrentLine()
    {
      return TextBoxControl.GetFirstCharIndexOfCurrentLine();
    }

    public virtual int GetLineFromCharIndex(int index)
    {
      return TextBoxControl.GetLineFromCharIndex(index);
    }

    /// <summary>
    ///    Retrieves the location within the control at the specified character index.
    /// </summary>
    public virtual Point GetPositionFromCharIndex(int index)
    {
      return TextBoxControl.GetPositionFromCharIndex(index);
    }

    public void ScrollToCaret()
    {
      TextBoxControl.ScrollToCaret();
    }

    public void Select(int start, int length)
    {
      TextBoxControl.Select(start, length);
    }

    //internal void InternalSelect(int start, int length)
    //{
    //  EhLibUtils.SendMessage(TextBoxControl, NativeMethods.EM_SETSEL, (IntPtr)start, (IntPtr)start + length);
    //  EhLibUtils.SendMessage(TextBoxControl, NativeMethods.EM_SCROLLCARET, IntPtr.Zero, IntPtr.Zero);
    //}

    public void SelectAll()
    {
      TextBoxControl.SelectAll();
    }

    public override string ToString()
    {
      return TextBoxControl.ToString();
    }

    public void Undo()
    {
      TextBoxControl.Undo();
    }

    //public override void HandleInEditControlDownAction(EditItem inEditControl, DownEventArgs e)
    //{
    //  if (inEditControl.DefaultAction || inEditControl.IsDropDown())
    //    InEditButtonDownDefaultAction(inEditControl, e);
    //}

    public override void InEditButtonDownDefaultAction(EditItem inEditControl, DownEventArgs e)
    {
      TextBoxEhManager.DefaultManager.InEditButtonDownDefaultAction(this, inEditControl, e);
    }
    #endregion <public methods

    #region internal methos
    #region internal methos.Paddings
    protected override void OnPaddingChanged(EventArgs e)
    {
      base.OnPaddingChanged(e);
      //RealignControls();
    }
    #endregion internal methos.Paddings

    #region >internal methos.TextBoxControl
    private void TextBoxControl_TextChanged(object sender, EventArgs e)
    {
      this.OnTextChanged(e);

      if (!codeTextChanging)
      {
        codeTextChanging = false;
        UserTextChanged();
      }

      //OnChanged(source, new EventArgs());
    }

    protected internal virtual void UserTextChanged()
    {
      if (AutoCompleting.Active)
      {
        ShowCompletingListBox(Text);
      }
    }

    protected internal virtual void ShowCompletingListBox(string filterText)
    {
      object dataSource;
      string propName;

      //AutoCompleting.DataSourceParams.GetDataSourceInfo(this, "Text", out dataSource, out propName);

      CompletingManager.GetCompletingDataSourceInfo(AutoCompleting, this, "Text", out dataSource, out propName);
      CompletingManager.SetParams(this, dataSource, propName, AutoCompleting.Match, AutoCompleting.DropDownListWidth);
      CompletingManager.SetFilterText(filterText);
    }

    protected virtual void TextBoxControl_KeyDown(object sender, KeyEventArgs e)
    {
      OnKeyDown(e);
    }

    protected virtual void TextBoxControl_KeyUp(object sender, KeyEventArgs e)
    {
      OnKeyUp(e);
    }

    protected virtual void TextBoxControl_KeyPress(object sender, KeyPressEventArgs e)
    {
      OnKeyPress(e);
    }

    private void TextBoxControl_Click(object sender, EventArgs e)
    {
      OnClick(e);
    }

    private void TextBoxControl_DoubleClick(object sender, EventArgs e)
    {
      OnDoubleClick(e);
    }

    private void TextBoxControl_MouseDown(object sender, MouseEventArgs e)
    {
      OnMouseDown(e);
    }

    private void TextBoxControl_MouseUp(object sender, MouseEventArgs e)
    {
      OnMouseUp(e);
    }

    protected virtual void TextBoxControl_GotFocus(object sender, EventArgs e)
    {
      Invalidate(true);
    }

    protected virtual void TextBoxControl_LostFocus(object sender, EventArgs e)
    {
      Invalidate(true);
    }

    protected virtual void TextBoxControl_MouseEnter(object sender, EventArgs e)
    {
      MouseOver = true;
      Invalidate(true);
    }

    protected virtual void TextBoxControl_MouseLeave(object sender, EventArgs e)
    {
      if (this.ClientRectangle.Contains(this.PointToClient(MousePosition)))
      {
        EhLibUtils.DoNothing();
      }
      else
      {
        MouseOver = false;
      }
    }

    //internal void ProcessTextBoxControl_WndProc(ref Message msg, WndProcDelegate baseTextWndProc)
    //{
    //}

    protected internal virtual void TextBoxControl_WndProc(ref Message msg, WndProcDelegate baseTextWndProc)
    {
      //if (handled) return;
      bool handled = false;

      switch (msg.Msg)
      {
        case NativeMethods.WM_PASTE:
          handled = DoCustomPaste();
          break;
        case NativeMethods.WM_CANCELMODE:
          CancelMode();
          break;
      }

      if (!handled)
        baseTextWndProc(ref msg);
    }

    private void CancelMode()
    {
      //;
    }

    protected internal virtual bool TextBoxControl_ProcessCmdKey(ref Message msg, Keys keyData)
    {
      //if (EditItem != null)
      //  return EditItem.ProcessCmdKey(ref msg, keyData);
      //else
      //  return false;
      return false;
    }

    protected virtual bool DoCustomPaste()
    {
      return false;
    }

    internal void IntenalLostFocus(EventArgs e)
    {
      OnLostFocus(e);
      if (!EhLibManager.DefaultEhLibManager.DropDownDebug)
        CompletingManager.HidePopUpListBox();
    }

    internal void IntenalGotFocus(EventArgs e)
    {
      OnGotFocus(e);
    }

    internal bool TextBoxControl_IsInputKey(Keys keyData)
    {
      return IsInputKey(keyData);
    }

    protected internal virtual void OnKeyPressProcessed(KeyPressEventArgs e)
    {
    }

    protected internal virtual void OnKeyDownProcessed(KeyEventArgs e)
    {
    }
    #endregion <internal methos.TextBoxControl

    protected virtual TextBoxBase CreateTextEditControl()
    {
      return new TextEditControl(this);
    }

    protected override Control CreateEditControl()
    {
      TextBoxBase result = CreateTextEditControl();
      result.BorderStyle = BorderStyle.None;
      result.GotFocus += TextBoxControl_GotFocus;
      result.LostFocus += TextBoxControl_LostFocus;
      result.MouseEnter += TextBoxControl_MouseEnter;
      result.MouseLeave += TextBoxControl_MouseLeave;
      result.KeyDown += TextBoxControl_KeyDown;
      result.KeyUp += TextBoxControl_KeyUp;
      result.KeyPress += TextBoxControl_KeyPress;
      result.Click += TextBoxControl_Click;
      result.DoubleClick += TextBoxControl_DoubleClick;
      result.TextChanged += TextBoxControl_TextChanged;
      result.MouseDown += TextBoxControl_MouseDown;
      result.MouseUp += TextBoxControl_MouseUp;

      return result;
    }

    protected override void OnLostFocus(EventArgs e)
    {
      base.OnLostFocus(e);
      //userTextChanged = false;
      //completingManager.HidePopUpListBox();
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
      if (CompletingManager.PopUpListBoxVisible)
      {
        CompletingManager.ProcessKeyDown(e);
        if (e.Handled)
        {
          e.SuppressKeyPress = true;
          return;
        }

        if (e.KeyCode == Keys.Escape)
        {
          CompletingManager.HidePopUpListBox();
          e.SuppressKeyPress = true;
        }
      }

      base.OnKeyDown(e);

      if (!e.Handled)
      {
        switch (e.KeyCode)
        {
          case Keys.F2:
            if (SelectionLength == Text.Length)
              Select(Text.Length, 0);
            else
              SelectAll();
            e.Handled = true;
            break;
        }
      }

      if (!e.Handled && 
          AutoCompleting.Active &&
          (int)AutoCompleting.Shortcut == (int)e.KeyData)
      {
        ShowCompletingListBox("");
      }
    }

    protected override void OnKeyPress(KeyPressEventArgs e)
    {
      base.OnKeyPress(e);
    }

    protected override void OnFontChanged(EventArgs e)
    {
      base.OnFontChanged(e);
      this.AdjustHeight(false);
    }

    protected override void OnHandleCreated(EventArgs e)
    {
      base.OnHandleCreated(e);
      this.AdjustHeight(true);
    }

    protected virtual void DataBindings_CollectionChanged(object sender, CollectionChangeEventArgs e)
    {
      if (e == null) return;

      Binding bindingObj = (e.Element as Binding);

      if (bindingObj != null)
      {
        if (e.Action == CollectionChangeAction.Add)
        {
          if (bindingObj.PropertyName == "Text")
          {
            bindingObj.BindingComplete += BindingObj_BindingComplete;
            UpdateDataForBinding(bindingObj);
          }
        }
        else if (e.Action == CollectionChangeAction.Remove)
        {
          bindingObj.BindingComplete -= BindingObj_BindingComplete;
        }
      }
    }

    private void BindingObj_BindingComplete(object sender, BindingCompleteEventArgs e)
    {
      UpdateDataForBinding(sender as Binding);
    }

    private void UnboundDataBindings()
    {
      foreach (Binding b in DataBindings)
      {
        b.BindingComplete -= BindingObj_BindingComplete;
      }
    }

    protected virtual bool IsUpdateMaxLengthFromBinding()
    {
      return true;
    }

    private void UpdateDataForBinding(Binding binding)
    {
      PropertyDescriptor propDesc;
      PropertyInfo propInfo;
      object colObj;
      DataColumn dCol;

      if (binding == null || binding.BindingManagerBase == null) return;

      propDesc = binding.BindingManagerBase.GetItemProperties().Find(binding.BindingMemberInfo.BindingField, true);
      if (propDesc == null) return;

      propInfo = propDesc.GetType().GetProperty("Column", BindingFlags.NonPublic | BindingFlags.Instance);
      if (propInfo == null) return;

      colObj = propInfo.GetValue(propDesc, null);
      if (colObj == null) return;

      dCol = (colObj as DataColumn);
      if (dCol == null) return;

      if (IsUpdateMaxLengthFromBinding())
        this.MaxLength = dCol.MaxLength;
    }

    protected override bool AutoHeight()
    {
      if (AutoSize && !Multiline)
        return true;
      else
        return false;
    }

    private void UpdateFixedHeight()
    {
      SetStyle(ControlStyles.FixedHeight, AutoHeight());
    }

    private void CompletingManager_ClosedUp(object sender, TextAutoCompletingClosedUpEventArgs e)
    {
      if (e.AcceptValue)
      {
        Text = e.SelectedValue;
        SelectAll();
        if (e.ChangedListWindowWidth > 0)
          AutoCompleting.DropDownListWidth = e.ChangedListWindowWidth;
      }
    }

    private void AutoCompleting_CollectionChanged(object sender, EventArgs e)
    {
      CompletingManager.ResetParams();
    }

    #endregion internal methos

  }

  /// <summary>
  /// Windows text box control. Internal nested class in a BaseTextBoxEh.
  /// </summary>
  [DesignTimeVisible(false)]
  [ToolboxItem(false)]
  public class TextEditControl : TextBox
  {
    internal readonly BaseTextBoxEh TextBox;
    private bool activeControlIsSetting;
    //private bool inMouseDown;
    private bool mouseFocused;

    //private bool userTextChanged;
    //private bool handleCreating;

    public TextEditControl(BaseTextBoxEh textBox)
    {
      TextBox = textBox;
      TabStop = false;
    }

    protected override void OnGotFocus(EventArgs e)
    {
      base.OnGotFocus(e);
      //textBox.ActiveControl = this;
      TextBox.IntenalGotFocus(e);
      ContainerControl parent = TextBox.Parent as ContainerControl;
      if (parent != null && 
          parent.ActiveControl != TextBox &&
          activeControlIsSetting == false)
      {
        activeControlIsSetting = true;
        try
        {
          parent.ActiveControl = TextBox;
        }
        finally
        {
          activeControlIsSetting = false;
        }
      }
    }

    protected override void OnLostFocus(EventArgs e)
    {
      base.OnLostFocus(e);
      TextBox.IntenalLostFocus(e);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
      //if (Focused)
      //  MessageBox.Show("Focuse");
      base.OnMouseDown(e);
    }

    protected override void OnMouseClick(MouseEventArgs e)
    {
      base.OnMouseClick(e);
      if (!mouseFocused  &&
          string.IsNullOrEmpty(Text) &&
          TextBox.AutoCompleting.Active &&
          TextBox.AutoCompleting.ShowListOnClickWhenEmpty
          )
      {
        TextBox.ShowCompletingListBox(Text);
      }
    }

    protected override void WndProc(ref Message m)
    {
      //switch (m.Msg)
      //{
      //  case NativeMethods.WM_REFLECT + NativeMethods.WM_COMMAND:
      //    WmReflectCommand(ref m);
      //    break;
      //}

      switch (m.Msg)
      {
        case NativeMethods.WM_LBUTTONDOWN:
          //inMouseDown = true;
          if (!Focused)
            mouseFocused = true;
          else
            mouseFocused = false;
          break;
      }

      //bool handled = false;
      TextBox.TextBoxControl_WndProc(ref m, base.WndProc);
      //if (!handled)
      //{
      //  base.WndProc(ref m);
      //}

      //if (userTextChanged)
      //{
      //  userTextChanged = false;
      //  UserTextChanged();
      //}

      //if (m.Msg == NativeMethods.WM_LBUTTONDOWN)
      //{
      //  inMouseDown = false;
      //}
    }

    protected override void DefWndProc(ref Message m)
    {
      base.DefWndProc(ref m);

      switch (m.Msg)
      {
        case NativeMethods.WM_CHAR:
          KeyPressEventArgs kpe = new KeyPressEventArgs(unchecked((char)(long)m.WParam));
          OnKeyPressProcessed(kpe);
          break;

        case NativeMethods.WM_KEYDOWN:
          var e = new KeyEventArgs((Keys)(long)m.WParam | Control.ModifierKeys);
          OnKeyDownProcessed(e);
          break;
      }
    }

    //private void WmReflectCommand(ref Message m)
    //{
    //  if (handleCreating) return;

    //  if (NativeMethods.SignedHIWORD(m.WParam) == NativeMethods.EN_CHANGE)
    //  {
    //    userTextChanged = true;
    //  }
    //}

    protected override void CreateHandle()
    {
      base.CreateHandle();

      //handleCreating = true;
      //try
      //{
      //  base.CreateHandle();
      //}
      //finally
      //{
      //  handleCreating = false;
      //}
    }

    protected override void OnHandleCreated(EventArgs e)
    {
      base.OnHandleCreated(e);
    }

    protected virtual void OnKeyPressProcessed(KeyPressEventArgs e)
    {
      TextBox.OnKeyPressProcessed(e);
    }

    private void OnKeyDownProcessed(KeyEventArgs e)
    {
      TextBox.OnKeyDownProcessed(e);
    }

    protected override bool IsInputKey(Keys keyData)
    {
      bool result = TextBox.TextBoxControl_IsInputKey(keyData);
      if (!result)
        result = base.IsInputKey(keyData);
      return result;
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
      bool result = base.ProcessCmdKey(ref msg, keyData);
      if (!result)
        result = TextBox.TextBoxControl_ProcessCmdKey(ref msg, keyData);
      return result;
    }

    private void UserTextChanged()
    {
      TextBox.UserTextChanged();
    }
  }
}
