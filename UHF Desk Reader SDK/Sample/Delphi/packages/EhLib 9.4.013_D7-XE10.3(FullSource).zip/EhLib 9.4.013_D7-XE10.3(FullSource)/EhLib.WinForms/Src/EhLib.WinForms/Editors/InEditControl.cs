﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  public enum UpDownButtonId
  {
    Up,
    Down,
  }

  public enum InEditAlignSide
  {
    Left,
    Right
  }

  public class UpDownEventArgs : EventArgs
  {
    private readonly UpDownButtonId buttonId;

    public UpDownEventArgs(UpDownButtonId buttonPushed)
    {
      buttonId = buttonPushed;
      Handled = false;
    }

    public UpDownButtonId ButtonId
    {
      get
      {
        return buttonId;
      }
    }
    public bool Handled
    { get; set; }
  }

  public class DownEventArgs : EventArgs
  {

    public DownEventArgs(bool autoRepeat, int nextAutoRepeatDelay)
    {
      Handled = false;
      AutoRepeat = autoRepeat;
      NextAutoRepeatDelay = nextAutoRepeatDelay;
    }

    public bool Handled
    { get; set; }

    public bool AutoRepeat
    { get; set; }

    public int NextAutoRepeatDelay
    { get; set; }
  }

  public class ClickEventArgs : EventArgs
  {
    public ClickEventArgs()
    {
      Handled = false;
    }

    public bool Handled
    { get; set; }
  }

  public class EditItemContextPaintEventArgs : EventArgs
  {
    private readonly bool pressed;
    private readonly bool hot;
    private readonly bool disabled;
    private readonly bool inControlBorderMerging;
    //private readonly bool isPaintBackground;
    //private readonly bool isPaintForeground;

    public EditItemContextPaintEventArgs(EditItem editItem, Rectangle clientRect, Color backColor, 
      bool pressed, bool hot, bool disabled, bool drawBackground, bool drawForeground, 
      bool inControlBorderMerging, GraphicsContext graphicsContext,
      Nullable<Point> mousePos, InEditControlMouseDownEventArgs mouseDownEventArgs
    )
    {
      EditItem = editItem;
      ClientRect = clientRect;
      this.pressed = pressed;
      this.hot = hot;
      this.disabled = disabled;
      this.inControlBorderMerging = inControlBorderMerging;
      IsPaintBackground = drawBackground;
      IsPaintForeground = drawForeground;
      MousePos = mousePos;
      MouseDownEventArgs = mouseDownEventArgs;
      GraphicsContext = graphicsContext;
    }

    public EditItem EditItem { get; private set; }

    public GraphicsContext GraphicsContext { get; private set; }

    public Graphics Graphics
    {
      get { return GraphicsContext.Graphics; }
    }

    public Rectangle ClientRect { get; private set; }

    public Nullable<Point> MousePos { get; private set; }

    public InEditControlMouseDownEventArgs MouseDownEventArgs { get; private set; }

    public bool Pressed
    {
      get { return pressed; }
    }

    public bool Hot
    {
      get { return hot; }
    }

    public bool Disabled
    {
      get { return disabled; }
    }

    public Color BackColor { get; set; }

    public bool InControlBorderMerging
    {
      get { return inControlBorderMerging; }
    }

    public bool IsPaintBackground { get; set; }

    public bool IsPaintForeground { get; set; }

    public bool Handled { get; set; }

    public void Paint(EditItemContextPaintEventArgs e)
    {
      e.EditItem.OnPaint(e);
    }

    public void PaintBackground(EditItemContextPaintEventArgs e)
    {
      e.EditItem.OnPaintBackground(e);
    }

    public void PaintForeground(EditItemContextPaintEventArgs e)
    {
      e.EditItem.OnPaintForeground(e);
    }

  }

  public class VisibleStateRequestedEventArgs : EventArgs
  {
    public VisibleStateRequestedEventArgs(bool visible)
    {
      Visible = visible;
    }

    public bool Visible
    { get; set; }
  }

  public class InEditControlMouseDownEventArgs : EventArgs
  {
    public InEditControlMouseDownEventArgs(EditItemControl ec, MouseEventArgs e)
    {
      MouseCaptureBounds = GetMouseCaptureBounds(ec, e.Location);
    }

    protected virtual Rectangle GetMouseCaptureBounds(EditItemControl ec, Point mousePos)
    {
      return new Rectangle(0, 0, ec.Width, ec.Height);
    }

    public Rectangle MouseCaptureBounds { get; internal set; }
    //public bool Handled { get; set; }
    //public bool AutoRepeat { get; set; }
    //public int NextAutoRepeatDelay { get; set; }
  }

  public class InEditControlClickEventArgs : ClickEventArgs
  {
    public InEditControlClickEventArgs()
    {
    }
  }

  //public delegate void EventHandler<UpDownEventArgs>(object sender, UpDownEventArgs e);
  //public delegate void EventHandler<DownEventArgs>(object sender, DownEventArgs e);
  //public delegate void EventHandler<ClickEventArgs>(object sender, ClickEventArgs e);
  //public delegate void EventHandler<VisibleStateRequestedEventArgs>(object sender, VisibleStateRequestedEventArgs e);

  public interface IEditItemOwner
  {
    Font GetDefaultFont();
    void EditItemChanged(EditItem editItem);
    Color DefaultForeColor();
    void EditItemOwnerChanged(IEditItemOwner oldOwner, IEditItemOwner newOwner);
    bool GetDefaultVisibleState(EditItem editItem);
  }

  /// <summary>
  /// Specify component that describes an extra control in a text editor like edit button or updown button
  /// </summary>
  [DesignerCategory("Code")]
  [TypeConverter(typeof(ExpandableObjectConverter))]
  [ToolboxItem(false)]
  [DesignTimeVisible(false)]
  //public class EditItem : Control
  public class EditItem : Component
  //public class EditItem
  {

    #region private consts
    protected const int DefaultTimerInterval = 500;
    #endregion private consts

    #region fields
    private int width = 15;
    bool widthStored;

    private BaseEditBoxEh editControl;
    private EditItemControl inEditWinControl;
    private bool defaultAction = true;

    //private KeyEventHandler onKeyDown;
    //private EventHandler<UpDownEventArgs> upDownEventHandler;
    //private DownEventHandler downEventHandler;
    private bool visibleStored;
    private bool visible;
    private EventHandler editItemChanged;
    //private EventHandler<VisibleStateRequestedEventArgs> defaultVisibleStateRequested;
    private InEditAlignSide alignSide = InEditAlignSide.Right;
    private bool disposed;
    private string toolTipText = "";
    private IEditItemOwner owner;

    #endregion fields

    #region constructor
    public EditItem()
    {
      //this.SetStyle(ControlStyles.Selectable, false);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposed) return;

      if (disposing)
      {
        if (EditControl != null && EditControl.InEditControls.IndexOf(this) >= 0)
        {
          EditControl.InEditControls.Remove(this);
        }
      }

      disposed = true;
      base.Dispose(disposing);
    }
    #endregion constructor

    #region properties
    public int Width
    {
      get
      {
        if (widthStored)
          return width;
        else
          return width;
      }
      set
      {
        if ((widthStored == false) || (value != width))
        {
          widthStored = true;
          width = value;
          WidthChanged();
        }
      }
    }

    [DefaultValue(true)]
    public bool DefaultAction
    {
      get
      {
        return defaultAction;
      }
      set
      {
        defaultAction = value;
      }
    }

    public bool Visible
    {
      get
      {
        if (visibleStored)
          return visible;
        else
          return DefaultVisible();
      }
      set
      {
        if (!visibleStored || value != visible)
        {
          visibleStored = true;
          visible = value;
          NotifyEditItemChanged();
        }
      }
    }

    [DefaultValue(InEditAlignSide.Right)]
    public InEditAlignSide AlignSide
    {
      get
      {
        return alignSide;
      }
      set
      {
        if (value != alignSide)
        {
          alignSide = value;
          NotifyEditItemChanged();
        }
      }
    }

    [DefaultValue(null)]
    public virtual ContextMenuStrip DropDownMenuStrip { get; set; }

    [Bindable(true)]
    [TypeConverter(typeof(StringConverter))]
    [DefaultValue(null)]
    public object Tag { get; set; }

    [DefaultValue("")]
    [Localizable(true)]
    public string ToolTipText
    {
      get
      {
        return toolTipText;
      }
      set
      {
        if (value != toolTipText)
        {
          toolTipText = value;
          ToolTipTextChanged();
        }
      }
    }
    #endregion

    #region run-time properties
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected internal EditItemControl InEditWinControl
    {
      get
      {
        if (inEditWinControl == null)
          inEditWinControl = CreateInEditWinControl();
        return inEditWinControl;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public IEditItemOwner Owner
    {
      get
      {
        return owner;
      }

      internal set
      {
        if (value == owner) return;

        IEditItemOwner oldOwner = owner;
        owner = value;

        if (oldOwner != null)
          oldOwner.EditItemOwnerChanged(oldOwner, owner);
        if (owner != null)
          owner.EditItemOwnerChanged(oldOwner, owner);
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public BaseEditBoxEh EditControl
    {
      get
      {
        return editControl;
      }
      internal set
      {
        if (editControl != value && editControl != null)
          editControl.InEditControls.Remove(this);
        editControl = value;
      }
    }

    [Browsable(false)]
    public virtual bool SupportInControlBorderMerging
    {
      get
      {
        return false;
      }
    }

    [Browsable(false)]
    public virtual int MaxHeight
    {
      get
      {
        return EhLibRenderManager.DefaultEhLibRenderManager.EditBoxEditButtonPainter.GetMaxHeightForWidth(Width);
      }
    }
    #endregion

    #region events
    //public event KeyEventHandler KeyDown
    //{
    //  add { onKeyDown += value; }
    //  remove { onKeyDown -= value; }
    //}

    //public event EventHandler<UpDownEventArgs> UpDown
    //{
    //  add
    //  {
    //    upDownEventHandler += value;
    //  }
    //  remove
    //  {
    //    upDownEventHandler -= value;
    //  }
    //}

    //public event DownEventHandler Down
    //{
    //  add
    //  {
    //    downEventHandler += value;
    //  }
    //  remove
    //  {
    //    downEventHandler -= value;
    //  }
    //}

    //public event EventHandler EditItemChanged
    //{
    //  add
    //  {
    //    editItemChanged += value;
    //  }

    //  remove
    //  {
    //    editItemChanged -= value;
    //  }
    //}

    //public event EventHandler<VisibleStateRequestedEventArgs> DefaultVisibleStateRequested
    //{
    //  add
    //  {
    //    defaultVisibleStateRequested += value;
    //  }

    //  remove
    //  {
    //    defaultVisibleStateRequested -= value;
    //  }
    //}
    #endregion  

    #region public methods
    public virtual bool IntegratedInBorder()
    {
      return false;
    }

    public virtual void ResetWidth()
    {
      if (widthStored)
      {
        widthStored = false;
        WidthChanged();
      }
    }

    public virtual int DefaultWidth()
    {
      return SystemInformation.VerticalScrollBarWidth;
    }

    public virtual void DefaultHandleDownAction(DownEventArgs e)
    {
      if (e.Handled) return;
      if (DefaultAction)
        EditControl.HandleInEditControlDownAction(this, e);
    }

    public virtual void DefaultHandleClickAction(InEditControlClickEventArgs e)
    {
      if (e.Handled) return;
      if (DefaultAction)
        EditControl.HandleInEditControlClickAction(this, e);
    }

    public virtual bool IsDropDown()
    {
      return false;
    }
    #endregion public methods

    #region intenal methods
    //protected void RemoveOwner()
    //{
    //  Owner = null;
    //}

    //protected void SetOwner(IEditItemOwner owner)
    //{
    //  if (Owner == owner) return;

    //  if (Owner != null)
    //  {
    //    IEditItemOwner oldOwner = Owner;
    //    owner = null;
    //    oldOwner.EditItemOwnerChanged(oldOwner, owner);
    //  }

    //  this.owner = owner;
    //}

    protected virtual void ToolTipTextChanged()
    {
    }

    protected virtual EditItemControl CreateInEditWinControl()
    {
      return new EditItemControl(this);
    }

    protected void NotifyEditItemChanged()
    {
      if (editItemChanged != null)
        editItemChanged(this, EventArgs.Empty);

      if (editControl != null)
        editControl.InEditControlChanged(this);

      if (Owner != null && Owner != editControl)
        Owner.EditItemChanged(this);
    }

    protected void WidthChanged()
    {
      NotifyEditItemChanged();
    }

    protected virtual bool ShouldSerializeWidth()
    {
      return (widthStored == true);
    }

    //protected internal virtual void OnUpDown(UpDownEventArgs e)
    //{
    //  if (upDownEventHandler != null)
    //    upDownEventHandler(this, e);
    //  if (!e.Handled)
    //    EditControl.OnProcessInEditUpDownButton(e);
    //}

    protected internal virtual void ProcessDown(DownEventArgs e)
    {
      HandleDownEvent(e);
      if (!e.Handled)
        OnDown(e);
    }

    protected virtual void HandleDownEvent(DownEventArgs e)
    {
    }

    protected virtual void OnDown(DownEventArgs e)
    {
      DefaultHandleDownAction(e);
    }

    public virtual InEditControlClickEventArgs CreateInEditControlClickEventArgs(MouseEventArgs mouseEventArgs, Rectangle inEditControlBounds)
    {
      return new InEditControlClickEventArgs();
    }

    protected internal virtual void ProcessClick(InEditControlClickEventArgs e)
    {
      HandleClickEvent(e);
      if (!e.Handled)
        OnClick(e);
    }

    protected virtual void HandleClickEvent(InEditControlClickEventArgs e)
    {
    }

    protected virtual void OnClick(InEditControlClickEventArgs e)
    {
      DefaultHandleClickAction(e);
    }

    protected internal virtual bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
      return false;
    }

    protected virtual bool DefaultVisible()
    {
      //if (defaultVisibleStateRequested != null)
      //{
      //  VisibleStateRequestedEventArgs e = new VisibleStateRequestedEventArgs(true);
      //  defaultVisibleStateRequested(this, e);
      //  return e.Visible;
      //}
      //else if (editControl != null)
      //{
      //  return editControl.IsInEditControlDefaultVisible(this);
      //}
      //else
      //  return true;
      if (Owner != null)
        return Owner.GetDefaultVisibleState(this);
      else
        return true;
    }

    protected bool ShouldSerializeVisible()
    {
      return (visibleStored == true);
    }

    protected void ResetVisible()
    {
      if (visibleStored)
      {
        visibleStored = false;
        NotifyEditItemChanged();
      }
    }

    protected internal virtual EditItemContextPaintEventArgs CreatePaintEventArgs(Rectangle clientRect,
      GraphicsContext graphicsContext, Color backColor, bool pressed, bool hot, bool disabled, 
      Nullable<Point> mousePos, InEditControlMouseDownEventArgs mouseDownEventArgs)
    {
      return new EditItemContextPaintEventArgs(this, clientRect, backColor, pressed, hot, disabled,
        true, true, false, graphicsContext, mousePos, mouseDownEventArgs);
    }

    protected internal virtual void ProcessPaint(EditItemContextPaintEventArgs e)
    {
      HandlePaintEvent(e);
      if (!e.Handled)
        OnPaint(e);
    }

    protected virtual void HandlePaintEvent(EditItemContextPaintEventArgs e)
    {

    }

    protected internal virtual void OnPaint(EditItemContextPaintEventArgs e)
    {
      if (e.IsPaintBackground)
        OnPaintBackground(e);
      if (e.IsPaintForeground)
        OnPaintForeground(e);
    }

    protected internal virtual void OnPaintBackground(EditItemContextPaintEventArgs e)
    {
      using (var pen = new Pen(Color.Red))
      {
        e.Graphics.DrawRectangle(pen, e.ClientRect);
      }
    }

    protected internal virtual void OnPaintForeground(EditItemContextPaintEventArgs e)
    {
      using (var pen = new Pen(Color.Red))
      {
        e.Graphics.DrawRectangle(pen, e.ClientRect);
      }
    }

    public virtual DownEventArgs CreateDownEventArgs(InEditControlMouseDownEventArgs mouseDownEventArgs)
    {
      return new DownEventArgs(false, DefaultTimerInterval);
    }
    #endregion intenal methods
  }

  [DesignTimeVisible(false)]
  [ToolboxItem(false)]
  public class EditItemControl : Control
  {
    private readonly EditItem editItem;
    private Timer timer;
    private int timerInterval;
    private MouseHoverToolTip textToolTip;

    #region constructor
    public EditItemControl(EditItem editItem)
    {
      this.editItem = editItem;
      SetStyle(ControlStyles.Selectable, false);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        StopTimer();

        if (textToolTip != null)
        {
          textToolTip.Dispose();
          textToolTip = null;
        }
      }

      base.Dispose(disposing);
    }
    #endregion

    #region properties
    public InEditControlMouseDownEventArgs MouseDownEventArgs { get; set; }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool MouseDownState { get; internal set; }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool MouseOver { get; internal set; }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool MouseIsInCaptureBounds { get; internal set; }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public Nullable<Point> MousePos { get; internal set; }

    protected internal EditItem EditItem
    {
      get { return editItem; }
    }

    protected internal MouseHoverToolTip TextToolTip
    {
      get
      {
        if (textToolTip == null)
          textToolTip = new MouseHoverToolTip();
        return textToolTip;
      }
    }

    protected internal bool InControlBorderMerging
    { get; set; }
    #endregion

    #region methods
    protected override void OnPaint(PaintEventArgs e)
    {
      bool pressed = MouseDownEventArgs != null && MouseIsInCaptureBounds;
      bool hot = MouseOver;
      bool disabled = !Enabled;

      GraphicsContext gc = new DisplayGraphicsContext(e.Graphics, e.ClipRectangle);

      EditItemContextPaintEventArgs eiArg = EditItem.CreatePaintEventArgs(
        ClientRectangle, gc, BackColor, pressed, hot, disabled, MousePos, MouseDownEventArgs);
      EditItem.ProcessPaint(eiArg);
      //ButtonRenderer.DrawButton(e.Graphics, btnRect, PushButtonState.Normal);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
      EditItem.EditControl.Focus();

      if (e.Button == MouseButtons.Left)
      {
        Capture = true;
        MouseDownEventArgs = CreateInEditControlMouseDownEventArgs(e);
        MouseDownState = true;
        MouseIsInCaptureBounds = IsMouseInCaptureBounds(MouseDownEventArgs.MouseCaptureBounds, e.Location);

        DownEventArgs dea = EditItem.CreateDownEventArgs(MouseDownEventArgs);
        EditItem.ProcessDown(dea);
        Invalidate();
        if (dea.AutoRepeat)
          StartTimer(dea.NextAutoRepeatDelay);
      }
      else
      {
        MouseDownEventArgs = null;
      }

      //base.OnMouseDown(parent.TranslateMouseEvent(this, e));
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
      Rectangle bounds = ClientRectangle;
      MousePos = e.Location;

      base.OnMouseMove(e);

      if (Capture)
      {
        bool mouseIsInCaptureBounds = false;

        if (MouseDownEventArgs != null)
        {
          mouseIsInCaptureBounds = IsMouseInCaptureBounds(MouseDownEventArgs.MouseCaptureBounds, e.Location);
        }

        if (mouseIsInCaptureBounds != MouseIsInCaptureBounds)
        {
          MouseIsInCaptureBounds = mouseIsInCaptureBounds;
          Invalidate();
          if (timer != null)
          {
            if (!MouseIsInCaptureBounds)
              timer.Enabled = false;
            else
              timer.Enabled = true;
          }
        }
      }

      if (bounds.Contains(e.X, e.Y) && !MouseOver)
      {
        MouseOver = true;
        Invalidate();
      }
      else if (!bounds.Contains(e.X, e.Y) && MouseOver)
      {
        MouseOver = false;
        Invalidate();
      }
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
      base.OnMouseUp(e);
      if (e.Button == MouseButtons.Left)
      {
        MouseDownEventArgs = null;
        MouseIsInCaptureBounds = false;
        Capture = false;
        Invalidate();
      }
    }

    protected override void OnMouseClick(MouseEventArgs e)
    {
      base.OnMouseClick(e);

      InEditControlClickEventArgs dea = EditItem.CreateInEditControlClickEventArgs(e, ClientRectangle);
      EditItem.ProcessClick(dea);
    }

    protected override void OnMouseCaptureChanged(EventArgs e)
    {
      base.OnMouseCaptureChanged(e);
      MouseDownEventArgs = null;
      MouseIsInCaptureBounds = false;
      StopTimer();
    }

    protected virtual bool IsMouseInCaptureBounds(Rectangle mouseCaptureBounds, Point mousePos)
    {
      return mouseCaptureBounds.Contains(mousePos);
    }

    protected override void OnMouseEnter(EventArgs e)
    {
      base.OnMouseEnter(e);
      if (!Capture)
        MouseOver = true;
      if (!DesignMode && !string.IsNullOrEmpty(EditItem.ToolTipText))
        TextToolTip.Show(EditItem.ToolTipText, this, null, -1, 3000);
      Invalidate();
    }

    protected override void OnMouseLeave(EventArgs e)
    {
      base.OnMouseLeave(e);
      if (!Capture)
        MouseOver = false;
      MousePos = null;
      if (textToolTip != null)
        textToolTip.Hide(this);
      Invalidate();
    }

    protected virtual InEditControlMouseDownEventArgs CreateInEditControlMouseDownEventArgs(MouseEventArgs mouseEventArgs)
    {
      return new InEditControlMouseDownEventArgs(this, mouseEventArgs);
    }

    private void StartTimer(int eNextAutoRepeatDelay)
    {
      if (timer == null)
      {
        timer = new Timer();
        timer.Tick += TimerHandler;
      }

      timerInterval = eNextAutoRepeatDelay;

      timer.Interval = timerInterval;
      timer.Start();
    }

    protected void StopTimer()
    {
      if (timer != null)
      {
        timer.Stop();
        timer.Tick -= TimerHandler;
        timer.Dispose();
        timer = null;
      }
      //parent.OnStopTimer();
    }

    protected virtual void TimerHandler(object source, EventArgs args)
    {

      //if (!Capture)
      //{
      //  StopTimer();
      //  return;
      //}

      DownEventArgs dea = EditItem.CreateDownEventArgs(MouseDownEventArgs);

      // Accelerate timer.
      timerInterval = timerInterval * 7;
      timerInterval = timerInterval / 10;
      if (timerInterval < 1)
        timerInterval = 1;

      dea.NextAutoRepeatDelay = timerInterval;
      EditItem.ProcessDown(dea);
      Invalidate();
      if (dea.AutoRepeat)
      {
        timer.Interval = dea.NextAutoRepeatDelay;
      }
      else
      {
        StopTimer();
      }

      //OnUpDown(new UpDownEventArgs(InternalUpDownButtonIdToUpDownButtonId(pushed)));
    }

    #endregion

  }

  [ListBindable(false)]
  public class EditItemControlsCollection : ObservableCollection<EditItem>
  {
    public EditItemControlsCollection()
    {
    }
  }
}
