﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  /// <summary>
  ///  Component to keep a list of data cell managers to display data in cells of 
  ///  DataGridEh, DataVertGridEh or/and DataPropertyGridEh controls.
  /// </summary>
  /// <remarks>
  /// CellManagersList is usually used on forms in which DataGridEh and DataPropertyGridEh are located 
  /// simultaneously, while both are connected to the same data source and display the same fields from 
  /// the source. 
  /// In this case, it is convenient to create a single set of DataCellManager components that correspond 
  /// to the fields of the data source and connect them to the DataGridEh columns and DataPropertyGridEh 
  /// rows. 
  /// Without CellManagersList, you would have to create and set up the similar capabilities for cells 
  /// in a DataGridEh and in a DataPropertyGridEh separately in each grid.
  /// </remarks>
  [DesignerCategory("Code")]
  [ToolboxItem(true)]
  [Designer("EhLib.WinForms.Design.CellManagersListDesigner, EhLib.WinForms.Design")]
  public class CellManagersList : Component
  {
    private readonly CellManagersListItems cellManagers;

    public CellManagersList()
    {
      cellManagers = new CellManagersListItems(this);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        foreach(var cm in CellManagers)
        {
          cm.Dispose();
        }
        cellManagers.Clear();
      }

      base.Dispose(disposing);
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    [Editor("EhLib.WinForms.Design.DataGridDynaColumnCellsEditor" + EhLibUtils.EhLibDesignDesignerVersionInfo, "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    public CellManagersListItems CellManagers
    {
      get
      {
        return cellManagers;
      }
    }

    public BaseGridCellManager[] CreateCellManagersFromDataSource(object dataSource)
    {
      IList list = dataSource as IList;
      List<BaseGridCellManager> cellList = new List<BaseGridCellManager>();

      foreach (var li in list)
      {
        BaseGridCellManager cm = CellManagersListItemsManager.DefaultManager.GetCellManagerForType(li.GetType());
      }

      return CellManagers.ToArray();
    }
  }

  /// <summary>
  ///  Collection of BaseGridCellManager. The class is used in a CellManagersList component.
  /// </summary>
  [ListBindable(false)]
  public class CellManagersListItems : Collection<BaseGridCellManager>
  {
    private readonly CellManagersList manList;

    public CellManagersListItems(CellManagersList manList)
    {
      this.manList = manList;
    }

    public new void Add(BaseGridCellManager item)
    {
      base.Add(item);
      //item.BoundGrid = grid;
    }
  }

  /// <summary>
  ///  Global class for CellManagersList component that is used to control default types of 
  ///  DataCellManager components when they is created automatically for DataProperty of DataSource.
  /// </summary>
  public class CellManagersListItemsManager : object
  {
    #region >static fields
    private static CellManagersListItemsManager _defaultManager;
    #endregion <static fields

    #region >constructor
    public CellManagersListItemsManager()
    {
    }
    #endregion <constructor

    #region <static properties
    public static CellManagersListItemsManager DefaultManager
    {
      get
      {
        if (_defaultManager == null)
          _defaultManager = new CellManagersListItemsManager();
        return _defaultManager;
      }
      set
      {
        _defaultManager = value;
      }
    }
    #endregion

    #region <methods
    public virtual BaseGridCellManager GetCellManagerForType(Type type)
    {
      Type colType = GetCellManagerTypeForDataType(type);
      if (colType != null)
        return (BaseGridCellManager)Activator.CreateInstance(colType);
      else
        return null;
    }

    public virtual Type GetCellManagerTypeForDataType(Type type)
    {
      Type colType;

      TypeConverter imageTypeConverter = TypeDescriptor.GetConverter(typeof(Image));
      if (type == typeof(bool) || type == typeof(CheckState))
      {
        colType = typeof(CheckBoxDataCellManager);
      }
      else if (typeof(System.Drawing.Image).IsAssignableFrom(type) || imageTypeConverter.CanConvertFrom(type))
      {
        colType = typeof(ImageDataCellManager);
      }
      else if (typeof(IList).IsAssignableFrom(type))
      {
        colType = null;
      }
      else if (typeof(DateTime).IsAssignableFrom(type))
      {
        colType = typeof(DateTimeDataCellManager);
      }
      else
      {
        colType = typeof(TextDataCellManager);
      }
      return colType;
    }
    #endregion <methods
  }
}
