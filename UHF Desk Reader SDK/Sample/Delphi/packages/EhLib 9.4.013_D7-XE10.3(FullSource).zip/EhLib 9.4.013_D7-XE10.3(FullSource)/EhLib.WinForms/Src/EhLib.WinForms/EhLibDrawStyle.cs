﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using EhLib.WinForms.Windows.Forms.VisualStyles;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  public class BaseGridFillFixedCellEventArgs : EventArgs
  {

    public BaseGridFillFixedCellEventArgs()
    {
    }

    public Rectangle CellRect { get; set; }
    public Graphics Graphics { get; set; }
    public bool IsHot { get; set; }
    public bool IsPressed { get; set; }
    public bool IsSelected { get; set; }
    public Color BackColor { get; set; }
    public CellFillStyle FillStyle { get; set; }
    public CellInnerBorderStyle InnerBorder { get; set; }
    public Color FillColor { get; set; }
    public Color SecondFillColor { get; set; }
  }

  public class SortMarkerPaintEventArgs : EventArgs
  {

    public SortMarkerPaintEventArgs()
    {
    }

    public Graphics Graphics { get; set; }
    public Rectangle MarkerAreaRect { get; set; }
    public Color ControlBackColor { get; set; }
    public Color ControlForeColor { get; set; }
    public SortMarkerStyle SortMarkerStyle { get; set; }
    public SortOrder SortOrder { get; set; }
    public int SortIndex { get; set; }
    public Color SortMarkerColor { get; set; }

  }

  public class InTitleFilterButtonMetrics
  {
    //public Size Size { get; set; }
    public Rectangle ButtonRect { get; set; }
    public Padding Margin { get; set; }
  }

  public class InTitleFilterButtonArgs
  {
    private readonly Graphics graphics;
    private readonly Rectangle rect;
    private readonly PushButtonState state;
    private readonly bool filterHaveData;
    private readonly bool paintBack;

    public InTitleFilterButtonArgs(Graphics graphics, Rectangle rect, PushButtonState state, bool filterHaveData, bool paintBack)
    {
      this.graphics = graphics;
      this.rect = rect;
      this.state = state;
      this.filterHaveData = filterHaveData;
      this.paintBack = paintBack;
    }

    public Graphics Graphics
    {
      get { return graphics; }
    }

    public Rectangle Rect
    {
      get { return rect; }
    }

    public PushButtonState State
    {
      get { return state; }
    }

    public bool FilterHaveData
    {
      get { return filterHaveData; }
    }

    public bool PaintBack
    {
      get { return paintBack; }
    }
  }

  public enum PushButtonBorderStyle
  { Thin, Thick };

  public class PushButtonBackDrawArgs
  {
    private readonly Graphics graphics;
    private readonly Rectangle rect;
    private readonly PushButtonState state;
    private readonly bool parentHasFrame;
    private readonly PushButtonBorderStyle borderStyle;

    public PushButtonBackDrawArgs(Graphics graphics, Rectangle rect, PushButtonState state, bool parentHasFrame, PushButtonBorderStyle borderStyle)
    {
      this.graphics = graphics;
      this.rect = rect;
      this.state = state;
      this.parentHasFrame = parentHasFrame;
      this.borderStyle = borderStyle;
    }

    public Graphics Graphics
    {
      get { return graphics; }
    }

    public Rectangle Rect
    {
      get { return rect; }
    }

    public PushButtonState State
    {
      get { return state; }
    }

    public bool ParentHasFrame
    {
      get { return parentHasFrame; }
    }

    public PushButtonBorderStyle BorderStyle
    {
      get { return borderStyle; }
    }
  }

  public class EhLibRenderManager
  {
    #region privates
    private static EhLibRenderManager _defaultEhLibRenderManager;

    private DataGridDrawStyle defDataGridDrawStyle;
    private BaseGridDrawStyle defBaseGridDrawStyle;
    private TextBoxDrawStyle defTextBoxDrawStyle;
    private ToolElementsDrawStyle defToolElementsDrawStyle;
    private ProgressBarRenderer defProgressBarRenderer;
    private DataVertGridDrawStyle defDataVertGridDrawStyle;
    private BaseElementsDrawStyle defBaseElementsDrawStyle;
    private EditBoxEditButtonPainter editBoxEditButtonPainter;
    private EhLibCheckBoxRenderer defCheckBoxRenderer;
    private EhLibRadioButtonRenderer defRadioButtonRenderer;
    private EhLibPushButtonRenderer defPushButtonRenderer;
    #endregion

    public EhLibRenderManager()
    {
    }

    #region properties
    public static EhLibRenderManager DefaultEhLibRenderManager
    {
      get
      {
        if (_defaultEhLibRenderManager == null)
        {
          _defaultEhLibRenderManager = new EhLibRenderManager();
          AppDomain.CurrentDomain.DomainUnload += OnDomainUnload;
          AppDomain.CurrentDomain.ProcessExit += OnProcessExit;
        }
        return _defaultEhLibRenderManager;
      }
      set
      {
        _defaultEhLibRenderManager = value;
      }
    }

    public DataGridDrawStyle DataGridDrawStyle
    {
      get
      {
        if (defDataGridDrawStyle == null)
          defDataGridDrawStyle = CreateDataGridDrawStyle();
        return defDataGridDrawStyle;
      }
      set
      {
        defDataGridDrawStyle = value;
      }
    }

    public DataVertGridDrawStyle DataVertGridDrawStyle
    {
      get
      {
        if (defDataVertGridDrawStyle == null)
          defDataVertGridDrawStyle = CreateDataVertGridDrawStyle();
        return defDataVertGridDrawStyle;
      }
      set
      {
        defDataVertGridDrawStyle = value;
      }
    }

    public BaseGridDrawStyle BaseGridDrawStyle
    {
      get
      {
        if (defBaseGridDrawStyle == null)
          defBaseGridDrawStyle = CreateBaseGridDrawStyle();
        return defBaseGridDrawStyle;
      }
      set
      {
        defBaseGridDrawStyle = value;
      }
    }

    public TextBoxDrawStyle TextBoxDrawStyle
    {
      get
      {
        if (defTextBoxDrawStyle == null)
          defTextBoxDrawStyle = CreateTextBoxDrawStyle();
        return defTextBoxDrawStyle;
      }
      set
      {
        defTextBoxDrawStyle = value;
      }
    }

    public ToolElementsDrawStyle ToolElementsDrawStyle
    {
      get
      {
        if (defToolElementsDrawStyle == null)
          defToolElementsDrawStyle = CreateToolElementsDrawStyle();
        return defToolElementsDrawStyle;
      }
      set
      {
        defToolElementsDrawStyle = value;
      }
    }

    public ProgressBarRenderer ProgressBarRenderer
    {
      get
      {
        if (defProgressBarRenderer == null)
          defProgressBarRenderer = CreateProgressBarRenderer();
        return defProgressBarRenderer;
      }
      set
      {
        defProgressBarRenderer = value;
      }
    }

    /// <summary>
    /// CheckBoxRenderer
    /// </summary>
    public EhLibCheckBoxRenderer CheckBoxRenderer
    {
      get
      {
        if (defCheckBoxRenderer == null)
          defCheckBoxRenderer = CreateCheckBoxRenderer();
        return defCheckBoxRenderer;
      }
      set
      {
        defCheckBoxRenderer = value;
      }
    }

    public EhLibRadioButtonRenderer RadioButtonRenderer
    {
      get
      {
        if (defRadioButtonRenderer == null)
          defRadioButtonRenderer = CreateRadioButtonRenderer();
        return defRadioButtonRenderer;
      }
      set
      {
        defRadioButtonRenderer = value;
      }
    }

    public EhLibPushButtonRenderer PushButtonRenderer
    {
      get
      {
        if (defPushButtonRenderer == null)
          defPushButtonRenderer = CreatePushButtonRenderer();
        return defPushButtonRenderer;
      }
      set
      {
        defPushButtonRenderer = value;
      }
    }

    public BaseElementsDrawStyle BaseElementsDrawStyle
    {
      get
      {
        if (defBaseElementsDrawStyle == null)
          defBaseElementsDrawStyle = CreateBaseElementsDrawStyle();
        return defBaseElementsDrawStyle;
      }
      set
      {
        defBaseElementsDrawStyle = value;
      }
    }

    public EditBoxEditButtonPainter EditBoxEditButtonPainter
    {
      get
      {
        if (editBoxEditButtonPainter == null)
          editBoxEditButtonPainter = CreateEditBoxEditButtonPainter();
        return editBoxEditButtonPainter;
      }
      set
      {
        editBoxEditButtonPainter = value;
      }
    }

    #endregion

    #region methods
    private static void OnDomainUnload(object sender, EventArgs e)
    {
      //this.RevokeComponent();
      //ExitDomain();
    }

    private static void OnProcessExit(object sender, EventArgs e)
    {
      //this.RevokeComponent();
      //ExitDomain();
    }

    protected virtual DataGridDrawStyle CreateDataGridDrawStyle()
    {
      return new DataGridDrawStyle();
    }
    protected virtual DataVertGridDrawStyle CreateDataVertGridDrawStyle()
    {
      return new DataVertGridDrawStyle();
    }

    protected virtual BaseGridDrawStyle CreateBaseGridDrawStyle()
    {
      return new BaseGridDrawStyle();
    }

    protected virtual TextBoxDrawStyle CreateTextBoxDrawStyle()
    {
      return new TextBoxDrawStyle();
    }

    protected virtual ToolElementsDrawStyle CreateToolElementsDrawStyle()
    {
      return new ToolElementsDrawStyle();
    }

    protected virtual ProgressBarRenderer CreateProgressBarRenderer()
    {
      return new ProgressBarRenderer();
    }

    protected virtual BaseElementsDrawStyle CreateBaseElementsDrawStyle()
    {
      return new BaseElementsDrawStyle();
    }

    protected virtual EditBoxEditButtonPainter CreateEditBoxEditButtonPainter()
    {
      return new EditBoxEditButtonPainter();
    }

    protected virtual EhLibCheckBoxRenderer CreateCheckBoxRenderer()
    {
      return new EhLibCheckBoxRenderer();
    }

    protected virtual EhLibRadioButtonRenderer CreateRadioButtonRenderer()
    {
      return new EhLibRadioButtonRenderer();
    }

    protected virtual EhLibPushButtonRenderer CreatePushButtonRenderer()
    {
      return new EhLibPushButtonRenderer();
    }
    #endregion
  }

  public class BaseElementsDrawStyle
  {
    public virtual void DrawCheckBox(Graphics g, Point location, CheckBoxState state, bool flat, bool tryUseVisualStyles)
    {
      if ((!flat) ||
          (tryUseVisualStyles && Application.RenderWithVisualStyles))
      {
        CheckBoxRenderer.DrawCheckBox(g, location, state);
      }
      else
      {
        Size chbSize = CheckBoxRenderer.GetGlyphSize(g, state);
        Rectangle fullRect = new Rectangle(location, chbSize);
        Rectangle chbRect = fullRect;
        chbRect.Inflate(-2, -2);

        Region oldClip = g.Clip;
        g.SetClip(chbRect, CombineMode.Intersect);

        CheckBoxRenderer.DrawCheckBox(g, location, state);

        if (oldClip != null)
          g.Clip = oldClip;

        chbRect = EhLibUtils.ChangeRectangle(chbRect, -1, -1, 1, 1);
        g.DrawRectangle(SystemPens.ControlDark, chbRect);
        //ControlPaint.DrawVisualStyleBorder(g, chbRect);
      }
    }
  }

  public class DataGridDrawStyle : BaseGridDrawStyle, IDisposable
  {
    #region privates
    Font sortMarkerFont;
    Cursor downArrowSelectCursor;
    Cursor rightArrowSelectCursor;
    Cursor leftArrowSelectCursor;
    readonly Padding columnOptionsSidePadding = new Padding(3, 2, 3, 2);
    private bool disposed;
    private TreeNodeStateRenderer treeNodeStateRenderer;
    #endregion

    public DataGridDrawStyle()
    {
    }

    ~DataGridDrawStyle()
    {
      Dispose(false);
    }

    public void Dispose()
    {
      Dispose(true);
      GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
      if (disposed)
        return;
      if (disposing)
      {
        if (sortMarkerFont != null) sortMarkerFont.Dispose();
        if (downArrowSelectCursor != null) downArrowSelectCursor.Dispose();
        if (rightArrowSelectCursor != null) rightArrowSelectCursor.Dispose();
        if (leftArrowSelectCursor != null) leftArrowSelectCursor.Dispose();
      }
      disposed = true;
    }

    #region properties
    public TreeNodeStateRenderer TreeNodeStateRenderer
    {
      get
      {
        if (treeNodeStateRenderer == null)
          treeNodeStateRenderer = CreateDefaultTreeNodeStateRenderer();
        return treeNodeStateRenderer;
      }
      set
      {
        treeNodeStateRenderer = value;
      }
    }

    public Font SortMarkerFont
    {
      get
      {
        if (sortMarkerFont == null)
          sortMarkerFont = new Font("Arial", 6F, FontStyle.Regular, GraphicsUnit.Point, 204);
        return sortMarkerFont;
      }
    }
    #endregion

    #region methods
    protected virtual TreeNodeStateRenderer CreateDefaultTreeNodeStateRenderer()
    {
      //return new StandardTreeNodeStateRenderer();
      //return new FlatTriangleTreeNodeStateRenderer();
      return new ExplorerStyleTreeNodeStateRenderer();
    }

    public virtual bool FixFillFixedCellRect(DataGridEh dataGrid, BaseGridFillFixedCellEventArgs e, ref Rectangle fillRect)
    {
      if (Application.RenderWithVisualStyles)
      {
        fillRect.Width = fillRect.Width + 2;
        fillRect.Height = fillRect.Height + 2;
        return true;
      }
      else
      {
        return false;
      }
    }

    public virtual void FillIndicatorCell(DataGridEh dataGrid, BaseGridFillFixedCellEventArgs e)
    {
      FillFixedCell(dataGrid, e);
    }

    public virtual void FillTopIndicatorCell(DataGridEh dataGrid, BaseGridFillFixedCellEventArgs e)
    {
      FillFixedCell(dataGrid, e);
    }

    public virtual void FillTitleCell(DataGridEh dataGrid, BaseGridFillFixedCellEventArgs e)
    {
      FillFixedCell(dataGrid, e);
    }

    public virtual void FillFixedCell(DataGridEh dataGrid, BaseGridFillFixedCellEventArgs e)
    {
      base.FillFixedCell(dataGrid, e);
    }

    public virtual Size GetSortMarkerSize(SortMarkerStyle sortMarkerStyle)
    {
      if (sortMarkerStyle == SortMarkerStyle.Default)
        sortMarkerStyle = GetDefaultSortMarkerStyle();
      if (sortMarkerStyle == SortMarkerStyle.Themed && !Application.RenderWithVisualStyles)
        sortMarkerStyle = SortMarkerStyle.Solid;
      switch (sortMarkerStyle)
      {
        case SortMarkerStyle.Framed:
          {
            return new Size(7, 8);
          }
        case SortMarkerStyle.Solid:
          {
            return new Size(9, 5);
          }
        case SortMarkerStyle.Themed:
          {
            VisualStyleElement element = VisualStyleElement.Header.SortArrow.SortedUp;
            VisualStyleRenderer render = new VisualStyleRenderer(element);
            Size sz = render.GetPartSize(EhLibUtils.DisplayGraphicsCash, ThemeSizeType.Draw);
            return sz;
          }
      }
      return new Size(0, 0);
    }

    public virtual SortMarkerStyle GetDefaultSortMarkerStyle()
    {
      if (Application.RenderWithVisualStyles)
        return SortMarkerStyle.Themed;
      else
        return SortMarkerStyle.Framed;
    }

    public virtual Size GetSortMarkerAreaSize(SortMarkerStyle sortMarkerStyle)
    {
      Size result = GetSortMarkerSize(sortMarkerStyle);
      Size textSize = EhLibUtils.DisplayGraphicsCash.MeasureString("0", SortMarkerFont).ToSize();
      result.Width = result.Width + textSize.Width;
      if (textSize.Height > result.Height)
        result.Height = textSize.Height;
      return result;
    }

    public virtual void DrawSortMarkerArea(SortMarkerPaintEventArgs e)
    {
      Size sz = GetSortMarkerSize(e.SortMarkerStyle);
      Rectangle elemRect = e.MarkerAreaRect;

      elemRect.Width = sz.Width;

      DrawSortMarker(ref elemRect, e);

      if (e.SortIndex >= 1)
      {
        elemRect.X = elemRect.X + elemRect.Width;
        elemRect.Width = e.MarkerAreaRect.Width - elemRect.Width;
        DrawSortIndex(ref elemRect, e);
      }
    }

    public virtual void DrawSortMarker(ref Rectangle sortMarkerRect, SortMarkerPaintEventArgs e)
    {

      SortMarkerStyle sortMarkerStyle = e.SortMarkerStyle;
      if (sortMarkerStyle == SortMarkerStyle.Default)
        sortMarkerStyle = GetDefaultSortMarkerStyle();

      switch (sortMarkerStyle)
      {
        case SortMarkerStyle.Framed:
          {
            DrawFramedSortMarker(ref sortMarkerRect, e);
            return;
          }
        case SortMarkerStyle.Solid:
          {
            DrawSolidSortMarker(ref sortMarkerRect, e);
            return;
          }
        case SortMarkerStyle.Themed:
          {
            DrawThemedSortMarker(ref sortMarkerRect, e);
            return;
          }
      }
    }

    public virtual void DrawThemedSortMarker(ref Rectangle sortMarkerRect, SortMarkerPaintEventArgs e)
    {
      if (Application.RenderWithVisualStyles)
      {
        VisualStyleElement element;
        VisualStyleRenderer render;

        if (e.SortOrder == SortOrder.Ascending)
          element = VisualStyleElement.Header.SortArrow.SortedUp;
        else
          element = VisualStyleElement.Header.SortArrow.SortedDown;
        render = new VisualStyleRenderer(element);

        render.DrawBackground(e.Graphics, sortMarkerRect);
      }
      else
      {
        DrawSolidSortMarker(ref sortMarkerRect, e);
      }
    }

    public virtual void DrawSolidSortMarker(ref Rectangle sortMarkerRect, SortMarkerPaintEventArgs e)
    {
      Rectangle smRect = new Rectangle();

      smRect.Size = GetSortMarkerSize(e.SortMarkerStyle);
      smRect = EhLibUtils.RectCenter(smRect, sortMarkerRect);

      if (e.SortOrder == SortOrder.Ascending)
        EhLibUtils.FillGradient(e.Graphics, smRect.Location, new Point[]
          { new Point(0, 0), new Point(9, 0),
           new Point(1, 1), new Point(8, 1),
           new Point(2, 2), new Point(7, 2),
           new Point(3, 3), new Point(6, 3),
           new Point(4, 4), new Point(5, 4)
          },
          e.SortMarkerColor, e.SortMarkerColor);
      else
        EhLibUtils.FillGradient(e.Graphics, smRect.Location, new Point[]
          { new Point(0, 4), new Point(9, 4),
            new Point(1, 3), new Point(8, 3),
            new Point(2, 2), new Point(7, 2),
            new Point(3, 1), new Point(6, 1),
            new Point(4, 0), new Point(5, 0)
          },
          e.SortMarkerColor, e.ControlForeColor);
    }

    public virtual void DrawFramedSortMarker(ref Rectangle sortMarkerRect, SortMarkerPaintEventArgs e)
    {
      Point[] points = new Point[4];
      Pen blackPen = new Pen(e.SortMarkerColor, 1);
      Rectangle smRect = new Rectangle();

      smRect.Size = GetSortMarkerSize(e.SortMarkerStyle);
      smRect = EhLibUtils.RectCenter(smRect, sortMarkerRect);

      if (e.SortOrder == SortOrder.Descending)
      {
        points[0].X = (smRect.Right + smRect.Left) / 2;
        points[0].Y = smRect.Bottom;
        points[1].X = smRect.Left;
        points[1].Y = smRect.Top + 1;
        points[2].X = smRect.Right - 1;
        points[2].Y = smRect.Top + 1;
        points[3].X = (smRect.Right + smRect.Left) / 2;
        points[3].Y = smRect.Bottom;
      }
      else
      {
        points[0].X = (smRect.Right + smRect.Left) / 2;
        points[0].Y = smRect.Top;
        points[1].X = smRect.Right - 1;
        points[1].Y = smRect.Bottom - 1;
        points[2].X = smRect.Left;
        points[2].Y = smRect.Bottom - 1;
        points[3].X = (smRect.Right + smRect.Left) / 2;
        points[3].Y = smRect.Top;
      }

      e.Graphics.DrawPolygon(blackPen, points);

      blackPen.Dispose();
    }

    public virtual void DrawSortIndex(ref Rectangle sortIndexRect, SortMarkerPaintEventArgs e)
    {
      string smIndexStr = e.SortIndex.ToString();
      Font font = SortMarkerFont;
      TextFormatFlags fmtFlags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter;

      TextRenderer.DrawText(e.Graphics, smIndexStr, font, sortIndexRect, e.ControlForeColor, fmtFlags);
    }

    public virtual Cursor DownArrowSelectCursor()
    {
      if (downArrowSelectCursor == null)
      {
        using (MemoryStream ms = new MemoryStream(Properties.Resources.DownArrowSelectCur))
        {
          downArrowSelectCursor = new Cursor(ms);
        }
      }
      return downArrowSelectCursor;
    }

    public virtual Cursor LeftArrowSelectCursor()
    {
      if (leftArrowSelectCursor == null)
      {
        using (MemoryStream ms = new MemoryStream(Properties.Resources.LeftArrowSelectCur))
        {
          leftArrowSelectCursor = new Cursor(ms);
        }
      }
      return leftArrowSelectCursor;
    }

    public virtual Cursor RightArrowSelectCursor()
    {
      if (rightArrowSelectCursor == null)
      {
        using (MemoryStream ms = new MemoryStream(Properties.Resources.RightArrowSelectCur))
        {
          rightArrowSelectCursor = new Cursor(ms);
        }
      }
      return rightArrowSelectCursor;
    }

    public virtual int ColSelectionAreaHeight()
    {
      return 20;
    }

    public virtual Padding GetColumnOptionsSidePadding()
    {
      return columnOptionsSidePadding;
    }

    public virtual Color GetFixedSelectedForeColor(DataGridEh dataGrid, Color backColor, Color foreColor)
    {
      if (Application.RenderWithVisualStyles)
      {
        return foreColor;
      }
      else
      {
        return SystemColors.HighlightText;
      }
    }

    public virtual void GetInTitleFilterButtonMetrics(DataGridEh dataGrid, Size cellSize, InTitleFilterButtonMetrics metric)
    {
      Size buttonSize = new Size(SystemInformation.VerticalScrollBarWidth, SystemInformation.VerticalScrollBarWidth);

      buttonSize.Width = buttonSize.Width * 9 / 10;

      metric.Margin = new Padding(1);

      if (buttonSize.Width + metric.Margin.Left + metric.Margin.Right > cellSize.Width / 2)
        buttonSize.Width = cellSize.Width / 2 - metric.Margin.Left - metric.Margin.Right;

      buttonSize.Height = buttonSize.Width * 3 / 2;
      if (buttonSize.Height + metric.Margin.Top + metric.Margin.Bottom > cellSize.Height)
        buttonSize.Height = cellSize.Height - metric.Margin.Top - metric.Margin.Bottom;

      Size buttonAreaSize = buttonSize;
      buttonAreaSize.Height += metric.Margin.Top + metric.Margin.Bottom;
      buttonAreaSize.Width += metric.Margin.Left + metric.Margin.Right;

      //Rectangle filterButtonRect = new Rectangle(
      //  cellSize.Width - buttonSize.Width,
      //  0,
      //  buttonSize.Width,
      //  buttonSize.Height
      //);

      Rectangle cellFilterArea = new Rectangle(cellSize.Width - buttonAreaSize.Width, 0, buttonAreaSize.Width, cellSize.Height);

      Rectangle filterButtonArea = new Rectangle(Point.Empty, buttonAreaSize);
      filterButtonArea = EhLibUtils.RectCenter(filterButtonArea, cellFilterArea);

      metric.ButtonRect = EhLibUtils.TrimPadding(filterButtonArea, metric.Margin);
    }

    public virtual void DrawInTitleFilterButton(DataGridEh dataGrid, InTitleFilterButtonArgs e)
    {
      if (Application.RenderWithVisualStyles)
      {
        if (e.PaintBack)
        {
          Rectangle btnRect = e.Rect;
          btnRect.Inflate(1, 1);
          ButtonRenderer.DrawButton(e.Graphics, btnRect, e.State);
        }
      }
      else
      {
        if (e.PaintBack)
        {
          Border3DStyle frameStyle;

          if (e.State == PushButtonState.Pressed)
            frameStyle = Border3DStyle.SunkenInner;
          else if (e.State == PushButtonState.Hot)
            frameStyle = Border3DStyle.RaisedInner;
          else
            frameStyle = Border3DStyle.Flat;

          e.Graphics.FillRectangle(new SolidBrush(SystemColors.ButtonFace), e.Rect);
          ControlPaint.DrawBorder3D(e.Graphics, e.Rect, frameStyle);
        }
      }
      DrawFilterButtonSign(dataGrid, e);
    }

    public virtual void DrawFilterButtonSign(DataGridEh dataGrid, InTitleFilterButtonArgs e)
    {
      Color fromColor, toColor;
      Point startPos;
      Rectangle signRect;

      if (e.FilterHaveData)
      {
        Bitmap bmp = Properties.Resources.TitleFilterHave2;

        signRect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        signRect = EhLibUtils.RectCenter(signRect, e.Rect);

        e.Graphics.DrawImage(bmp, signRect);
      }
      else
      {
        signRect = new Rectangle(0, 0, 6, 3);
        signRect = EhLibUtils.RectCenter(signRect, e.Rect);

        fromColor = EhLibUtils.ApproximateColor(SystemColors.ControlDarkDark, Color.Black, 30);
        toColor = EhLibUtils.ApproximateColor(SystemColors.ControlDarkDark, Color.White, 00);
        startPos = new Point((signRect.Right + signRect.Left - 7) / 2 + 1,
                             (signRect.Top + signRect.Bottom - 2) / 2);

        EhLibUtils.FillGradient(e.Graphics, startPos, new Point[]
          { new Point(0, 0), new Point(7, 0),
           new Point(1, 1), new Point(6, 1),
           new Point(2, 2), new Point(5, 2),
           new Point(3, 3), new Point(4, 3)
          },
          fromColor, toColor);
      }
    }

    public virtual void DrawRowselCheckBox(Graphics g, Point location, CheckBoxState state, bool flat, bool tryUseVisualStyles)
    {
      EhLibRenderManager.DefaultEhLibRenderManager.BaseElementsDrawStyle.DrawCheckBox(g, location, state, flat, tryUseVisualStyles);
    }

    protected override GridSelectionRenderer CreateDefaultDataSelectionRenderer()
    {
      //return new GridClassicSelectionRenderer();
      return new GridTranslucentSelectionRenderer();
    }
    #endregion
  }

  public class DataVertGridDrawStyle : BaseGridDrawStyle, IDisposable
  {
    #region privates
    Cursor downArrowSelectCursor;
    Cursor rightArrowSelectCursor;
    readonly Padding columnOptionsSidePadding = new Padding(3, 2, 3, 2);
    private bool disposed;
    #endregion

    #region constructor
    public DataVertGridDrawStyle()
    {
    }

    ~DataVertGridDrawStyle()
    {
      Dispose(false);
    }

    public void Dispose()
    {
      Dispose(true);
      GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
      if (disposed)
        return;
      if (disposing)
      {
        if (downArrowSelectCursor != null) downArrowSelectCursor.Dispose();
        if (rightArrowSelectCursor != null) rightArrowSelectCursor.Dispose();
      }
      disposed = true;
    }
    #endregion

    public virtual bool FixFillFixedCellRect(DataVertGridEh grid, BaseGridFillFixedCellEventArgs e, ref Rectangle fillRect)
    {
      if (Application.RenderWithVisualStyles)
      {
        fillRect.Width = fillRect.Width + 2;
        fillRect.Height = fillRect.Height + 2;
        return true;
      }
      else
      {
        return false;
      }
    }

    public virtual void FillTitleCell(DataVertGridEh grid, BaseGridFillFixedCellEventArgs e)
    {
      FillFixedCell(grid, e);
    }

    public virtual void FillFixedCell(DataVertGridEh grid, BaseGridFillFixedCellEventArgs e)
    {
      base.FillFixedCell(grid, e);
    }

    public virtual Cursor DownArrowSelectCursor()
    {
      if (downArrowSelectCursor == null)
      {
        using (MemoryStream ms = new MemoryStream(Properties.Resources.DownArrowSelectCur))
        {
          downArrowSelectCursor = new Cursor(ms);
        }
      }
      return downArrowSelectCursor;
    }

    public virtual Cursor RightArrowSelectCursor()
    {
      if (rightArrowSelectCursor == null)
      {
        using (MemoryStream ms = new MemoryStream(Properties.Resources.RightArrowSelectCur))
        {
          rightArrowSelectCursor = new Cursor(ms);
        }
      }
      return rightArrowSelectCursor;
    }

    public virtual Padding GetColumnOptionsSidePadding()
    {
      return columnOptionsSidePadding;
    }

    public virtual Color GetFixedSelectedForeColor(DataVertGridEh grid, Color backColor, Color foreColor)
    {
      if (Application.RenderWithVisualStyles)
      {
        return foreColor;
      }
      else
      {
        return SystemColors.HighlightText;
      }
    }

    public virtual Size GetDefaultEditButtonSize(Size cellSize)
    {
      Size size = new Size(SystemInformation.VerticalScrollBarWidth, SystemInformation.VerticalScrollBarWidth);

      size.Width = size.Width * 9 / 10;

      if (size.Width > cellSize.Width / 2)
        size.Width = cellSize.Width / 2;

      size.Height = size.Width * 3 / 2;
      if (size.Height > cellSize.Height)
        size.Height = cellSize.Height;

      return size;
    }
  }

  /// <summary>
  /// Contains methods and properties for drawing some grid elements.
  /// </summary>
  public class BaseGridDrawStyle
  {

    #region >privates
    private bool applicationRenderWithVisualStyles;
    private object capturePaintControl;
    private VisualStyleRenderer visualStyleRender;
    private GridSelectionRenderer dataSelectionRenderer;
    private GridSelectionRenderer defaultDataSelectionRenderer;
    #endregion <privates

    public BaseGridDrawStyle()
    {
    }

    #region >properties
    public bool PaintCaptured
    {
      get
      {
        return capturePaintControl != null;
      }
    }

    public bool RenderWithVisualStyles
    {
      get
      {
        if (PaintCaptured)
          return applicationRenderWithVisualStyles;
        else
          return Application.RenderWithVisualStyles;
      }
    }

    public GridSelectionRenderer DataSelectionRenderer
    {
      get
      {
        if (dataSelectionRenderer != null)
          return dataSelectionRenderer;
        else
          return DefaultDataSelectionRenderer;
      }

      set
      {
        dataSelectionRenderer = value;
      }
    }

    public GridSelectionRenderer DefaultDataSelectionRenderer
    {
      get
      {
        if (defaultDataSelectionRenderer == null)
          defaultDataSelectionRenderer = CreateDefaultDataSelectionRenderer();
        return defaultDataSelectionRenderer;
      }
    }
    #endregion <properties

    public virtual Color DefaultBrightLineColor(BaseGridControl grid)
    {
      Color result;
      bool useVisualStyles;

      if (capturePaintControl != null)
        useVisualStyles = applicationRenderWithVisualStyles;
      else
        useVisualStyles = Application.RenderWithVisualStyles;

      if (useVisualStyles)
      {
        //VisualStyleRenderer render = new VisualStyleRenderer(VisualStyleElement.Button.PushButton.Normal);
        //return render.GetColor(ColorProperty.FillColor);
        return SystemColors.ButtonFace;
      }
      else if (grid.CanFillSelectionByTheme())
      {
        if (grid.BackColor.ToArgb() == 0xF0F0F0)
          result = Color.Gray;
        else
          result = Color.FromArgb(0xF0F0F0);
      }
      else if (grid.BackColor == Color.Silver)
        result = Color.Gray;
      else
        result = Color.Silver;

      return result;
    }

    public virtual Color DefaultDarkLineColor(BaseGridControl grid)
    {
      if (RenderWithVisualStyles)
      {
        if (Environment.OSVersion.Version.Major >= 6)
        {
          if (visualStyleRender == null)
            visualStyleRender = new VisualStyleRenderer(VisualStyleElement.Header.Item.Normal);
          return visualStyleRender.GetColor(ColorProperty.EdgeFillColor);
        }
        else
        {
          return Color.FromArgb(0xCB, 0xC7, 0xB8);
        }
      }
      else
      {
        //return Color.Gray;
        return SystemColors.ButtonShadow;
      }
    }

    /// <summary> 
    /// The style that is used when Application VisualStyles are not available.
    /// </summary>
    /// <returns>
    /// Returns default style for fixed cell of a grid.
    /// </returns>
    public virtual CellFillStyle DefaultCustomFixedCellFillStyle()
    {
      return CellFillStyle.Solid;
    }

    public virtual void FillFixedCell(BaseGridControl grid, BaseGridFillFixedCellEventArgs e)
    {
      //-return;
      if (Application.RenderWithVisualStyles && e.FillStyle == CellFillStyle.VisualStyles)
      {
        VisualStyleRenderer renderer;
        Rectangle fillRect = e.CellRect;
        Region clientClip = null;
        bool clipped = false;

        if (e.IsPressed || (e.IsSelected && !e.IsHot))
          renderer = new VisualStyleRenderer(VisualStyleElement.Header.Item.Pressed);
        else if (e.IsHot)
          renderer = new VisualStyleRenderer(VisualStyleElement.Header.Item.Hot);
        else
          renderer = new VisualStyleRenderer(VisualStyleElement.Header.Item.Normal);

        if (FixFillFixedCellRect(grid, e, ref fillRect))
        {
          clientClip = grid.PaintingSetClip(e.Graphics, e.CellRect, CombineMode.Intersect);
          //clientClip = e.Graphics.Clip;
          //e.Graphics.SetClip(e.CellRect, CombineMode.Intersect);
          clipped = true;
        }
        if (grid.UseRightToLeft)
          fillRect = EhLibUtils.RightToLeftFlipRectangle(grid.ClientRectangle, fillRect);
        renderer.DrawBackground(e.Graphics, fillRect);
        if (clipped)
        {
          grid.PaintingSetClip(e.Graphics, clientClip, CombineMode.Replace);
          //e.Graphics.Clip = clientClip;
        }
      }
      else
      {
        CellFillStyle fillStyle;
        Rectangle fillRect = e.CellRect;

        if (e.FillStyle == CellFillStyle.VisualStyles)
          fillStyle = DefaultCustomFixedCellFillStyle();
        else
          fillStyle = e.FillStyle;

        if (grid.UseRightToLeft)
          fillRect = EhLibUtils.RightToLeftFlipRectangle(grid.ClientRectangle, fillRect);

        if (fillStyle == CellFillStyle.Solid)
        {
          Color color = e.BackColor;
          if (e.IsSelected)
          {
            color = SystemColors.Highlight;
            float h = color.GetHue();
            float s = color.GetSaturation();
            float b = color.GetBrightness();
            color = EhLibUtils.ColorFromAHSB(255, h, s / 6, b);
          }
          using (SolidBrush fillBrush = new SolidBrush(color))
          {
            e.Graphics.FillRectangle(fillBrush, fillRect);
          }
        }
        else if (fillStyle == CellFillStyle.VertGradient)
        {
          EhLibUtils.FillRectangleGradient(e.Graphics, fillRect, e.SecondFillColor, e.FillColor);
        }

        if (e.InnerBorder == CellInnerBorderStyle.RaisedTopLeft)
        {
          Border3DStyle style;
          if (e.IsPressed)
            style = Border3DStyle.SunkenInner;
          else
            style = Border3DStyle.RaisedInner;
          ControlPaint.DrawBorder3D(e.Graphics, fillRect, style, Border3DSide.Left | Border3DSide.Top);
        }
        else if (e.InnerBorder == CellInnerBorderStyle.RaisedFull)
        {
          Border3DStyle style = Border3DStyle.RaisedInner;
          ControlPaint.DrawBorder3D(e.Graphics, fillRect, style);
        }
      }
    }

    public virtual bool FixFillFixedCellRect(BaseGridControl grid, BaseGridFillFixedCellEventArgs e, ref Rectangle fillRect)
    {
      if (Application.RenderWithVisualStyles)
      {
        fillRect.Width = fillRect.Width + 2;
        fillRect.Height = fillRect.Height + 2;
        return true;
      }
      else
      {
        return false;
      }
    }

    protected virtual void RefreshDrawBuffer()
    {
      applicationRenderWithVisualStyles = Application.RenderWithVisualStyles;
    }

    public virtual void CapturePaint(Control control)
    {
      if (capturePaintControl == null)
      {
        capturePaintControl = control;
        RefreshDrawBuffer();
      }
    }

    public virtual void ReleasePaint(Control control)
    {
      if (capturePaintControl == control)
        capturePaintControl = null;
      visualStyleRender = null;
    }

    protected virtual GridSelectionRenderer CreateDefaultDataSelectionRenderer()
    {
      return new GridTranslucentSelectionRenderer();
    }
  }

  //TextBoxRenderStyle
  public class TextBoxDrawStyle
  {

    private readonly bool textBoxNoScrollElementChecked = false;
    private bool textBoxNoScrollElementIsDefined;

    private VisualStyleRenderer visualStyleRenderer;
    private readonly VisualStyleElement textBoxElement = VisualStyleElement.TextBox.TextEdit.Normal;
    private static readonly VisualStyleElement TextBoxNoScrollElement =
      VisualStyleElement.CreateElement("EDIT",
                                       (int)EDITPARTS.EP_EDITBORDER_NOSCROLL,
                                       (int)EDITBORDER_NOSCROLLSTATES.EPSN_NORMAL);

    public TextBoxDrawStyle()
    {
    }

    protected void CheckElements()
    {
      if (textBoxNoScrollElementChecked) return;
      textBoxNoScrollElementIsDefined = VisualStyleRenderer.IsElementDefined(TextBoxNoScrollElement);
    }

    public virtual VisualStyleElement TextBoxElement()
    {
      CheckElements();
      if (textBoxNoScrollElementIsDefined)
        return TextBoxNoScrollElement;
      else
        return textBoxElement;
    }

    public virtual TextBoxState GetTextBoxState(bool isHot, bool isSelected, bool isDisabled, bool isReadonly)
    {
      if (isDisabled)
        return TextBoxState.Disabled;
      else if (isReadonly)
        return TextBoxState.Readonly;
      else if (isSelected)
        return TextBoxState.Selected;
      else if (isHot)
        return TextBoxState.Hot;
      else
        return TextBoxState.Normal;
      //Assist = 7
    }

    public virtual void DrawTextBoxFrame(Graphics g, Rectangle bounds, TextBoxState state, Control childControl, BorderStyle borderStyle)
    {
      if (borderStyle == BorderStyle.None) return;

      if (Application.RenderWithVisualStyles && borderStyle == BorderStyle.Fixed3D)
      {
        if (visualStyleRenderer == null)
        {
          visualStyleRenderer = new VisualStyleRenderer(TextBoxElement().ClassName, TextBoxElement().Part, (int)state);
        }
        else
        {
          visualStyleRenderer.SetParameters(TextBoxElement().ClassName, TextBoxElement().Part, (int)state);
        }

        if (visualStyleRenderer.IsBackgroundPartiallyTransparent() && (childControl != null))
          visualStyleRenderer.DrawParentBackground(g, bounds, childControl);
        visualStyleRenderer.DrawBackground(g, bounds);
      }
      else
      {
        if (borderStyle == BorderStyle.Fixed3D)
          ControlPaint.DrawBorder3D(g, bounds, Border3DStyle.Sunken);
        else
          ControlPaint.DrawBorder(g, bounds, SystemColors.ControlDarkDark, ButtonBorderStyle.Solid);
        //visualStyleRenderer.DrawEdge(e.Graphics, bounds, Edges.Left | Edges.Right | Edges.Top | Edges.Bottom, EdgeStyle.Sunken, EdgeEffects.None);
        //ControlPaint.DrawBorder(g, bounds, SystemColors.ButtonFace, ButtonBorderStyle.Dashed);
      }
    }

  }

  public class ToolElementsDrawStyle
  {

    public ToolElementsDrawStyle()
    {
    }

    public virtual void DrawPushButtonBack(Graphics g, PushButtonBackDrawArgs e)
    {
      if (Application.RenderWithVisualStyles ||
          (e.ParentHasFrame && e.BorderStyle == PushButtonBorderStyle.Thick))
      {
        Rectangle btnRect = e.Rect;

        if (Application.RenderWithVisualStyles)
          btnRect.Inflate(1, 1);
        ButtonRenderer.DrawButton(e.Graphics, btnRect, e.State);
      }
      else
      {
        Border3DStyle frameStyle;
        Rectangle innerRect = e.Rect;
        innerRect.Inflate(-1, -1);

        e.Graphics.FillRectangle(new SolidBrush(SystemColors.ButtonFace), innerRect);

        if (e.ParentHasFrame && e.BorderStyle == PushButtonBorderStyle.Thin)
        {
          if (e.State == PushButtonState.Pressed)
            frameStyle = Border3DStyle.SunkenInner;
          else
            frameStyle = Border3DStyle.RaisedInner;
        }
        else
        {
          if (e.State == PushButtonState.Pressed)
            frameStyle = Border3DStyle.SunkenInner;
          else if (e.State == PushButtonState.Hot)
            frameStyle = Border3DStyle.RaisedInner;
          else
            frameStyle = Border3DStyle.Adjust;
        }
        ControlPaint.DrawBorder3D(e.Graphics, e.Rect, frameStyle);
      }
    }

    public virtual void DrawDropDownButtonSign(Graphics g, Rectangle bounds, PushButtonState state)
    {
      DrawDownSignButtonSign(g, bounds, state);
    }

    public virtual void DrawDownSignButtonSign(Graphics g, Rectangle bounds, PushButtonState state)
    {
      Rectangle signRect = new Rectangle(0, 0, 6, 3);
      signRect = EhLibUtils.RectCenter(signRect, bounds);

      Color fromColor = EhLibUtils.ApproximateColor(SystemColors.ControlDarkDark, Color.Black, 30);
      Color toColor = EhLibUtils.ApproximateColor(SystemColors.ControlDarkDark, Color.White, 00);
      Point startPos = new Point((signRect.Right + signRect.Left - 7) / 2 + 1,
        (signRect.Top + signRect.Bottom - 2) / 2);

      EhLibUtils.FillGradient(g, startPos, new Point[]
        { new Point(0, 0), new Point(7, 0),
          new Point(1, 1), new Point(6, 1),
          new Point(2, 2), new Point(5, 2),
          new Point(3, 3), new Point(4, 3)
        },
        fromColor, toColor);
    }

    public virtual void DrawUpSignButtonSign(Graphics g, Rectangle bounds, PushButtonState state)
    {
      Rectangle signRect = new Rectangle(0, 0, 6, 3);
      signRect = EhLibUtils.RectCenter(signRect, bounds);

      Color fromColor = EhLibUtils.ApproximateColor(SystemColors.ControlDarkDark, Color.Black, 30);
      Color toColor = EhLibUtils.ApproximateColor(SystemColors.ControlDarkDark, Color.White, 00);
      Point startPos = new Point((signRect.Right + signRect.Left - 7) / 2 + 1,
        (signRect.Top + signRect.Bottom - 2) / 2);

      EhLibUtils.FillGradient(g, startPos, new Point[]
        { new Point(0, 3), new Point(7, 3),
          new Point(1, 2), new Point(6, 2),
          new Point(2, 1), new Point(5, 1),
          new Point(3, 0), new Point(4, 0)
        },
        fromColor, toColor);
    }

    public virtual void DrawLeftSignButtonSign(Graphics g, Rectangle bounds, PushButtonState state)
    {
      Rectangle signRect = new Rectangle(0, 0, 3, 6);
      signRect = EhLibUtils.RectCenter(signRect, bounds);

      Color fromColor = EhLibUtils.ApproximateColor(SystemColors.ControlDarkDark, Color.Black, 30);
      Color toColor = EhLibUtils.ApproximateColor(SystemColors.ControlDarkDark, Color.White, 00);
      Point startPos = new Point((signRect.Right + signRect.Left - 7) / 2 + 2,
                                 (signRect.Top + signRect.Bottom - 2) / 2 - 2);

      EhLibUtils.FillGradient(g, startPos, new Point[]
        {
          new Point(3, 0), new Point(4, 0),
          new Point(2, 1), new Point(4, 1),
          new Point(1, 2), new Point(4, 2),
          new Point(0, 3), new Point(4, 3),
          new Point(1, 4), new Point(4, 4),
          new Point(2, 5), new Point(4, 5),
          new Point(3, 6), new Point(4, 6),
        },
        fromColor, toColor);
    }

    public virtual void DrawRightSignButtonSign(Graphics g, Rectangle bounds, PushButtonState state)
    {
      Rectangle signRect = new Rectangle(0, 0, 3, 6);
      signRect = EhLibUtils.RectCenter(signRect, bounds);

      Color fromColor = EhLibUtils.ApproximateColor(SystemColors.ControlDarkDark, Color.Black, 30);
      Color toColor = EhLibUtils.ApproximateColor(SystemColors.ControlDarkDark, Color.White, 00);
      Point startPos = new Point((signRect.Right + signRect.Left - 7) / 2 + 2,
                                 (signRect.Top + signRect.Bottom - 2) / 2 - 2);

      EhLibUtils.FillGradient(g, startPos, new Point[]
        {
          new Point(0, 0), new Point(1, 0),
          new Point(0, 1), new Point(2, 1),
          new Point(0, 2), new Point(3, 2),
          new Point(0, 3), new Point(4, 3),
          new Point(0, 4), new Point(3, 4),
          new Point(0, 5), new Point(2, 5),
          new Point(0, 6), new Point(1, 6),
        },
        fromColor, toColor);
    }

    public virtual void DrawEllipsisButtonSign(Graphics g, Rectangle bounds, PushButtonState state)
    {
      Rectangle signRect = new Rectangle(0, 0, 10, 2);
      signRect = EhLibUtils.RectCenter(signRect, bounds);

      Color fromColor = EhLibUtils.ApproximateColor(SystemColors.ControlDarkDark, Color.Black, 30);
      Color toColor = EhLibUtils.ApproximateColor(SystemColors.ControlDarkDark, Color.White, 00);
      Point startPos = signRect.Location;

      EhLibUtils.FillGradient(g, startPos, new Point[]
        { new Point(0, 0), new Point(2, 0),
           new Point(0, 1), new Point(2, 1),
        },
        fromColor, toColor);

      EhLibUtils.FillGradient(g, startPos, new Point[]
        { new Point(4, 0), new Point(6, 0),
           new Point(4, 1), new Point(6, 1),
        },
        fromColor, toColor);

      EhLibUtils.FillGradient(g, startPos, new Point[]
        { new Point(8, 0), new Point(10, 0),
           new Point(8, 1), new Point(10, 1),
        },
        fromColor, toColor);

    }

    public virtual Font GetRefLinkFont(Font font)
    {
      return new Font(font, FontStyle.Underline);
    }

    public virtual Color GetRefLinkFontColor()
    {
      return SystemColors.HotTrack;
    }

  }

  public class ProgressBarPaintEventArgs : EventArgs
  {

    public ProgressBarPaintEventArgs()
    {
      //ShowText = true;
      //TextType = ProgressBarTextType.AsPercent;
      //TextDecimalPlaces = 0;
      Indent = 1;
      //FrameFigureType = ProgressBarFrameFigureType.Rectangle;
      FrameSizeType = ProgressBarFrameSizeType.Val;
      Font = null;
      TextAlignment = HorizontalAlignment.Center;
    }

    public virtual void ResetProperties()
    {
      //ShowText = true;
      //TextType = ProgressBarTextType.AsPercent;
      //TextDecimalPlaces = 0;
      Indent = 1;
      //FrameFigureType = ProgressBarFrameFigureType.Rectangle;
      FrameSizeType = ProgressBarFrameSizeType.Val;
      Font = null;
      TextAlignment = HorizontalAlignment.Center;
    }

    //public double CurrentValue { get; set; }
    //public double MinValue { get; set; }
    //public double MaxValue { get; set; }
    public double PercentValue { get; set; }

    public Color BarFillColor { get; set; }
    public Color BarFrameColor { get; set; }
    public Color BackgroundColor { get; set; }
    public Color TextColor { get; set; }
    public Color OutbarTextColor { get; set; }

    //public bool ShowText { get; set; }

    //public ProgressBarTextType TextType { get; set; }
    //public int TextDecimalPlaces { get; set; }
    public HorizontalAlignment TextAlignment { get; set; }
    //public ProgressBarFrameFigureType FrameFigureType { get; set; }
    public ProgressBarFrameSizeType FrameSizeType { get; set; }
    public int Indent { get; set; }
    public Font Font { get; set; }
    public string Text { get; set; }
    public bool ShowText { get; set; }
  }

  public class ProgressBarRenderer
  {

    public ProgressBarRenderer()
    {
    }

    public virtual ProgressBarPaintEventArgs CreateProgressBarPaintArgs()
    {
      return new ProgressBarPaintEventArgs();
    }

    public virtual void DrawBar(GraphicsContext gc, Rectangle bounds, ProgressBarPaintEventArgs args)
    {
      bool clipBarText = false;

      if (args.BackgroundColor != Color.Empty)
      {
        using (SolidBrush brush = new SolidBrush(args.BackgroundColor))
        {
          gc.Graphics.FillRectangle(brush, bounds);
        }
      }

      Rectangle progressBarFaceRect = CalcBarFaceRect(gc.Graphics, bounds, args);

      if (!string.IsNullOrEmpty(args.Text))
      {
        if (args.TextColor != args.OutbarTextColor && args.ShowText)
        {
          DrawText(gc, bounds, args, progressBarFaceRect, false, args.OutbarTextColor);
          clipBarText = true;
        }
      }

      DrawBarFace(gc.Graphics, bounds, args, progressBarFaceRect);

      if (!string.IsNullOrEmpty(args.Text) && args.ShowText)
        DrawText(gc, bounds, args, progressBarFaceRect, clipBarText, args.TextColor);
    }

    public virtual double CalcPercentValue(double value, double minValue, double maxValue)
    {
      double absMaxValue;
      double absCurValue;

      absMaxValue = Math.Abs(maxValue - minValue);
      absCurValue = Math.Abs(value - minValue);
      return absCurValue / absMaxValue * 100;
    }

    public virtual string FormatText(double value, double minValue, double maxValue, int decimalPlaces, ProgressBarTextType textType)
    {
      string result;

      if (textType == ProgressBarTextType.AsValue)
        result = Math.Round(value, -decimalPlaces).ToString(CultureInfo.CurrentCulture);
      else
        result = Math.Round(value / (maxValue - minValue) * 100, decimalPlaces) + "%";

      return result;
    }

    public virtual Rectangle CalcBarFaceRect(Graphics g, Rectangle bounds, ProgressBarPaintEventArgs args)
    {
      Rectangle progressFrameRect;
      int progressWidth;
      //double maxValue;
      //double curValue;

      progressFrameRect = bounds;
      progressFrameRect.Inflate(-args.Indent, -args.Indent);
      //progressFrameRect.Width = progressFrameRect.Width - 1;
      //progressFrameRect.Height = progressFrameRect.Height - 1;

      progressWidth = (int)Math.Round(args.PercentValue / 100 * progressFrameRect.Width);

      if (progressWidth < 0) progressWidth = 0;
      if (progressWidth > progressFrameRect.Width) progressWidth = progressFrameRect.Width;

      //completeRect = progressFrameRect;
      //completeRect.Width = progressWidth;
      //if (args.FrameSizeType == ProgressBarFrameSizeType.Val)
      progressFrameRect.Width = progressWidth;

      return progressFrameRect;
    }

    public virtual void DrawBarFace(Graphics g, Rectangle bounds, ProgressBarPaintEventArgs args, Rectangle progressBarFaceRect)
    {
      Rectangle fillRect = EhLibUtils.ChangeRectangle(progressBarFaceRect, 1, 1, -2, -2);
      using (SolidBrush brush = new SolidBrush(args.BarFillColor))
      {
        g.FillRectangle(brush, fillRect);
      }

      Rectangle frameRect = EhLibUtils.ChangeRectangle(progressBarFaceRect, 0, 0, -1, -1);
      using (Pen pen = new Pen(args.BarFrameColor))
      {
        g.DrawRectangle(pen, frameRect);
      }
    }

    public virtual void DrawText(GraphicsContext gc, Rectangle bounds, ProgressBarPaintEventArgs args,
      Rectangle progressBarFaceRect, bool clipTextByBarFaceRect, Color textColor)
    {
      Rectangle textRect = bounds;
      Region oldClip = null;
      string progressText = args.Text;

      if (clipTextByBarFaceRect)
      {
        oldClip = gc.Graphics.Clip;
        gc.Graphics.SetClip(progressBarFaceRect, CombineMode.Intersect);
      }

      //textRect.Height = textRect.Height - 1;
      gc.DrawText(progressText, args.Font, textRect, textColor, args.TextAlignment,
        VerticalAlignment.Center, TextFormatFlagsEh.None);

      if (clipTextByBarFaceRect)
      {
        if (oldClip != null)
          gc.Graphics.Clip = oldClip;
      }
    }

    public virtual void FillProgressBarPaintArgsDefaultValues(ProgressBarPaintEventArgs args)
    {
      args.BackgroundColor = SystemColors.Window;
      args.BarFrameColor = SystemColors.ControlDarkDark;
      args.BarFillColor = Color.FromArgb(0xA6, 0xCA, 0xF0);//Color.SkyBlue;

      //args.ShowText = true;
      //args.TextType = ProgressBarTextType.AsPercent;
      //args.TextDecimalPlaces = 0;
      args.Indent = 1;
      //FrameFigureType = ProgressBarFrameFigureType.Rectangle;
      args.FrameSizeType = ProgressBarFrameSizeType.Val;
      args.Font = null;
      args.TextAlignment = HorizontalAlignment.Center;

    }
  }

  public class SlopeGradientProgressBarRenderer : ProgressBarRenderer
  {

    public SlopeGradientProgressBarRenderer()
    {
      //BaseBarFaceColor = Color.FromArgb(124, 185, 232);
      //BaseBarFaceColor = Color.FromArgb(113, 175, 234);
      //BaseBarFaceColor = Color.FromArgb(168, 209, 248);
      BaseBarFaceColor = Color.FromArgb(150, 191, 230);
    }

    Color BaseBarFaceColor { get; set; }

    public override void DrawBarFace(Graphics g, Rectangle bounds, ProgressBarPaintEventArgs args, Rectangle progressBarFaceRect)
    {

      Rectangle drawRect = progressBarFaceRect;
      //Color color = BaseBarFaceColor;
      Color color = args.BarFillColor;

      Rectangle fillR = EhLibUtils.ChangeRectangle(drawRect, 2, 2, -4, -4);
      Rectangle fr1 = EhLibUtils.ChangeRectangle(drawRect, 1, 1, -2, -2);
      Rectangle fr2 = drawRect;

      if (fr1.Width <= 0) fr1.Width = 1;
      if (fr2.Width <= 1) fr2.Width = 2;

      float h = color.GetHue();
      float s = color.GetSaturation();
      float b = color.GetBrightness();
      //s = s + (1 - s) * 0.6f;
      b = b + (1 - b) * 0.375f;
      Color col1 = EhLibUtils.ColorFromAHSB(255, h, s, b);
      //Color col1 = Color.FromArgb(255, 172, 211, 248);
      Color col2 = Color.FromArgb(255, color);

      if (progressBarFaceRect.Width > 0 && progressBarFaceRect.Height > 0)
      {
        double angleRad = Math.Atan((double)drawRect.Width / drawRect.Height);
        float angleDeg = (float)(angleRad * (180 / Math.PI));
        LinearGradientBrush linearGradientBrush = new LinearGradientBrush(drawRect, col1, col2, angleDeg);

        g.FillRectangle(SystemBrushes.Window, fr1);
        //return;

        g.FillRectangle(linearGradientBrush, fillR);
      }

      //fr1
      g.DrawLine(new Pen(Color.FromArgb(105, color)),
                          new Point(fr1.Left, fr1.Top),
                          new Point(fr1.Left, fr1.Bottom - 1)
                          );
      g.DrawLine(new Pen(Color.FromArgb(105, color)),
                          new Point(fr1.Right - 1, fr1.Top),
                          new Point(fr1.Right - 1, fr1.Bottom - 1)
                          );
      g.DrawLine(new Pen(Color.FromArgb(45, color)),
                          new Point(fr1.Left, fr1.Top),
                          new Point(fr1.Right - 1, fr1.Top)
                          );
      g.DrawLine(new Pen(Color.FromArgb(167, color)),
                          new Point(fr1.Left, fr1.Bottom - 1),
                          new Point(fr1.Right - 1, fr1.Bottom - 1)
                          );

      //fr2
      g.DrawLine(new Pen(Color.FromArgb(255, 142, 148, 155)),
                          new Point(fr2.Left, fr2.Top + 1),
                          new Point(fr2.Left, fr2.Bottom - 2)
                          );
      g.DrawLine(new Pen(Color.FromArgb(255, 142, 148, 155)),
                          new Point(fr2.Right - 1, fr2.Top + 1),
                          new Point(fr2.Right - 1, fr2.Bottom - 2)
                          );

      if (fr2.Width == 3)
      {
        g.FillRectangle(new SolidBrush(Color.FromArgb(255, 142, 148, 155)), fr2.Left + 1, fr2.Top, 1, 1);
        g.FillRectangle(new SolidBrush(Color.FromArgb(255, 142, 148, 155)), fr2.Left + 1, fr2.Bottom - 1, 1, 1);
      }
      else
      {
        g.DrawLine(new Pen(Color.FromArgb(255, 142, 148, 155)),
                            new Point(fr2.Left + 1, fr2.Top),
                            new Point(fr2.Right - 2, fr2.Top)
                            );
        g.DrawLine(new Pen(Color.FromArgb(255, 142, 148, 155)),
                            new Point(fr2.Left + 1, fr2.Bottom - 1),
                            new Point(fr2.Right - 2, fr2.Bottom - 1)
                            );
      }
    }

  }

  public class EditBoxEditButtonPainter
  {

    public EditBoxEditButtonPainter()
    {
    }

    public virtual void DrawButtonBackground(GraphicsContext gc, Rectangle bounds, PushButtonState state, InEditButtonStyleKind styleKind)
    {
      bool themed = Application.RenderWithVisualStyles;
      Rectangle btnRect = bounds;

      if (themed && styleKind != InEditButtonStyleKind.SysDropDown)
        btnRect.Inflate(1, 1);

      if (styleKind == InEditButtonStyleKind.SysDropDown)
      {
        ComboBoxState cbState;
        switch (state)
        {
          case PushButtonState.Hot:
            cbState = ComboBoxState.Hot;
            break;
          case PushButtonState.Pressed:
            cbState = ComboBoxState.Pressed;
            break;
          case PushButtonState.Disabled:
            cbState = ComboBoxState.Disabled;
            break;
          default:
            cbState = ComboBoxState.Normal;
            break;
        }

        DropDownButtonAlign buttonAlign = DropDownButtonAlign.Neutral;

        if (gc.DeviceType == GraphicsContextDeviceType.Printer && themed)
        {
          VisualStyleElement vse = ComboBoxRenderer.ComboBoxElementByComboBoxState(cbState);
          Rectangle bitmapRect = new Rectangle(0, 0, btnRect.Width, btnRect.Height);
          Bitmap cbBitmap = EhLibUtils.VisualStyleRendererToImage(vse, bitmapRect) as Bitmap;
          gc.Graphics.DrawImage(cbBitmap, btnRect);
        }
        else
        {
          ComboBoxRenderer.DrawDropDownButton(gc.Graphics, btnRect, cbState, buttonAlign, null);
        }
      }
      else
      {
        if (gc.DeviceType == GraphicsContextDeviceType.Printer && themed)
        {
          VisualStyleElement vse = EhLibPushButtonRenderer.ButtonElementByButtonState(state);
          Rectangle bitmapRect = new Rectangle(0, 0, btnRect.Width, btnRect.Height);
          Bitmap cbBitmap = EhLibUtils.VisualStyleRendererToImage(vse, bitmapRect) as Bitmap;
          gc.Graphics.DrawImage(cbBitmap, btnRect);
        }
        else
        {
          ButtonRenderer.DrawButton(gc.Graphics, btnRect, state);
        }
      }
    }

    public virtual int GetMaxHeightForWidth(int buttonWidth)
    {
      return buttonWidth * 3 / 2;
    }
  }

  public class GridSelectionRenderer
  {
    public virtual bool FocusRectangleIsTranslucent
    {
      get
      {
        return false;
      }
    }

    public virtual Color ForeFocusColor
    {
      get
      {
        return SystemColors.HighlightText;
      }
    }

    public virtual void DrawSelectionRectangle(Graphics g, Rectangle rect, bool focused, bool disabled, int transparency)
    {
      DrawHighlightedRowCellRectangle(g, rect, focused, disabled, transparency);
    }

    public virtual void DrawFocusRectangle(Graphics g, Rectangle rect, bool focused, bool disabled, int transparency,
      bool leftBorderContinue, bool rightBorderContinue)
    {
      Color baseColor;
      if (focused)
        baseColor = SystemColors.Highlight;
      else
        baseColor = SystemColors.ButtonShadow;

      using (SolidBrush fillBrush = new SolidBrush(baseColor))
      {
        g.FillRectangle(fillBrush, rect);
      }
    }

    public virtual void DrawHighlightedRowCellRectangle(Graphics g, Rectangle rect, bool focused, bool disabled, int transparency)
    {
      Color baseColor;
      if (focused)
        baseColor = SystemColors.Highlight;
      else
        baseColor = SystemColors.ButtonShadow;

      int alpha = 255 / 6;
      Color backFilledColor = Color.FromArgb(alpha, baseColor);

      using (SolidBrush fillBrush = new SolidBrush(backFilledColor))
      {
        g.FillRectangle(fillBrush, rect);
      }
    }

    public virtual void DrawHotRectangle(Graphics g, Rectangle rect)
    {

    }
  }

  public class GridClassicSelectionRenderer : GridSelectionRenderer
  {

  }

  public class GridTranslucentSelectionRenderer : GridSelectionRenderer
  {
    public override bool FocusRectangleIsTranslucent
    {
      get
      {
        return true;
      }
    }

    public override Color ForeFocusColor
    {
      get
      {
        //return SystemColors.HighlightText;
        return Color.Empty;
      }
    }

    //public override void DrawSelectionRectangle(Graphics g, Rectangle rect, bool focused, bool disabled, int transparency)
    //{

    //}

    public override void DrawFocusRectangle(Graphics g, Rectangle rect, bool focused, bool disabled, int transparency,
      bool leftBorderContinue, bool rightBorderContinue)
    {
      Color baseColor;
      if (focused)
        baseColor = Color.FromArgb(255, 0, 136, 255);
      else
        baseColor = SystemColors.ButtonShadow;

      int alpha = 255 / 4;
      Color backFilledColor = Color.FromArgb(alpha, baseColor);

      using (SolidBrush fillBrush = new SolidBrush(backFilledColor))
      {
        g.FillRectangle(fillBrush, rect);
      }
    }

    public override void DrawHighlightedRowCellRectangle(Graphics g, Rectangle rect, bool focused, bool disabled, int transparency)
    {
      Color baseColor;
      if (focused)
        baseColor = Color.FromArgb(255, 0, 136, 255);
      //baseColor = SystemColors.Highlight;
      else
        baseColor = SystemColors.ButtonShadow;

      //int alpha = (int)((float)255 / 6 / 5 * 2);
      int alpha = (int)((float)255 / 4 / 5 * 2);
      Color backFilledColor = Color.FromArgb(alpha, baseColor);

      using (SolidBrush fillBrush = new SolidBrush(backFilledColor))
      {
        g.FillRectangle(fillBrush, rect);
      }
    }

    public override void DrawHotRectangle(Graphics g, Rectangle rect)
    {

    }
  }

  /// <summary>
  ///   Provides methods used to render a check box control with or without visual styles.
  ///   The class can be inherited and assign to <see cref="EhLibRenderManager.CheckBoxRenderer"/>.
  /// </summary>
  public class EhLibCheckBoxRenderer
  {
    private Bitmap[] cachedBimaps;

    public EhLibCheckBoxRenderer()
    {
      int size = (int)CheckBoxState.MixedDisabled + 1;
      cachedBimaps = new Bitmap[size];
    }

    public virtual Bitmap GetCheckboxBitmap(CheckBoxState cbState)
    {
      Bitmap cbBitmap = cachedBimaps[(int)cbState];
      if (cbBitmap == null)
      {
        if (ToolStripManager.VisualStylesEnabled)
        {
          VisualStyleElement element;

          switch (cbState)
          {
            case CheckBoxState.UncheckedNormal: element = VisualStyleElement.Button.CheckBox.UncheckedNormal; break;
            case CheckBoxState.UncheckedHot: element = VisualStyleElement.Button.CheckBox.UncheckedHot; break;
            case CheckBoxState.UncheckedPressed: element = VisualStyleElement.Button.CheckBox.UncheckedPressed; break;
            case CheckBoxState.UncheckedDisabled: element = VisualStyleElement.Button.CheckBox.UncheckedDisabled; break;

            case CheckBoxState.CheckedNormal: element = VisualStyleElement.Button.CheckBox.CheckedNormal; break;
            case CheckBoxState.CheckedHot: element = VisualStyleElement.Button.CheckBox.CheckedHot; break;
            case CheckBoxState.CheckedPressed: element = VisualStyleElement.Button.CheckBox.CheckedPressed; break;
            case CheckBoxState.CheckedDisabled: element = VisualStyleElement.Button.CheckBox.CheckedDisabled; break;

            case CheckBoxState.MixedNormal: element = VisualStyleElement.Button.CheckBox.MixedNormal; break;
            case CheckBoxState.MixedHot: element = VisualStyleElement.Button.CheckBox.MixedHot; break;
            case CheckBoxState.MixedPressed: element = VisualStyleElement.Button.CheckBox.MixedPressed; break;
            case CheckBoxState.MixedDisabled: element = VisualStyleElement.Button.CheckBox.MixedDisabled; break;

            default: element = VisualStyleElement.Button.CheckBox.CheckedNormal; break;
          }

          Size cbSize = CheckBoxRenderer.GetGlyphSize(EhLibUtils.DisplayGraphicsCash, cbState);
          cbBitmap = EhLibUtils.VisualStyleRendererToImage(element, new Rectangle(0, 0, cbSize.Width, cbSize.Height)) as Bitmap;
        }
        else
        {

          Size cbSize = CheckBoxRenderer.GetGlyphSize(EhLibUtils.DisplayGraphicsCash, cbState);
          cbBitmap = new Bitmap(cbSize.Width, cbSize.Height);

          using (Graphics offscreen = Graphics.FromImage(cbBitmap))
          {
            offscreen.Clear(Color.Transparent);
            CheckBoxRenderer.DrawCheckBox(offscreen, new Point(0, 0), cbState);
          }
        }

        cachedBimaps[(int)cbState] = cbBitmap;
      }

      return cbBitmap;
    }

    public virtual void DrawCheckBox(Graphics g, Rectangle bounds, CheckBoxState state)
    {
      Rectangle chRect = Rectangle.Empty;
      Bitmap cdImage = GetCheckboxBitmap(state);
      //Size cbSize = CheckBoxRenderer.GetGlyphSize(g, state);
      chRect.Size = cdImage.Size;
      chRect = EhLibUtils.RectCenter(chRect, bounds);

      g.DrawImage(cdImage, chRect);
    }

    public virtual Size GetGlyphSize(Graphics g, CheckBoxState state)
    {
      Bitmap cdImage = GetCheckboxBitmap(state);
      return cdImage.Size;
    }

  }

  /// <summary>
  ///   Provides methods used to render a option button control with or without visual styles.
  ///   The class can be inherited and assign to <see cref="EhLibRenderManager.RadioButtonRenderer"/>.
  /// </summary>
  public class EhLibRadioButtonRenderer
  {
    private Bitmap[] cachedBimaps;

    public EhLibRadioButtonRenderer()
    {
      int size = (int)RadioButtonState.CheckedDisabled + 1;
      cachedBimaps = new Bitmap[size];
    }

    public virtual Bitmap GetRadioButtonBitmap(RadioButtonState cbState)
    {
      Bitmap cbBitmap = cachedBimaps[(int)cbState];
      if (cbBitmap == null)
      {
        if (ToolStripManager.VisualStylesEnabled)
        {
          VisualStyleElement element;

          switch (cbState)
          {
            case RadioButtonState.UncheckedNormal: element = VisualStyleElement.Button.RadioButton.UncheckedNormal; break;
            case RadioButtonState.UncheckedHot: element = VisualStyleElement.Button.RadioButton.UncheckedHot; break;
            case RadioButtonState.UncheckedPressed: element = VisualStyleElement.Button.RadioButton.UncheckedPressed; break;
            case RadioButtonState.UncheckedDisabled: element = VisualStyleElement.Button.RadioButton.UncheckedDisabled; break;

            case RadioButtonState.CheckedNormal: element = VisualStyleElement.Button.RadioButton.CheckedNormal; break;
            case RadioButtonState.CheckedHot: element = VisualStyleElement.Button.RadioButton.CheckedHot; break;
            case RadioButtonState.CheckedPressed: element = VisualStyleElement.Button.RadioButton.CheckedPressed; break;
            case RadioButtonState.CheckedDisabled: element = VisualStyleElement.Button.RadioButton.CheckedDisabled; break;

            default: element = VisualStyleElement.Button.RadioButton.CheckedNormal; break;
          }

          Size cbSize = RadioButtonRenderer.GetGlyphSize(EhLibUtils.DisplayGraphicsCash, cbState);
          cbBitmap = EhLibUtils.VisualStyleRendererToImage(element, new Rectangle(0, 0, cbSize.Width, cbSize.Height)) as Bitmap;
        }
        else
        {
          Size cbSize = RadioButtonRenderer.GetGlyphSize(EhLibUtils.DisplayGraphicsCash, cbState);
          cbBitmap = new Bitmap(cbSize.Width, cbSize.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

          using (Graphics offscreen = Graphics.FromImage(cbBitmap))
          {
            //offscreen.Clear(Color.Transparent);
            //offscreen.Clear(Color.FromArgb(0, 0, 0, 0));
            RadioButtonRenderer.DrawRadioButton(offscreen, new Point(0, 0), cbState);
          }
        }

        cachedBimaps[(int)cbState] = cbBitmap;
      }

      return cbBitmap;
    }

    public virtual void DrawRadioButton(Graphics g, Rectangle bounds, RadioButtonState state)
    {
      Rectangle chRect = Rectangle.Empty;
      Bitmap cdImage = GetRadioButtonBitmap(state);
      chRect.Size = cdImage.Size;
      chRect = EhLibUtils.RectCenter(chRect, bounds);

      g.DrawImage(cdImage, chRect);
    }

    public virtual Size GetGlyphSize(Graphics g, RadioButtonState state)
    {
      Bitmap cdImage = GetRadioButtonBitmap(state);
      return cdImage.Size;
    }

  }

  /// <summary>
  ///   Provides methods used to render a option button control with or without visual styles.
  ///   The class can be inherited and assign to <see cref="EhLibRenderManager.RadioButtonRenderer"/>.
  /// </summary>
  public class EhLibPushButtonRenderer
  {

    public EhLibPushButtonRenderer()
    {
    }

    public static VisualStyleElement ButtonElementByButtonState(PushButtonState state)
    {
      switch (state)
      {
        case PushButtonState.Normal: return VisualStyleElement.Button.PushButton.Normal;
        case PushButtonState.Hot: return VisualStyleElement.Button.PushButton.Hot;
        case PushButtonState.Pressed: return VisualStyleElement.Button.PushButton.Pressed;
        case PushButtonState.Disabled: return VisualStyleElement.Button.PushButton.Disabled; 
        case PushButtonState.Default: return VisualStyleElement.Button.PushButton.Default;
      }
      return VisualStyleElement.Button.PushButton.Normal;
    }

    public virtual Bitmap GetPushButtonBitmap(PushButtonState state, Size size)
    {
      Bitmap cbBitmap;

      if (ToolStripManager.VisualStylesEnabled)
      {
        VisualStyleElement element = ButtonElementByButtonState(state);

        cbBitmap = EhLibUtils.VisualStyleRendererToImage(element, new Rectangle(0, 0, size.Width, size.Height)) as Bitmap;
      }
      else
      {
        cbBitmap = new Bitmap(size.Width, size.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

        using (Graphics offscreen = Graphics.FromImage(cbBitmap))
        {
          ButtonRenderer.DrawButton(offscreen, new Rectangle(0, 0, size.Width, size.Height), state);
        }
      }

      return cbBitmap;
    }

    public virtual void DrawButton(Graphics g, Rectangle bounds, PushButtonState state)
    {
      ButtonRenderer.DrawButton(g, bounds, state);
    }

    public virtual void DrawButton(GraphicsContext gc, Rectangle bounds, PushButtonState state)
    {
      if (gc.DeviceType == GraphicsContextDeviceType.Display)
      {
        DrawButton(gc.Graphics, bounds, state);
      }
      else
      {
        Bitmap cdImage = GetPushButtonBitmap(state, bounds.Size);
        gc.Graphics.DrawImage(cdImage, bounds);
      }
    }

  }

}
