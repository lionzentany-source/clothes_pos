﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace EhLib.WinForms
{

  /// <summary>
  /// Internal DataSource that is binded to the external DataSource and restrict list of 
  /// items by the filters applyed in the DataGridEh. 
  /// </summary>
  /// <remarks>
  /// You can retrieve an instance of this class through the <see cref="DataGridEh.DataView"/> property.
  /// You can use <see cref="DataGridEh.DataView"/> as same data as the DataSource assigned in the DataGridEh 
  /// but with the list of items restricted by the filters applyed in the DataGrid.
  /// For example, <see cref="DataGridEh.DataView"/> property can be assigned to 
  /// <see cref="System.Windows.Forms.BindingNavigator.BindingSource"/> property to make visible 
  /// the same number of records that can be seen in the DataGridEh, taking into account filters.
  /// </remarks>
  public class DataGridDataView : IBindingList, IList, ICollection, IEnumerable
  {
    DataGridEh grid;
    ListChangedEventHandler listChanged;

    public DataGridDataView(DataGridEh grid)
    {
      this.grid = grid;
    }

    public DataGridEh Grid
    {
      get { return grid; }
    }

    public object this[int index]
    {
      get
      {
        return grid.VisibleRows[index];
      }
      set
      {
        throw new NotSupportedException("set is not supported");
      }
    }

    public bool AllowNew
    {
      get { return Grid.AllowedOperations.AllowAdd; }
    }

    public bool AllowEdit
    {
      get { return false; }
    }

    public bool AllowRemove
    {
      get { return Grid.AllowedOperations.AllowRemove; }
    }

    public bool SupportsChangeNotification
    {
      get { return true; }
    }

    public bool SupportsSearching
    {
      get { return false; }
    }

    public bool SupportsSorting
    {
      get { return false; }
    }

    public bool IsSorted
    {
      get { return false; }
    }

    public PropertyDescriptor SortProperty
    {
      get { return null; }
    }

    public ListSortDirection SortDirection
    {
      get { return ListSortDirection.Ascending; }
    }

    public bool IsReadOnly
    {
      get { return Grid.ReadOnly; }
    }

    public bool IsFixedSize
    {
      get { return false; }
    }

    public int Count
    {
      get { return grid.VisibleRows.Count; }
    }

    public object SyncRoot
    {
      get { return null; }
    }

    public bool IsSynchronized
    {
      get { return true; }
    }

    public event ListChangedEventHandler ListChanged
    {
      add { listChanged += value; }
      remove { listChanged -= value; }
    }

    public int Add(object value)
    {
      throw new NotImplementedException();
    }

    public void AddIndex(PropertyDescriptor property)
    {
      throw new NotImplementedException();
    }

    public object AddNew()
    {
      Grid.EditActions.MoveCurrentToNewRow();
      return Grid.CurrentRow;
    }

    public void ApplySort(PropertyDescriptor property, ListSortDirection direction)
    {
      throw new NotImplementedException();
    }

    public void Clear()
    {
      throw new NotImplementedException();
    }

    public bool Contains(object value)
    {
      throw new NotImplementedException();
    }

    public void CopyTo(Array array, int index)
    {
      throw new NotImplementedException();
    }

    public int Find(PropertyDescriptor property, object key)
    {
      throw new NotImplementedException();
    }

    public IEnumerator GetEnumerator()
    {
      return grid.VisibleRows.GetEnumerator();
    }

    public int IndexOf(object value)
    {
      throw new NotImplementedException();
    }

    public void Insert(int index, object value)
    {
      throw new NotImplementedException();
    }

    public void Remove(object value)
    {
      throw new NotImplementedException();
    }

    public void RemoveAt(int index)
    {
      if (Grid.DataViewBindingSource.Position == index)
        Grid.DataLink.DeleteCurrent();
      else
        throw new NotImplementedException();
    }

    public void RemoveIndex(PropertyDescriptor property)
    {
      throw new NotImplementedException();
    }

    public void RemoveSort()
    {
      throw new NotImplementedException();
    }

    internal void FireEvent(ListChangedEventArgs e)
    {
      if (listChanged != null)
        listChanged(this, e);
    }
  }

}
