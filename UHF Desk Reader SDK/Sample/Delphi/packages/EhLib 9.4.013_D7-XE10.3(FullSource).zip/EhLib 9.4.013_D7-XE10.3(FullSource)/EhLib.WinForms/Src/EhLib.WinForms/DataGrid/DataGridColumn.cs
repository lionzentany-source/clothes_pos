﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  //  public delegate void DataGridColumnWidthChangedEventHandler(object sender, EventArgs e);

  public enum DataGridColumnFrozenState
  {
    None, ToLeftSide, ToRightSide
  }

  /// <summary>
  /// Represents a column in a <see cref = "DataGridEh" /> control.
  /// </summary>
  /// <remarks>
  /// The DataGridColumn class represents a logical column in a DataGridEh control.
  /// 
  /// You can retrieve columns through the Columns collection of the control.
  /// 
  /// Unlike a <see cref="EhLib.WinForms.DataGridRow"/>, which matches the items in the DataSource list,
  /// DataGridColumn is used mainly to adjust the appearance and 
  /// behavior of the column user interface (UI), such as column width and cell format.
  /// </remarks>
  [Designer("EhLib.WinForms.Design.DataGridColumnDesigner" + EhLibUtils.EhLibDesignDesignerVersionInfo)]
  [DesignerCategory("Code")]
  [TypeConverter(typeof(ExpandableObjectConverter))]
  [DesignTimeVisible(false)]
  [ToolboxItem(false)]
  [DataGridColumnDesignTimeVisible(true)]
  public class DataGridColumn : PropertyAxisBar, IGridLineHost, IMultiTitleNodeProvider
  {

    #region private consts
    private static readonly object EventKeyDataCellDisplayValueNeeded = new object();

    private static readonly object EventKeyColumnWidthChanged = new object();

    private static readonly object EventKeyDataCellManagerNeeded = new object();
    private static readonly object EventKeyDataCellPullValue = new object();
    private static readonly object EventKeyDataCellPushValue = new object();
    private static readonly object EventKeyDataCellValuesAreDuplicatesStateNeeded = new object();
    private static readonly object EventKeyDataCellFormatParamsNeeded = new object();

    private static readonly object EventKeyDataCellPaint = new object();
    private static readonly object EventKeyDataCellCustomAreaPaint = new object();
    private static readonly object EventKeyDataCellContentPaint = new object();

    private static readonly object EventKeyDataCellMouseDown = new object();
    private static readonly object EventKeyDataCellMouseMove = new object();
    private static readonly object EventKeyDataCellMouseUp = new object();
    private static readonly object EventKeyDataCellMouseClick = new object();
    private static readonly object EventKeyDataCellMouseDoubleClick = new object();
    private static readonly object EventKeyDataCellMouseEnter = new object();
    private static readonly object EventKeyDataCellMouseLeave = new object();
    private static readonly object EventKeyDataCellMouseHover = new object();
    private static readonly object EventKeyDataCellContentClick = new object();

    private static readonly object EventKeyDataCellCanModifyStateNeeded = new object();
    private static readonly object EventKeyDataCellCanShowEditorStateNeeded = new object();
    private static readonly object EventKeyDataCellEditorParamsNeeded = new object();
    private static readonly object EventKeyDataCellEditValueNeeded = new object();
    private static readonly object EventKeyDataCellParseValue = new object();
    private static readonly object EventKeyDataCellEditorOccupy = new object();
    private static readonly object EventKeyDataCellEditorRelease = new object();

    private static readonly object EventKeyDataCellToolTipInfo = new object();
    private static readonly object EventKeyDataCellContextMenuStripNeeded = new object();
    private static readonly object EventKeyDataCellClientAreaNeeded = new object();
    private static readonly object EventKeyDataCellOptimalWidthNeeded = new object();
    #endregion

    #region privates
    private int defaultWidth = 64;
    private readonly DataGridColumnFooter footer;
    private int width = -1;

    private readonly DataGridColumnRowCells rowCells;
    private int minWidth;
    private int maxWidth;

    //private Color backColor = Color.Empty;
    private DataGridColumnFrozenState frozen = DataGridColumnFrozenState.None;
    private readonly GridLine vertLine;
    //private DataGridColumnTitle title;

    internal bool WidthStored;
    internal bool SelectedInternal;
    internal float FillWeightInternal = 100;
    internal bool OmitFromWidthCalculation;
    private bool mergeDuplicates;
    private DataGridColumnMergeDuplicatesList mergeDuplicatesList;

    private bool cacheDisplayValuesStored = false;
    private bool cacheDisplayValues;
    private readonly List<ValueDisplayValuePair> listValuesCacheList;
    private readonly PropAxisBarListValuesCache listValuesCache;
    #endregion

    public DataGridColumn()
    {
      footer = new DataGridColumnFooter(this);
      rowCells = new DataGridColumnRowCells(this);
      vertLine = new GridLine(this);
      listValuesCacheList = new List<ValueDisplayValuePair>();
      listValuesCache = new PropAxisBarListValuesCache(listValuesCacheList);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        footer.Dispose();
      }

      base.Dispose(disposing);
    }

    #region design-time properties
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridColumnFooter Footer
    {
      get { return footer; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public new DataGridColumnTitle Title
    {
      get
      {
        return (DataGridColumnTitle)base.Title;
      }
    }

    public int Width
    {
      get
      {
        if (WidthStored)
          return width;
        else
          return DefaultWidth;
      }
      set
      {
        if ((WidthStored == false) || (width != value))
        {
          WidthStored = true;
          value = AdjustWidth(value);
          width = value;
          OnWidthChanged();
        }
      }
    }

    [DefaultValue(0)]
    public int MinWidth
    {
      get
      {
        return minWidth;
      }
      set
      {
        if (minWidth != value)
        {
          minWidth = value;
          if ((Grid != null) && (!Grid.InInitialization))
            width = AdjustWidth(value);
          OnWidthChanged();
        }
      }
    }

    [DefaultValue(0)]
    public int MaxWidth
    {
      get
      {
        return maxWidth;
      }
      set
      {
        if (maxWidth != value)
        {
          maxWidth = value;
          if ((Grid != null) && (!Grid.InInitialization))
            width = AdjustWidth(value);
          OnWidthChanged();
        }
      }
    }

    [DefaultValue(100F)]
    [Browsable(false)]
    public float FillWeight
    {
      get
      {
        return FillWeightInternal;
      }
      set
      {
        // ReSharper disable once CompareOfFloatsByEqualityOperator
        if (value != FillWeightInternal)
        {
          FillWeightInternal = value;
          FillWeightChanged();
        }
      }
    }

    [DefaultValue(DataGridColumnFrozenState.None)]
    public DataGridColumnFrozenState Frozen
    {
      get
      {
        return frozen;
      }

      set
      {
        if (value != frozen)
        {
          frozen = value;
          if (Grid != null)
            Grid.ColumnFrozenChanged(this, value);
        }
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridLine VertLine
    {
      get
      {
        return vertLine;
      }
    }

    [DefaultValue(false)]
    public bool MergeDuplicates
    {
      get
      {
        return mergeDuplicates;
      }
      set
      {
        if (value != mergeDuplicates)
        {
          mergeDuplicates = value;
          if (mergeDuplicates)
            MergeDuplicatesList.ListIsObsolete();
          if (Grid != null)
          {
            Grid.ColumnMergeDuplicatesChanged(this, value);
          }
        }
      }
    }

    DataGridTitleNodeType IMultiTitleNodeProvider.NodeType
    {
      get
      {
        return Title.TitleNode.NodeType;
      }
    }

    DataGridColumnTitle IMultiTitleNodeProvider.ColumnTitle
    {
      get
      {
        return GetMultiTitleColumnTitle();
      }
    }

    DataGridSuperTitle IMultiTitleNodeProvider.SuperTitle
    {
      get
      {
        return GetMultiTitleSuperTitle();
      }
    }

    [DefaultValue(null)]
    public virtual ContextMenuStrip ContextMenuStrip
    {
      get { return InternalCellManager.ContextMenuStrip; }
      set { InternalCellManager.ContextMenuStrip = value; }
    }

    //public Font Font
    //{
    //  get { return DataCell.Font; }
    //  set { DataCell.Font = value; }
    //}

    /// <summary>
    /// Gets or sets a value indicating whether the user can change value in the column's cells.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1716:IdentifiersShouldNotMatchKeywords", MessageId = "ReadOnly")]
    [DefaultValue(false)]
    public virtual bool ReadOnly
    {
      get { return InternalCellManager.ReadOnly; }
      set { InternalCellManager.ReadOnly = value; }
    }

    /// <summary>
    /// Contains properties that specify how column's cells calculate the cell height for every row.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridRowHeightOptions HeightOptions
    {
      get
      {
        return InternalCellManager.HeightOptions;
      }
    }
    #endregion

    #region >events
    /// <summary>
    /// Occurs when the grid request the display value for the date cell position specified by Column and Row
    /// </summary>
    public event EventHandler<DataGridDataCellDisplayValueNeededEventArgs> DataCellDisplayValueNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellDisplayValueNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellDisplayValueNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell in the grid data area needs to be drawn.
    /// </summary>
    public event EventHandler<DataGridDataCellPaintEventArgs> DataCellPaint
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellPaint, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellPaint, value);
      }
    }

    /// <summary>
    /// Occurs when a cell content in the grid data call needs to be drawn.
    /// </summary>
    public event EventHandler<DataGridDataCellContentPaintEventArgs> DataCellContentPaint
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellContentPaint, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellContentPaint, value);
      }
    }

    /// <summary>
    /// Occurs when a client rectangle should be specified.
    /// The area outside the client rectangle is a custom area.
    /// </summary>
    public event EventHandler<DataGridDataCellClientAreaNeededEventArgs> DataCellClientAreaNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellClientAreaNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellClientAreaNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a custom area inside the data cell needs to be drawn.
    /// Write DataCellClientAreaNeeded event handler to specify the size of client rectangle and define custom area outside the client.
    /// </summary>
    public event EventHandler<DataGridDataCellPaintEventArgs> DataCellCustomAreaPaint
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellCustomAreaPaint, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellCustomAreaPaint, value);
      }
    }

    /// <summary>
    /// Occurs when a "data" cell paint params like BackColor, Font, etc should be specified.
    /// By default these params are assigned from column properties
    /// </summary>
    public event EventHandler<DataGridDataCellFormatParamsNeededEventArgs> DataCellFormatParamsNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellFormatParamsNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellFormatParamsNeeded, value);
      }
    }

    //Mouse
    /// <summary>
    /// Occurs when the user presses a mouse button while the mouse pointer is 
    /// within the boundaries of a "data" cell.
    /// </summary>
    public event EventHandler<DataGridDataCellMouseEventArgs> DataCellMouseDown
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseDown, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseDown, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer moves over the boundaries of a "data" cell.
    /// </summary>
    public event EventHandler<DataGridDataCellMouseEventArgs> DataCellMouseMove
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseMove, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseMove, value);
      }
    }

    /// <summary>
    /// Occurs when the user releases a mouse button while over a "data" cell.
    /// </summary>
    public event EventHandler<DataGridDataCellMouseEventArgs> DataCellMouseUp
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseUp, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseUp, value);
      }
    }

    /// <summary>
    /// Occurs whenever the user clicks anywhere on a "data" cell with the mouse.
    /// </summary>
    public event EventHandler<DataGridDataCellMouseEventArgs> DataCellMouseClick
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseClick, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseClick, value);
      }
    }

    /// <summary>
    /// Occurs when a "data" cell within the DataGridEh is double-clicked.
    /// </summary>
    public event EventHandler<DataGridDataCellMouseEventArgs> DataCellMouseDoubleClick
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseDoubleClick, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseDoubleClick, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer enters a "data" cell.
    /// </summary>
    public event EventHandler<DataGridDataCellEnterEventArgs> DataCellMouseEnter
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseEnter, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseEnter, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer leaves a "data" cell.
    /// </summary>
    public event EventHandler<DataGridDataCellLeaveEventArgs> DataCellMouseLeave
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseLeave, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseLeave, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer rests on the "data" cell.
    /// </summary>
    public event EventHandler<DataGridDataCellMouseEventArgs> DataCellMouseHover
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseHover, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseHover, value);
      }
    }

    /// <summary>
    /// Occurs when the user clicks on the content part of the data cell with the mouse or keyboard.
    /// </summary>
    /// <remarks>
    ///   This event can be used to catch the click event on the text when DataGridTextColumn.CellDataIsLink or
    ///   click on the DataGridButtonColumn
    /// </remarks>
    public event EventHandler<DataGridDataCellEventArgs> DataCellContentClick
    {
      add { this.Events.AddHandler(EventKeyDataCellContentClick, value); }
      remove { this.Events.RemoveHandler(EventKeyDataCellContentClick, value); }
    }

    //Editor
    /// <summary>
    /// Occurs when the cell editor requests and sets its readonly state.
    /// </summary>
    public event EventHandler<DataGridDataCellCanModifyStateNeededEventArgs> DataCellCanModifyStateNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellCanModifyStateNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellCanModifyStateNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when the grid is going to show the data cell editor.
    /// </summary>
    /// <remarks>
    /// Set e.CanShowEditor to false to prevent editor showing.
    /// </remarks>
    public event EventHandler<DataGridDataCellCanShowEditorStateNeededEventArgs> DataCellCanShowEditorStateNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellCanShowEditorStateNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellCanShowEditorStateNeeded, value);
      }
    }

    /// <summary>
    /// Occurs before a grid opens cell editor when a data cell editor params 
    /// such as BackColor, Font, etc should be specified.
    /// </summary>
    public event EventHandler<DataGridDataCellEditorParamsEventArgs> DataCellEditorParamsNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellEditorParamsNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellEditorParamsNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager converts datasource cell value to the value for the editor.
    /// </summary>
    public event EventHandler<DataGridDataCellEditValueNeededEventArgs> DataCellEditValueNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellEditValueNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellEditValueNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager converts a value from the editor to the value for datasource.
    /// </summary>
    public event EventHandler<DataGridDataCellParseValueEventArgs> DataCellParseValue
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellParseValue, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellParseValue, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager occupy the editor before open to show and edit value.
    /// </summary>
    /// <remarks>
    /// The grid uses a shared cell editor for the columns of same types.
    /// </remarks>
    public event EventHandler<DataGridDataCellEditorOccupyEventArgs> DataCellEditorOccupy
    {
      add
      {
        Events.AddHandler(EventKeyDataCellEditorOccupy, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellEditorOccupy, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager releases the shared editor for using in other columns.
    /// </summary>
    /// <remarks>
    /// If you changed properties or events in the DataCellEditorOccupy event handler,
    /// you should restore properties and events in this event handler.
    /// </remarks>
    public event EventHandler<DataGridDataCellEditorReleaseEventArgs> DataCellEditorRelease
    {
      add
      {
        Events.AddHandler(EventKeyDataCellEditorRelease, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellEditorRelease, value);
      }
    }

    //Other Data Cell Manager events

    /// <summary>
    /// Occurs when a cell manager requests info to show in tooltip window.
    /// </summary>
    /// <remarks>
    /// For text data, assign the text to e.ToolTipText property by the text you want to be shown in tooltip window.
    /// </remarks>
    public event EventHandler<DataGridDataCellToolTipInfoEventArgs> DataCellToolTipInfoNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellToolTipInfo, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellToolTipInfo, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager requests ContextMenuStrip before MenuStrip is shown.
    /// </summary>
    /// <remarks>
    /// Assign e.ContextMenuStrip property by the MenuStrip you want to be shown.
    /// </remarks>
    public event EventHandler<DataGridDataCellContextMenuStripNeededEventArgs> DataCellContextMenuStripNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellContextMenuStripNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellContextMenuStripNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when grid calculate cell width for specified row so that the text fits in the area of the cell.
    /// </summary>
    /// <remarks>
    /// Assign e.OptimalWidth property by the optimal calculated width. Use e.Column and e.Row properties to get cell value.
    /// </remarks>
    public event EventHandler<DataGridDataCellOptimalWidthNeededEventArgs> DataCellOptimalWidthNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellOptimalWidthNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellOptimalWidthNeeded, value);
      }
    }

    //No Data Cell Manager

    /// <summary>
    /// Occurs when the grid take value from the DataSource to draw, edit or for other needs.
    /// </summary>
    /// <remarks>
    /// Set e.Handled to true if you take value inside the event handler.
    /// </remarks>
    public event EventHandler<DataGridDataCellPullValueEventArgs> DataCellPullValue
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellPullValue, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellPullValue, value);
      }
    }

    /// <summary>
    /// Occurs when the grid write changed value from Editor to the DataSource.
    /// </summary>
    /// 
    /// <remarks>
    /// Set e.Handled to true if you write changed value inside the event handler.
    /// </remarks>
    /// 
    /// <example> 
    /// This sample shows how to save data to the Server right after user end edit cell value
    /// <code>
    ///private void DataGridEh1_DataCellPushValue(object sender, DataGridDataCellPushValueEventArgs e)
    ///{
    ///  e.PushValue(e); //Use default code to PushValue value to DataSource
    ///  dataGridEh1.EndCurrentEdit();
    ///  employeesTableAdapter.Update(allTypesTablesDataSet.Employees);
    ///  e.Handled = true;
    ///}
    /// </code>
    /// </example>
    public event EventHandler<DataGridDataCellPushValueEventArgs> DataCellPushValue
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellPushValue, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellPushValue, value);
      }
    }

    /// <summary>
    /// Occurs when the grid is going to process cell paint, mouse click or some other operations over the cell.
    /// </summary>
    /// <remarks>
    /// You can assign e.CellManager property in the handler code by the different CellManagers to display various 
    /// types of cells in the column depending on the values of the record.
    /// </remarks>
    public event EventHandler<DataGridDataCellManagerNeededEventArgs> DataCellManagerNeeded
    {
      add { this.Events.AddHandler(EventKeyDataCellManagerNeeded, value); }
      remove { this.Events.RemoveHandler(EventKeyDataCellManagerNeeded, value); }
    }

    /// <summary>
    /// Occurs when the grid calculate if two adjacent cells in the column have the same value to merge cell vertically.
    /// </summary>
    /// <remarks>
    /// Grid try to merge duplicate values when Column.MergeDuplcates is true. Set e.ValuesAreDuplicates to true 
    /// if values for Row1 and Row2 are the same.
    /// </remarks>
    public event EventHandler<DataGridValuesAreDuplicatesStateNeededEventArgs> ValuesAreDuplicatesStateNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellValuesAreDuplicatesStateNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellValuesAreDuplicatesStateNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when the width of the column is changed.
    /// </summary>
    public event EventHandler<DataGridColumnEventArgs> WidthChanged
    {
      add
      {
        this.Events.AddHandler(EventKeyColumnWidthChanged, value);
      }

      remove
      {
        this.Events.RemoveHandler(EventKeyColumnWidthChanged, value);
      }
    }
    #endregion

    #region >runtime properties
    [Browsable(false)]
    public new DataGridEh Grid
    {
      get
      {
        return (DataGridEh)base.Grid;
      }

      protected internal set
      {
        base.Grid = value;
      }
    }

    [Browsable(false)]
    public bool IsDataBound
    {
      get { return (PropDescr != null); }
    }

    [DefaultValue(false)]
    [Browsable(false)]
    public bool Selected
    {
      get
      {
        if ((Grid != null) &&
            (Grid.Selection.SelectionType == GridSelectionType.All))
          return true;
        else
          return SelectedInternal;
      }
      set
      {
        if (value != SelectedInternal)
        {
          if (Grid == null)
            SelectedInternal = value;
          else
            Grid.Selection.AddSelectedColumn(this, value);
        }
      }
    }

    [Browsable(false)]
    public DataGridColumnRowCells RowCells
    {
      get
      {
        return rowCells;
      }
    }

    /// <summary>
    /// The cell for a new virtual row.
    /// New virtual row - is a row that does not have an appropriate entry in the DatGrid.Rows collection.
    /// </summary>
    [Browsable(false)]
    public virtual BaseGridCellManager NewVirtualRowCell
    {
      get
      {
        return DefaultCellManager;
      }
    }

    [Browsable(false)]
    public virtual int DefaultWidth
    {
      get { return defaultWidth; }
      internal set { defaultWidth = value; }
    }

    [Browsable(false)]
    public bool CacheDisplayValues
    {
      get
      {
        if (cacheDisplayValuesStored)
          return cacheDisplayValues;
        else
          return DefaultCacheDisplayValues();
      }
      set
      {
        if ((cacheDisplayValuesStored == false) || (cacheDisplayValues != value))
        {
          cacheDisplayValuesStored = true;
          cacheDisplayValues = value;
          CacheDisplayValuesChanged();
        }
      }
    }

    [Browsable(false)]
    protected internal override bool DisplayValuesCached
    {
      get
      {
        return CacheDisplayValues;
      }
    }
    #endregion <runtime properties

    #region >internal fields and properties
    internal int WidthInternal
    {
      set
      {
        this.width = value;
      }
    }

    internal DataGridColumnMergeDuplicatesList MergeDuplicatesList
    {
      get
      {
        if (mergeDuplicatesList == null)
          mergeDuplicatesList = new DataGridColumnMergeDuplicatesList(this);
        return mergeDuplicatesList;
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public EditButton EditButton
    {
      get
      {
        return InternalCellManager.EditButton;
      }
      //set
      //{
      //  DataCell.EditButton = value;
      //}
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    [Editor("EhLib.WinForms.Design.InEditControlsCollectionEditor" + EhLibUtils.EhLibDesignDesignerVersionInfo, "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    //[ListBindable(false)] doesn't work here
    public EditItemControlsCollection InEditControls
    {
      get { return InternalCellManager.InEditControls; }
    }
    #endregion <internal fields and properties

    #region >Methods
    //Width
    internal bool ShouldSerializeWidth()
    {
      return (WidthStored == true);
    }

    public void ResetWidth()
    {
      WidthStored = false;
      OnWidthChanged();
    }

    private void OnWidthChanged()
    {
      if (Grid != null)
        Grid.OnColumnWidthChanged(this);

      var eh = this.Events[EventKeyColumnWidthChanged] as EventHandler<DataGridColumnEventArgs>;
      if (eh != null)
      {
        eh(this, new DataGridColumnEventArgs(this));
      }
    }

    internal virtual int CalcDefaultWidth()
    {
      int dataRowIndex;
      int rowLength;
      int rowWidth, maxRowWidth;

      SizeF sf;

      if (Grid == null) return 100;

      sf = EhLibUtils.MeasureText(EhLibUtils.DisplayGraphicsCash, "0", Grid.Font);

      rowLength = 0;
      dataRowIndex = 0;

      if (Grid.AutoSizeColumnOptions.ConsiderTitle)
        maxRowWidth = Title.CalcDefaultWidth();
      else
        maxRowWidth = EhLibUtils.MeasureText(EhLibUtils.DisplayGraphicsCash, "0", Grid.Font).Width;

      DataGridColumnAutoSizeConsiderRowsMode considerDataCell = Grid.AutoSizeColumnOptions.ConsiderRowsMode;
      int considerRowCount;
      if (considerDataCell == DataGridColumnAutoSizeConsiderRowsMode.ConsiderRowCount)
        considerRowCount = Grid.AutoSizeColumnOptions.ConsiderRowCount;
      else if (considerDataCell == DataGridColumnAutoSizeConsiderRowsMode.VisibleRows)
        considerRowCount = Grid.VisibleRowCount;
      else
        considerRowCount = Grid.Rows.Count;

      if (considerDataCell != DataGridColumnAutoSizeConsiderRowsMode.None)
      {
        foreach (DataGridRow row in Grid.VisibleRows)
        {
          int colIndex, rowIndex;

          BaseGridCellManager cell = GetRowCellManager(row);
          //cell.AreaCellPosToGridCellPos(VisibleIndex, row.VisibleIndex, out colIndex, out rowIndex);
          Grid.DataCellIndexToGridCellIndex(VisibleIndex, row.VisibleIndex, out colIndex, out rowIndex);

          BaseDataCellManager dataCell = cell as BaseDataCellManager;
          if (/*VisibleIndex >= 0 && */dataCell != null)
            rowWidth = dataCell.GetOptimalWidth(colIndex, rowIndex, VisibleIndex, row.VisibleIndex, this, row);
          else
          {
            string text = GetRowDisplayText(row);
            rowWidth = EhLibUtils.MeasureText(EhLibUtils.DisplayGraphicsCash, text, Grid.Font).Width;
          }

          if (rowWidth > maxRowWidth)
            maxRowWidth = rowWidth;
          dataRowIndex++;

          if (dataRowIndex > considerRowCount) break;
        }

      }

      if ((Grid.AutoSizeColumnOptions.MaxAutoWidth > 0) &&
          (maxRowWidth > Grid.AutoSizeColumnOptions.MaxAutoWidth))
      {
        maxRowWidth = Grid.AutoSizeColumnOptions.MaxAutoWidth;
      }

      if (maxRowWidth == 0)
        return (int)sf.Width * rowLength;
      else
        return maxRowWidth;

      //return 100;
    }

    public int AdjustWidth(int value)
    {
      if (value < MinWidth)
        value = MinWidth;
      if ((MaxWidth > 0) && (value > MaxWidth))
        value = MaxWidth;
      return value;
    }

    //IGridLineHost
    void IGridLineHost.GridLineChanged(GridLine gl)
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    protected virtual void GridLineChanged(GridLine gl)
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    bool IGridLineHost.GridLineDefaultVisible(GridLine gl)
    {
      return Grid.ColumnOptions.VertLine.Visible;
    }

    Color IGridLineHost.GridLineDefaultColor(GridLine gl)
    {
      return Grid.ColumnOptions.VertLine.Color;
    }

    DashStyle IGridLineHost.GridLineDefaultStyle(GridLine gl)
    {
      return Grid.ColumnOptions.VertLine.Style;
    }

    //Mouse
    protected internal override void HandleMouseDownEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseDown] as EventHandler<DataGridDataCellMouseEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void OnMouseDown(DataAxisGridDataCellMouseEventArgs e)
    {
      DataGridEh grid = Grid;
      DataGridRow row = e.ListItemBar as DataGridRow;

      if (grid != null &&
          grid.TreeViewArea.Visible &&
          e.AreaColIndex == 0)
      {
        Rectangle treeAreaRect = e.CellRect;
        treeAreaRect.Width = e.CustomRect.Left - e.CellRect.Left;
        treeAreaRect.Location = Point.Empty;

        if (treeAreaRect.Contains(new Point(e.InCellX, e.InCellY)))
        {
          DataGridTreeViewNodeStateNeededEventArgs nodeState = grid.TreeViewArea.GetTreeNodeState(row);
          bool nodeExpanded = nodeState.Expanded;
          grid.TreeViewArea.SetTreeNodeExpandedState(row, !nodeExpanded);
          e.Handled = true;
        }
      }
    }

    protected internal override void HandleMouseMoveEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseMove] as EventHandler<DataGridDataCellMouseEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleMouseUpEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseUp] as EventHandler<DataGridDataCellMouseEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleMouseClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseClick] as EventHandler<DataGridDataCellMouseEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleMouseDoubleClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseDoubleClick] as EventHandler<DataGridDataCellMouseEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleMouseEnterEvent(DataAxisGridDataCellEnterEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseEnter] as EventHandler<DataGridDataCellEnterEventArgs>;
      if (eh != null)
      {
        var hea = new DataGridDataCellEnterEventArgs(e);
        eh(this, hea);
      }
    }

    protected internal override void HandleMouseLeaveEvent(DataAxisGridDataCellLeaveEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseLeave] as EventHandler<DataGridDataCellLeaveEventArgs>;
      if (eh != null)
      {
        var hea = new DataGridDataCellLeaveEventArgs(e);
        eh(this, hea);
      }
    }

    protected internal override void HandleMouseHoverEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseHover] as EventHandler<DataGridDataCellMouseEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    //PullValue
    protected internal override DataAxisGridDataCellPullValueEventArgs CreatePullValueEventArgs(
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
    {
      return new DataGridDataCellPullValueEventArgs(propAxisBar, listItemBar, cellMan);
    }

    protected internal override void OnPullValue(DataAxisGridDataCellPullValueEventArgs e)
    {
      DataGridRow row = (DataGridRow)e.ListItemBar;
      e.Value = InternalGetRowValue(row);
      e.Handled = true;
    }

    protected internal override void HandlePullValueEvent(DataAxisGridDataCellPullValueEventArgs e)
    {
      var dge = (DataGridDataCellPullValueEventArgs)e;

      Grid.HandlePullValueEvent(dge);

      var eh = this.Events[EventKeyDataCellPullValue] as EventHandler<DataGridDataCellPullValueEventArgs>;
      if (eh != null)
        eh(this, dge);
    }

    //PushValue
    protected internal override DataAxisGridDataCellPushValueEventArgs CreatePushValueEventArgs(
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
    {
      return new DataGridDataCellPushValueEventArgs(propAxisBar, listItemBar, cellMan);
    }

    protected internal override void OnPushValue(DataAxisGridDataCellPushValueEventArgs e)
    {
      DataGridRow row = (DataGridRow)e.ListItemBar;

      if (PropDescr == null)
        throw new InvalidOperationException("PropDescr == null");

      if (Grid.CurrentRow == row)
        Grid.DataLink.SetCurrentRowValue(PropDescr, e.Value);
      else
        PropDescr.SetValue(row.SourceItem, e.Value);
    }

    protected internal override void HandlePushValueEvent(DataAxisGridDataCellPushValueEventArgs e)
    {
      var dge = (DataGridDataCellPushValueEventArgs)e;

      Grid.HandlePushValueEvent(dge);

      var eh = this.Events[EventKeyDataCellPushValue] as EventHandler<DataGridDataCellPushValueEventArgs>;
      if (eh != null)
        eh(this, dge);
    }

    //ToolTipInfo
    //protected internal override DataAxisGridDataCellToolTipInfoEventArgs CreateToolTipInfoEventArgs(
    //  PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
    //{
    //  return new DataGridDataCellToolTipInfoEventArgs(propAxisBar, listItemBar, cellMan);
    //}

    protected internal override void HandleDataCellToolTipInfoNeeded(DataAxisGridDataCellToolTipInfoEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellToolTipInfo] as EventHandler<DataGridDataCellToolTipInfoEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellToolTipInfoEventArgs(e);
        eh(this, ge);
      }
    }

    // DataCellContextMenuStripNeeded
    protected internal override void HandleDataCellContextMenuStripNeededEvent(DataAxisGridDataCellContextMenuStripNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellContextMenuStripNeeded] as EventHandler<DataGridDataCellContextMenuStripNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellContextMenuStripNeededEventArgs(e);
        eh(this, ge);
      }
    }

    //ValuesAreDuplicatesStateNeeded
    internal bool CheckValuesAreDuplicates(DataGridRow row1, DataGridRow row2)
    {
      var e = new DataGridValuesAreDuplicatesStateNeededEventArgs(this, row1, row2);
      ProcessValuesAreDuplicatesStateNeeded(e);
      return e.ValuesAreDuplicates;
    }

    internal void ProcessValuesAreDuplicatesStateNeeded(DataGridValuesAreDuplicatesStateNeededEventArgs e)
    {
      HandleValuesAreDuplicatesStateNeededEvent(e);
      if (!e.Handled)
        InternalOnValuesAreDuplicatesStateNeeded(e);
    }

    private void HandleValuesAreDuplicatesStateNeededEvent(DataGridValuesAreDuplicatesStateNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellValuesAreDuplicatesStateNeeded] as EventHandler<DataGridValuesAreDuplicatesStateNeededEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    internal void InternalOnValuesAreDuplicatesStateNeeded(DataGridValuesAreDuplicatesStateNeededEventArgs e)
    {
      object value1 = GetListItemBarValue(e.Row1);
      object value2 = GetListItemBarValue(e.Row2);
      e.ValuesAreDuplicates = ValuesEqual(value1, value2);
    }

    public bool ValuesEqual(object value1, object value2)
    {
      if (value1 == null && value2 != null)
        return false;
      else if (value1 != null && value2 == null)
        return false;
      else if (value1 == null && value2 == null)
        return true;
      else
        return value1.Equals(value2);
    }

    //Padding
    protected override void PaddingChanged()
    {
      if (Grid != null)
        Grid.UpdateBaseFixedBands();
    }

    //VertAlign
    public override VerticalAlignment DefaultVertAlign()
    {
      if (Grid != null)
        return Grid.ColumnOptions.VertAlign;
      else
        return VerticalAlignment.Bottom;
    }

    //ForeColor
    public override Color DefaultForeColor()
    {
      if (Grid != null)
        return Grid.ColumnOptions.ForeColor;
      else
        return SystemColors.WindowText;
    }

    //Font
    public override Font DefaultFont()
    {
      if (Grid != null)
        return Grid.ColumnOptions.Font;
      else
        return null;
    }

    protected override void FontChanged()
    {
      if (Grid != null)
        Grid.UpdateRowHeights();
    }

    //AllowShowEditor
    public override bool DefaultAllowShowEditor()
    {
      if (Grid != null)
        return Grid.ColumnOptions.AllowShowEditor;
      else
        return false;
    }

    //CanModifyStateNeeded
    //protected internal override DataAxisGridDataCellCanModifyStateNeededEventArgs CreateCanModifyStateNeededEventArgs(
    //  PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
    //{
    //  return new DataGridDataCellCanModifyStateNeededEventArgs(propAxisBar, listItemBar, cellMan);
    //}

    protected internal override void HandleCanModifyStateNeededEvent(DataAxisGridDataCellCanModifyStateNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellCanModifyStateNeeded] as EventHandler<DataGridDataCellCanModifyStateNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellCanModifyStateNeededEventArgs(e);
        eh(this, ge);
      }
    }

    //CacheDisplayValues
    protected internal void CacheDisplayValuesChanged()
    {
      CheckUpdateCachedValues();
    }

    protected virtual bool DefaultCacheDisplayValues()
    {
      if (Grid != null)
        return Grid.ColumnOptions.CacheDisplayValues;
      else
        return false;
    }

    protected virtual bool ShouldSerializeCacheDisplayValues()
    {
      return cacheDisplayValuesStored;
    }

    public void ResetCacheDisplayValues()
    {
      cacheDisplayValuesStored = false;
      CacheDisplayValuesChanged();
    }

    protected virtual void UpdateDisplayValuesCache(ValueDisplayValuePairListChangedType changeType, int sourceItemIndex)
    {
      switch (changeType)
      {
        case ValueDisplayValuePairListChangedType.Reset:
        case ValueDisplayValuePairListChangedType.MoveItem:
          listValuesCacheList.Clear();
          if (Grid != null && Grid.Rows.Count > 0)
          {
            foreach (DataGridRow row in Grid.Rows)
            {
              ValueDisplayValuePair dval = new ValueDisplayValuePair();
              UpdateDisplayValuePairForRow(row, dval);
              listValuesCacheList.Add(dval);
            }
          }
          break;

        case ValueDisplayValuePairListChangedType.AddItem:
          {
            ValueDisplayValuePair dval = new ValueDisplayValuePair();
            DataGridRow row = Grid.Rows[sourceItemIndex];

            UpdateDisplayValuePairForRow(row, dval);

            listValuesCacheList.Add(dval);
          }
          break;

        case ValueDisplayValuePairListChangedType.DeleteItem:
          {
            listValuesCacheList.RemoveAt(sourceItemIndex);
          }
          break;

        case ValueDisplayValuePairListChangedType.ChangeItem:
          {
            ValueDisplayValuePair dval = listValuesCacheList[sourceItemIndex];
            DataGridRow row = Grid.Rows[sourceItemIndex];
            UpdateDisplayValuePairForRow(row, dval);
          }
          break;
        default:
          break;
      }
    }

    protected virtual void UpdateDisplayValuePairForRow(DataGridRow row, ValueDisplayValuePair dval)
    {
      dval.Value = GetRowValue(row);

      BaseGridCellManager cell = InternalGetRowCellManager(row);
      BaseDataCellManager dataCell = (cell as BaseDataCellManager);
      if (dataCell != null)
      {
        DataAxisGridDataCellDisplayValueNeededEventArgs e = dataCell.CreateDisplayValueNeededEventArgs(this, row, dval.Value);
        dataCell.ProcessDisplayValueNeeded(e);
        dval.DisplayValue = e.DisplayValue;
      }
      else
      {
        dval.DisplayValue = null;
      }
    }

    public override object GetCachedDisplayValue(object listItem)
    {
      DataGridRow row = listItem as DataGridRow;
      int index = row.Index;
      if (index < listValuesCache.Count)
      {
        ValueDisplayValuePair pair = listValuesCache[index];
        return pair.DisplayValue;

      }
      else
        return null;
    }

    //CurrencyManagerChanged
    protected void CheckUpdateCachedValues()
    {
      if (DisplayValuesCached)
        UpdateDisplayValuesCache(ValueDisplayValuePairListChangedType.Reset, -1);
      else
        listValuesCacheList.Clear();
    }

    private void CheckUpdateCachedValuesInDataChanged(object sender, ListChangedEventArgs e)
    {
      if (DisplayValuesCached)
      {
        switch (e.ListChangedType)
        {
          case ListChangedType.Reset:
            UpdateDisplayValuesCache(ValueDisplayValuePairListChangedType.Reset, -1);
            break;

          case ListChangedType.ItemMoved:
            UpdateDisplayValuesCache(ValueDisplayValuePairListChangedType.Reset, -1);
            break;

          case ListChangedType.ItemAdded:
            UpdateDisplayValuesCache(ValueDisplayValuePairListChangedType.AddItem, e.NewIndex);
            break;

          case ListChangedType.ItemChanged:
            UpdateDisplayValuesCache(ValueDisplayValuePairListChangedType.ChangeItem, e.NewIndex);
            break;

          case ListChangedType.ItemDeleted:
            UpdateDisplayValuesCache(ValueDisplayValuePairListChangedType.DeleteItem, e.NewIndex);
            break;

          default:
            UpdateDisplayValuesCache(ValueDisplayValuePairListChangedType.Reset, -1);
            break;
        }
      }
      else
      {
        listValuesCacheList.Clear();
      }
    }

    //Other
    protected override void PropDescrChanged()
    {
      if (Grid != null && !Grid.InInitialization)
      {
        RaiseCurrencyManagerChangedEvent();
      }
    }

    public void RaiseCurrencyManagerChangedEvent()
    {
      var ce = new ListChangedEventArgs(ListChangedType.Reset, -1);
      CurrencyManagerChanged(null, ce);
    }

    public void SetRowValue(DataGridRow row, object value)
    {
      SetValue(row, value);
    }

    protected internal override void HandleParseValueEvent(DataAxisGridDataCellParseValueEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellParseValue] as EventHandler<DataGridDataCellParseValueEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellParseValueEventArgs(e);
        eh(this, ge);
      }
    }

    protected override DataAxisGridBarTitle CreateDataAxisGridBarTitle()
    {
      return new DataGridColumnTitle(this);
    }

    protected override void GridChanged()
    {
      base.GridChanged();
      InternalCellManager.BoundGrid = Grid;
      UpdateDefaultPadding();
      UpdateFooterList();
      if (Grid != null && !Grid.InInitialization && DataValueSourceActive)
        RaiseCurrencyManagerChangedEvent();
    }

    public override BaseGridCellManager GetDataCellManager(DataAxisGridListItemBar listItemBar)
    {
      return GetRowCellManager((DataGridRow)listItemBar);
    }

    public BaseGridCellManager GetRowCellManager(DataGridRow row)
    {
      return InternalGetRowCellManager(row);
    }

    public BaseDataCellManager GetRowDataCellManager(DataGridRow row)
    {
      return GetRowCellManager(row) as BaseDataCellManager;
    }

    protected internal BaseGridCellManager InternalGetRowCellManager(DataGridRow row)
    {
      DataGridDataCellManagerNeededEventArgs e = new DataGridDataCellManagerNeededEventArgs(this, row);
      OnGetRowCellManager(e);
      if (e.CellManager == null)
        e.CellManager = Grid.EmptyDataCell;
      return e.CellManager;
    }

    protected virtual void OnGetRowCellManager(DataGridDataCellManagerNeededEventArgs e)
    {
      Grid.HandleDataCellManagerNeededEvent(e);

      var eh = this.Events[EventKeyDataCellManagerNeeded] as EventHandler<DataGridDataCellManagerNeededEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }

      if (e.CellManager == null)
        e.CellManager = DefaultCellManager;
    }

    protected virtual void FillWeightChanged()
    {
      if (Grid != null)
        Grid.UpdateFitColWidthsToClient();
    }

    internal void DataPropertyNameChanged()
    {
      if (Grid != null)
        Grid.UpdateColumnsList();
    }

    protected internal virtual void GridFooterAdded(DataGridFooterRow footerRow, int index)
    {
      //DataGridColumnFooterItem colFooter = new DataGridColumnFooterItem
      //{
      //  Column = this,
      //  //FooterRow = footerRow
      //};
      //DataGridColumnFooterItem colFooter = null;

      if (index == Footer.Items.Count)
        Footer.Items.Add(null);
      else
        Footer.Items.Insert(index, null);
    }

    protected internal virtual void GridFooterRemoved(DataGridFooterRow footerRow, int index)
    {
      Footer.Items.RemoveAt(index);
    }

    internal void GridFooterRowMoved(int oldIndex, int newIndex)
    {
      DataGridColumnFooterItem footerItem = Footer.Items[oldIndex];
      Footer.Items.RemoveAt(oldIndex);
      Footer.Items.Insert(newIndex, footerItem);
    }

    protected internal void UpdateFooterList()
    {
      if (Grid == null) return;
      if (Grid.InInitialization) return;

      if (Footer.Items.Count < Grid.Footer.Rows.Count)
      {
        for (int i = Footer.Items.Count; i < Grid.Footer.Rows.Count; i++)
          GridFooterAdded(Grid.Footer.Rows[i], i);
      }
      else if (Footer.Items.Count > Grid.Footer.Rows.Count)
      {
        for (int i = Footer.Items.Count-1; i >= Grid.Footer.Rows.Count; i--)
          GridFooterRemoved(null, i);
      }

      for(int i = 0; i < Grid.Footer.Rows.Count; i++)
      {
        DataGridColumnFooterItem fi = Footer.Items[i];
        if (fi != null)
          fi.FooterRowInternal = Grid.Footer.Rows[i];
      }
    }

    protected internal virtual int CalcDefaultRowHeight()
    {
      int th;
      Font font = Font;
      if (font != null)
      {
        if (HeightOptions.Unit == GridRowHeightUnit.TextLine)
          th = EhLibUtils.GetFontHeight(Font) * HeightOptions.ContentHeight;
        else
          th = HeightOptions.ContentHeight;
      }
      else
      {
        th = 16;
      }
      th = th + Padding.Top + Padding.Bottom;
      return th;
    }

    protected internal virtual int CalcRowHeight(DataGridRow row)
    {
      BaseGridCellManager cell = GetRowCellManager(row);
      BaseDataCellManager dataCell = cell as BaseDataCellManager;
      if (dataCell != null)
        return dataCell.ProcessCalcCellHeight(this, row, Width);
      else
        return CalcDefaultRowHeight();
    }

    public virtual Collection<KeyDisplayValue> GetUniqueStringListValues()
    {
      var srcVals = new List<object>();
      var resVals = new List<KeyDisplayValue>();
      var resColl = new Collection<KeyDisplayValue>();
      object ats;

      Collection<DataGridColumn> fList = Grid.Title.Filter.GetFilterList(this);

      foreach (DataGridRow row in Grid.Rows)
      {
        if (Grid.Title.Filter.RowMatchColumnsFilter(row, fList))
          srcVals.Add(GetRowValue(row));
      }

      srcVals.Sort(EhLibUtils.DBCompareValues);

      if (srcVals.Count == 0)
        return resColl;

      ats = srcVals[0];
      resVals.Add(new KeyDisplayValue(ats, GetValueDisplayText(ats)));

      for (int i = 1; i < srcVals.Count; i++)
      {
        if (EhLibUtils.DBCompareValues(ats, srcVals[i])  != 0)
        {
          ats = srcVals[i];
          resVals.Add(new KeyDisplayValue(ats, GetValueDisplayText(ats)));
        }
      }

      resVals.Sort(CompareKeyDisplayValues);

      foreach (KeyDisplayValue v in resVals)
        resColl.Add(v);

      return resColl;
    }

    public override Collection<object> GetEditUniqueValues()
    {
      var srcVals = new List<object>();
      var resVals = new Collection<object>();

      foreach (DataGridRow row in Grid.Rows)
      {
        srcVals.Add(GetRowValue(row));
      }

      srcVals.Sort(EhLibUtils.DBCompareValues);

      if (srcVals.Count == 0)
        return null;

      object ats = srcVals[0];
      resVals.Add(ats);

      for (int i = 1; i < srcVals.Count; i++)
      {
        if (EhLibUtils.DBCompareValues(ats, srcVals[i]) != 0)
        {
          ats = srcVals[i];
          resVals.Add(ats);
        }
      }

      return resVals;
    }

    protected virtual int CompareKeyDisplayValues(KeyDisplayValue x, KeyDisplayValue y)
    {
      return EhLibUtilsInternal.DBCompareValues(x.KeyValue, y.KeyValue);
    }

    public virtual object GetRowValue(DataGridRow row)
    {
      return GetListItemBarValue(row);
    }

    public virtual object GetSortingRowValue(DataGridRow row)
    {
      return GetListItemBarSortingValue(row);
    }

    protected virtual object InternalGetRowValue(DataGridRow row)
    {
      if (DataValueSource == DataValueSource.ListItem && row != null)
      {
        return row.SourceItem;
      }
      else if (PropDescr == null || row == null)
      {
        return null;
      }
      else
      {
        object srcRow = row.SourceItem;
        return PropDescr.GetValue(srcRow);
      }
    }

    //private string GetDirectRowDisplayText(DataGridRow row)
    //{
    //  //object srcRow = row.srcRow;
    //  if (row == null) return null;

    //  object value = GetRowValue(row);
    //  return GetValueDisplayText(value);
    //}

    public string GetValueDisplayText(object value)
    {
      return DefaultCellManager.GetValueDisplayText(this, value);
    }

    public virtual object ParseValue(object formattedValue)
    {
      DataGridRow dataRow;

      if (Grid.Rows.Count > 0)
        dataRow = Grid.Rows[0];
      else
        dataRow = null;

      return ParseValue(dataRow, formattedValue);
    }

    public override void Invalidate()
    {
      if (Grid != null)
        Grid.InvalidateGrid();
    }

    public virtual string GetRowDisplayText(DataGridRow row)
    {
      BaseGridCellManager cell = InternalGetRowCellManager(row);
      BaseDataCellManager dataCell = (cell as BaseDataCellManager);
      if (dataCell != null)
        return dataCell.GetDisplayText(this, row);
      else
        return cell.GetDisplayText(Grid, VisibleIndex, row.VisibleIndex);
    }

    public virtual ContextMenuStrip GetContextMenuStripAtRow(DataGridRow row)
    {
      BaseDataCellManager dataCellMan = GetRowDataCellManager(row);
      if (dataCellMan != null)
        return dataCellMan.ContextMenuStrip;
      else
        return null;
    }

    public virtual bool CanModifyValueAtRow(DataGridRow row)
    {
      BaseDataCellManager dataCellMan = GetRowDataCellManager(row);
      if (dataCellMan != null)
        return !dataCellMan.ReadOnly;
      else
        return false;
    }

    protected internal override void OnDataCellContentClick(DataAxisGridDataCellEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellContentClick] as EventHandler<DataGridDataCellEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellEventArgs(e);
        eh(this, ge);

        //eh(this, (DataGridDataCellEventArgs)e);
      }
    }

    DataGridTitleNode IMultiTitleNodeProvider.GetNode()
    {
      //if (Title.TitleNode.Parent == null)
      //  return null;
      //else
      return Title.TitleNode;
    }

    public DataGridColumnTitle GetMultiTitleColumnTitle()
    {
      return Title.TitleNode.ColumnTitle;
    }

    public DataGridSuperTitle GetMultiTitleSuperTitle()
    {
      return Title.TitleNode.SuperTitle;
    }

    protected internal override void UpdatedInList()
    {
      base.UpdatedInList();
      UpdateFooterList();
    }

    protected internal virtual void StartCellRectSelectionMode(BaseGridCellMouseEventArgs e)
    {
      Grid.StartCellRectSelectionMode(e.GridMouseArgs);
    }

    protected internal override void CellFontChanged()
    {
      if (Grid != null)
        Grid.UpdateRowHeights();
    }

    protected internal override void RowHeightAutoExpandChanged()
    {
      if (Grid != null)
        Grid.RowHeightAutoExpandChanged();
    }

    public override bool HeightOptionsDefaultAutoExpand(GridRowHeightOptions heightOptions)
    {
      if (Grid != null)
        return Grid.RowOptions.HeightOptions.AutoExpand;
      else
        return false;
    }

    public override int HeightOptionsDefaultContentHeight(GridRowHeightOptions heightOptions)
    {
      if (Grid != null)
        return Grid.RowOptions.HeightOptions.ContentHeight;
      else
        return 1;
    }

    public override int HeightOptionsDefaultMaxContentHeight(GridRowHeightOptions heightOptions)
    {
      if (Grid != null)
        return Grid.RowOptions.HeightOptions.MaxContentHeight;
      else
        return 0;
    }

    public override GridRowHeightUnit HeightOptionsDefaultUnit(GridRowHeightOptions heightOptions)
    {
      if (Grid != null)
        return Grid.RowOptions.HeightOptions.Unit;
      else
        return GridRowHeightUnit.TextLine;
    }

    protected internal override void HandleDataCellPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellPaint] as EventHandler<DataGridDataCellPaintEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellPaintEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellContentPaintEvent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellContentPaint] as EventHandler<DataGridDataCellContentPaintEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellContentPaintEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellCustomAreaPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellCustomAreaPaint] as EventHandler<DataGridDataCellPaintEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellPaintEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void PaintCellBackground(BaseDataCellManager cellMan, DataAxisGridDataCellPaintEventArgs e)
    {
      Color baseColor = e.BackColor;
      int alpha = 255;
      bool drawSelection = false;


      if (Grid.Background.Visible && baseColor == Grid.BackColor)
      {
        // Paint nothing
      }
      else
      {
        if (Grid.Background.Visible && baseColor.A == 255)
          baseColor = Color.FromArgb(Grid.Background.GridOpacityOptions.CellsOpacity, baseColor);

        e.BackFilledColor = baseColor;
        using (SolidBrush fillBrush = new SolidBrush(baseColor))
        {
          Grid.PaintingFillRectangle(e.Graphics, fillBrush, e.ClientRect);
        }
      }

      Rectangle selectionRect = e.ClientRect;

      if ((Grid.Selection.SelectionType != GridSelectionType.None))
      {
        if (((BasePaintCellStates.Current & e.State) != 0) ||
            ((BasePaintCellStates.RowSelected & e.State) != 0))
        {
          if (Grid.Background.Visible)
            alpha = Grid.Background.GridOpacityOptions.FocusCellOpacity;
          else
            alpha = 255;
          if (Grid.Selection.AlwaysShowSelection || Grid.IsActiveControl())
            drawSelection = true;
        }
        else if ((BasePaintCellStates.Selected & e.State) != 0)
        {
          //alpha = 255 / 6;
          //drawSelection = true;
          Grid.DrawStyle.DataSelectionRenderer.DrawSelectionRectangle(
            e.Graphics, e.ClientRect, Grid.IsActiveControl(), false, alpha);
        }
      }
      else if (((BasePaintCellStates.Current & e.State) != 0) ||
                ((BasePaintCellStates.RowSelected & e.State) != 0))
      {
        if (Grid.Background.Visible)
          alpha = Grid.Background.GridOpacityOptions.FocusCellOpacity;
        else
          alpha = 255;
        if (Grid.Selection.AlwaysShowSelection || Grid.IsActiveControl())
          drawSelection = true;

        if (((BasePaintCellStates.RowSelected & e.State) != 0) && 
            Grid.DrawStyle.DataSelectionRenderer.FocusRectangleIsTranslucent
        )
          selectionRect = e.CellAreaRect;
      }
      else if (Grid.Selection.RowHighlight &&
          ((BasePaintCellStates.Current & e.State) == 0) &&
          ((BasePaintCellStates.CurrentRow & e.State) != 0))
      {
        //alpha = 255 / 6;
        //drawSelection = true;
        if (Grid.Selection.AlwaysShowSelection || Grid.IsActiveControl())
        {
          Grid.DrawStyle.DataSelectionRenderer.DrawHighlightedRowCellRectangle(
            e.Graphics, e.ClientRect, Grid.IsActiveControl(), false, alpha);
        }
      }

      if (drawSelection)
      {
        Grid.DrawStyle.DataSelectionRenderer.DrawFocusRectangle(
          e.Graphics, selectionRect, Grid.IsActiveControl(), false, alpha, false, false);
      }
    }

    protected internal override void OnGetDataCellBorderParams(BaseGridCellBorderEventArgs e)
    {
      if (e.BorderType == GridCellBorderSide.Right || e.BorderType == GridCellBorderSide.Left)
      {
        if (e.ColIndex == Grid.FixedColCount - 1)
        {
          e.Visible = true;
          e.Color = Grid.LineOptions.DarkColor;
          e.Style = DashStyle.Solid;
        }
        else if (e.AreaColIndex < Grid.VisibleColumns.Count)
        {
          GridLine gl = Grid.VisibleColumns[e.AreaColIndex].VertLine;
          e.Visible = gl.Visible;
          e.Color = gl.Color;
          e.Style = gl.Style;
          e.IsExtent = true;
        }
      }
      else if (e.BorderType == GridCellBorderSide.Bottom)
      {
        e.Visible = Grid.RowOptions.HorzLine.Visible;
        e.IsExtent = true;
        e.Color = Grid.RowOptions.HorzLine.Color;
        e.Style = Grid.RowOptions.HorzLine.Style;

        DataGridColumn column = null;
        DataGridRow row = null;

        if (e.AreaColIndex < Grid.VisibleColumns.Count)
          column = Grid.VisibleColumns[e.AreaColIndex];
        if (e.AreaRowIndex < Grid.VisibleRows.Count)
          row = Grid.VisibleRows[e.AreaRowIndex];

        var hlpe = new DataGridHorzLineParamsNeededEventArgs(column, row)
        {
          Visible = e.Visible,
          Color = e.Color,
          Style = e.Style
        };

        Grid.OnHorzLineParamsNeeded(hlpe);

        e.Visible = hlpe.Visible;
        e.Color = hlpe.Color;
        e.Style = hlpe.Style;
      }

      if (e.Visible && Grid.Background.Visible)
        e.Color = Color.FromArgb(Grid.Background.GridOpacityOptions.LinesOpacity, e.Color);
    }

    protected internal override bool IsPaintEditItemBackground(EditItem editButton, DataAxisGridDataCellPaintEventArgs e, Rectangle itemRect)
    {

      DataGridEditItemOptions eiOpts = Grid.ColumnOptions.EditItemOptions;

      if (eiOpts.PaintBackgroundTime == DataGridCellItemPaintTime.Always)
        return true;
      else if (eiOpts.PaintBackgroundTime == DataGridCellItemPaintTime.Never)
        return false;
      else if (eiOpts.PaintBackgroundTime == DataGridCellItemPaintTime.WhenHot)
        return false;
      else if (eiOpts.PaintBackgroundTime == DataGridCellItemPaintTime.WhenAreaHot)
      {
        if (eiOpts.ActiveArea == DataGridActiveArea.Row)
          return ((e.State & BasePaintCellStates.RowHotTrack) != 0);
        else
          return ((e.State & BasePaintCellStates.HotTrack) != 0);
      }
      else if (eiOpts.PaintBackgroundTime == DataGridCellItemPaintTime.WhenAreaHotOrActive)
      {
        if (eiOpts.ActiveArea == DataGridActiveArea.Row)
          return ((e.State & BasePaintCellStates.RowHotTrack) != 0 && Grid.IsDrawHotState()) ||
                  ((e.State & BasePaintCellStates.CurrentRow) != 0);
        else
          return ((e.State & BasePaintCellStates.HotTrack) != 0) ||
                 ((e.State & BasePaintCellStates.Current) != 0);
      }
      else
        return false;
    }

    protected internal override bool IsPaintEditItemForeground(EditItem editButton, DataAxisGridDataCellPaintEventArgs e, Rectangle itemRect)
    {
      DataGridEditItemOptions eiOpts = Grid.ColumnOptions.EditItemOptions;

      if (eiOpts.PaintTime == DataGridCellItemPaintTime.Always)
        return true;
      else if (eiOpts.PaintTime == DataGridCellItemPaintTime.Never)
        return false;
      else if (eiOpts.PaintTime == DataGridCellItemPaintTime.WhenHot)
        return false;
      else if (eiOpts.PaintTime == DataGridCellItemPaintTime.WhenAreaHot)
      {
        if (eiOpts.ActiveArea == DataGridActiveArea.Row)
          return ((e.State & BasePaintCellStates.RowHotTrack) != 0);
        else
          return ((e.State & BasePaintCellStates.HotTrack) != 0);
      }
      else if (eiOpts.PaintTime == DataGridCellItemPaintTime.WhenAreaHotOrActive)
      {
        if (eiOpts.ActiveArea == DataGridActiveArea.Row)
          return ((e.State & BasePaintCellStates.RowHotTrack) != 0) ||
                 (e.RowIndex == Grid.Row);
        else
          return ((e.State & BasePaintCellStates.HotTrack) != 0) ||
                 (e.ColIndex == Grid.Col && e.RowIndex == Grid.Row);
      }
      else
        return false;
    }

    protected internal override void SpecifyPaintParams(DataAxisGridDataCellPaintEventArgs e)
    {
      if (((BasePaintCellStates.Current & e.State) != 0) ||
          ((BasePaintCellStates.RowSelected & e.State) != 0)
      )
      {
        //e.ForePaintColor = ((DataGridDataCellPaintEventArgs)e).Column.Grid.DrawStyle.DataSelectionRenderer.ForeFocusColor;
        DataGridEh grid = e.PropAxisBar.Grid as DataGridEh;
        e.ForePaintColor = grid.DrawStyle.DataSelectionRenderer.ForeFocusColor;
        if (e.ForePaintColor == Color.Empty)
          e.ForePaintColor = e.ForeColor;
      }
      else
      {
        e.ForePaintColor = e.ForeColor;
      }
    }

    protected internal override void GridCellPosToDataCellPos(int gridColIndex, int gridRowIndex, out int areaColIndex, out int areaRowIndex)
    {
      areaColIndex = gridColIndex - Grid.StartDataColIndex;
      areaRowIndex = gridRowIndex - Grid.FixedRowCount;
    }

    protected internal override void DataCellPosToGridCellPos(int areaColIndex, int areaRowIndex, out int gridColIndex, out int gridRowIndex)
    {
      gridColIndex = areaColIndex + Grid.StartDataColIndex;
      gridRowIndex = areaRowIndex + Grid.FixedRowCount;
    }

    protected internal override bool IsDataCellSelected(int dataColIndex, int dataRowIndex)
    {
      if (Grid.Selection.SelectionType == GridSelectionType.Columns)
        return Grid.VisibleColumns[dataColIndex].Selected;
      else if (Grid.Selection.SelectionType == GridSelectionType.Rows && dataRowIndex < Grid.VisibleRows.Count)
        return Grid.VisibleRows[dataRowIndex].Selected;
      else if (Grid.Selection.SelectionType == GridSelectionType.CellsBox)
        return Grid.Selection.CellsRectContains(dataColIndex, dataRowIndex);
      else if (Grid.Selection.SelectionType == GridSelectionType.All)
        return true;
      else
        return false;
    }

    protected internal override void HandleFormatParamsNeededEvent(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellFormatParamsNeeded] as EventHandler<DataGridDataCellFormatParamsNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellFormatParamsNeededEventArgs(e);
        eh(this, ge);
      }
    }

    //protected internal override GridBaseVirtualDataCellEventArgs CreateFormatParamsNeededEventArgs(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    //{
    //  return new DataGridDataCellFormatParamsNeededEventArgs(e);
    //}

    protected internal override void HandleCanShowEditorStateNeededEvent(DataAxisGridDataCellCanShowEditorStateNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellCanShowEditorStateNeeded] as EventHandler<DataGridDataCellCanShowEditorStateNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellCanShowEditorStateNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditorParamsNeededEvent(DataAxisGridDataCellEditorParamsNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellEditorParamsNeeded] as EventHandler<DataGridDataCellEditorParamsEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellEditorParamsEventArgs(e);
        eh(this, ge);
      }
    }

    //protected internal override BaseGridCellMouseEventArgs CreateDataCellMouseEventArgs(
    //  int colIndex, int rowIndex, int areaColIndex, int areaRowIndex,
    //  PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell,
    //  int inCellX, int inCellY, Rectangle cellRect, MouseEventArgs gridMouseArgs)
    //{
    //  return new DataGridDataCellMouseEventArgs(
    //    cell, colIndex, rowIndex, areaColIndex, areaRowIndex, propAxisBar, listItemBar, inCellX, inCellY, cellRect, gridMouseArgs);
    //}

    //protected internal override DataAxisGridDataCellEventArgs CreateDataCellEventArgs(DataAxisGrid grid,
    //  int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect,
    //  PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell
    //  )
    //{
    //  return new DataGridDataCellEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, propAxisBar, listItemBar, cell);
    //}

    //protected internal override DataAxisGridDataCellClientAreaNeededEventArgs CreateDataCellClientAreaNeededEventArgs(PropertyAxisBar propAxisBar,
    //    DataAxisGridListItemBar listItemBar, Rectangle cellRect, BaseDataCellManager cellMan)
    //{
    //  return new DataAxisGridDataCellClientAreaNeededEventArgs(propAxisBar, listItemBar, cellRect, cellMan);
    //}

    protected internal override void HandleDataCellClientAreaNeededEvent(DataAxisGridDataCellClientAreaNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellClientAreaNeeded] as EventHandler<DataGridDataCellClientAreaNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellClientAreaNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override DataAxisGridDataCellOptimalWidthNeededEventArgs CreateDataCellOptimalWidthNeededEventArgs(
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
    {
      return new DataGridDataCellOptimalWidthNeededEventArgs(propAxisBar, listItemBar, cellMan);
    }

    protected internal override void HandleCellOptimalWidthNeededEvent(DataAxisGridDataCellOptimalWidthNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellOptimalWidthNeeded] as EventHandler<DataGridDataCellOptimalWidthNeededEventArgs>;
      if (eh != null)
      {
        eh(this, (DataGridDataCellOptimalWidthNeededEventArgs)e);
      }
    }

    protected internal override void HandleDisplayValueNeededEvent(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellDisplayValueNeeded] as EventHandler<DataGridDataCellDisplayValueNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellDisplayValueNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditValueNeededEvent(DataAxisGridDataCellEditValueNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellEditValueNeeded] as EventHandler<DataGridDataCellEditValueNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellEditValueNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditorOccupyEvent(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
      var eh = Events[EventKeyDataCellEditorOccupy] as EventHandler<DataGridDataCellEditorOccupyEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellEditorOccupyEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditorReleaseEvent(DataAxisGridDataCellEditorReleaseEventArgs e)
    {
      var eh = Events[EventKeyDataCellEditorRelease] as EventHandler<DataGridDataCellEditorReleaseEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellEditorReleaseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void PaintDataCellServiceArea(DataAxisGridDataCellPaintEventArgs e)
    {
      DataGridEh grid = null;
      DataGridColumn column = e.PropAxisBar as DataGridColumn;
      DataGridRow row = e.ListItemBar as DataGridRow;
      //DataGridDataCellPaintEventArgs de = e as DataGridDataCellPaintEventArgs;
      DataGridDataCellPaintEventArgs de = new DataGridDataCellPaintEventArgs(e);

      if (column != null)
        grid = column.Grid;

      if (grid != null &&
          grid.TreeViewArea.Visible &&
          e.AreaColIndex == 0)
      {
        grid.TreeViewArea.PaintTreeArea(de);
      }
    }

    protected internal override Rectangle GetCellCustomRect(DataAxisGridListItemBar listItemBar, Rectangle cellRect)
    {
      //DataGridEh grid = null;
      //DataGridColumn column = propAxisBar as DataGridColumn;
      DataGridRow row = listItemBar as DataGridRow;

      //if (column != null)
      //  grid = column.Grid;

      if (Grid != null &&
          Grid.TreeViewArea.Visible &&
          VisibleIndex == 0)
      {
        Rectangle customCellRect = cellRect;
        int treeNodeAreaWidth = Grid.TreeViewArea.GetTreeNodeAreaWidth(this, row);
        customCellRect.X = customCellRect.X + treeNodeAreaWidth;
        customCellRect.Width = customCellRect.Width - treeNodeAreaWidth;
        return customCellRect;
      }
      else
      {
        return base.GetCellCustomRect(listItemBar, cellRect);
      }
    }

    protected internal virtual void RollPosChanged()
    {
    }

    protected internal virtual bool IsFullInvalidateOnVertScroll()
    {
      if (MergeDuplicates)
        return true;
      else
        return false;
    }

    protected internal virtual void CurrencyManagerChanged(object sender, ListChangedEventArgs e)
    {
      if (MergeDuplicates)
        MergeDuplicatesList.ListIsObsolete();
      CheckUpdateCachedValuesInDataChanged(sender, e);
    }

    protected internal virtual void OnVisibleRowListChanged(EventArgs e)
    {
      if (MergeDuplicates)
        MergeDuplicatesList.ListIsObsolete();
    }

    protected internal virtual bool DataRowHeightIsPermanent()
    {
      Delegate eh = this.Events[EventKeyDataCellManagerNeeded];
      if (eh != null || HeightOptions.AutoExpand)
        return false;
      else
        return true;
    }

    #endregion <Methods

  }

}
