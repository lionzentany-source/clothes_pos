﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2019 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Data;
using System.Diagnostics;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace EhLib.WinForms
{
  //public delegate void EventArgsProc<TEventArgs>(TEventArgs e) where TEventArgs : EventArgs;

  //public enum DataAxisGridDataCellFormatApplying
  //{
  //  DisplayValue, EditValue
  //}

  /// <summary> 
  /// Defines the state of the Row position in the DataGridEh and the Column position in 
  /// the DataVertGrid or the DataPropertyGrid
  /// </summary>
  public enum DataAxisGridListAxisItemViewState
  {
    /// <summary> 
    /// The Row item have DataRow
    /// </summary>
    DataBrowse,
    DataEdit,
    DataNew,
    VirtualNew,
    VirtualEmpty
  }

  /// <summary> 
  /// Manages the display, editing, and interactive behavior of cells in the grid in the data area
  /// </summary>
  [TypeConverter(typeof(DataCellManagerConverter))]
  public class BaseDataCellManager : BaseGridCellManager, IGridRowHeightOptionsOwner, IEditItemOwner
  {

    #region >private consts
    private static readonly object EventKeyDisplayValueNeeded = new object();
    private static readonly object EventKeyPaint = new object();
    private static readonly object EventKeyCustomAreaPaint = new object();
    private static readonly object EventKeyClientAreaNeeded = new object();
    private static readonly object EventKeyContentPaint = new object();
    private static readonly object EventKeyFormatParamsNeeded = new object();

    private static readonly object EventKeyMouseDown = new object();
    private static readonly object EventKeyMouseMove = new object();
    private static readonly object EventKeyMouseUp = new object();
    private static readonly object EventKeyMouseClick = new object();
    private static readonly object EventKeyMouseDoubleClick = new object();
    private static readonly object EventKeyMouseEnter = new object();
    private static readonly object EventKeyMouseLeave = new object();
    private static readonly object EventKeyMouseHover = new object();

    private static readonly object EventKeyCanModifyStateNeeded = new object();
    private static readonly object EventKeyCanShowEditorStateNeeded = new object();
    private static readonly object EventKeyEditorParamsNeeded = new object();
    private static readonly object EventKeyEditValueNeeded = new object();
    private static readonly object EventKeyEditorOccupy = new object();
    private static readonly object EventKeyEditorRelease = new object();

    private static readonly object EventKeyParseValueNeeded = new object();
    private static readonly object EventKeyContextMenuStripNeeded = new object();
      
    private static readonly object EventKeyToolTipInfo = new object();
    #endregion <private consts

    #region >privates
    private PropertyAxisBar boundPropAxisBar;

    private EditButton editButton;
    private bool paddingStored;
    private Padding padding = new Padding(0);
    //private Padding defaultPadding = new Padding(2, 2, 0, 0);
    private bool horzAlignStored;
    private HorizontalAlignment horzAlign;
    private bool vertAlignStored;
    private VerticalAlignment vertAlign;
    private Color foreColor = Color.Empty;
    private bool foreColorStored;
    private bool readOnly;
    private bool readOnlyStored;
    private Font font;
    private Color backColor = Color.Empty;
    private bool backColorStored;
    private bool allowShowEditorStored;
    private bool allowShowEditor;
    private Type editorType;
    private readonly GridDataRowHeightOptions heightOptions;
    //private DataCellWorker cellWorker;
    private readonly EditItemControlsCollection inEditControls;

    //private DataAxisGridDataCellPaintEventArgs paintEventArgs;
    #endregion <privates


    #region >constructor
    public BaseDataCellManager()
    {
      heightOptions = new GridDataRowHeightOptions(this);
      //ContextMenuIsCompound = true;
      inEditControls = new EditItemControlsCollection();
      inEditControls.CollectionChanged += InEditControls_CollectionChanged;
    }
    #endregion <constructor

    #region >designtime properties
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    protected internal EditButton EditButton
    {
      get
      {
        if (editButton == null)
        {
          InitEditButton();
        }

        return editButton;
      }

      set
      {
        if (editButton != value)
        {
          if (editButton != null)
          {
            //TODO: editButton.RemoveOwner();
            //editButton.EditItemChanged -= EditItemChanged;
            //editButton.DefaultVisibleStateRequested -= EditButtonDefaultVisibleStateRequested;
          }

          editButton = value;

          if (editButton != null)
          {
            //TODO: editButton.AddOwner(this);
            //editButton.EditItemChanged += EditItemChanged;
            //editButton.DefaultVisibleStateRequested += EditButtonDefaultVisibleStateRequested;
          }

          EditButtonChanged();
        }
      }
    }

    public Padding Padding
    {
      get
      {
        return GetPadding(BoundPropAxisBar);
      }
      set
      {
        padding = value;
        paddingStored = true;
        PaddingChanged();
      }
    }

    public HorizontalAlignment HorzAlign
    {
      get
      {
        if (horzAlignStored)
          return horzAlign;
        else
          return DefaultHorzAlign();
      }
      set
      {
        if ((horzAlignStored == false) || (horzAlign != value))
        {
          horzAlignStored = true;
          horzAlign = value;
          HorzAlignChanged();
        }
      }
    }

    public VerticalAlignment VertAlign
    {
      get
      {
        if (vertAlignStored)
          return vertAlign;
        else
          return DefaultVertAlign();
      }
      set
      {
        if ((vertAlignStored == false) || (vertAlign != value))
        {
          vertAlignStored = true;
          vertAlign = value;
          VertAlignChanged();
        }
      }
    }

    public Color BackColor
    {
      get
      {
        if (backColorStored)
          return backColor;
        else
          return DefaultBackColor();
      }
      set
      {
        if ((backColorStored == false) || (backColor != value))
        {
          backColorStored = true;
          backColor = value;
          BackColorChanged();
        }
      }
    }

    public Color ForeColor
    {
      get
      {
        if (foreColorStored)
          return foreColor;
        else
          return DefaultForeColor();
      }
      set
      {
        if ((foreColorStored == false) || (foreColor != value))
        {
          foreColorStored = true;
          foreColor = value;
          ForeColorChanged();
        }
      }
    }

    public Font Font
    {
      get
      {
        return GetFont(BoundPropAxisBar);
      }
      set
      {
        font = value;
        FontChanged();
      }
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1716:IdentifiersShouldNotMatchKeywords", MessageId = "ReadOnly")]
    [DefaultValue(false)]
    public virtual bool ReadOnly
    {
      get
      {
        if (readOnlyStored)
          return readOnly;
        else
          return DefaultReadOnly();
      }
      set
      {
        if ((readOnlyStored == false) || (readOnly != value))
        {
          readOnlyStored = true;
          readOnly = value;
          OnReadOnlyChanged();
        }
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridDataRowHeightOptions HeightOptions
    {
      get
      {
        return heightOptions;
      }
    }
    #endregion <designtime properties

    #region >runtime properties
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public PropertyAxisBar BoundPropAxisBar
    {
      get
      {
        return boundPropAxisBar;
      }
      set
      {
        boundPropAxisBar = value;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public new DataAxisGrid BoundGrid
    {
      get { return (DataAxisGrid)base.BoundGrid; }
      set { base.BoundGrid = value; }
    }

    //[Browsable(false)]
    //public DataCellWorker CellWorker
    //{
    //  get
    //  {
    //    if (cellWorker == null)
    //      cellWorker = CreateDataCellWorker();
    //    return cellWorker;
    //  }
    //}


    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    [Editor("EhLib.WinForms.Design.InEditControlsCollectionEditor" + EhLibUtils.EhLibDesignDesignerVersionInfo, "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    protected internal EditItemControlsCollection InEditControls
    {
      get { return inEditControls; }
    }

    protected internal bool AllowShowEditor
    {
      get
      {
        if (allowShowEditorStored)
          return allowShowEditor;
        else
          return DefaultAllowShowEditor();
      }
      set
      {
        if (allowShowEditor != value || allowShowEditorStored == false)
        {
          allowShowEditorStored = true;
          allowShowEditor = value;
        }
      }
    }

    [DefaultValue(null)]
    public virtual ContextMenuStrip ContextMenuStrip { get; set; }

    //[DefaultValue(true)]
    //public bool ContextMenuIsCompound { get; set; }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public new virtual Type EditorType
    {
      get
      {
        if (editorType == null)
          return DefaultEditorType;
        else
          return editorType;
      }
      set
      {
        if (editorType != value)
        {
          editorType = value;
          EditorTypeChanged();
        }
      }
    }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    protected virtual Type DefaultEditorType
    {
      get { return null; }
    }

    [TypeConverter(typeof(StringConverter))]
    [DefaultValue(null)]
    public object Tag { get; set; }
    #endregion <runtime properties

    #region >events
    /// <summary>
    /// Occurs when a cell needs to be drawn.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellPaintEventArgs> Paint
    {
      add
      {
        this.Events.AddHandler(EventKeyPaint, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyPaint, value);
      }
    }

    /// <summary>
    /// Occurs when a cell content needs to be drawn.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellContentPaintEventArgs> ContentPaint
    {
      add
      {
        this.Events.AddHandler(EventKeyContentPaint, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyContentPaint, value);
      }
    }

    /// <summary>
    /// Occurs when a custom area inside the cell needs to be drawn.
    /// Write ClientAreaNeeded event handler to specify the size of client rectangle and define custom area outside the client.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellPaintEventArgs> CustomAreaPaint
    {
      add
      {
        this.Events.AddHandler(EventKeyCustomAreaPaint, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyCustomAreaPaint, value);
      }
    }

    /// <summary>
    /// Occurs when a client rectangle should be specified.
    /// The area outside the client rectangle is a custom area.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellClientAreaNeededEventArgs> ClientAreaNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyClientAreaNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyClientAreaNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager requests a display value of a cell position from DataSource. For example when drawing cell value.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellDisplayValueNeededEventArgs> DisplayValueNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDisplayValueNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDisplayValueNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell editor convert the edited value of the cell to the value that will be written to the DataSource.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellParseValueEventArgs> ParseValueNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyParseValueNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyParseValueNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell paint params like BackColor, Font, etc should be specified.
    /// By default the params are assigned from cell properties
    /// </summary>
    public event EventHandler<DataAxisGridDataCellFormatParamsNeededEventArgs> FormatParamsNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyFormatParamsNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyFormatParamsNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when the user presses a mouse button while the mouse pointer is 
    /// within the boundaries of a cell.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellMouseEventArgs> MouseDown
    {
      add
      {
        this.Events.AddHandler(EventKeyMouseDown, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyMouseDown, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer moves over the boundaries of a cell.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellMouseEventArgs> MouseMove
    {
      add
      {
        this.Events.AddHandler(EventKeyMouseMove, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyMouseMove, value);
      }
    }

    /// <summary>
    /// Occurs when the user releases a mouse button while over a cell.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellMouseEventArgs> MouseUp
    {
      add
      {
        this.Events.AddHandler(EventKeyMouseUp, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyMouseUp, value);
      }
    }

    /// <summary>
    /// Occurs whenever the user clicks anywhere on a cell with the mouse.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellMouseEventArgs> MouseClick
    {
      add
      {
        this.Events.AddHandler(EventKeyMouseClick, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyMouseClick, value);
      }
    }

    /// <summary>
    /// Occurs when a cell within the DataGridEh is double-clicked.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellMouseEventArgs> MouseDoubleClick
    {
      add
      {
        this.Events.AddHandler(EventKeyMouseDoubleClick, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyMouseDoubleClick, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer enters a cell.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellEnterEventArgs> MouseEnter
    {
      add
      {
        this.Events.AddHandler(EventKeyMouseEnter, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyMouseEnter, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer leaves a cell.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellLeaveEventArgs> MouseLeave
    {
      add
      {
        this.Events.AddHandler(EventKeyMouseLeave, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyMouseLeave, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer rests on the cell.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellMouseEventArgs> MouseHover
    {
      add
      {
        this.Events.AddHandler(EventKeyMouseHover, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyMouseHover, value);
      }
    }

    public event EventHandler<DataAxisGridDataCellContextMenuStripNeededEventArgs> ContextMenuStripNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyContextMenuStripNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyContextMenuStripNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when the cell editor requests and sets its readonly state.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellCanModifyStateNeededEventArgs> CanModifyStateNeeded
    {
      add
      {
        Events.AddHandler(EventKeyCanModifyStateNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyCanModifyStateNeeded, value);
      }
    }

    public event EventHandler<DataAxisGridDataCellCanShowEditorStateNeededEventArgs> CanShowEditorStateNeeded
    {
      add
      {
        Events.AddHandler(EventKeyCanShowEditorStateNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyCanShowEditorStateNeeded, value);
      }
    }

    public event EventHandler<DataAxisGridDataCellEditorParamsNeededEventArgs> EditorParamsNeeded
    {
      add
      {
        Events.AddHandler(EventKeyEditorParamsNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyEditorParamsNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager converts datasource cell value to the value for the editor.
    /// </summary>
    public event EventHandler<DataAxisGridDataCellEditValueNeededEventArgs> EditValueNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyEditValueNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyEditValueNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager occupy the editor before open to show and edit value.
    /// </summary>
    /// <remarks>
    /// The grid uses a shared cell editor for the columns of same types.
    /// </remarks>
    public event EventHandler<DataAxisGridDataCellEditorOccupyEventArgs> EditorOccupy
    {
      add
      {
        Events.AddHandler(EventKeyEditorOccupy, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyEditorOccupy, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager releases the shared editor for using in other columns.
    /// </summary>
    /// <remarks>
    /// If you changed properties or events in the DataCellEditorOccupy event handler,
    /// you should restore properties and events in this event handler.
    /// </remarks>
    public event EventHandler<DataAxisGridDataCellEditorReleaseEventArgs> EditorRelease
    {
      add
      {
        Events.AddHandler(EventKeyEditorRelease, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyEditorRelease, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager requests info to show in tooltip window.
    /// </summary>
    /// <remarks>
    /// For text data, assign the text to e.ToolTipText property by the text you want to be shown in tooltip window.
    /// </remarks>
    public event EventHandler<DataAxisGridDataCellToolTipInfoEventArgs> ToolTipInfoNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyToolTipInfo, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyToolTipInfo, value);
      }
    }
    #endregion <events

    #region> methods
    //Padding
    public virtual void PaddingChanged()
    {
      if (BoundGrid != null)
        BoundGrid.UpdateBaseFixedBands();
    }

    public virtual Padding DefaultPadding()
    {
      return GetDefaultPadding(BoundPropAxisBar);
    }

    public virtual Padding GetPadding(PropertyAxisBar propAxisBar)
    {
      if (paddingStored)
        return padding;
      else if (propAxisBar == BoundPropAxisBar)
        return DefaultPadding();
      //else if (BoundPropAxisBar != null)
      //  return BoundPropAxisBar.Padding;
      else if (propAxisBar != null)
        return propAxisBar.Padding;
      else
        return Padding.Empty;
    }

    public virtual Padding GetDefaultPadding(PropertyAxisBar propAxisBar)
    {
      if (propAxisBar != null && propAxisBar.Grid != null)
        return propAxisBar.Grid.GetDefaultPaddingForAlign(HorzAlign, VertAlign);
      else
        return Padding.Empty;
    }

    public virtual bool ShouldSerializePadding()
    {
      return (paddingStored == true);
    }

    public virtual void ResetPadding()
    {
      paddingStored = false;
      PaddingChanged();
    }

    //HorzAlign
    public virtual HorizontalAlignment DefaultHorzAlign()
    {
      if (BoundPropAxisBar != null)
        return BoundPropAxisBar.DefaultHorzAlign();
      else
        return HorizontalAlignment.Left;
    }

    public virtual HorizontalAlignment GetHorzAlign(PropertyAxisBar propAxisBar)
    {
      if (horzAlignStored)
        return horzAlign;
      else if (propAxisBar == BoundPropAxisBar)
        return DefaultHorzAlign();
      //else if (BoundPropAxisBar != null)
      //  return BoundPropAxisBar.HorzAlign;
      else if (propAxisBar != null)
        return propAxisBar.HorzAlign;
      else
        return HorizontalAlignment.Left;
    }

    protected virtual void HorzAlignChanged()
    {
      if (BoundGrid != null)
        BoundGrid.Invalidate();
    }

    public virtual bool ShouldSerializeHorzAlign()
    {
      return (horzAlignStored == true);
    }

    public virtual void ResetHorzAlign()
    {
      horzAlignStored = false;
      HorzAlignChanged();
    }

    //VertAlign
    public virtual VerticalAlignment DefaultVertAlign()
    {
      if (BoundPropAxisBar != null)
        return BoundPropAxisBar.DefaultVertAlign();
      else
        return VerticalAlignment.Top;
    }

    public virtual VerticalAlignment GetVertAlign(PropertyAxisBar propAxisBar)
    {
      if (vertAlignStored)
        return vertAlign;
      else if (propAxisBar == BoundPropAxisBar)
        return DefaultVertAlign();
      //else if (BoundPropAxisBar != null)
      //  return BoundPropAxisBar.VertAlign;
      else if (propAxisBar != null)
        return propAxisBar.VertAlign;
      else
        return VerticalAlignment.Top;
    }

    protected internal virtual void VertAlignChanged()
    {
      if (BoundGrid != null)
        BoundGrid.Invalidate();
    }

    public virtual bool ShouldSerializeVertAlign()
    {
      return (vertAlignStored == true);
    }

    public virtual void ResetVertAlign()
    {
      vertAlignStored = false;
      VertAlignChanged();
    }

    //ReadOnly
    private bool DefaultReadOnly()
    {
      if (BoundPropAxisBar != null)
        return BoundPropAxisBar.DefaulReadOnly();
      else
        return false;
    }

    private void OnReadOnlyChanged()
    {
    }

    protected virtual bool ShouldSerializeReadOnly()
    {
      return (readOnlyStored == true);
    }

    public virtual void ResetReadOnly()
    {
      readOnlyStored = false;
      OnReadOnlyChanged();
    }

    //BackColor
    protected virtual void BackColorChanged()
    {
      if (BoundGrid != null)
        BoundGrid.Invalidate();
    }

    public virtual Color DefaultBackColor()
    {
      if (BoundPropAxisBar != null)
        return BoundPropAxisBar.BackColor;
      else
        return SystemColors.Window;
    }

    public virtual Color GetBackColor(PropertyAxisBar propAxisBar)
    {
      if (backColorStored)
        return BackColor;
      else if (propAxisBar == BoundPropAxisBar)
        return DefaultBackColor();
      //else if (BoundPropAxisBar != null)
      //  return BoundPropAxisBar.BackColor;
      else if (propAxisBar != null)
        return propAxisBar.BackColor;
      else
        return SystemColors.Window;
    }

    protected virtual bool ShouldSerializeBackColor()
    {
      return (backColorStored == true);
    }

    public virtual void ResetBackColor()
    {
      backColorStored = false;
      BackColorChanged();
    }

    //ForeColor
    protected virtual void ForeColorChanged()
    {
      if (BoundGrid != null)
        BoundGrid.Invalidate();
    }

    public virtual Color DefaultForeColor()
    {
      if (BoundPropAxisBar != null)
        return BoundPropAxisBar.DefaultForeColor();
      else
        return SystemColors.WindowText;
    }

    public virtual Color GetForeColor(PropertyAxisBar propAxisBar)
    {
      if (foreColorStored)
        return ForeColor;
      else if (propAxisBar == BoundPropAxisBar)
        return DefaultForeColor();
      //else if (BoundPropAxisBar != null)
      //  return BoundPropAxisBar.ForeColor;
      else if (propAxisBar != null)
        return propAxisBar.ForeColor;
      else
        return SystemColors.WindowText;
    }

    protected internal virtual bool ShouldSerializeForeColor()
    {
      return (foreColorStored == true);
    }

    public virtual void ResetForeColor()
    {
      foreColorStored = false;
      ForeColorChanged();
    }

    //Font
    protected virtual void FontChanged()
    {
      if (BoundPropAxisBar != null)
        BoundPropAxisBar.CellFontChanged();
    }

    public virtual Font DefaultFont()
    {
      if (BoundPropAxisBar != null)
        return BoundPropAxisBar.DefaultFont();
      else
        return null;
    }

    public virtual Font GetFont(PropertyAxisBar propAxisBar)
    {
      if (font != null)
        return font;
      else if (propAxisBar == BoundPropAxisBar)
        return DefaultFont();
      else if (propAxisBar != null)
        return propAxisBar.Font;
      else
        return null;

      //if (font != null)
      //  return font;
      //else if (propAxisBar == BoundPropAxisBar)
      //  return DefaultFont();
      //else if (BoundPropAxisBar != null)
      //  return BoundPropAxisBar.Font;
      //else if (propAxisBar != null)
      //  return propAxisBar.Font;
      //else
      //  return null;
    }

    public virtual bool ShouldSerializeFont()
    {
      return (font != null);
    }

    public virtual void ResetFont()
    {
      if (font != null)
      {
        font = null;
        FontChanged();
      }
    }

    //AllowShowEditor
    public virtual bool DefaultAllowShowEditor()
    {
      if (BoundGrid == null)
        return false;
      else
        return BoundGrid.DefaultAllowShowEditor();
    }

    protected internal virtual bool ShouldSerializeAllowShowEditor()
    {
      return (allowShowEditorStored == true);
    }

    public virtual void ResetAllowShowEditor()
    {
      allowShowEditorStored = false;
    }

    //IGridRowHeightOptionsOwner

    void IGridRowHeightOptionsOwner.HeightOptionsChanged(GridRowHeightOptions heightOptions)
    {
      if (BoundPropAxisBar != null)
        BoundPropAxisBar.RowHeightAutoExpandChanged();
    }

    bool IGridRowHeightOptionsOwner.HeightOptionsDefaultAutoExpand(GridRowHeightOptions heightOptions)
    {
      if (BoundPropAxisBar != null)
        return BoundPropAxisBar.HeightOptionsDefaultAutoExpand(heightOptions);
      else
        return false;
    }

    int IGridRowHeightOptionsOwner.HeightOptionsDefaultContentHeight(GridRowHeightOptions heightOptions)
    {
      if (BoundPropAxisBar != null)
        return BoundPropAxisBar.HeightOptionsDefaultContentHeight(heightOptions);
      else
        return 1;
    }

    int IGridRowHeightOptionsOwner.HeightOptionsDefaultMaxContentHeight(GridRowHeightOptions heightOptions)
    {
      if (BoundPropAxisBar != null)
        return BoundPropAxisBar.HeightOptionsDefaultMaxContentHeight(heightOptions);
      else
        return 0;
    }

    GridRowHeightUnit IGridRowHeightOptionsOwner.HeightOptionsDefaultUnit(GridRowHeightOptions heightOptions)
    {
      if (BoundPropAxisBar != null)
        return BoundPropAxisBar.HeightOptionsDefaultUnit(heightOptions);
      else
        return GridRowHeightUnit.TextLine;
    }

    //FormatParams
    protected virtual DataAxisGridDataCellFormatParamsNeededEventArgs CreateFormatParamsNeededEventArgs(
      DataAxisGrid grid, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
        return new DataAxisGridDataCellFormatParamsNeededEventArgs(grid, propAxisBar, listItemBar, this);
    }

    protected internal virtual void ProcessFormatParamsNeeded(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
      OnFormatParamsNeeded(e);

      if (e.ListItemBar != null)
      {
        if (BoundGrid != null && e.PropAxisBar != null && BoundGrid != e.PropAxisBar.Grid)
          BoundGrid.HandleFormatParamsNeededEvent(e);
        if (e.Grid != null)
          e.Grid.HandleFormatParamsNeededEvent(e);

        if (BoundPropAxisBar != null && BoundPropAxisBar != e.PropAxisBar)
          BoundPropAxisBar.HandleFormatParamsNeededEvent(e);
        if (e.PropAxisBar != null)
          e.PropAxisBar.HandleFormatParamsNeededEvent(e);

        HandleFormatParamsNeededEvent(e);
      }
    }

    protected virtual void OnFormatParamsNeeded(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
      e.HorzAlign = GetHorzAlign(e.PropAxisBar);
      e.VertAlign = GetVertAlign(e.PropAxisBar);
      e.Font = GetFont(e.PropAxisBar);
      e.BackColor = GetBackColor(e.PropAxisBar);
      e.ForeColor = GetForeColor(e.PropAxisBar);
      e.Padding = GetPadding(e.PropAxisBar);

      if (e.Grid != null)
        e.Grid.SpecifyFormatParams(e);
    }

    protected virtual void HandleFormatParamsNeededEvent(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
      var eh = this.Events[EventKeyFormatParamsNeeded] as EventHandler<DataAxisGridDataCellFormatParamsNeededEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    public virtual DataAxisGridDataCellFormatParamsNeededEventArgs CreateProcessFormatParams(DataAxisGrid grid, PropertyAxisBar propAxisBar,  DataAxisGridListItemBar listItemBar)
    {
      DataAxisGridDataCellFormatParamsNeededEventArgs e = CreateFormatParamsNeededEventArgs(grid, propAxisBar, listItemBar);
      ProcessFormatParamsNeeded(e);
      return e;
    }

    //CanShowEditor
    public virtual DataAxisGridDataCellCanShowEditorStateNeededEventArgs CreateCanShowEditorStateEventArg(
        BaseGridControl grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      return new DataAxisGridDataCellCanShowEditorStateNeededEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex,
        propAxisBar, listItemBar, this);
    }

    public virtual bool CanShowEditor(DataAxisGrid grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex)
    {
      DataAxisGridDataCellCanShowEditorStateNeededEventArgs result;
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = grid as DataAxisGrid;

      AxisObjectsByDataColRowIndex(axisGrid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar);

      result = CreateCanShowEditorStateEventArg(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, propAxisBar, listItemBar);
      ProcessCanShowEditorStateNeeded(result);

      return result.CanShowEditor;
    }

    protected virtual void ProcessCanShowEditorStateNeeded(DataAxisGridDataCellCanShowEditorStateNeededEventArgs e)
    {
      OnCanShowEditorStateNeeded(e);

      if (BoundGrid != null && BoundGrid != e.PropAxisBar.Grid)
        BoundGrid.HandleCanShowEditorStateNeededEvent(e);
      if (e.PropAxisBar.Grid != null)
        e.PropAxisBar.Grid.HandleCanShowEditorStateNeededEvent(e);

      if (BoundPropAxisBar != null && BoundPropAxisBar != e.PropAxisBar)
        BoundPropAxisBar.HandleCanShowEditorStateNeededEvent(e);
      e.PropAxisBar.HandleCanShowEditorStateNeededEvent(e);

      HandleCanShowEditorStateNeededEvent(e);
    }

    protected virtual void OnCanShowEditorStateNeeded(DataAxisGridDataCellCanShowEditorStateNeededEventArgs e)
    {
      e.CanShowEditor = CanShowEditor(e.PropAxisBar, e.ListItemBar);
    }

    protected void HandleCanShowEditorStateNeededEvent(DataAxisGridDataCellCanShowEditorStateNeededEventArgs e)
    {
      var eh = this.Events[EventKeyCanShowEditorStateNeeded] as EventHandler<DataAxisGridDataCellCanShowEditorStateNeededEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected virtual bool CanShowEditor(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      if (allowShowEditorStored)
      {
        return AllowShowEditor;
      }
      else
      {
        return propAxisBar.AllowShowEditor;
      }
    }

    public override bool CanMouseDownShowEditor(BaseGridCellMouseEventArgs e)
    {
      DataAxisGridDataCellMouseEventArgs de = e as DataAxisGridDataCellMouseEventArgs;
      if (de != null )
      {
        return de.ClientRect.Contains(e.GridMouseArgs.Location);
      }
      else
      {
        return base.CanMouseDownShowEditor(e);
      }
    }


    //EditorParams
    public virtual DataAxisGridDataCellEditorParamsNeededEventArgs GetCellEditorParams(DataAxisGrid grid,
        int colIndex, int rowIndex, int areaColIndex, int areaRowIndex)
    {
      DataAxisGridDataCellEditorParamsNeededEventArgs result;
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGridListAxisItemViewState listAxisItemViewState;
      AxisObjectsByDataColRowIndex(grid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar, out listAxisItemViewState);

      result = CreateDataCellEditorParamsEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, propAxisBar, listItemBar);

      OnFillEditorParams(result);

      return result;
    }

    protected virtual DataAxisGridDataCellEditorParamsNeededEventArgs CreateDataCellEditorParamsEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      return new DataAxisGridDataCellEditorParamsNeededEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex,
        propAxisBar, listItemBar, this);
    }

    protected virtual void OnFillEditorParams(DataAxisGridDataCellEditorParamsNeededEventArgs e)
    {
      e.Font = GetFont(e.PropAxisBar);
      e.BackColor = GetBackColor(e.PropAxisBar);
      e.ForeColor = GetForeColor(e.PropAxisBar);
      e.Padding = GetPadding(e.PropAxisBar);
      e.EditorType = GetEditorType(e.PropAxisBar);
      //e.CanShowEditor = Grid.CanShowEditor();
      e.ReadOnly = !CanModify(e.PropAxisBar, e.ListItemBar);

      DataAxisGrid axisGrid = e.Grid as DataAxisGrid;
      DataAxisGridDataCellFormatParamsNeededEventArgs fe = CreateFormatParamsNeededEventArgs(axisGrid, e.PropAxisBar, e.ListItemBar);
      ProcessFormatParamsNeeded(fe);

      e.AssignFormatParams(fe);

      if (e.ListItemBar != null)
      {
        if (BoundGrid != null && BoundGrid != e.PropAxisBar.Grid)
          BoundGrid.HandleEditorParamsNeededEvent(e);
        if (e.PropAxisBar.Grid != null)
          e.PropAxisBar.Grid.HandleEditorParamsNeededEvent(e);

        if (BoundPropAxisBar != null && BoundPropAxisBar != e.PropAxisBar)
          BoundPropAxisBar.HandleEditorParamsNeededEvent(e);
        e.PropAxisBar.HandleEditorParamsNeededEvent(e);

        HandleCanShowEditorStateNeededEvent(e);
      }
    }

    private void HandleCanShowEditorStateNeededEvent(DataAxisGridDataCellEditorParamsNeededEventArgs e)
    {
      var eh = Events[EventKeyEditorParamsNeeded] as EventHandler<DataAxisGridDataCellEditorParamsNeededEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    //EditorOccupy
    public virtual DataAxisGridDataCellEditorOccupyEventArgs FormEditorOccupyEventArgs(
      BaseGridControl grid, 
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, Control editor, object value, bool selectAll,
      DataAxisGridDataCellEditorParamsNeededEventArgs editorParams)
    {
      DataAxisGridDataCellEditorOccupyEventArgs result;

      result = CreateEditorOccupyEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex,
        cellRect, propAxisBar, listItemBar, editor, value, selectAll, editorParams);

      ProcessEditorOccupy(result);

      return result;
    }

    protected virtual DataAxisGridDataCellEditorOccupyEventArgs CreateEditorOccupyEventArgs(
      BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, Control editor, object value, bool selectAll,
      DataAxisGridDataCellEditorParamsNeededEventArgs editorParams)
    {
      return new DataAxisGridDataCellEditorOccupyEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, 
        cellRect, propAxisBar, listItemBar, this, editor, value, selectAll, editorParams);
    }

    protected internal virtual void ProcessEditorOccupy(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
      if (e.ListItemBar != null)
      {
        if (BoundGrid != null && BoundGrid != e.PropAxisBar.Grid)
          BoundGrid.HandleEditorOccupyEvent(e);
        if (e.PropAxisBar.Grid != null)
          e.PropAxisBar.Grid.HandleEditorOccupyEvent(e);

        if (BoundPropAxisBar != null && BoundPropAxisBar != e.PropAxisBar)
          BoundPropAxisBar.HandleEditorOccupyEvent(e);
        e.PropAxisBar.HandleEditorOccupyEvent(e);

        HandleEditorOccupyEvent(e);
      }
      
      if (!e.Handled)
        OnEditorOccupy(e);
    }

    protected internal virtual void OnEditorOccupy(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
      //CellWorker.OnEditorOccupy(e);
    }

    protected virtual void HandleEditorOccupyEvent(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
      var eh = Events[EventKeyEditorOccupy] as EventHandler<DataAxisGridDataCellEditorOccupyEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    //EditorRelease
    public override void ReleaseEditControl(Control cellEditControl)
    {
      IDataAxisGridCellInPlaceEditor iInPlaceEditor = (IDataAxisGridCellInPlaceEditor)cellEditControl;
      DataAxisGridDataCellEditorOccupyEventArgs cellPosData = iInPlaceEditor.CellPosData;

      DataAxisGridDataCellEditorReleaseEventArgs rea = CreateEditorReleaseEventArgs(cellPosData.PropAxisBar, cellPosData.ListItemBar, cellEditControl);
      ProcesEditorRelease(rea);

      iInPlaceEditor.CellManager = null;
      iInPlaceEditor.CellPosData = null;
      iInPlaceEditor.EditorTableRowIndex = -1;
    }

    protected virtual DataAxisGridDataCellEditorReleaseEventArgs CreateEditorReleaseEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, Control editor)
    {
      return new DataAxisGridDataCellEditorReleaseEventArgs(propAxisBar, listItemBar, editor, this);
    }

    protected internal virtual void ProcesEditorRelease(DataAxisGridDataCellEditorReleaseEventArgs e)
    {
      if (e.PropAxisBar != null)
      {
        if (e.PropAxisBar.Grid != null)
          e.PropAxisBar.Grid.HandleEditorReleaseEvent(e);
        e.PropAxisBar.HandleEditorReleaseEvent(e);
      }
      HandleEditorReleaseEvent(e);

      if (!e.Handled)
        OnEditorRelease(e);
    }

    protected virtual void OnEditorRelease(DataAxisGridDataCellEditorReleaseEventArgs e)
    {
      //CellWorker.OnEditorRelease(e);
    }

    protected virtual void HandleEditorReleaseEvent(DataAxisGridDataCellEditorReleaseEventArgs e)
    {
      var eh = Events[EventKeyEditorRelease] as EventHandler<DataAxisGridDataCellEditorReleaseEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    //Editor events
    protected internal virtual void OnEditorKeyDown(DataAxisGridEditorKeyEventArgs ke)
    {
      ke.PropAxisBar.OnEditorKeyDown(ke);
      ke.Grid.OnEditorKeyDown(ke);
    }

    //Paint
    protected internal override void HandlePaintEvent(BaseGridCellPaintEventArgs e)
    {
      DataAxisGridDataCellPaintEventArgs de = (DataAxisGridDataCellPaintEventArgs)e;
      if (de.ListItemBar == null || de.PropAxisBar == null) return;

      if (BoundGrid != null && BoundGrid != de.PropAxisBar.Grid)
        BoundGrid.HandleDataCellPaintEvent(de);
      if (de.PropAxisBar.Grid != null)
        de.PropAxisBar.Grid.HandleDataCellPaintEvent(de);

      if (BoundPropAxisBar != null && BoundPropAxisBar != de.PropAxisBar)
        BoundPropAxisBar.HandleDataCellPaintEvent(de);
      de.PropAxisBar.HandleDataCellPaintEvent(de);

      HandlePaintEvent(de);
    }

    protected virtual void HandlePaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = this.Events[EventKeyPaint] as EventHandler<DataAxisGridDataCellPaintEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    public override BaseGridCellPaintEventArgs GetCellPaintParams(
        BaseGridControl grid,
        GraphicsContext gc,
        int colIndex, int rowIndex,
        Rectangle paintRect, Rectangle cellAreaRect,
        BasePaintCellStates state,
        int areaColIndex, int areaRowIndex,
        Point inCellMousePos
      )
    {
      DataAxisGridDataCellPaintEventArgs result;
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGridListAxisItemViewState listAxisItemViewState;
      DataAxisGrid axisGrid = grid as DataAxisGrid;
      AxisObjectsByDataColRowIndex(axisGrid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar, out listAxisItemViewState);

      DataAxisGridDataCellFormatParamsNeededEventArgs fe = CreateFormatParamsNeededEventArgs(axisGrid, propAxisBar, listItemBar);
      ProcessFormatParamsNeeded(fe);

      result = CreatePaintEventArgs(axisGrid, this, gc, colIndex, rowIndex,
          paintRect, cellAreaRect, state,
          areaColIndex, areaRowIndex, inCellMousePos, propAxisBar, listItemBar, listAxisItemViewState, fe);

      //FillPaintParamsFromFormatParams(result, formatParams);
      SpecifyPaintParams(result);

      result.CustomRect = GetCellCustomRect(propAxisBar, listItemBar, result.CellRect);
      result.ClientRect = GetCellClientRect(propAxisBar, listItemBar, result.CustomRect);
      result.ContentRect = CalcContentRect(result.ClientRect);
      result.InEditItemsHeight = CalcInEditItemsHeight(result.ClientRect);

      return result;
    }

    protected internal virtual DataAxisGridDataCellPaintEventArgs CreatePaintEventArgs(DataAxisGrid grid, BaseGridCellManager cellManager, GraphicsContext gc,
        int colIndex, int rowIndex, Rectangle paintRect, Rectangle cellAreaRect, BasePaintCellStates state, int areaColIndex, int areaRowIndex,
        Point inCellMousePos, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, DataAxisGridListAxisItemViewState listAxisItemViewState,
        DataAxisGridDataCellFormatParamsNeededEventArgs fe)
    {
      return new DataAxisGridDataCellPaintEventArgs(grid, this, gc, colIndex, rowIndex, paintRect, cellAreaRect, state,
        areaColIndex, areaRowIndex, inCellMousePos, propAxisBar, listItemBar, listAxisItemViewState, fe);
    }

    protected internal virtual void SpecifyPaintParams(DataAxisGridDataCellPaintEventArgs e)
    {
      if (e.PropAxisBar != null)
        e.PropAxisBar.SpecifyPaintParams(e);
    }

    protected internal override void OnPaint(BaseGridCellPaintEventArgs e)
    {
      //base.OnPaint(e);

      var de = (DataAxisGridDataCellPaintEventArgs)e;

      if (de.ListItemBar == null)
        OnPaintVirtualNewCell(de);
      else
        OnPaint(de);
    }

    protected virtual void OnPaintVirtualNewCell(DataAxisGridDataCellPaintEventArgs e)
    {
      PaintBackground(e);
      if (((DataAxisGrid)e.Grid).CurrentListItemBar == null)
      {
        PaintForeground(e);
      }
    }

    protected virtual void OnPaint(DataAxisGridDataCellPaintEventArgs e)
    {
      PaintBackground(e);
      PaintForeground(e);
    }

    protected internal override void OnPaintBackground(BaseGridCellPaintEventArgs e)
    {
      PaintBackground((DataAxisGridDataCellPaintEventArgs)e);
    }

    protected virtual void PaintBackground(DataAxisGridDataCellPaintEventArgs e)
    {
      if (!e.IsPaintBackground) return;

      if (e.PropAxisBar != null)
        e.PropAxisBar.PaintCellBackground(this, e);
      else
        InternalPaintCellBackground(e);
    }

    internal void InternalPaintCellBackground(DataAxisGridDataCellPaintEventArgs e)
    {
      Color baseColor = e.BackColor;

      //if (BoundPropAxisBar != null)
      //  baseColor = BoundPropAxisBar.BackColor;
      //else
      //  baseColor = Grid.BackColor;

      int alpha = 255;
      bool drawSelection = false;

      if (e.Grid.Background.Visible && baseColor == e.Grid.BackColor)
      {
        // Paint nothing
      }
      else
      {
        if (e.Grid.Background.Visible && baseColor.A == 255)
          baseColor = Color.FromArgb(e.Grid.Background.GridOpacityOptions.CellsOpacity, baseColor);

        using (
          SolidBrush fillBrush = new SolidBrush(baseColor))
        {
          e.Grid.PaintingFillRectangle(e.Graphics, fillBrush, e.ClientRect);
        }
      }

      if (((BasePaintCellStates.Current & e.State) != 0) ||
                ((BasePaintCellStates.RowSelected & e.State) != 0))
      {
        if (e.Grid.Background.Visible)
          alpha = e.Grid.Background.GridOpacityOptions.FocusCellOpacity;
        else
          alpha = 255;
        drawSelection = true;
      }

      if (drawSelection)
      {

        if (e.Grid.IsActiveControl())
          baseColor = SystemColors.Highlight;
        else
          baseColor = SystemColors.ButtonShadow;

        using (
          SolidBrush fillBrush = new SolidBrush(Color.FromArgb(alpha, baseColor)))
        {
          e.Grid.PaintingFillRectangle(e.Graphics, fillBrush, e.ClientRect);
        }
      }
    }

    protected internal override void OnPaintForeground(BaseGridCellPaintEventArgs e)
    {
      PaintForeground((DataAxisGridDataCellPaintEventArgs)e);
    }

    protected virtual void PaintForeground(DataAxisGridDataCellPaintEventArgs e)
    {
      if (!e.IsPaintForeground) return;

      OnPaintServiceArea(e);
      OnPaintClientRect(e);
      OnPaintCustomArea(e);
    }

    protected internal virtual void OnPaintServiceArea(DataAxisGridDataCellPaintEventArgs e)
    {
      if (e.PropAxisBar != null)
        e.PropAxisBar.PaintDataCellServiceArea(e);
    }

    private void OnPaintClientRect(DataAxisGridDataCellPaintEventArgs e)
    {
      Rectangle paintRect = e.ClientRect;
      DataAxisGridDataCellContentPaintEventArgs ce;
      PaintContentSurroundArea(e, ref paintRect);

      ce = new DataAxisGridDataCellContentPaintEventArgs(e, paintRect);
      ProcessPaintContent(ce);
    }

    protected internal virtual void OnPaintCustomArea(DataAxisGridDataCellPaintEventArgs e)
    {
      if (e.ListItemBar != null && e.PropAxisBar != null)
      {
        if (BoundGrid != null && BoundGrid != e.PropAxisBar.Grid)
          BoundGrid.HandleDataCellCustomAreaPaintEvent(e);
        if (e.PropAxisBar.Grid != null)
          e.PropAxisBar.Grid.HandleDataCellCustomAreaPaintEvent(e);

        if (BoundPropAxisBar != null && BoundPropAxisBar != e.PropAxisBar)
          BoundPropAxisBar.HandleDataCellCustomAreaPaintEvent(e);
        e.PropAxisBar.HandleDataCellCustomAreaPaintEvent(e);

        HandleCustomAreaPaintEvent(e);
      }
    }

    protected internal virtual void HandleCustomAreaPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = this.Events[EventKeyCustomAreaPaint] as EventHandler<DataAxisGridDataCellPaintEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected virtual void PaintContentSurroundArea(DataAxisGridDataCellPaintEventArgs e, ref Rectangle paintRect)
    {
      PaintLeftEditItems(e, ref paintRect);
      PaintRightEditItems(e, ref paintRect);
    }

    protected virtual void PaintLeftEditItems(DataAxisGridDataCellPaintEventArgs e, ref Rectangle paintRect)
    {
      List<EditItem> leftInEditItems = new List<EditItem>();
      Rectangle boundsRect = new Rectangle(0, paintRect.Top, 0, e.InEditItemsHeight);

      GetSideInEditItems(InEditAlignSide.Left, leftInEditItems);

      foreach (EditItem ei in leftInEditItems)
      {
        //boundsRect.X += ei.Width;
        boundsRect.Width += ei.Width;
      }

      boundsRect.X = paintRect.Left;
      paintRect.X = paintRect.X + boundsRect.Width;
      paintRect.Width = paintRect.Width - boundsRect.Width;

      if (boundsRect.Width > 0)
        PaintEditItemsInBounds(e, paintRect, leftInEditItems, boundsRect);
    }

    protected virtual void PaintRightEditItems(DataAxisGridDataCellPaintEventArgs e, ref Rectangle paintRect)
    {
      List<EditItem> rightInEditItems = new List<EditItem>();
      Rectangle boundsRect = new Rectangle(0, paintRect.Top, 0, e.InEditItemsHeight);

      GetSideInEditItems(InEditAlignSide.Right, rightInEditItems);

      foreach (EditItem ei in rightInEditItems)
      {
        boundsRect.Width += ei.Width;
      }

      boundsRect.X = paintRect.Right - boundsRect.Width;
      paintRect.Width = paintRect.Width - boundsRect.Width;

      PaintEditItemsInBounds(e, paintRect, rightInEditItems, boundsRect);
    }

    public Rectangle CalcContentRect(Rectangle clientRect)
    {
      Rectangle result = clientRect;
      int leftEditItemsWidth = CalcSideInEditItemsWidth(InEditAlignSide.Left);
      int rightEditItemsWidth = CalcSideInEditItemsWidth(InEditAlignSide.Right);
      result.X = result.X + leftEditItemsWidth;
      result.Width = result.Width - leftEditItemsWidth - rightEditItemsWidth;

      return result;
    }

    protected virtual int CalcSideInEditItemsWidth(InEditAlignSide alignSide)
    {
      int result = 0;
      List<EditItem> sideInEditItems = new List<EditItem>();
      GetSideInEditItems(alignSide, sideInEditItems);

      foreach (EditItem ei in sideInEditItems)
      {
        result += ei.Width;
      }

      return result;
    }

    protected virtual void GetSideInEditItems(InEditAlignSide alignSide, List<EditItem> inEditItems)
    {
      foreach (EditItem ei in InEditControls)
      {
        if (ei.Visible &&
            ei.AlignSide == alignSide)
        {
          inEditItems.Add(ei);
        }
      }

      if (EditButton != null &&
          EditButton.AlignSide == alignSide &&
          EditButton.Visible)
      {
        inEditItems.Add(EditButton);
      }
    }

    protected virtual void PaintEditItemsInBounds(DataAxisGridDataCellPaintEventArgs e, Rectangle paintRect, 
      List<EditItem> rightInEditItems, Rectangle boundsRect)
    {
      Rectangle ebRect = boundsRect;
      ebRect.Width = 0;

      foreach (var item in rightInEditItems)
      {
        ebRect.Width = item.Width;

        EditItemContextPaintEventArgs eItArg = item.CreatePaintEventArgs(
          ebRect, e.GraphicsContext, e.BackColor, false, false, false, null, null);

        eItArg.IsPaintBackground = IsPaintEditItemBackground(item, e, ebRect);
        eItArg.IsPaintForeground = IsPaintEditItemForeground(item, e, ebRect);

        item.ProcessPaint(eItArg);

        ebRect.X = ebRect.X + item.Width;
      }
    }

    protected virtual bool IsPaintEditItemBackground(EditItem editButton, DataAxisGridDataCellPaintEventArgs e, Rectangle itemRect)
    {
      if (BoundPropAxisBar != null)
        return BoundPropAxisBar.IsPaintEditItemBackground(editButton, e, itemRect);
      else
        return true;
    }

    protected virtual bool IsPaintEditItemForeground(EditItem editButton, DataAxisGridDataCellPaintEventArgs e, Rectangle itemRect)
    {
      if (BoundPropAxisBar != null)
        return BoundPropAxisBar.IsPaintEditItemForeground(editButton, e, itemRect);
      else
        return true;
    }

    protected virtual void ProcessPaintContent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      if (e.ListItemBar != null && e.PropAxisBar != null)
      {
        if (BoundGrid != null && BoundGrid != e.PropAxisBar.Grid)
          BoundGrid.HandleDataCellContentPaintEvent(e);
        if (e.PropAxisBar.Grid != null)
          e.PropAxisBar.Grid.HandleDataCellContentPaintEvent(e);

        if (BoundPropAxisBar != null && BoundPropAxisBar != e.PropAxisBar)
          BoundPropAxisBar.HandleDataCellContentPaintEvent(e);
        e.PropAxisBar.HandleDataCellContentPaintEvent(e);

        HandleDataCellContentPaintEvent(e);
      }

      if (!e.Handled)
        OnPaintContent(e);
    }

    private void HandleDataCellContentPaintEvent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      var eh = this.Events[EventKeyCustomAreaPaint] as EventHandler<DataAxisGridDataCellContentPaintEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual void OnPaintContent(DataAxisGridDataCellContentPaintEventArgs e)
    {

      Color fForeColor = e.ParentCellPaintArgs.ForePaintColor;

      string text = GetDisplayText(e.ParentCellPaintArgs.Grid, e.DataColIndex, e.DataRowIndex);
      if (text != null)
      {
        e.ParentCellPaintArgs.Grid.PaintingDrawText(e.GraphicsContext, text, e.ParentCellPaintArgs.Font, e.CellContentRect, fForeColor, 
          e.ParentCellPaintArgs.HorzAlign, e.ParentCellPaintArgs.VertAlign, false);
      }
    }

    //protected internal override void PrintCell(BaseGridControl grid, PrintServiceEventArgs e,
    //  Rectangle paintRect,
    //  int colIndex, int rowIndex,
    //  int areaColIndex, int areaRowIndex,
    //  PrintServiceEventArgs printContext
    //    )
    //{
    //  Font drawFont;
    //  Rectangle textRect;
    //  Color fForeColor = Color.Black;
    //  bool wordWrap;
    //  //DataGridColumn column = Grid.VisibleColumns[dataColIndex];

    //  PropertyAxisBar propAxisBar;
    //  DataAxisGridListItemBar listItemBar;
    //  DataAxisGrid axisGrid = grid as DataAxisGrid;

    //  AxisObjectsByDataColRowIndex(axisGrid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar);

    //  string text = GetDisplayText(grid, areaColIndex, areaRowIndex);
    //  if (text != null)
    //  {
    //    drawFont = Font;
    //    TextFormatFlagsEh flags = TextFormatFlagsEh.None;
    //    textRect = EhLibUtils.TrimPadding(paintRect, Padding);

    //    wordWrap = CheckWordWrap(propAxisBar, textRect);
    //    if (wordWrap)
    //      flags = flags | TextFormatFlagsEh.WordBreak;

    //    e.DrawText(text, drawFont, textRect, fForeColor, HorzAlign, VertAlign, flags);
    //  }
    //}

    // CellClientRect

    protected internal virtual DataAxisGridDataCellClientAreaNeededEventArgs CreateDataCellClientAreaNeededEventArgs(PropertyAxisBar propAxisBar,
        DataAxisGridListItemBar listItemBar, Rectangle cellRect, BaseDataCellManager cellMan)
    {
      return new DataAxisGridDataCellClientAreaNeededEventArgs(propAxisBar, listItemBar, cellRect, cellMan);
    }

    protected internal Rectangle GetCellClientRect(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, Rectangle cellRect)
    {
      DataAxisGridDataCellClientAreaNeededEventArgs de = CreateDataCellClientAreaNeededEventArgs(propAxisBar, listItemBar, cellRect, this);

      if (de.ListItemBar != null && de.PropAxisBar != null)
      {
        if (BoundGrid != null && BoundGrid != de.PropAxisBar.Grid)
          BoundGrid.HandleDataCellClientAreaNeededEvent(de);
        if (de.PropAxisBar.Grid != null)
          de.PropAxisBar.Grid.HandleDataCellClientAreaNeededEvent(de);

        if (BoundPropAxisBar != null && BoundPropAxisBar != de.PropAxisBar)
          BoundPropAxisBar.HandleDataCellClientAreaNeededEvent(de);
        de.PropAxisBar.HandleDataCellClientAreaNeededEvent(de);

      }
      HandleClientAreaNeededEvent(de);
      return de.CellClientRect;
    }

    protected virtual void HandleClientAreaNeededEvent(DataAxisGridDataCellClientAreaNeededEventArgs e)
    {
      var eh = this.Events[EventKeyClientAreaNeeded] as EventHandler<DataAxisGridDataCellClientAreaNeededEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    protected internal virtual Rectangle GetCellCustomRect(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, Rectangle cellRect)
    {
      if (propAxisBar != null)
        return propAxisBar.GetCellCustomRect(listItemBar, cellRect);
      else
        return cellRect;
    }

    protected internal virtual int CalcInEditItemsHeight(Rectangle cellClientRect)
    {
      int result = cellClientRect.Height;

      if (EditButton != null && EditButton.Visible && EditButton.MaxHeight < result)
        result = EditButton.MaxHeight;

      foreach (EditItem ei in InEditControls)
      {
        if (ei.Visible && ei.MaxHeight < result)
          result = ei.MaxHeight;
      }

      return result;
    }

    // Handle mouse*****
    // Handle mouseDown
    protected internal override void ProcessMouseDown(BaseGridCellMouseEventArgs e)
    {
      DataAxisGridDataCellMouseEventArgs de = e as DataAxisGridDataCellMouseEventArgs;
      if (de != null && de.ListItemBar != null)
      {
        if (BoundGrid != null && BoundGrid != de.PropAxisBar.Grid)
          BoundGrid.HandleDataCellMouseDownEvent(de);
        if (de.PropAxisBar.Grid != null)
          de.PropAxisBar.Grid.HandleDataCellMouseDownEvent(de);

        if (BoundPropAxisBar != null && BoundPropAxisBar != de.PropAxisBar)
          BoundPropAxisBar.HandleMouseDownEvent(de);
        de.PropAxisBar.HandleMouseDownEvent(de);

        HandleMouseDownEvent(de);
      }
      else
      {
        base.ProcessMouseDown(e);
      }

      if (!de.Handled)
        OnMouseDown(de);
    }

    protected internal virtual void HandleMouseDownEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyMouseDown] as EventHandler<DataAxisGridDataCellMouseEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual void OnMouseDown(DataAxisGridDataCellMouseEventArgs e)
    {
      if (e.PropAxisBar != null)
      {
        e.PropAxisBar.OnMouseDown(e);
        if (e.Handled) return;
      }

      e.Handled = CheckPassMouseDownToEditor(e);
      if (e.Handled) return;

      if (IsSelected(e.Grid, e.AreaColIndex, e.AreaRowIndex) &&
          e.Button == MouseButtons.Right
         )
        EhLibUtils.DoNothing();
      else
        base.OnMouseDown(e);
    }

    protected internal virtual bool CanMouseDownStartSelectionAtPos(DataAxisGridDataCellMouseEventArgs e)
    {
      Rectangle custRect = GetCellCustomRect(e.PropAxisBar, e.ListItemBar, e.CellRect);
      if (custRect.Contains(e.GridMouseArgs.Location))
        return true;
      else
        return false;
    }

    // Handle mouseMove
    protected internal override void ProcessMouseMove(BaseGridCellMouseEventArgs e)
    {
      DataAxisGridDataCellMouseEventArgs de = e as DataAxisGridDataCellMouseEventArgs;
      if (de != null && de.ListItemBar != null)
      {
        if (BoundGrid != null && BoundGrid != de.PropAxisBar.Grid)
          BoundGrid.HandleDataCellMouseMoveEvent(de);
        if (de.PropAxisBar.Grid != null)
          de.PropAxisBar.Grid.HandleDataCellMouseMoveEvent(de);

        if (BoundPropAxisBar != null && BoundPropAxisBar != de.PropAxisBar)
          BoundPropAxisBar.HandleMouseMoveEvent(de);
        de.PropAxisBar.HandleMouseMoveEvent(de);

        HandleMouseMoveEvent(de);
      }
      else
      {
        base.ProcessMouseMove(e);
      }

      if (!de.Handled)
        OnMouseMove(de);
    }

    protected internal virtual void HandleMouseMoveEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyMouseMove] as EventHandler<DataAxisGridDataCellMouseEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual void OnMouseMove(DataAxisGridDataCellMouseEventArgs e)
    {
      base.OnMouseMove(e);
    }

    // Handle mouseUp
    protected internal override void ProcessMouseUp(BaseGridCellMouseEventArgs e)
    {
      DataAxisGridDataCellMouseEventArgs de = e as DataAxisGridDataCellMouseEventArgs;
      if (de != null && de.ListItemBar != null)
      {
        if (BoundGrid != null && BoundGrid != de.PropAxisBar.Grid)
          BoundGrid.HandleDataCellMouseUpEvent(de);
        if (de.PropAxisBar.Grid != null)
          de.PropAxisBar.Grid.HandleDataCellMouseUpEvent(de);

        if (BoundPropAxisBar != null && BoundPropAxisBar != de.PropAxisBar)
          BoundPropAxisBar.HandleMouseUpEvent(de);
        de.PropAxisBar.HandleMouseUpEvent(de);

        HandleMouseUpEvent(de);
      }
      else
      {
        base.ProcessMouseUp(e);
      }

      if (!de.Handled)
        OnMouseUp(de);
    }

    protected internal virtual void HandleMouseUpEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyMouseUp] as EventHandler<DataAxisGridDataCellMouseEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual void OnMouseUp(DataAxisGridDataCellMouseEventArgs e)
    {
      base.OnMouseUp(e);
    }

    // Handle mouseClick
    protected internal override void ProcessMouseClick(BaseGridCellMouseEventArgs e)
    {
      DataAxisGridDataCellMouseEventArgs de = e as DataAxisGridDataCellMouseEventArgs;
      if (de != null && de.ListItemBar != null)
      {
        if (BoundGrid != null && BoundGrid != de.PropAxisBar.Grid)
          BoundGrid.HandleDataCellMouseClickEvent(de);
        if (de.PropAxisBar.Grid != null)
          de.PropAxisBar.Grid.HandleDataCellMouseClickEvent(de);

        if (BoundPropAxisBar != null && BoundPropAxisBar != de.PropAxisBar)
          BoundPropAxisBar.HandleMouseClickEvent(de);
        de.PropAxisBar.HandleMouseClickEvent(de);

        HandleMouseClickEvent(de);
      }
      else
      {
        base.ProcessMouseClick(e);
      }

      if (!de.Handled)
        OnMouseClick(de);
    }

    protected internal virtual void HandleMouseClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyMouseClick] as EventHandler<DataAxisGridDataCellMouseEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual void OnMouseClick(DataAxisGridDataCellMouseEventArgs e)
    {
      base.OnMouseClick(e);
    }

    // Handle mouseDoubleClick
    protected internal override void ProcessMouseDoubleClick(BaseGridCellMouseEventArgs e)
    {
      DataAxisGridDataCellMouseEventArgs de = e as DataAxisGridDataCellMouseEventArgs;
      if (de != null && de.ListItemBar != null)
      {
        if (BoundGrid != null && BoundGrid != de.PropAxisBar.Grid)
          BoundGrid.HandleDataCellMouseDoubleClickEvent(de);
        if (de.PropAxisBar.Grid != null)
          de.PropAxisBar.Grid.HandleDataCellMouseDoubleClickEvent(de);

        if (BoundPropAxisBar != null && BoundPropAxisBar != de.PropAxisBar)
          BoundPropAxisBar.HandleMouseDoubleClickEvent(de);
        de.PropAxisBar.HandleMouseDoubleClickEvent(de);

        HandleMouseDoubleClickEvent(de);
      }
      else
      {
        base.ProcessMouseDoubleClick(e);
      }

      if (!de.Handled)
        OnMouseDoubleClick(de);
    }

    protected internal virtual void HandleMouseDoubleClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyMouseDoubleClick] as EventHandler<DataAxisGridDataCellMouseEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual void OnMouseDoubleClick(DataAxisGridDataCellMouseEventArgs e)
    {
      base.OnMouseDoubleClick(e);
    }

    // Handle MouseEnter
    protected internal override void ProcessMouseEnter(BaseGridCellEnterEventArgs e)
    {
      DataAxisGridDataCellEnterEventArgs de = e as DataAxisGridDataCellEnterEventArgs;
      if (de != null)
      {
        if (de.ListItemBar != null)
        {
          if (BoundGrid != null && BoundGrid != de.PropAxisBar.Grid)
            BoundGrid.HandleDataCellMouseEnter(de);
          if (de.PropAxisBar.Grid != null)
            de.PropAxisBar.Grid.HandleDataCellMouseEnter(de);

          if (BoundPropAxisBar != null && BoundPropAxisBar != de.PropAxisBar)
            BoundPropAxisBar.HandleMouseEnterEvent(de);
          de.PropAxisBar.HandleMouseEnterEvent(de);

          HandleMouseEnterEvent(de);
        }
        OnMouseEnter(de);
      }
      else
      {
        base.ProcessMouseEnter(e);
      }
    }

    protected internal virtual void HandleMouseEnterEvent(DataAxisGridDataCellEnterEventArgs e)
    {
      var eh = this.Events[EventKeyMouseEnter] as EventHandler<DataAxisGridDataCellEnterEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual void OnMouseEnter(DataAxisGridDataCellEnterEventArgs e)
    {
      base.OnMouseEnter(e);

      string toolTipText = GetCellToolTipText(e);
      if (!string.IsNullOrEmpty(toolTipText))
      {
        ((DataAxisGrid)e.Grid).ShowCellHintTooltip(toolTipText, -1);
      }
    }

    // Handle MouseLeave
    protected internal override void ProcessMouseLeave(BaseGridCellLeaveEventArgs e)
    {
      DataAxisGridDataCellLeaveEventArgs de = e as DataAxisGridDataCellLeaveEventArgs;
      if (de != null)
      {
        if (de.ListItemBar != null)
        {
          if (BoundGrid != null && BoundGrid != de.PropAxisBar.Grid)
            BoundGrid.HandleDataCellMouseLeave(de);
          if (de.PropAxisBar.Grid != null)
            de.PropAxisBar.Grid.HandleDataCellMouseLeave(de);

          if (BoundPropAxisBar != null && BoundPropAxisBar != de.PropAxisBar)
            BoundPropAxisBar.HandleMouseLeaveEvent(de);
          de.PropAxisBar.HandleMouseLeaveEvent(de);

          HandleMouseLeaveEvent(de);
        }
        OnMouseLeave(de);
      }
      else
      {
        base.ProcessMouseLeave(e);
      }
    }

    protected internal virtual void HandleMouseLeaveEvent(DataAxisGridDataCellLeaveEventArgs e)
    {
      var eh = this.Events[EventKeyMouseLeave] as EventHandler<DataAxisGridDataCellLeaveEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual void OnMouseLeave(DataAxisGridDataCellLeaveEventArgs e)
    {
      base.OnMouseLeave(e);
      ((DataAxisGrid)e.Grid).HideCellHintToolTip();
    }

    // Handle MouseHover
    protected internal override void ProcessMouseHover(BaseGridCellMouseEventArgs e)
    {
      DataAxisGridDataCellMouseEventArgs de = e as DataAxisGridDataCellMouseEventArgs;
      if (de != null)
      {
        if (de.ListItemBar != null)
        {
          if (BoundGrid != null && BoundGrid != de.PropAxisBar.Grid)
            BoundGrid.HandleDataCellMouseHoverEvent(de);
          if (de.PropAxisBar.Grid != null)
            de.PropAxisBar.Grid.HandleDataCellMouseHoverEvent(de);

          if (BoundPropAxisBar != null && BoundPropAxisBar != de.PropAxisBar)
            BoundPropAxisBar.HandleMouseHoverEvent(de);
          de.PropAxisBar.HandleMouseHoverEvent(de);

          HandleMouseHoverEvent(de);
        }

        if (!de.Handled)
          OnMouseHover(de);
      }
      else
      {
        base.ProcessMouseHover(e);
      }
    }

    protected internal virtual void HandleMouseHoverEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyMouseHover] as EventHandler<DataAxisGridDataCellMouseEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual void OnMouseHover(DataAxisGridDataCellMouseEventArgs e)
    {
      base.OnMouseHover(e);
    }

    //Other
    private Type GetEditorType(PropertyAxisBar propAxisBar)
    {
      return EditorType;
      //if (editorType != null)
      //  return editorType;
      //else if (propAxisBar == BoundPropAxisBar)
      //  return DefaultEditorType;
      //else if (BoundPropAxisBar != null)
      //  return BoundPropAxisBar.EditorType;
      //else if (propAxisBar != null)
      //  return propAxisBar.EditorType;
      //else
      //  return null;
    }

    protected virtual void EditorTypeChanged()
    {
    }

    private void InEditControls_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
    {
      if (e.Action == NotifyCollectionChangedAction.Remove)
      {
        foreach (EditItem ei in e.OldItems)
        {
          ei.InEditWinControl.Parent = null;
          if (ei.Owner == this)
            ei.Owner = null;
        }
      }

      foreach (EditItem ei in InEditControls)
      {
        //ei.EditControl = this;
        if (ei.Owner == null)
          ei.Owner = this;
      }

      if (BoundPropAxisBar != null)
        BoundPropAxisBar.InEditControlsCollectionChanged(sender, e);
    }

    public override void OccupyEditControl(BaseGridControl grid, Control cellEditControl, bool selectAll, BaseGridCellEditorParamsNeededEventArgs editorParams)
    {
      DataAxisGridDataCellEditorParamsNeededEventArgs de = editorParams as DataAxisGridDataCellEditorParamsNeededEventArgs;

      object editValue = GetEditValue(de.PropAxisBar, de.ListItemBar);

      DataAxisGridDataCellEditorOccupyEventArgs oeEventArgs = CreateEditorOccupyEventArgs(grid, de.ColIndex, de.RowIndex,
        de.AreaColIndex, de.AreaRowIndex, de.CellRect, de.PropAxisBar, de.ListItemBar, cellEditControl, editValue, selectAll, de);

      ProcessEditorOccupy(oeEventArgs);

      ((IDataAxisGridCellInPlaceEditor)cellEditControl).CellPosData = oeEventArgs;

      //CellWorker.OccupyEditControl(cellEditControl, selectAll, editorParams);
    }

    //protected virtual DataCellWorker CreateDataCellWorker()
    //{
    //  throw new NotImplementedException();
    //}

    protected internal virtual void OnContentClick(DataAxisGridDataCellEventArgs e)
    {
      ((DataAxisGrid)e.Grid).OnDataCellContentClick(e);
      if (BoundPropAxisBar != null)
        BoundPropAxisBar.OnDataCellContentClick(e);
    }

    protected virtual bool CheckPassMouseDownToEditor(DataAxisGridDataCellMouseEventArgs de)
    {
      bool result = false;
      bool isInEditItemsRect = false;
      Rectangle editItemsRect;

      if (!CanMouseDownShowEditor(de)) return false;

      editItemsRect = GetLeftEditItemsRect(de.PropAxisBar, de.ListItemBar, de.CellRect);
      if (editItemsRect.Contains(de.GridMouseArgs.Location))// InCellX, de.InCellY))
        isInEditItemsRect = true;

      editItemsRect = GetRightEditItemsRect(de.PropAxisBar, de.ListItemBar, de.CellRect);
      //if (editItemsRect.Contains(de.InCellX, de.InCellY))
      if (editItemsRect.Contains(de.GridMouseArgs.Location))
        isInEditItemsRect = true;

      if (isInEditItemsRect)
      {
        de.Grid.InteractiveFocusCell(de.ColIndex, de.RowIndex, InteractiveActionSource.Mouse);
        if (de.Grid.EditorMode)
          de.Grid.HideEditor(true);
        de.Grid.ShowEditor(true);
        if (de.Grid.EditorMode)
        {
          Control inEditItem = EhLibUtils.ControlFromScreenPoint(de.Grid.PointToScreen(de.GridMouseArgs.Location));
          if (inEditItem != null && inEditItem != de.Grid)
          {
            Point mousePos = de.Grid.PointToScreen(de.GridMouseArgs.Location);
            mousePos = inEditItem.PointToClient(mousePos);
            EhLibUtils.SendMouseDownMessage(inEditItem, mousePos, de.GridMouseArgs.Button);
            result = true;
          }
        }
      }

      return result;
    }

    protected internal override BaseGridCellMouseEventArgs CreateMouseEventArgs(
      BaseGridControl grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, int inCellX, int inCellY,
      Rectangle cellRect, MouseEventArgs gridMouseArgs)
    {
      BaseGridCellMouseEventArgs de;
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = grid as DataAxisGrid;

      AxisObjectsByDataColRowIndex(axisGrid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar);

      //if (propAxisBar != null)
      //  de = propAxisBar.CreateDataCellMouseEventArgs(
      //    colIndex, rowIndex, areaColIndex, areaRowIndex, propAxisBar, listItemBar, this, inCellX, inCellY, cellRect, gridMouseArgs);
      //else
      //  de = CreateMouseEventArgs(colIndex, rowIndex, areaColIndex, areaRowIndex, propAxisBar, listItemBar, inCellX, inCellY, cellRect, gridMouseArgs);
      de = CreateMouseEventArgs(axisGrid, colIndex, rowIndex, areaColIndex, areaRowIndex, propAxisBar, listItemBar, 
                                inCellX, inCellY, cellRect, gridMouseArgs);

      return de;
    }

    protected internal virtual DataAxisGridDataCellMouseEventArgs CreateMouseEventArgs(
      DataAxisGrid grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, 
      int inCellX, int inCellY, Rectangle cellRect, MouseEventArgs gridMouseArgs)
    {
      var result = new DataAxisGridDataCellMouseEventArgs(grid, this, 
        colIndex, rowIndex, areaColIndex, areaRowIndex, propAxisBar, listItemBar, 
        inCellX, inCellY, cellRect, gridMouseArgs);

      result.CustomRect = GetCellCustomRect(propAxisBar, listItemBar, cellRect);
      result.ClientRect = GetCellClientRect(propAxisBar, listItemBar, result.CustomRect);
      result.ContentRect = CalcContentRect(result.ClientRect);

      return result;
    }

    protected internal override BaseGridCellEnterEventArgs CreateMouseEnterEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int leaveColIndex, int leaveRowIndex)
    {
      BaseGridCellEnterEventArgs de;
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = grid as DataAxisGrid;

      AxisObjectsByDataColRowIndex(axisGrid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar);

      //if (PropAxisBar != null)
      //  de = PropAxisBar.CreateDataCellEnterEventArgs(
      //    colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, leaveColIndex, leaveRowIndex, propAxisBar, listItemBar, this);
      //else
      //  de = base.CreateCellEnterEventArgs(colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, leaveColIndex, leaveRowIndex);
      de = CreateMouseEnterEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, leaveColIndex, leaveRowIndex, propAxisBar, listItemBar);

      return de;
    }

    protected internal virtual DataAxisGridDataCellEnterEventArgs CreateMouseEnterEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int leaveColIndex, int leaveRowIndex,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      return new DataAxisGridDataCellEnterEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, leaveColIndex, leaveRowIndex, propAxisBar, listItemBar, this);
    }

    protected internal override BaseGridCellLeaveEventArgs CreateMouseLeaveEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int enterColIndex, int enterRowIndex)
    {
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = grid as DataAxisGrid;

      AxisObjectsByDataColRowIndex(axisGrid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar);

      BaseGridCellLeaveEventArgs de;
      //if (PropAxisBar != null)
      //  de = PropAxisBar.CreateDataCellLeaveEventArgs(
      //    colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, enterColIndex, enterRowIndex, propAxisBar, listItemBar, this);
      //else
      //  de = base.CreateCellLeaveEventArgs(colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, enterColIndex, enterRowIndex);
      de = CreateMouseLeaveEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, 
             enterColIndex, enterRowIndex, propAxisBar, listItemBar);

      return de;
    }

    protected internal virtual DataAxisGridDataCellLeaveEventArgs CreateMouseLeaveEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int enterColIndex, int enterRowIndex,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      return new DataAxisGridDataCellLeaveEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, 
        enterColIndex, enterRowIndex, propAxisBar, listItemBar, this);
    }

    //ParseValue

    internal object ProcessParseValue(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, object value)
    {
      DataAxisGridDataCellParseValueEventArgs e = CreateParseValueEventArgs(propAxisBar, listItemBar, this, value);

      if (BoundGrid != null && BoundGrid != e.PropAxisBar.Grid)
        BoundGrid.HandleParseValueEvent(e);
      if (e.PropAxisBar.Grid != null)
        e.PropAxisBar.Grid.HandleParseValueEvent(e);

      if (BoundPropAxisBar != null && BoundPropAxisBar != e.PropAxisBar)
        BoundPropAxisBar.HandleParseValueEvent(e);
      e.PropAxisBar.HandleParseValueEvent(e);

      HandleParseValueEvent(e);

      if (!e.Handled)
        OnParseValue(e);

      return e.OutValue;
    }

    protected internal virtual void OnParseValue(DataAxisGridDataCellParseValueEventArgs e)
    {
      e.PropAxisBar.OnParseValue(e);
    }

    protected internal virtual DataAxisGridDataCellParseValueEventArgs CreateParseValueEventArgs(
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan, object inValue)
    {
      return new DataAxisGridDataCellParseValueEventArgs(propAxisBar, listItemBar, cellMan, inValue);
    }

    protected internal virtual void HandleParseValueEvent(DataAxisGridDataCellParseValueEventArgs e)
    {
      var eh = this.Events[EventKeyParseValueNeeded] as EventHandler<DataAxisGridDataCellParseValueEventArgs>;
      if (eh != null)
        eh(this, (DataAxisGridDataCellParseValueEventArgs)e);
    }


    //CanModify
    public bool CanModify(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = grid as DataAxisGrid;
      AxisObjectsByDataColRowIndex(axisGrid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar);

      return CanModify(propAxisBar, listItemBar);
    }

    public virtual bool CanModify(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      DataAxisGridDataCellCanModifyStateNeededEventArgs e = CreateCanModifyStateNeededEventArgs(propAxisBar, listItemBar);
      ProcessCanModifyStateNeeded(e);

      return e.CanModify;
    }

    protected virtual DataAxisGridDataCellCanModifyStateNeededEventArgs CreateCanModifyStateNeededEventArgs(
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      //if (propAxisBar != null)
      //  e = propAxisBar.CreateCanModifyStateNeededEventArgs(propAxisBar, listItemBar, this);
      //else
      //  e =  new DataAxisGridDataCellCanModifyStateNeededEventArgs(propAxisBar, listItemBar, this);
      DataAxisGridDataCellCanModifyStateNeededEventArgs e;
      e = new DataAxisGridDataCellCanModifyStateNeededEventArgs(propAxisBar, listItemBar, this);
      return e;
    }

    protected virtual void ProcessCanModifyStateNeeded(DataAxisGridDataCellCanModifyStateNeededEventArgs e)
    {
      OnCanModifyStateNeeded(e);

      if (BoundGrid != null && BoundGrid != e.PropAxisBar.Grid)
        BoundGrid.HandleCanModifyStateNeededEvent(e);
      if (e.PropAxisBar.Grid != null)
        e.PropAxisBar.Grid.HandleCanModifyStateNeededEvent(e);

      if (BoundPropAxisBar != null && BoundPropAxisBar != e.PropAxisBar)
        BoundPropAxisBar.HandleCanModifyStateNeededEvent(e);
      e.PropAxisBar.HandleCanModifyStateNeededEvent(e);

      //if (e.PropAxisBar != null)
      //{
      //  e.PropAxisBar.Grid.HandleCanModifyStateNeededEvent(e);
      //  e.PropAxisBar.ProcessCanModifyStateNeeded(e);
      //}
      HandleCanModifyStateNeededEvent(e);
    }

    protected virtual void OnCanModifyStateNeeded(DataAxisGridDataCellCanModifyStateNeededEventArgs e)
    {
      if (e.PropAxisBar != null && e.ListItemBar != null)
        //TODO Conside Grid.EditOptions.AddAllows, ModifyAllowed
        e.CanModify = !ReadOnly && !e.PropAxisBar.Grid.ReadOnly;
      else
        e.CanModify = false;
    }

    protected virtual void HandleCanModifyStateNeededEvent(DataAxisGridDataCellCanModifyStateNeededEventArgs e)
    {
      var eh = this.Events[EventKeyCanModifyStateNeeded] as EventHandler<DataAxisGridDataCellCanModifyStateNeededEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    // IEditItemOwner
    Font IEditItemOwner.GetDefaultFont()
    {
      return Font;
    }

    void IEditItemOwner.EditItemChanged(EditItem editItem)
    {
      if (BoundPropAxisBar != null)
        BoundPropAxisBar.EditItemChanged(editItem);
    }

    Color IEditItemOwner.DefaultForeColor()
    {
      return ForeColor;
    }

    void IEditItemOwner.EditItemOwnerChanged(IEditItemOwner oldOwner, IEditItemOwner newOwner)
    {
      if (BoundPropAxisBar != null)
        BoundPropAxisBar.EditItemChanged(null);
    }

    bool IEditItemOwner.GetDefaultVisibleState(EditItem editItem)
    {
      return GetEditItemDefaultVisibleState(editItem);
    }

    //Other 
    //protected internal void PassThroughEventHandlers<TEventArgs>(
    //  EventArgsProc<TEventArgs> boundGridEvent,
    //  EventArgsProc<TEventArgs> argGridEvent,
    //  EventArgsProc<TEventArgs> propAxisBarEvent,
    //  EventArgsProc<TEventArgs> boundAxisBarEvent,
    //  EventArgsProc<TEventArgs> cellEvent,
    //  TEventArgs e) 
    //  where TEventArgs : EventArgs
    //{
    //  boundGridEvent(e);
    //  argGridEvent(e);
    //  propAxisBarEvent(e);
    //  boundAxisBarEvent(e);
    //  cellEvent(e);
    //}

    protected internal virtual DataAxisGridDataCellEventArgs CreateDataCellEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell
      )
    {
      return new DataAxisGridDataCellEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, 
        propAxisBar, listItemBar, cell);
    }

    protected internal override BaseGridCellEventArgs CreateCellEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect)
    {
      BaseGridCellEventArgs de;
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = grid as DataAxisGrid;

      AxisObjectsByDataColRowIndex(axisGrid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar);

      if (propAxisBar != null)
        de = propAxisBar.CreateDataCellEventArgs(axisGrid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, propAxisBar, listItemBar, this);
      else
        de = CreateDataCellEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, propAxisBar, listItemBar, this);

      return de;
    }

    public virtual void AxisObjectsByDataColRowIndex(DataAxisGrid grid, int dataColIndex, int dataRowIndex, 
      out PropertyAxisBar propAxisBar, out DataAxisGridListItemBar listItemBar)
    {
      DataAxisGridListAxisItemViewState listAxisItemViewState;
      grid.AxisObjectsByDataColRowIndex(dataColIndex, dataRowIndex, out propAxisBar, out listItemBar, out listAxisItemViewState);
    }

    public virtual void AxisObjectsByDataColRowIndex(DataAxisGrid grid, int dataColIndex, int dataRowIndex, 
      out PropertyAxisBar propAxisBar, out DataAxisGridListItemBar listItemBar, out DataAxisGridListAxisItemViewState listAxisItemViewState)
    {
      grid.AxisObjectsByDataColRowIndex(dataColIndex, dataRowIndex, out propAxisBar, out listItemBar, out listAxisItemViewState);
    }

    protected internal virtual int CalcDefaultRowHeight(PropertyAxisBar propAxisBar)
    {
      int th;
      Padding padding = GetPadding(propAxisBar);

      th = EhLibUtils.GetFontHeight(GetFont(propAxisBar));
      th = th + padding.Top + padding.Bottom;
      return th;
    }

    protected internal virtual int CalcCellHeight(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, int cellWidth)
    {
      int th;

      if (HeightOptions.Unit == GridRowHeightUnit.TextLine)
      {
        Padding padding = GetPadding(propAxisBar);
        th = EhLibUtils.GetFontHeight(GetFont(propAxisBar)) * HeightOptions.ContentHeight;
        th = th + padding.Top + padding.Bottom;
      }
      else
      {
        th = HeightOptions.ContentHeight;
        th = th + Padding.Top + Padding.Bottom;
      }

      return th;
    }

    protected internal virtual int ProcessCalcCellHeight(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, int cellWidth)
    {
      int th;
      int rowMaxHeight;

      th = CalcCellHeight(propAxisBar, listItemBar, cellWidth);
      Padding padding = GetPadding(propAxisBar);

      if (HeightOptions.MaxContentHeight > 0)
      {
        if (HeightOptions.Unit == GridRowHeightUnit.TextLine)
        {
          int fh = EhLibUtils.GetFontHeight(Font);
          rowMaxHeight = fh * HeightOptions.MaxContentHeight;
          rowMaxHeight = rowMaxHeight + padding.Top + padding.Bottom;
        }
        else
        {
          rowMaxHeight = HeightOptions.MaxContentHeight;
          rowMaxHeight = rowMaxHeight + padding.Top + padding.Bottom;
        }

        if (th > rowMaxHeight)
          th = rowMaxHeight;
      }

      return th;
    }

    public override string GetDisplayText(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = grid as DataAxisGrid;

      AxisObjectsByDataColRowIndex(axisGrid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar);

      return GetDisplayText(propAxisBar, listItemBar);
    }

    public virtual string GetDisplayText(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      object val;
      if (propAxisBar != null && listItemBar != null)
      {
        if (propAxisBar.DisplayValuesCached)
        {
          val = propAxisBar.GetCachedDisplayValue(listItemBar);
          if (val != null)
            return val.ToString();
          else
            return null;
        }
        else
        {
          val = propAxisBar.GetListItemBarValue(listItemBar);
          //return GetValueDisplayText(propAxisBar, val);
          DataAxisGridDataCellDisplayValueNeededEventArgs e = CreateDisplayValueNeededEventArgs(propAxisBar, listItemBar, val);

          ProcessDisplayValueNeeded(e);
          if (e.DisplayValue != null)
            return e.DisplayValue.ToString();
          else
            return null;
        }
      }
      else
        return null;
    }

    public string GetValueDisplayText(PropertyAxisBar propAxisBar, object value)
    {
      DataAxisGridDataCellDisplayValueNeededEventArgs e = CreateDisplayValueNeededEventArgs(propAxisBar, null, value);

      ProcessDisplayValueNeeded(e);
      if (e.DisplayValue != null)
        return e.DisplayValue.ToString();
      else
        return null;
    }

    protected internal virtual DataAxisGridDataCellDisplayValueNeededEventArgs CreateDisplayValueNeededEventArgs(
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, object value)
    {
      return new DataAxisGridDataCellDisplayValueNeededEventArgs(propAxisBar, listItemBar, this, value);
    }

    protected internal void ProcessDisplayValueNeeded(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      if (BoundGrid != null && BoundGrid != e.PropAxisBar.Grid)
        BoundGrid.HandleDisplayValueNeededEvent(e);
      if (e.PropAxisBar.Grid != null)
        e.PropAxisBar.Grid.HandleDisplayValueNeededEvent(e);

      if (BoundPropAxisBar != null && BoundPropAxisBar != e.PropAxisBar)
        BoundPropAxisBar.HandleDisplayValueNeededEvent(e);
      e.PropAxisBar.HandleDisplayValueNeededEvent(e);

      HandleDisplayValueNeededEvent(e);

      if (!e.Handled)
        OnDisplayValueNeeded(e);
    }

    protected virtual void HandleDisplayValueNeededEvent(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDisplayValueNeeded] as EventHandler<DataAxisGridDataCellDisplayValueNeededEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual void OnDisplayValueNeeded(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      Type dataType;

      if (boundPropAxisBar != null)
        dataType = boundPropAxisBar.DataType;
      else
        dataType = null;

      TypeConverter srcConverter = null;
      TypeConverter targetConverter = EhLibUtils.GetCachedStringConverter();
      if (dataType != null)
        srcConverter = TypeDescriptor.GetConverter(dataType);
      object result = EhLibManager.DefaultEhLibManager.ValueConverter.FormatValue(
        e.Value, typeof(string), srcConverter, targetConverter, "", null, "", null);
      e.DisplayValue = result.ToString();
    }

    //Edit Value Needed
    public virtual object GetEditValue(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      if (propAxisBar != null && listItemBar != null)
      {
        object value = propAxisBar.GetListItemBarValue(listItemBar);

        DataAxisGridDataCellEditValueNeededEventArgs e = CreateEditValueNeededEventArgs(propAxisBar, value);

        ProcessEditValueNeeded(e);
        return e.EditValue;
      }
      else
        return null;
    }

    protected internal virtual DataAxisGridDataCellEditValueNeededEventArgs CreateEditValueNeededEventArgs(
      PropertyAxisBar propAxisBar, object value)
    {
      return new DataAxisGridDataCellEditValueNeededEventArgs(propAxisBar, this, value);
    }

    protected internal void ProcessEditValueNeeded(DataAxisGridDataCellEditValueNeededEventArgs e)
    {
      if (BoundGrid != null && BoundGrid != e.PropAxisBar.Grid)
        BoundGrid.HandleEditValueNeededEvent(e);
      if (e.PropAxisBar.Grid != null)
        e.PropAxisBar.Grid.HandleEditValueNeededEvent(e);

      if (BoundPropAxisBar != null && BoundPropAxisBar != e.PropAxisBar)
        BoundPropAxisBar.HandleEditValueNeededEvent(e);
      e.PropAxisBar.HandleEditValueNeededEvent(e);

      HandleEditValueNeededEvent(e);

      if (!e.Handled)
        OnEditValueNeeded(e);
    }

    protected virtual void HandleEditValueNeededEvent(DataAxisGridDataCellEditValueNeededEventArgs e)
    {
      var eh = this.Events[EventKeyEditValueNeeded] as EventHandler<DataAxisGridDataCellEditValueNeededEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected virtual void OnEditValueNeeded(DataAxisGridDataCellEditValueNeededEventArgs e)
    {
      //e.EditValue = CellWorker.ValueToEditValue(e.Value);
      e.EditValue = e.Value;
    }

    //Other
    protected internal override void OnGetCellBorderParams(BaseGridCellBorderEventArgs e)
    {
      base.OnGetCellBorderParams(e);

      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = e.Grid as DataAxisGrid;

      AxisObjectsByDataColRowIndex(axisGrid, e.AreaColIndex, e.AreaRowIndex, out propAxisBar, out listItemBar);

      if (propAxisBar != null)
        propAxisBar.OnGetDataCellBorderParams(e);
    }

    public virtual void InitEditButton()
    {
      editButton = CreateDropDownButton();
      editButton.Owner = this;
      //TODO: editButton.AddOwner(this);
      //editButton.EditItemChanged += EditItemChanged;
      //editButton.DefaultVisibleStateRequested += EditButtonDefaultVisibleStateRequested;
    }

    protected virtual bool GetEditItemDefaultVisibleState(EditItem editItem)
    {
      if (editItem == EditButton)
        return EditButtonDefaultVisible();
      else
        return true;
    }

    //private void EditItemChanged(object sender, EventArgs e)
    //{
    //  EditButtonChanged();
    //}

    protected virtual void EditButtonChanged()
    {
      if (BoundGrid != null)
        BoundGrid.Invalidate();
    }

    //private void EditButtonDefaultVisibleStateRequested(object sender, VisibleStateRequestedEventArgs e)
    //{
    //  e.Visible = EditButtonDefaultVisible();
    //}

    protected virtual bool EditButtonDefaultVisible()
    {
      return false;
    }

    protected internal virtual bool EditButtonAccessible()
    {
      if (editButton != null || EditButtonDefaultVisible())
        return true;
      else
        return false;
    }

    protected virtual EditButton CreateDropDownButton()
    {
      return new EditButton();
    }

    //public override void GridCellPosToAreaCellPos(int gridColIndex, int gridRowIndex, out int areaColIndex, out int areaRowIndex)
    //{
    //  areaColIndex = gridColIndex;
    //  areaRowIndex = gridRowIndex;

    //  if (PropAxisBar != null)
    //    PropAxisBar.GridCellPosToDataCellPos(gridColIndex, gridRowIndex, out areaColIndex, out areaRowIndex);
    //}

    //public override void AreaCellPosToGridCellPos(int areaColIndex, int areaRowIndex, out int gridColIndex, out int gridRowIndex)
    //{
    //  gridColIndex = areaColIndex;
    //  gridRowIndex = areaRowIndex;

    //  if (PropAxisBar != null)
    //    PropAxisBar.DataCellPosToGridCellPos(areaColIndex, areaRowIndex, out gridColIndex, out gridRowIndex);
    //}

    protected virtual Rectangle GetLeftEditItemsRect(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, Rectangle cellRect)
    {
      Rectangle clientRect = GetCellClientRect(propAxisBar, listItemBar, cellRect);
      //return Rectangle.Empty;
      int leftEditItemsWidth = CalcSideInEditItemsWidth(InEditAlignSide.Left);
      Rectangle result = new Rectangle(clientRect.X, clientRect.Y, leftEditItemsWidth, clientRect.Height);
      return result;
    }

    protected virtual Rectangle GetRightEditItemsRect(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, Rectangle cellRect)
    {
      Rectangle clientRect = GetCellClientRect(propAxisBar, listItemBar, cellRect);
      int rightEditItemsWidth = CalcSideInEditItemsWidth(InEditAlignSide.Right);
      Rectangle result = new Rectangle(clientRect.Right - rightEditItemsWidth, clientRect.Y, rightEditItemsWidth, clientRect.Height);
      return result;

      //Rectangle result = Rectangle.Empty;

      //if (EditButtonAccessible() && EditButton.Visible)
      //{
      //  result.X = cellRect.Width - EditButton.Width;
      //  result.Width = EditButton.Width;
      //  result.Y = 0;
      //  result.Height = cellRect.Height;
      //}

      //return result;
    }

    protected internal override bool IsSelected(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = grid as DataAxisGrid;

      AxisObjectsByDataColRowIndex(axisGrid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar);

      if (propAxisBar != null)
        return propAxisBar.IsDataCellSelected(areaColIndex, areaRowIndex);
      else
        return false;
    }

    //protected internal override BaseGridCellCustomAreaMeasuresEventArgs CreateCellCustomAreaMeasuresEventArgs(
    //  int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, CellCustomAreaMeasures areaMeasures)
    //{
    //  PropertyAxisBar propAxisBar;
    //  DataAxisGridListItemBar listItemBar;

    //  AxisObjectsByDataColRowIndex(areaColIndex, areaRowIndex, out propAxisBar, out listItemBar);

    //  if (PropAxisBar != null)
    //    return PropAxisBar.CreateCellCustomAreaMeasuresEventArgs(colIndex, rowIndex, areaColIndex, areaRowIndex, propAxisBar, listItemBar, areaMeasures);
    //  else 
    //    return base.CreateCellCustomAreaMeasuresEventArgs(colIndex, rowIndex, areaColIndex, areaRowIndex, areaMeasures);
    //}

    //protected internal override void OnCellCustomAreaMeasuresNeeded(BaseGridCellCustomAreaMeasuresEventArgs e)
    //{
    //  if (PropAxisBar != null)
    //    PropAxisBar.OnCellCustomAreaMeasuresNeeded(e);
    //}

    protected internal override BaseGridCellContextMenuStripNeededEventArgs CreateCellContextMenuStripNeededEventArgs(
      BaseGridControl grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, int inCellX, int inCellY,
      Rectangle cellRect, int mousePosX, int mousePosY)
    {
      DataAxisGridDataCellContextMenuStripNeededEventArgs de;
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = grid as DataAxisGrid;

      AxisObjectsByDataColRowIndex(axisGrid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar);

      de = CreateCellContextMenuStripNeededEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, 
        inCellX, inCellY, cellRect, mousePosX, mousePosY, propAxisBar, listItemBar);

      return de;
    }

    protected virtual DataAxisGridDataCellContextMenuStripNeededEventArgs CreateCellContextMenuStripNeededEventArgs(
      BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, int inCellX, int inCellY,
      Rectangle cellRect, int mousePosX, int mousePosY, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      return new DataAxisGridDataCellContextMenuStripNeededEventArgs(grid, this, colIndex, rowIndex, areaColIndex, areaRowIndex, inCellX, inCellY,
        cellRect, mousePosX, mousePosY, propAxisBar, listItemBar);
    }

    protected internal override void OnContextMenuStripNeeded(BaseGridCellContextMenuStripNeededEventArgs e)
    {
      var age = e as DataAxisGridDataCellContextMenuStripNeededEventArgs;
      if (age != null && BoundGrid != null)
      {
        BoundGrid.OnDataCellContextMenuStripNeeded(age);
      }
      else
      {
        e.ContextMenuStrip = ContextMenuStrip;
      }
    }

    protected internal override void HandleMouseContextMenuStripNeededEvent(BaseGridCellContextMenuStripNeededEventArgs e)
    {
      var age = e as DataAxisGridDataCellContextMenuStripNeededEventArgs;

      if (BoundGrid != null && BoundGrid != age.PropAxisBar.Grid)
        BoundGrid.HandleDataCellContextMenuStripNeededEvent(age);
      if (age.PropAxisBar.Grid != null)
        age.PropAxisBar.Grid.HandleDataCellContextMenuStripNeededEvent(age);

      if (BoundPropAxisBar != null && BoundPropAxisBar != age.PropAxisBar)
        BoundPropAxisBar.HandleDataCellContextMenuStripNeededEvent(age);
      age.PropAxisBar.HandleDataCellContextMenuStripNeededEvent(age);

      HandleMouseContextMenuStripNeededEvent(age);
    }

    protected virtual void HandleMouseContextMenuStripNeededEvent(DataAxisGridDataCellContextMenuStripNeededEventArgs e)
    {
      var eh = this.Events[EventKeyContextMenuStripNeeded] as EventHandler<DataAxisGridDataCellContextMenuStripNeededEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual int GetOptimalWidth(int colIndex, int rowIndex, int dataColIndex, int dataRowIndex, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      //int result;
      //result = GetOptimalCellStandartAreaWidth(colIndex, rowIndex, dataColIndex, dataRowIndex, listItemBar) +
      //         GetOptimalCellCustomAreaWidth(colIndex, rowIndex, dataColIndex, dataRowIndex, listItemBar);
      //return result;

      var e = CreateDataCellOptimalWidthNeededEventArgs(propAxisBar, listItemBar);
      ProcessCellOptimalWidthNeeded(e);
      return e.OptimalWidth;
    }

    protected virtual DataAxisGridDataCellOptimalWidthNeededEventArgs CreateDataCellOptimalWidthNeededEventArgs(
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      if (propAxisBar != null)
        return propAxisBar.CreateDataCellOptimalWidthNeededEventArgs(propAxisBar, listItemBar, this);
      else
        return new DataAxisGridDataCellOptimalWidthNeededEventArgs(propAxisBar, listItemBar, this);
    }

    private void ProcessCellOptimalWidthNeeded(DataAxisGridDataCellOptimalWidthNeededEventArgs e)
    {
      OnCellOptimalWidthNeeded(e);
      HandleCellOptimalWidthNeededEvent(e);
    }

    private void HandleCellOptimalWidthNeededEvent(DataAxisGridDataCellOptimalWidthNeededEventArgs e)
    {
      if (e.PropAxisBar != null)
        e.PropAxisBar.HandleCellOptimalWidthNeededEvent(e);
    }

    protected virtual void OnCellOptimalWidthNeeded(DataAxisGridDataCellOptimalWidthNeededEventArgs e)
    {
      e.OptimalWidth = GetOptimalCellStandardAreaWidth(e.PropAxisBar, e.ListItemBar);
    }

    protected internal virtual int GetOptimalCellStandardAreaWidth(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      DataAxisGridDataCellFormatParamsNeededEventArgs fpe = CreateProcessFormatParams(propAxisBar.Grid, propAxisBar, listItemBar);

      int result = GetOptimalCellContentWidth(0, 0, 0, 0, fpe);

      Rectangle cellInitRect = new Rectangle(0, 0, 1000, propAxisBar.Grid.DefaultRowHeight);
      Rectangle customRect = GetCellCustomRect(propAxisBar, listItemBar, cellInitRect);
      Rectangle clientRect = GetCellClientRect(propAxisBar, listItemBar, customRect);
      Rectangle contentRect = CalcContentRect(clientRect);

      Rectangle textAreaRect = EhLibUtils.TrimPadding(contentRect, fpe.Padding);

      //result = result + fpe.Padding.Left + fpe.Padding.Right + 2;
      //int leftSideItemsWith = CalcSideInEditItemsWidth(InEditAlignSide.Left);
      //int rightSideItemsWith = CalcSideInEditItemsWidth(InEditAlignSide.Right);
      ////if (EditButton.Visible)
      ////  result = result + EditButton.Width;
      //result = result + leftSideItemsWith + rightSideItemsWith;
      result = result + (cellInitRect.Width - textAreaRect.Width) + 2;
      return result;
    }

    protected internal virtual int GetOptimalCellContentWidth(int colIndex, int rowIndex, int dataColIndex, int dataRowIndex, 
      DataAxisGridDataCellFormatParamsNeededEventArgs fpe)
    {
      int result;
      string text = GetDisplayText(fpe.PropAxisBar, fpe.ListItemBar);
      result = EhLibUtils.MeasureText(EhLibUtils.DisplayGraphicsCash, text, fpe.Font).Width;
      return result;
    }

    //protected internal virtual int GetOptimalCellCustomAreaWidth(int colIndex, int rowIndex, int dataColIndex, int dataRowIndex, DataAxisGridListItemBar listItemBar)
    //{
    //  var custAreaMeasures = new CellCustomAreaMeasures();
    //  SetCellCustomAreaMeasures(colIndex, rowIndex, dataColIndex, dataRowIndex, custAreaMeasures);
    //  return custAreaMeasures.LeftSide.Width + custAreaMeasures.RightSide.Width;
    //}

    protected virtual string GetCellToolTipText(BaseGridCellEventArgs e)
    {
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = e.Grid as DataAxisGrid;

      AxisObjectsByDataColRowIndex(axisGrid, e.AreaColIndex, e.AreaRowIndex, out propAxisBar, out listItemBar);

      DataAxisGridDataCellToolTipInfoEventArgs de;
      if (listItemBar != null)
      {
        de = CreateToolTipInfoEventArgs(propAxisBar, listItemBar, this);
        ProcessDataCellToolTipInfoNeeded(de);
        return de.ToolTipText;
      }
      else
      {
        return null;
      }

    }

    protected internal virtual DataAxisGridDataCellToolTipInfoEventArgs CreateToolTipInfoEventArgs(
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
    {
      return new DataAxisGridDataCellToolTipInfoEventArgs(propAxisBar, listItemBar, cellMan);
    }

    protected internal virtual void ProcessDataCellToolTipInfoNeeded(DataAxisGridDataCellToolTipInfoEventArgs e)
    {

      if (BoundGrid != null && BoundGrid != e.PropAxisBar.Grid)
        BoundGrid.HandleDataCellToolTipInfoNeeded(e);
      if (e.PropAxisBar.Grid != null)
        e.PropAxisBar.Grid.HandleDataCellToolTipInfoNeeded(e);

      if (BoundPropAxisBar != null && BoundPropAxisBar != e.PropAxisBar)
        BoundPropAxisBar.HandleDataCellToolTipInfoNeeded(e);
      e.PropAxisBar.HandleDataCellToolTipInfoNeeded(e);

      HandleDataCellToolTipInfoNeeded(e);
    }

    protected internal virtual void HandleDataCellToolTipInfoNeeded(DataAxisGridDataCellToolTipInfoEventArgs e)
    {
      var eh = this.Events[EventKeyToolTipInfo] as EventHandler<DataAxisGridDataCellToolTipInfoEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual bool CheckWordWrap(PropertyAxisBar propAxisBar, Rectangle paintRect)
    {
      return false;
    }

    public virtual string GetTypeNameAbbr()
    {
      return "";
    }
    #endregion

  }

  //public interface IGridDataRowHeightOptionsOwner : IGridRowHeightOptionsOwner
  //{
  //  bool GetHeightOptionsDefaultAutoExpand(PropertyAxisBar propAxisBar, GridRowHeightOptions heightOptions);
  //  //int GetHeightOptionsDefaultContentHeight(GridRowHeightOptions heightOptions);
  //  //int GetHeightOptionsDefaultMaxContentHeight(GridRowHeightOptions heightOptions);
  //  //GridRowHeightUnit GetHeightOptionsDefaultUnit(GridRowHeightOptions heightOptions);
  //}

  public class GridDataRowHeightOptions : GridRowHeightOptions
  {
    public GridDataRowHeightOptions(IGridRowHeightOptionsOwner owner) : base(owner)
    {
    }

    //[Browsable(false)]
    //public new IGridDataRowHeightOptionsOwner Owner
    //{
    //  get { return base.Owner as IGridDataRowHeightOptionsOwner; }
    //}

    public bool GetAutoExpand(PropertyAxisBar propAxisBar)
    {
      if (ShouldSerializeAutoExpand())
        return AutoExpand;
      else
        return (propAxisBar as IGridRowHeightOptionsOwner).HeightOptionsDefaultAutoExpand(this);
    }
  }
}
