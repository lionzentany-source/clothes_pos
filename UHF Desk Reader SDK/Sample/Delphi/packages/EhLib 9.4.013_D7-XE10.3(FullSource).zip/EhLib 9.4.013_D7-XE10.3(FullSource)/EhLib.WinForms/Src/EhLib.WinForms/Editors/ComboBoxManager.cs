﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  public class ComboBoxManager
  {
    #region static fields
    private static ComboBoxManager _defaultManager;
    #endregion static fields

    public ComboBoxManager()
    {
    }

    public static ComboBoxManager DefaultManager
    {
      get
      {
        if (_defaultManager == null)
          _defaultManager = new ComboBoxManager();
        return _defaultManager;
      }
      set
      {
        _defaultManager = value;
      }
    }

    #region methods
    public virtual Type GetMainColumnType()
    {
      return typeof(ComboBoxTextColumn);
    }

    #endregion methods
  }
}