﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ComponentModel.Design;
using System.Drawing.Design;
using System.Collections;
using System.ComponentModel.Design.Serialization;

namespace EhLib.WinForms.Design
{
  [ToolboxItem(false)]
  public partial class CellManagersListDesignBox : UserControl
  {
    private CellManagersList сellMansList;
    private List<CellManListRow> gridList = new List<CellManListRow>();
    private bool flatListRebuilding;

    private Color designFrameColor = Color.FromArgb(245, 155, 0);  //HST 38 
    private Color designFillColor = Color.FromArgb(250, 245, 234); //Sat 39, 16, 250

    public class CellManListRow : object
    {

      public CellManListRow()
      {
      }

      public string Name { get; set; }
      public object RefObject { get; set; }
    }

    public CellManagersListDesignBox()
    {
      InitializeComponent();

      bindingSource1.DataSource = gridList;

      framePanel.CustomBorderColor = designFrameColor;
      managerGrid.Border.Color = designFrameColor;
      managerGrid.BackColor = designFillColor;
    }

    public object GetSelectionIfOne
    {
      get
      {
        if (сellMansList == null) return null;

        var SelService = (ISelectionService)сellMansList.Site.GetService(typeof(ISelectionService));
        if (SelService == null) return null;

        ICollection sel = SelService.GetSelectedComponents();

        if (sel.Count != 1)
          return null;

        foreach (object o in sel)
        {
          return o;
        }

        return null;
      }
    }

    public void SetCellManagersList(CellManagersList сellMansList)
    {
      if (this.сellMansList != сellMansList)
      {
        if (this.сellMansList != null)
        {
        }

        this.сellMansList = сellMansList;

        if (this.сellMansList != null)
        {
        }

        ReloadData();
      }
    }

    private void ReloadData()
    {
      flatListRebuilding = true;

      gridList.Clear();

      if (сellMansList != null)
      {
        foreach (var cellMan in сellMansList.CellManagers)
        {
          gridList.Add(
            new CellManListRow()
            {
              Name = cellMan.ToString(),
              RefObject = cellMan
            }
          );
        }
      }

      bindingSource1.ResetBindings(false);


      object selObj = GetSelectionIfOne;

      if (selObj == null)
      {
        managerGrid.CurrentRowIndex = -1;
      }
      else
      {
        for (int i = 0; i < bindingSource1.List.Count; i++)
        {
          object item = bindingSource1.List[i];
          if (item == selObj)
          {
            bindingSource1.Position = i;
            break;
          }
        }
      }

      flatListRebuilding = false;
    }

    private void UpdateToolBar()
    {
      //tbAdd.Enabled = false;
      //tbDelete.Enabled = false;
      //tbMoveUp.Enabled = false;
      //tbMoveDown.Enabled = false;
      tbShowEditor.Enabled = true;

      //tbAdd.Visible = false;
      //tbDelete.Visible = false;
      //tbMoveUp.Visible = false;
      //tbMoveDown.Visible = false;
      //toolStripSeparator1.Visible = false;
      //toolStripSeparator2.Visible = false;
    }

    private void BindingSource1_CurrentChanged(object sender, EventArgs e)
    {
      UpdateToolBar();
      if (flatListRebuilding) return;
      var node = bindingSource1.Current as CellManListRow;
      if (node != null)
      {
        object selObject = node.RefObject;
        var SelService = (ISelectionService)сellMansList.Site.GetService(typeof(ISelectionService));
        if (SelService == null) return;
        SelService.SetSelectedComponents(new object[] { selObject });

        //Form_PorpertiesGrid.ShowPropertiesGridFormFor(node.RefObject);
      }
    }

    private void TbShowEditor_Click(object sender, EventArgs e)
    {
      PropertyDescriptor propDesc = TypeDescriptor.GetProperties(сellMansList)["CellManagers"];
      object editor = propDesc.GetEditor(typeof(UITypeEditor));
      UITypeEditor uiEditor = editor as UITypeEditor;
      if (uiEditor != null)
      {
        var internalSrv = new EhLib.WinForms.Design.DialogWindowsFormsEditorService(сellMansList, propDesc);
        uiEditor.EditValue(internalSrv, internalSrv, сellMansList.CellManagers);
      }
      ReloadData();
    }

    private string GenerateUniqueName(string propName, string template)
    {
      INameCreationService nameService = (INameCreationService)сellMansList.Site.GetService(typeof(INameCreationService));
      string result = template;
      result = result.Replace("{DataPropertyName}", propName);

      int num = 0;
      string numS = "";
      while (true)
      {
        if (nameService.IsValidName(result + numS))
        {
          result = result + numS;
          break;
        }
        num = num + 1;
        numS = num.ToString();
      }

      if (result != string.Empty && char.IsUpper(result[0]))
      {
        result = char.ToLowerInvariant(result[0]) + result.Substring(1);
      }

      return result;
    }

    private void TsButton_Click(object sender, EventArgs e)
    {
      var dataSource = FormSelectDataSource.ShowSelectDataSourceDialog(сellMansList);

      List<PropertyDescriptor> propList = DataAxisGridAddBoundBandsDialog.GetSelectedListProperties(сellMansList, dataSource, null, null, "", "Cell");
      if (propList == null) return;
      //List<BaseGridCellManager> cellMansList = new List<BaseGridCellManager>();

      foreach (var pd in propList)
      {
        Type colType = CellManagersListItemsManager.DefaultManager.GetCellManagerTypeForDataType(pd.PropertyType);
        if (colType == null) continue;

        BaseGridCellManager cellMan;

        if (сellMansList.Site != null)
        {
          IDesignerHost host = (IDesignerHost)сellMansList.Site.GetService(typeof(IDesignerHost));
          string compName = GenerateUniqueName(pd.Name, "{DataPropertyName}Cell");
          if (!String.IsNullOrEmpty(compName))
            cellMan = (BaseGridCellManager)host.CreateComponent(colType, compName);
          else
            cellMan = (BaseGridCellManager)host.CreateComponent(colType);
        }
        else
        {
          cellMan = (BaseGridCellManager)Activator.CreateInstance(colType);
        }

        //band.DataPropertyName = prop.Name;
        //cellMansList.Add(cellMan);
        сellMansList.CellManagers.Add(cellMan);
      }
    }
  }
}
