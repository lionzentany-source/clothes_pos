﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;

namespace EhLib.WinForms.Design
{
  public class DataGridFooterRowsEditor : CollectionEditor
  {

    public DataGridFooterRowsEditor(Type type) : base(type)
    {
    }

    protected override object SetItems(object editValue, object[] value)
    {
      //DataGridFooterRows rows = editValue as DataGridFooterRows;
      //if (rows != null)
      //{
      //  DataGridFooterRow[] rowsValue = new DataGridFooterRow[value.Length];
      //  value.CopyTo(rowsValue, 0);

      //  rows.SetItems(rowsValue);
      //  return editValue;
      //}
      //else
      //{
      //  return base.SetItems(editValue, value);
      //}
      DataGridFooterRows rows = (DataGridFooterRows)editValue;
      rows.BeginUpdate();
      try
      {
        return base.SetItems(editValue, value);
      }
      finally
      {
        rows.EndUpdate();
      }

    }
  }

  public class DataGridFooterValueFunctionTypeConverter : TypeConverter
  {
    /// <summary>
    /// </summary>
    public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
    {
      if (sourceType == typeof(string))
      {
        return true;
      }
      return base.CanConvertFrom(context, sourceType);
    }

    /// <summary>
    /// </summary>
    public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
    {
      if (destinationType == typeof(string))
      {
        return true;
      }
      return base.CanConvertTo(context, destinationType);
    }

    /// <summary>
    /// </summary>
    public override object ConvertFrom(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value)
    {
      if (value is string)
      {
        Type type;
        string sValue = (string)value;

        if (sValue == "(None)" || sValue == "" || sValue == null)
          type = null;
        else
          type = Type.GetType(sValue);
        return type;
      }

      return base.ConvertFrom(context, culture, value);
    }

    /// <summary>
    /// </summary>
    public override object ConvertTo(ITypeDescriptorContext context, System.Globalization.CultureInfo culture, object value, Type destinationType)
    {
      if (destinationType == typeof(string))
      {
        string convertedValue;

        if (value == null)
        {
          convertedValue = "(None)";
        }
        else
        {
          convertedValue = value.ToString();
        }
        return convertedValue;
      }
      return base.ConvertTo(context, culture, value, destinationType);
    }

    /// <summary>
    /// </summary>
    public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
    {
      return true;
    }

    /// <summary>
    /// </summary>
    public override TypeConverter.StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
    {
      List<Type> result = new List<Type>();
      Type rootType = typeof(AggregationCalculator);

      ITypeDiscoveryService tds = (ITypeDiscoveryService)context.GetService(typeof(ITypeDiscoveryService));

      result.Add(null);

      if (tds != null)
      {
        foreach (Type actionType in tds.GetTypes(rootType, false))
        {
          if (!result.Contains(actionType) &&
              (actionType != rootType))
          {
            result.Add(actionType);
          }
        }
      }

      return new TypeConverter.StandardValuesCollection(result);
    }

    /// <summary>
    /// </summary>
    public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
    {
      return true;
    }
  }

}
