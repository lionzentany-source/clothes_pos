﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines the type of formating the text in ProgressBar
  /// </summary>
  public enum ProgressBarTextType
  {
    /// <summary>
    /// Show text as a value
    /// </summary>
    AsValue,

    /// <summary>
    /// Show text as a percent between MinValue and MaxValue
    /// </summary>
    AsPercent
  };

  /// <summary>
  /// Defines the type of size of the ProgressBar frame
  /// </summary>
  public enum ProgressBarFrameSizeType
  { Full, Val };

  /// <summary>
  /// Defines a type of data cell manager that displays progress bar user interface (UI).
  /// </summary>
  //[DataCellDesignTimeVisible(true)]
  //[ToolboxItem(true)]
  public class ProgressBarDataCellManager : BaseDataCellManager
  {
    #region private consts
    private static readonly object EventKeyPaint = new object();
    private static readonly object EventKeyFormatParamsNeeded = new object();
    #endregion

    #region privates
    private double minValue;
    private double maxValue = 100;
    private Color backColor = Color.Empty;
    private Color barFrameColor = Color.Empty;
    private Color barFillColor = Color.Empty;
    private Color textColor = Color.Empty;
    private bool showText = true;
    private ProgressBarTextType textType = ProgressBarTextType.AsPercent;
    private int textDecimalPlaces;
    private ProgressBarFrameSizeType frameSizeType = ProgressBarFrameSizeType.Val;
    private ProgressBarRenderer progressBarRenderer;
    #endregion

    #region constructor
    public ProgressBarDataCellManager()
    {
      MinValue = 0;
      MaxValue = 100;
      TextColor = Color.Empty;
      ShowText = true;
      TextType = ProgressBarTextType.AsPercent;
      TextDecimalPlaces = TextDecimalPlaces;
      FrameSizeType = FrameSizeType;
    }
    #endregion

    #region properties
    //new public DataGridProgressBarColumn Column
    //{
    //  get { return (DataGridProgressBarColumn)base.Column; }
    //}

    //public Double CurrentValue { get; set; }
    [DefaultValue(0D)]
    public double MinValue
    {
      get { return minValue; }
      set { minValue = value; }
    }

    [DefaultValue(100D)]
    public double MaxValue
    {
      get { return maxValue; }
      set { maxValue = value; }
    }

    //[DefaultValue(Color.Empty)]
    public Color BarFillColor
    {
      get { return barFillColor; }
      set { barFillColor = value; }
    }

    //[DefaultValue(Color.Empty)]
    public Color BarFrameColor
    {
      get { return barFrameColor; }
      set { barFrameColor = value; }
    }

    public Color TextColor
    {
      get { return textColor; }
      set { textColor = value; }
    }

    [DefaultValue(true)]
    public bool ShowText
    {
      get { return showText; }
      set { showText = value; }
    }

    [DefaultValue(ProgressBarTextType.AsPercent)]
    public ProgressBarTextType TextType
    {
      get { return textType; }
      set { textType = value; }
    }

    [DefaultValue(0)]
    public int TextDecimalPlaces
    {
      get { return textDecimalPlaces; }
      set { textDecimalPlaces = value; }
    }

    [DefaultValue(ProgressBarFrameSizeType.Val)]
    public ProgressBarFrameSizeType FrameSizeType
    {
      get { return frameSizeType; }
      set { frameSizeType = value; }
    }
    #endregion

    #region >events
    /// <summary>
    /// Occurs when a cell needs to be drawn.
    /// </summary>
    public new event EventHandler<DataAxisGridProgressBarDataCellPaintEventArgs> Paint
    {
      add
      {
        this.Events.AddHandler(EventKeyPaint, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyPaint, value);
      }
    }

    /// <summary>
    /// Occurs when a cell paint params like BackColor, Font, etc should be specified.
    /// By default the params are assigned from cell properties
    /// </summary>
    public new event EventHandler<DataAxisGridProgressBarDataCellFormatParamsNeededEventArgs> FormatParamsNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyFormatParamsNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyFormatParamsNeeded, value);
      }
    }
    #endregion <events

    #region >runtime properties

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Browsable(false)]
    public ProgressBarRenderer ProgressBarRenderer
    {
      get
      {
        if (progressBarRenderer != null)
          return progressBarRenderer;
        else
          return DefaultProgressBarRenderer();
      }
      set
      {
        progressBarRenderer = value;
      }
    }

    protected override Type DefaultEditorType
    {
      get
      {
        return typeof(DataAxisGridTextBoxEditControl);
      }
    }
    #endregion <runtime properties

    #region public methods
    public override string GetDisplayText(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      return base.GetDisplayText(propAxisBar, listItemBar);
    }

    public override string GetTypeNameAbbr()
    {
      return "PrgBr";
    }
    #endregion

    #region internal methods
    //BarFrameColor
    public virtual Color DefaultBarFrameColor()
    {
      return Color.Empty;
    }

    protected internal virtual bool ShouldSerializeBarFrameColor()
    {
      if (barFrameColor == DefaultBarFrameColor())
        return false;
      else
        return true;
    }

    public virtual void ResetBarFrameColor()
    {
      barFrameColor = DefaultBarFrameColor();
      BarFrameColorChanged();
    }

    protected internal void BarFrameColorChanged()
    {
      if (BoundGrid != null)
        BoundGrid.Invalidate();
    }

    //BarFillColor
    protected internal virtual Color DefaultBarFillColor()
    {
      return Color.Empty;
    }

    protected internal virtual bool ShouldSerializeBarFillColor()
    {
      if (BarFillColor.IsEmpty)
        return false;
      else
        return true;
    }

    public virtual void ResetBarFillColor()
    {
      barFillColor = DefaultBarFillColor();
      BarFillColorChanged();
    }

    protected internal void BarFillColorChanged()
    {
      if (BoundGrid != null)
        BoundGrid.Invalidate();
    }

    //FrameColor
    public virtual Color DefaultFrameColor()
    {
      return Color.Empty;
    }

    //FrameTextColor
    protected internal virtual Color DefaultTextColor()
    {
      return Color.Empty;
    }

    protected internal virtual bool ShouldSerializeTextColor()
    {
      if (backColor.IsEmpty)
        return false;
      else
        return true;
    }

    public virtual void ResetTextColor()
    {
      textColor = DefaultTextColor();
      TextColorChanged();
    }

    protected internal void TextColorChanged()
    {
      if (BoundGrid != null)
        BoundGrid.Invalidate();
    }

    //FrameFore
    public override Color DefaultForeColor()
    {
      return Color.Empty;
    }

    public override bool DefaultAllowShowEditor()
    {
      return false;
    }

    //Editor
    protected internal override void OnEditorOccupy(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
      Rectangle cellRect;
      bool wordWrap = false;
      DataAxisGridTextBoxEditControl editor = (DataAxisGridTextBoxEditControl)e.Editor;
      //DataAxisGridDataCellEditorParamsNeededEventArgs de = editorParams as DataAxisGridDataCellEditorParamsNeededEventArgs;

      cellRect = e.Grid.CellRect(e.ColIndex, e.RowIndex, true);

      editor.SetEditButton(EditButton);
      foreach (var ei in InEditControls)
        editor.InEditControls.Add(ei);
      editor.EditorEditValue = GetEditValue(e.PropAxisBar, e.ListItemBar);
      if (e != null)
        editor.Font = e.EditorParams.Font;
      editor.ReadOnly = e.EditorParams.ReadOnly;
      editor.PrepareEditorForEdit(e.SelectAll);
      editor.Padding = e.EditorParams.Padding;
      editor.TextAlign = HorzAlign;
      editor.WordWrap = wordWrap;
      editor.Multiline = editor.WordWrap;
      editor.MaxLength = e.PropAxisBar.MaxLength;
    }

    protected override void OnEditorRelease(DataAxisGridDataCellEditorReleaseEventArgs e)
    {
      DataAxisGridTextBoxEditControl editor = (DataAxisGridTextBoxEditControl)e.Editor;
      editor.SetEditButton(null);
      editor.InEditControls.Clear();
    }

    protected override void OnEditValueNeeded(DataAxisGridDataCellEditValueNeededEventArgs e)
    {
      e.EditValue = ValueToStringValue(e.Value);
    }

    public virtual object ValueToStringValue(object value)
    {
      Type dataType;

      if (value != null)
        dataType = value.GetType();
      else
        dataType = null;

      TypeConverter srcConverter = null;
      TypeConverter targetConverter = EhLibUtils.GetCachedStringConverter();
      if (dataType != null)
        srcConverter = TypeDescriptor.GetConverter(dataType);
      object result = EhLibManager.DefaultEhLibManager.ValueConverter.FormatValue(
        value, typeof(string), srcConverter, targetConverter, null, null, "", null);
      return result.ToString();
    }

    //Other
    protected internal override void OnDisplayValueNeeded(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      ProgressBarRenderer pbRenderer = ProgressBarRenderer;
      double dValue = GetValueAsDouble(e.Value);
      e.DisplayValue = pbRenderer.FormatText(dValue, MinValue, MaxValue, TextDecimalPlaces, TextType);
    }

    protected override DataAxisGridDataCellFormatParamsNeededEventArgs CreateFormatParamsNeededEventArgs(
      DataAxisGrid grid, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      return new DataAxisGridProgressBarDataCellFormatParamsNeededEventArgs(grid, propAxisBar, listItemBar, this);
    }

    protected override void OnFormatParamsNeeded(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
      e.HorzAlign = GetHorzAlign(e.PropAxisBar);
      e.VertAlign = GetVertAlign(e.PropAxisBar);
      e.Font = GetFont(e.PropAxisBar);
      e.BackColor = GetBackColor(e.PropAxisBar);
      e.ForeColor = GetForeColor(e.PropAxisBar);
      e.Padding = GetPadding(e.PropAxisBar);

      var pbe = e as DataAxisGridProgressBarDataCellFormatParamsNeededEventArgs;
      if (pbe != null)
      {
        ProgressBarPaintEventArgs args = ProgressBarRenderer.CreateProgressBarPaintArgs();
        ProgressBarRenderer.FillProgressBarPaintArgsDefaultValues(args);

        if (BarFillColor == Color.Empty)
          pbe.BarFillColor = args.BarFillColor;
        else
          pbe.BarFillColor = BarFillColor;

        if (BarFrameColor == Color.Empty)
          pbe.BarFrameColor = args.BarFrameColor;
        else
          pbe.BarFrameColor = BarFrameColor;

        pbe.ShowText = ShowText;
      }
    }

    protected internal override DataAxisGridDataCellPaintEventArgs CreatePaintEventArgs(DataAxisGrid grid, BaseGridCellManager cellManager, GraphicsContext gc,
        int colIndex, int rowIndex, Rectangle paintRect, Rectangle cellAreaRect, BasePaintCellStates state, int areaColIndex, int areaRowIndex,
        Point inCellMousePos, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, DataAxisGridListAxisItemViewState listAxisItemViewState,
        DataAxisGridDataCellFormatParamsNeededEventArgs fe)
    {
      return new DataAxisGridProgressBarDataCellPaintEventArgs(grid, this, gc, colIndex, rowIndex, paintRect, cellAreaRect, state,
          areaColIndex, areaRowIndex, inCellMousePos, propAxisBar, listItemBar, listAxisItemViewState, fe);
    }

    protected override void HandlePaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = this.Events[EventKeyPaint] as EventHandler<DataAxisGridProgressBarDataCellPaintEventArgs>;
      if (eh != null)
        eh(this, (DataAxisGridProgressBarDataCellPaintEventArgs)e);
    }

    protected internal override void OnPaintContent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      if (e.PropAxisBar == null) return;
      object val = e.PropAxisBar.GetListItemBarValue(e.ListItemBar);

      if (EhLibUtils.DBValueEqual(val, null)) return;

      ProgressBarRenderer pbRenderer = ProgressBarRenderer;
      ProgressBarPaintEventArgs args = pbRenderer.CreateProgressBarPaintArgs();

      pbRenderer.FillProgressBarPaintArgsDefaultValues(args);

      if (e.PropAxisBar != null)
      {
        double fVal = GetValueAsDouble(val);

        args.PercentValue = pbRenderer.CalcPercentValue(fVal, MinValue, MaxValue);
        args.Text = GetDisplayText(e.PropAxisBar, e.ListItemBar);

        args.Font = e.ParentCellPaintArgs.Font;
        if (ForeColor == Color.Empty)
          args.TextColor = SystemColors.WindowText;
        else
          args.TextColor = ForeColor;

        args.OutbarTextColor = args.TextColor;

        if ((BasePaintCellStates.Current & e.State) != 0)
        {
          float backBright = e.ParentCellPaintArgs.BackFilledColor.GetBrightness();
          float fontBright = args.TextColor.GetBrightness();
          if ((backBright < 0.5 && fontBright < 0.5) ||
              (backBright >= 0.5 && fontBright >= 0.5)
          )
            args.OutbarTextColor = SystemColors.HighlightText;
        }

        var pbe = e.ParentCellPaintArgs as DataAxisGridProgressBarDataCellPaintEventArgs;
        if (pbe != null)
        {
          if (pbe.BarFillColor != Color.Empty)
            args.BarFillColor = pbe.BarFillColor;
          if (pbe.BarFrameColor != Color.Empty)
            args.BarFrameColor = pbe.BarFrameColor;
          args.ShowText = pbe.ShowText;
        }

        args.BackgroundColor = Color.Empty;
        args.FrameSizeType = FrameSizeType;
        args.Indent = 0;
      }

      Rectangle progressBarPaintRect = EhLibUtils.TrimPadding(e.CellContentRect, e.ParentCellPaintArgs.Padding);

      ProgressBarRenderer.DrawBar(e.GraphicsContext, progressBarPaintRect, args);
    }

    public virtual ProgressBarRenderer DefaultProgressBarRenderer()
    {
      return EhLibRenderManager.DefaultEhLibRenderManager.ProgressBarRenderer;
    }

    public override Padding GetDefaultPadding(PropertyAxisBar propAxisBar)
    {
      if (propAxisBar != null && propAxisBar.Grid != null)
        return propAxisBar.Grid.GetDataCellSidePadding();
      else
        return Padding.Empty;
    }

    //public override Padding DefaultPadding()
    //{
    //  if (BoundGrid != null)
    //    return BoundGrid.GetDataCellSidePadding();
    //  else
    //    return Padding.Empty;
    //}

    public double GetValueAsDouble(object value)
    {
      double result = MinValue;

      if (!EhLibUtils.DBValueEqual(value, null))
      {
        TypeConverter typeConverter = TypeDescriptor.GetConverter(value.GetType());

        if (!EhLibUtils.DBValueEqual(value, null) &&
            typeConverter.CanConvertTo(typeof(double)))
        {
          object dval = typeConverter.ConvertTo(value, typeof(double));
          if (dval != null)
          {
            result = (double)dval;
          }
        }
      }

      return result;
    }

    protected override void HandleFormatParamsNeededEvent(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
      var eh = this.Events[EventKeyFormatParamsNeeded] as EventHandler<DataAxisGridProgressBarDataCellFormatParamsNeededEventArgs>;
      if (eh != null)
        eh(this, (DataAxisGridProgressBarDataCellFormatParamsNeededEventArgs)e);
    }
    #endregion
  }

  /// <summary>
  /// Event args for Paint event of a ProgressBarDataCellManager control 
  /// </summary>
  public class DataAxisGridProgressBarDataCellPaintEventArgs : DataAxisGridDataCellPaintEventArgs
  {
    public DataAxisGridProgressBarDataCellPaintEventArgs(DataAxisGrid grid, BaseGridCellManager cellManager, GraphicsContext gc, int colIndex, int rowIndex,
      Rectangle cellRect, Rectangle cellAreaRect, BasePaintCellStates state, int areaColIndex, int areaRowIndex, Point inCellMousePos,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, DataAxisGridListAxisItemViewState listAxisItemViewState,
      DataAxisGridDataCellFormatParamsNeededEventArgs fe)
      : base(grid, cellManager, gc, colIndex, rowIndex, cellRect, cellAreaRect, state, areaColIndex, areaRowIndex, inCellMousePos,
      propAxisBar, listItemBar, listAxisItemViewState, fe)
    {
      var pbfe = fe as DataAxisGridProgressBarDataCellFormatParamsNeededEventArgs;
      if (pbfe != null)
      {
        BarFillColor = pbfe.BarFillColor;
        BarFrameColor = pbfe.BarFrameColor;
        ShowText = pbfe.ShowText;
      }
    }

    public Color BarFillColor { get; set; }
    public Color BarFrameColor { get; set; }
    public bool ShowText { get; set; }
  }

  /// <summary>
  /// Event args for FormatParamsNeeded event of a ProgressBarDataCellManager control 
  /// </summary>
  public class DataAxisGridProgressBarDataCellFormatParamsNeededEventArgs : DataAxisGridDataCellFormatParamsNeededEventArgs
  {
    public DataAxisGridProgressBarDataCellFormatParamsNeededEventArgs(DataAxisGrid grid, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell)
      : base(grid, propAxisBar, listItemBar, cell)
    {
    }

    public Color BarFillColor { get; set; }
    public Color BarFrameColor { get; set; }
    public bool ShowText { get; set; }
  }

  //public interface IProgressBarDataCellManager
  //{
  //  double MinValue { get; }
  //  double MaxValue { get; }
  //  Color BarFillColor { get; }
  //  Color BarFrameColor { get; }
  //  //Color TextColor { get; }
  //  bool ShowText { get; }
  //  ProgressBarTextType TextType { get; }
  //  int TextDecimalPlaces { get; }
  //  ProgressBarFrameSizeType FrameSizeType { get; }
  //  ProgressBarRenderer ProgressBarRenderer { get; }
  //}

  //public class DataAxisGridProgressBarDataCellFormatParamsNeededEventArgs : DataAxisGridDataCellFormatParamsNeededEventArgs
  //{

  //  public DataAxisGridProgressBarDataCellFormatParamsNeededEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell
  //    ) : base (propAxisBar, listItemBar, cell)
  //  {
  //  }

  //  public Color BarFillColor { get; set; }
  //  public Color BarFrameColor { get; set; }
  //}

  //public interface IDataAxisGridProgressBarDataCellFormatParamsNeededEventArgs
  //{
  //  Color BarFillColor { get; set; }
  //  Color BarFrameColor { get; set; }
  //}

  //public class DataAxisGridProgressBarDataCellPaintEventArgs : DataAxisGridDataCellPaintEventArgs
  //{
  //  public DataAxisGridProgressBarDataCellPaintEventArgs(BaseGridCellManager cellManager, Graphics graphics, int colIndex, int rowIndex,
  //    Rectangle cellRect, Rectangle cellAreaRect, BasePaintCellStates state, int areaColIndex, int areaRowIndex, Point inCellMousePos,
  //    PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, DataAxisGridListAxisItemViewState listAxisItemViewState,
  //    DataAxisGridDataCellFormatParamsNeededEventArgs fe) : base (cellManager, graphics, colIndex, rowIndex,
  //    cellRect, cellAreaRect, state, areaColIndex, areaRowIndex, inCellMousePos, propAxisBar, listItemBar, 
  //    listAxisItemViewState, fe)
  //  {
  //    var pbfe = fe as IDataAxisGridProgressBarDataCellFormatParamsNeededEventArgs;
  //    if (pbfe != null)
  //    {
  //      BarFillColor = pbfe.BarFillColor;
  //      BarFrameColor = pbfe.BarFrameColor;
  //    }
  //  }

  //  public Color BarFillColor { get; set; }
  //  public Color BarFrameColor { get; set; }
  //}

  //public interface IDataAxisGridProgressBarDataCellPaintEventArgs
  //{
  //  Color BarFillColor { get; set; }
  //  Color BarFrameColor { get; set; }
  //}

  //public class ProgressBarDataCellWorker : DataCellWorker
  //{
  //  #region privates
  //  private readonly IProgressBarDataCellManager progressBarCellManager;
  //  #endregion

  //  #region constructor
  //  public ProgressBarDataCellWorker(BaseDataCellManager cellManager) : base(cellManager)
  //  {
  //    this.progressBarCellManager = cellManager as IProgressBarDataCellManager;
  //  }
  //  #endregion

  //  #region properties
  //  public IProgressBarDataCellManager ProgressBarCellManager
  //  {
  //    get { return progressBarCellManager; }
  //  }

  //  public double MinValue
  //  {
  //    get { return ProgressBarCellManager.MinValue; }
  //  }

  //  public double MaxValue
  //  {
  //    get { return ProgressBarCellManager.MaxValue; }
  //  }

  //  public Color BarFrameColor
  //  {
  //    get { return ProgressBarCellManager.BarFrameColor; }
  //  }

  //  public Color BarFillColor
  //  {
  //    get { return ProgressBarCellManager.BarFillColor; }
  //  }

  //  public bool ShowText
  //  {
  //    get { return ProgressBarCellManager.ShowText; }
  //  }

  //  public ProgressBarTextType TextType
  //  {
  //    get { return ProgressBarCellManager.TextType; }
  //  }

  //  public int TextDecimalPlaces
  //  {
  //    get { return ProgressBarCellManager.TextDecimalPlaces; }
  //  }

  //  public ProgressBarFrameSizeType FrameSizeType
  //  {
  //    get { return ProgressBarCellManager.FrameSizeType; }
  //  }

  //  public ProgressBarRenderer ProgressBarRenderer
  //  {
  //    get { return ProgressBarCellManager.ProgressBarRenderer; }
  //  }
  //  #endregion

  //  #region public methods
  //  public virtual void PaintForeground(DataAxisGridDataCellPaintEventArgs e)
  //  {
  //    if (e.PropAxisBar == null) return;
  //    object val = e.PropAxisBar.GetListItemBarValue(e.ListItemBar);

  //    if (EhLibUtils.DBValueEqual(val, null))  return;

  //    ProgressBarRenderer pbRenderer = ProgressBarRenderer;
  //    ProgressBarPaintEventArgs args = pbRenderer.CreateProgressBarPaintArgs();

  //    pbRenderer.FillProgressBarPaintArgsDefaultValues(args);

  //    if (e.PropAxisBar != null)
  //    {
  //      double fVal = GetValueAsDouble(val);

  //      args.PercentValue = pbRenderer.CalcPercentValue(fVal, MinValue, MaxValue);
  //      args.Text = GetDisplayText(e.PropAxisBar, e.ListItemBar);

  //      args.Font = e.Font;
  //      if (ForeColor == Color.Empty)
  //        args.TextColor = SystemColors.WindowText;
  //      else
  //        args.TextColor = ForeColor;

  //      args.OutbarTextColor = args.TextColor;

  //      if ((BasePaintCellStates.Current & e.State) != 0)
  //      {
  //        float backBright = e.BackFilledColor.GetBrightness();
  //        float fontBright = args.TextColor.GetBrightness();
  //        if ((backBright < 0.5 && fontBright < 0.5) ||
  //            (backBright >= 0.5 && fontBright >= 0.5)
  //        )
  //          args.OutbarTextColor = SystemColors.HighlightText;
  //      }

  //      var pbe = e as IDataAxisGridProgressBarDataCellPaintEventArgs;
  //      if (pbe != null)
  //      {
  //        if (pbe.BarFillColor != Color.Empty)
  //          args.BarFillColor = pbe.BarFillColor;
  //        if (pbe.BarFrameColor != Color.Empty)
  //          args.BarFrameColor = pbe.BarFrameColor;
  //      }

  //      args.BackgroundColor = Color.Empty;
  //      args.FrameSizeType = FrameSizeType;
  //      args.Indent = 0;
  //    }

  //    Rectangle progressBarPaintRect = EhLibUtils.TrimPadding(e.CellRect, Padding);

  //    ProgressBarRenderer.DrawBar(e.Graphics, progressBarPaintRect, args);
  //  }

  //  public virtual void OnFormatParamsNeeded(DataAxisGridDataCellFormatParamsNeededEventArgs e)
  //  {
  //    ProgressBarPaintEventArgs args = ProgressBarRenderer.CreateProgressBarPaintArgs();
  //    ProgressBarRenderer.FillProgressBarPaintArgsDefaultValues(args);

  //    if (e.ForeColor == Color.Empty)
  //      e.ForeColor = args.TextColor;

  //    var pbe = e as IDataAxisGridProgressBarDataCellFormatParamsNeededEventArgs;
  //    if (pbe != null)
  //    {
  //      if (pbe.BarFillColor == Color.Empty)
  //        pbe.BarFillColor = args.BarFillColor;
  //      if (pbe.BarFrameColor == Color.Empty)
  //        pbe.BarFrameColor = args.BarFrameColor;
  //    }
  //  }

  //  public double GetValueAsDouble(object value)
  //  {
  //    double result = MinValue;

  //    if (!EhLibUtils.DBValueEqual(value, null))
  //    {
  //      TypeConverter typeConverter = TypeDescriptor.GetConverter(value.GetType());

  //      if (!EhLibUtils.DBValueEqual(value, null) &&
  //          typeConverter.CanConvertTo(typeof(double)))
  //      {
  //        object dval = typeConverter.ConvertTo(value, typeof(double));
  //        if (dval != null)
  //        {
  //          result = (double)dval;
  //        }
  //      }
  //    }

  //    return result;
  //  }

  //  public override void OnEditorOccupy(DataAxisGridDataCellEditorOccupyEventArgs e)
  //  {
  //    Rectangle cellRect;
  //    bool wordWrap = false;
  //    DataAxisGridTextBoxEditControl editor = (DataAxisGridTextBoxEditControl)e.Editor;
  //    //DataAxisGridDataCellEditorParamsNeededEventArgs de = editorParams as DataAxisGridDataCellEditorParamsNeededEventArgs;

  //    cellRect = Grid.CellRect(e.ColIndex, e.RowIndex, true);

  //    editor.SetEditButton(EditButton);
  //    foreach (var ei in InEditControls)
  //      editor.InEditControls.Add(ei);
  //    editor.EditorEditValue = CellManager.GetEditValue(e.PropAxisBar, e.ListItemBar);
  //    if (e != null)
  //      editor.Font = e.EditorParams.Font;
  //    editor.ReadOnly = e.EditorParams.ReadOnly;
  //    editor.PrepareEditorForEdit(e.SelectAll);
  //    editor.Padding = e.EditorParams.Padding;
  //    editor.TextAlign = HorzAlign;
  //    editor.WordWrap = wordWrap;
  //    editor.Multiline = editor.WordWrap;
  //    editor.MaxLength = e.PropAxisBar.MaxLength;
  //  }

  //  public override void OnEditorRelease(DataAxisGridDataCellEditorReleaseEventArgs e)
  //  {
  //    DataAxisGridTextBoxEditControl editor = (DataAxisGridTextBoxEditControl)e.Editor;
  //    editor.SetEditButton(null);
  //    editor.InEditControls.Clear();
  //  }

  //  public override object ValueToEditValue(object value)
  //  {
  //    return ValueToStringValue(value);
  //  }

  //  public virtual object ValueToStringValue(object value)
  //  {
  //    Type dataType;

  //    if (value != null)
  //      dataType = value.GetType();
  //    else
  //      dataType = null;

  //    TypeConverter srcConverter = null;
  //    TypeConverter targetConverter = EhLibUtils.GetCachedStringConverter();
  //    if (dataType != null)
  //      srcConverter = TypeDescriptor.GetConverter(dataType);
  //    object result = EhLibManager.DefaultEhLibManager.ValueConverter.FormatValue(
  //      value, typeof(string), srcConverter, targetConverter, null, null, "", null);
  //    return result.ToString();
  //  }
  //  #endregion
  //}

}
