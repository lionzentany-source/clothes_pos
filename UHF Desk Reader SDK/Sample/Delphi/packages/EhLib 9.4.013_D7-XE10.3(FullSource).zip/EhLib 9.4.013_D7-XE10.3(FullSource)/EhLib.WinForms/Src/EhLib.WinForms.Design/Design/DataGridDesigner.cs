﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2018 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Windows.Forms.Design;
using System.Drawing;
using System.Collections;
using System.Diagnostics;
using System.Windows.Forms;
using System.Windows.Forms.Design.Behavior;
using System.Collections.Generic;
using System.Drawing.Drawing2D;

namespace EhLib.WinForms.Design
{
  [System.Security.Permissions.PermissionSet(System.Security.Permissions.SecurityAction.Demand, Name = "FullTrust")]
  public class DataGridDesigner : DataAxisGridDesigner, IDataGridDesigner
  {
    private DesignerActionListCollection actionLists;
    //private Adorner titleAdorner;

    //internal DesignerVerb globalVerb;

    //private DesignerVerb addSuperTitleVerb;
    //private DesignerVerb deleteSuperTitleVerb;
    //private DesignerVerb removeFromSuperTitleVerb;

    private List<DesignerVerb> subTitlesMenuList = new List<DesignerVerb>();

    internal IDesignerHost DesignerHost;
    internal Point GridMouseDownPos = Point.Empty;
    internal DataGridDesignManagerControl DesignManager = null;
    internal INestedContainer nestedContainer;
    #region constructor

    public DataGridDesigner()
    {
      EmptyFooterItem = new DummyFooterItem();
      EmptyFooterItemDesignerVerb = new DesignerVerb("Create Footer Item", CreateFooterItem);
      EmptyFooterItemDesignerVerb.Visible = false;

      //this.DeleteFooterItemDesignerVerb = new DesignerVerb("Delete Footer Item", DeleteFooterItem);
      //this.DeleteFooterItemDesignerVerb.Visible = false;
    }

    public override void Initialize(IComponent component)
    {
      base.Initialize(component);

      nestedContainer = (INestedContainer)GetService(typeof(INestedContainer));
      if (nestedContainer != null)
      {
        nestedContainer.Add(Grid.Title, "Title");
        nestedContainer.Add(Grid.SearchBox, "SearchBox");
        //nc.Add(StaticColumns, "StaticColumns");
        nestedContainer.Add(Grid.Footer, "Footer");
        nestedContainer.Add(Grid.HorzScrollBar, "HorzScrollBar");
        nestedContainer.Add(Grid.VertScrollBar, "VertScrollBar");
        nestedContainer.Add(Grid.IndicatorColumn, "IndicatorColumn");
        nestedContainer.Add(Grid.IndicatorTitle, "IndicatorTitle");
        nestedContainer.Add(Grid.TreeViewArea, "TreeViewArea");
      }

      Grid.DataGridDesigner = this;
      Grid.OrderedColumnsListChanged += Grid_OrderedColumnsListChanged;

      //titleAdorner = new Adorner();
      //Debug.Assert(this.BehaviorService != null, "this.BehaviorService != null");
      //this.BehaviorService.Adorners.Add(titleAdorner);
      //titleAdorner.Glyphs.Add(new GridTitleGlyph(BehaviorService, Control, this));

      DesignerHost = (IDesignerHost)GetService(typeof(IDesignerHost));
      DesignerHost.LoadComplete += DesignerHost_LoadComplete;

      // DesignManager
      DesignManager = new DataGridDesignManagerControl();
      DesignManager.SetTargetDataGridEh(Grid);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        if (nestedContainer != null) nestedContainer.Dispose();

        if (Grid != null)
        {
          Grid.DataGridDesigner = null;
          Grid.OrderedColumnsListChanged -= Grid_OrderedColumnsListChanged;
        }

        if (DesignerHost != null)
        {
          DesignerHost.LoadComplete -= DesignerHost_LoadComplete;
          DesignerHost = null;
        }

        if (DesignManager != null)
        {
          DesignManager.SetTargetDataGridEh(null);
          DesignManager.Dispose();
        }

        if (EmptyFooterItem != null)
          EmptyFooterItem.Dispose();
      }

      base.Dispose(disposing);
      disposed = true;
    }
    #endregion

    #region properties
    internal new DataGridEh Grid
    {
      get { return Component as DataGridEh; }
    }

    public override string PropAxisBarName
    {
      get { return "Column"; }
    }

    public override string PropAxisBarsName
    {
      get { return "Columns"; }
    }

    public override Type StaticPropBarCollectionType
    {
      get { return typeof(DataGridStaticColumnCollection); }
    }

    public override ICollection AssociatedComponents
    {
      get
      {
        //return base.AssociatedComponents;
        ArrayList acItems = new ArrayList();
        //items.Add(Grid.StaticColumns);
        //items.Add(Grid.SearchBox);

        //StaticColumns
        foreach (DataGridColumn c in Grid.StaticColumns)
        {
          acItems.Add(c);
          foreach (var f in c.Footer.Items)
          {
            if (f != null)
              acItems.Add(f);
          }
        }
        //items.Add(Grid.HorzScrollBar);

        //SuperTitle
        if (Grid.Title.MultiTitle.Active)
        {
          DataGridTitleNode node = Grid.Title.MultiTitle.TitleTree.GetFirst();
          while (node != null)
          {
            if (node.NodeType == DataGridTitleNodeType.SuperTitle)
            {
              acItems.Add(node.SuperTitle);
            }
            node = Grid.Title.MultiTitle.TitleTree.GetNext(node);
          }
        }

        //FooterRows
        foreach (DataGridFooterRow fr in Grid.Footer.Rows)
        {
          acItems.Add(fr);
        }

        return acItems;
      }
    }

    public override DesignerVerbCollection Verbs
    {
      get
      {
        //var result = base.Verbs;
        DesignerVerbCollection dvc = new DesignerVerbCollection();
        //dvc.Add(new DesignerVerb("Создать testEvent", ConnectEvent));

        //if (EmptyFooterItem.FooterRow != null && EmptyFooterItem.Column != null)
        //{
        //  dvc.Add(new DesignerVerb("Create Footer Item", CreateFooterItem));
        //}
        dvc.Add(EmptyFooterItemDesignerVerb);
        dvc.Add(new DesignerVerb("About EhLib.WinForms", ShowAboutDialog));

        return dvc;
      }
    }

    public override DesignerActionListCollection ActionLists
    {
      get
      {
        if (actionLists == null)
        {
          actionLists = new DesignerActionListCollection();
          actionLists.Add(new DataAxisGridChooseDataSourceActionList(this));
          actionLists.Add(new DataAxisGridActionList(this));
          actionLists.Add(new DataAxisGridPropertiesActionList(this));
          //actionLists.Add(new DataGridTestActionList(Component));
          actionLists.AddRange(base.ActionLists);
        }
        return actionLists;
      }
    }

    public override Type PropAxisBarType
    {
      get { return typeof(DataGridColumn); }
    }

    public DummyFooterItem EmptyFooterItem { get; private set; }

    public DesignerVerb EmptyFooterItemDesignerVerb { get; private set; }

    //public DesignerVerb DeleteFooterItemDesignerVerb { get; private set; }
    #endregion

    #region overridden methods
    protected override bool GetHitTest(Point point)
    {
      if (Grid == null)
      {
        return base.GetHitTest(point);
      }

      Point tpPoint = this.Control.PointToClient(point);

      if (Grid.GridState == BaseGridState.Normal)
      {
        BaseGridState state = Grid.CheckSizingState(tpPoint.X, tpPoint.Y);
        if (state == BaseGridState.ColSizing)
          return true;
      }

      GridCoord cellCoord = Grid.CalcCellCoordFromPoint(tpPoint.X, tpPoint.Y);
      Component hitTestComponent = GetHitTestComponent(tpPoint);
      if ((hitTestComponent != null) ||
          (cellCoord.X >= Grid.StartDataColIndex) && (cellCoord.Y == Grid.TitleRowIndex))
      {
        //        MessageBox.Show(cellCoord.X.ToString() +":"+ cellCoord.Y.ToString());
        return true;
      }

      if (DesignManager != null && DesignManager.DesignManagerBounds.Contains(tpPoint))
        return true;

      return base.GetHitTest(point);
    }

    protected override void OnSetCursor()
    {
      if (Grid == null)
      {
        base.OnSetCursor();
        return;
      }

      Point gridCurPos = Grid.PointToClient(Cursor.Position);

      Component hitTestComponent = GetHitTestComponent(gridCurPos);
      BaseGridState state = Grid.CheckSizingState(gridCurPos.X, gridCurPos.Y);
      if (state == BaseGridState.ColSizing)
      {
        Cursor.Current = Cursors.HSplit;
      }
      else if (hitTestComponent != null)
      {
        Cursor.Current = Cursors.Arrow;
      }
      else
      {
        base.OnSetCursor();
      }
    }

    protected override void OnMouseDragBegin(int x, int y)
    {
      base.OnMouseDragBegin(x, y);
    }

    protected override void OnMouseDragMove(int x, int y)
    {
      Component hitComponent = GetHitTestComponent(new Point(x, y));
      if (hitComponent != null)
        MessageBox.Show(@"Start Column Moving");
      else
        base.OnMouseDragMove(x, y);
    }

    //protected override void WndProc(ref Message m)
    //{
    //  switch (m.Msg)
    //  {
    //    case NativeMethods.WM_MOUSEMOVE:
    //      WmMouseMove(ref m);
    //      break;
    //    case NativeMethods.WM_LBUTTONUP:
    //      WmMouseUp(ref m, MouseButtons.Left);
    //      break;
    //    case NativeMethods.WM_RBUTTONUP:
    //      WmMouseUp(ref m, MouseButtons.Right);
    //      break;
    //    case NativeMethods.WM_LBUTTONDOWN:
    //      WmMouseDown(ref m, MouseButtons.Left);
    //      break;
    //    case NativeMethods.WM_RBUTTONDOWN:
    //      WmMouseDown(ref m, MouseButtons.Right);
    //      break;
    //    // TMP
    //    //case NativeMethods.WM_NCHITTEST:
    //    //  WmNCHitTest(ref m);
    //    //  break;

    //    default:
    //      base.WndProc(ref m);
    //      break;
    //  }
    //}

    public override void DoDefaultAction()
    {
      ShowEditColumnsDialog();
    }

    protected override void OnContextMenu(int x, int y)
    {
      //System.Windows.Forms.MessageBox.Show("OnContextMenu(int x, int y)");
      //AddGlobalMenu(null);
      base.OnContextMenu(x, y);
      //System.Windows.Forms.MessageBox.Show("After OnContextMenu(int x, int y)");
    }

    public override DataAxisGridPropertyBarsEditor CreatePropertyBarsEditor()
    {
      return new DataGridColumnsEditor(StaticPropBarCollectionType);
    }
    #endregion

    #region methods
    // IDataGridDesigner
    public virtual void PaintCellDesignData(DataGridEh grid, Graphics graphics, int col, int row, Rectangle rect, 
      BasePaintCellStates state, BaseGridCellPaintEventArgs e)
    {
      CellAreaType cellAreaType = grid.GetCellAreaTypeByColRow(col, row);
      if (cellAreaType.VertType == DataGridCellAreaVertType.Title)
      {
        var tp = e as DataGridTitleCellPaintEventArgs;
        DataGridColumn column;
        if (tp == null)
        {
          int colIndex = grid.BaseToDataColIndex(col);
          if (colIndex < 0 || colIndex >= grid.VisibleColumns.Count) return;
          column = grid.VisibleColumns[colIndex];
        }
        else
        {
          column = tp.Column;
        }

        if ((SelService != null) && (column != null))
        {
          if (SelService.GetComponentSelected(column))
          { 
            Rectangle paintRect = rect;
            paintRect.Inflate(-2, -2);
            using (Pen pen = new Pen(Color.Black, 1))
            {
              pen.DashStyle = DashStyle.Dot;
              graphics.DrawRectangle(pen, paintRect);
            }
          }
        }
      }
      else if (cellAreaType.VertType == DataGridCellAreaVertType.Footer && 
                 (cellAreaType.HorzType == DataGridCellAreaHorzType.Data || 
                  cellAreaType.HorzType == DataGridCellAreaHorzType.Contra)
              )
      {
        int localColIndex;
        int localRowIndex;
        grid.CellManByColRow(col, row, out localColIndex, out localRowIndex);
        if (localColIndex >= grid.VisibleColumns.Count) return;
        DataGridColumn column = grid.VisibleColumns[localColIndex];
        if (localRowIndex < column.Footer.Items.Count)
        {
          int shift = 0;
          Component selItem = null;
          DataGridColumnFooterItem footerItem = column.Footer.Items[localRowIndex];
          if (footerItem != null)
          {
            if (SelService.GetComponentSelected(footerItem))
              selItem = footerItem;
          }
          else
          {
            if (EmptyFooterItem.Column == column && EmptyFooterItem.FooterRow == Grid.Footer.Rows[localRowIndex])
              selItem = EmptyFooterItem;
          }

          if (selItem != null)
          {
            //if (SelService.GetComponentSelected(selItem))
            {
              Rectangle paintRect = rect;
              paintRect = EhLibUtils.ChangeRectangle(paintRect, 1, 1, -3, -3);
              //paintRect.Inflate(-1, -1);
              using (Pen pen = new Pen(Color.Black, 1))
              {
                pen.DashStyle = DashStyle.Dot;
                graphics.DrawRectangle(pen, paintRect);
              }
              shift = 2;
            }
          }

          if (footerItem != null)
          {
            graphics.DrawPolygon(new Pen(Color.Silver),
              new Point[] {
                new Point(rect.Right-7-shift, rect.Top+1+shift),
                new Point(rect.Right-2-shift, rect.Top+1+shift),
                new Point(rect.Right-2-shift, rect.Top+6+shift)
              });
          }
        }
      }
    }

    public virtual void PaintSuperTitleCellDesignData(DataGridEh grid, DataGridSuperTitle superTitle, 
      Graphics graphics, Rectangle rect)
    {
      if (SelService.GetComponentSelected(superTitle))
      {
        Rectangle paintRect = rect;
        paintRect.Inflate(-2, -2);
        using (Pen pen = new Pen(Color.Black, 1))
        {
          pen.DashStyle = DashStyle.Dot;
          graphics.DrawRectangle(pen, paintRect);
        }
      }
    }

    public virtual void InteractiveSetColWidths(int colIndex, int newSize)
    {
      if (colIndex >= Grid.StartDataColIndex)
      {
        DataGridColumn column = Grid.VisibleColumns[colIndex - Grid.StartDataColIndex];

        column.Width = newSize;
        ComponentChanged(Grid);
      }
    }

    public virtual void InteractiveMoveColumn(int fromIndex, int toIndex)
    {
      ((IBaseGridControlInternal)Grid).MoveColumn(fromIndex, toIndex);

      //if (Grid.StaticColumns.Count != Grid.Columns.Count)
      //  throw (new InvalidOperationException(@"Can't move column when grid have dynamic columns"));
      //Grid.StaticColumns.SetColumnsOrder(Grid.ViewOrderedColumns);
      //ComponentChanged(Grid);
    }

    public virtual void GridMouseDown(MouseEventArgs e)
    {
      int index;
      int pos, ofs;
      BaseGridState state;

      GridMouseDownPos = e.Location;

      //BaseGridState state = Grid.CheckSizingState(e.X, e.Y);
      Grid.CalcSizingState(e.X, e.Y, out state, out index, out pos, out ofs);

      if (e.Button == MouseButtons.Left && state == BaseGridState.ColSizing)
      {
        Grid.Capture = true;
        if (Grid.Capture)
        {
          //MessageBox.Show("grid.StartColSizing");
          Grid.StartColSizing(index, e.X, e.Y, pos, ofs);
        }
        return;
      }

      Component hitTestComponent = GetHitTestComponent(e.Location);

      if (hitTestComponent != null)
      {
        if (e.Button == MouseButtons.Left)
        {
          if (hitTestComponent == EmptyFooterItem)
          {
            SelectEmptyFooterItem(e.Location);
          }
          else
          {
            ISelectionService selSrv = SelService;
            selSrv.SetSelectedComponents(new object[] { hitTestComponent });
          }
        }
      }
    }

    public virtual void GridMouseUp(MouseEventArgs e)
    {
      Component hitTestComponent = GetHitTestComponent(e.Location);

      if (e.Button == MouseButtons.Right && hitTestComponent != null)
      {
        //menu.Show(control, new Point(control.Width, 0));

        IMenuCommandService service = (IMenuCommandService)GetService(typeof(IMenuCommandService));
        if (service != null)
        {
          Point screenMousePos = Grid.PointToScreen(e.Location);
          //AddGlobalMenu(service);
          service.ShowContextMenu(MenuCommands.SelectionMenu, screenMousePos.X, screenMousePos.Y);
          //RemoveGlobalMenu(service);
        }
      }
    }

    public virtual void GridMouseMove(MouseEventArgs e)
    {
      ((IBaseGridControlInternal)Grid).UpdateCursor(e);

      Component hitTestComponent = GetHitTestComponent(e.Location);

      if (hitTestComponent != null &&
          (hitTestComponent is DataGridSuperTitle || hitTestComponent is DataGridColumn) &&
          e.Button == MouseButtons.Left &&
          Grid.GridState == BaseGridState.Normal &&
          GridMouseDownPos != e.Location
         )
      {
        GridCoord cellHit = Grid.CalcCellCoordFromPoint(e.X, e.Y);

        Grid.StartColMoving(cellHit.X, cellHit.X, e.X, e.Y);
      }
    }

    public virtual void GridEndInitialization(DataGridEh grid)
    {
      if (grid == Grid)
        DesignManager.GridEndInitialization();
    }

    // Other

    private void Grid_OrderedColumnsListChanged(object sender, EventArgs e)
    {
      if (!Grid.InInitialization && !((IDataAxisGridInternal)Grid).IsInEndInit())
      {
        //MessageBox.Show("Grid_OrderedColumnsListChanged");
        Grid.StaticColumns.SetColumnsOrder(Grid.ViewOrderedColumns);
        ComponentChanged(Grid);
      }
    }

    private void DesignerHost_LoadComplete(object sender, EventArgs e)
    {
      if (DesignManager != null)
        DesignManager.GridEndInitialization();
    }

    private void ComponentChanged(object component)
    {
      IComponentChangeService desTimeChangeService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
      if (desTimeChangeService != null)
      {
        desTimeChangeService.OnComponentChanged(component, null, null, null);
        //desTimeChangeService.OnComponentChanged(this, null, null, null);
      }
    }

    public void ShowEditColumnsDialog()
    {
      DataGridColumnsEditor ce = new DataGridColumnsEditor(typeof(DataGridStaticColumnCollection));

      PropertyDescriptor propDesc = TypeDescriptor.GetProperties(Grid)["StaticColumns"];
      DialogWindowsFormsEditorService internalSrv = new DialogWindowsFormsEditorService(Grid, propDesc);

      ce.EditValue(internalSrv, internalSrv, Grid.StaticColumns);
    }

    internal new object GetService(Type serviceType)
    {
      return base.GetService(serviceType);
    }

    //internal void AddGlobalMenu(IMenuCommandService mcSerive)
    //{
    //  bool allSelIsMultiTitleProvider = false;
    //  ICollection sel = SelService.GetSelectedComponents();
    //  object selObject = null;
    //  DataGridSuperTitle parentSuperTitle = null;
    //  DataGridTitleNode parentNode = null;

    //  foreach (object o in sel)
    //  {
    //    IMultiTitleNodeProvider iNode = (o as IMultiTitleNodeProvider);
    //    DataGridTitleNode gridTitleNode = null;
    //    if (iNode != null)
    //    {
    //      gridTitleNode = iNode.GetNode();
    //      if (gridTitleNode != null)
    //        parentNode = gridTitleNode.Parent;
    //    }
    //    if (gridTitleNode != null &&
    //        gridTitleNode.Parent != Grid.Title.MultiTitle.Root &&
    //        gridTitleNode.Parent.NodeType == DataGridTitleNodeType.SuperTitle)
    //      parentSuperTitle = gridTitleNode.Parent.SuperTitle;
    //    break;
    //  }

    //  foreach (object o in sel)
    //  {
    //    if (sel.Count == 1)
    //      selObject = o;

    //    IMultiTitleNodeProvider iNode = (o as IMultiTitleNodeProvider);
    //    if (iNode == null)
    //    {
    //      allSelIsMultiTitleProvider = false;
    //      parentSuperTitle = null;
    //      parentNode = null;
    //      break;
    //    }
    //    else
    //    {
    //      DataGridTitleNode gridTitleeNode = iNode.GetNode();
    //      if (gridTitleeNode != null && gridTitleeNode.Parent != parentNode)
    //        parentNode = null;
    //      if (gridTitleeNode != null && gridTitleeNode.Parent.SuperTitle != parentSuperTitle)
    //        parentSuperTitle = null;
    //      allSelIsMultiTitleProvider = true;
    //    }
    //  }

    //  IMenuCommandService mcs;

    //  if (mcSerive != null)
    //    mcs = mcSerive;
    //  else
    //    mcs = (IMenuCommandService)Component.Site.GetService(typeof(IMenuCommandService));

    //  //// Добавляем меню
    //  //if (globalVerb == null)
    //  //  globalVerb = new DesignerVerb("Глобальное меню", OnGlobal1);
    //  //globalVerb.Visible = true;
    //  //globalVerb.Enabled = allSelIsCols;
    //  //globalVerb.Supported = true;
    //  //mcs.RemoveVerb(globalVerb);
    //  //mcs.AddVerb(globalVerb);

    //  // Delete SuperTitle Verb
    //  //string verbText;

    //  if (deleteSuperTitleVerb != null)
    //    mcs.RemoveVerb(deleteSuperTitleVerb);

    //  //if (selObject is DataGridSuperTitle)
    //  //  verbText = "Delete SuperTitle '" + ((DataGridSuperTitle)selObject).Text + "'";
    //  //else
    //  //  verbText = "Delete SuperTitle";

    //  deleteSuperTitleVerb = new DesignerVerb("Delete SuperTitle", DeleteSuperTitleHandler);
    //  deleteSuperTitleVerb.Visible = true;
    //  deleteSuperTitleVerb.Enabled = selObject is DataGridSuperTitle;
    //  deleteSuperTitleVerb.Supported = true;
    //  mcs.AddVerb(deleteSuperTitleVerb);

    //  // Add SuperTitle Verb
    //  if (addSuperTitleVerb == null)
    //    addSuperTitleVerb = new DesignerVerb("Add SuperTitle", AddSuperTitleHandler);
    //  addSuperTitleVerb.Visible = true;
    //  addSuperTitleVerb.Enabled = allSelIsMultiTitleProvider && Grid.Title.MultiTitle.Active;
    //  addSuperTitleVerb.Supported = true;
    //  mcs.RemoveVerb(addSuperTitleVerb);
    //  mcs.AddVerb(addSuperTitleVerb);


    //  // remove From SuperTitle Verb
    //  if (removeFromSuperTitleVerb != null)
    //  {
    //    mcs.RemoveVerb(removeFromSuperTitleVerb);
    //    removeFromSuperTitleVerb = null;
    //  }

    //  if (parentSuperTitle != null)
    //  {
    //    removeFromSuperTitleVerb = new DesignerVerb("Remove from \"" + parentSuperTitle.Text + "\"", MoveToSuperTitleHandler);
    //    removeFromSuperTitleVerb.Visible = true;
    //    removeFromSuperTitleVerb.Enabled = allSelIsMultiTitleProvider && Grid.Title.MultiTitle.Active;
    //    removeFromSuperTitleVerb.Supported = true;
    //    mcs.AddVerb(removeFromSuperTitleVerb);
    //  }

    //  if (Grid.Title.MultiTitle.Active)
    //  {
    //    ClearSubtitleMenuList(mcSerive);

    //    DataGridTitleNode node = Grid.Title.MultiTitle.GetFirst();
    //    while (node != null)
    //    {
    //      if (node.NodeType == DataGridTitleNodeType.SuperTitle)
    //      {
    //        DesignerVerb sbvVerb = new DesignerVerb("Move under \"" + node.SuperTitle.Text + "\"", MoveToSuperTitleHandler);

    //        sbvVerb.Visible = true;
    //        sbvVerb.Enabled = allSelIsMultiTitleProvider;
    //        sbvVerb.Supported = true;
    //        mcs.AddVerb(sbvVerb);

    //        subTitlesMenuList.Add(sbvVerb);
    //      }
    //      node = Grid.Title.MultiTitle.GetNext(node);
    //    }
    //  }
    //}

    //internal void RemoveGlobalMenu(IMenuCommandService mcSerive)
    //{
    //  //if (globalVerb != null)
    //  //  mcSerive.RemoveVerb(globalVerb);
    //  if (addSuperTitleVerb != null)
    //    mcSerive.RemoveVerb(addSuperTitleVerb);
    //  if (deleteSuperTitleVerb != null)
    //    mcSerive.RemoveVerb(deleteSuperTitleVerb);
    //}

    internal void ClearSubtitleMenuList(IMenuCommandService mcSerive)
    {
      foreach(DesignerVerb verb in subTitlesMenuList)
      {
        mcSerive.RemoveVerb(verb);
      }
      subTitlesMenuList.Clear();
    }

    //private void OnGlobal1(object sender, System.EventArgs e)
    //{
    //  System.Windows.Forms.MessageBox.Show(@"Вызвано меню Global1");
    //}

    private void DeleteSuperTitleHandler(object sender, System.EventArgs e)
    {
      ICollection sel = SelService.GetSelectedComponents();

      foreach (object o in sel)
      {
        DataGridSuperTitle sp = o as DataGridSuperTitle;
        if (sp != null)
        {
          sp.Dispose();
          return;
        }
      }

      IComponentChangeService chService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
      chService.OnComponentChanged(this, null, null, null);
    }

    private void AddSuperTitleHandler(object sender, System.EventArgs e)
    {
      ICollection sel = SelService.GetSelectedComponents();
      List<object> selList = new List<object>();


      foreach (object o in sel)
      {
        if ((o is DataGridColumn) || (o is DataGridSuperTitle))
        {
          selList.Add(o);
        }
        else
        {
          MessageBox.Show(@"The selected object is not DataGridColumn or DataGridSuperTitle");
          return;
        }
      }

      if (selList.Count == 0) return;

      int itemLevel = ((IMultiTitleNodeProvider)selList[0]).GetNode().Level;

      foreach (object o in selList)
      {
        DataGridTitleNode n = ((IMultiTitleNodeProvider)o).GetNode();
        if (n.Level != itemLevel)
        {
          MessageBox.Show(@"Not all selected nodes is on the same tree node level");
          return;
        }
      }

      IMultiTitleNodeProvider firstItem = (IMultiTitleNodeProvider)selList[0];

      string stTitleText = "SuperTitle";
      DialogResult result = EhLibUtils.InputBox("Name of title", "Enter text of title", ref stTitleText);
      if (result != DialogResult.OK) return;

      IDesignerHost host = (IDesignerHost)GetService(typeof(IDesignerHost));
      DataGridSuperTitle st = (DataGridSuperTitle)host.CreateComponent(typeof(DataGridSuperTitle));
      st.Text = stTitleText;
      //DataGridSuperTitle st = new DataGridSuperTitle()
      //{
      //  Text = stTitleText
      //};

      DataGridTitleNode node = firstItem.GetNode();

      Grid.Title.MultiTitle.TitleTree.BeginUpdate();
      int Index = node.Index;
      node.Parent.Subtitles.Insert(Index, st);

      //selList.Reverse();

      foreach (object o in selList)
      {
        st.Subtitles.MoveIn(st.Subtitles.Count, (IMultiTitleNodeProvider)o);
      }

      Grid.Title.MultiTitle.TitleTree.EndUpdate();

      IComponentChangeService chService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
      chService.OnComponentChanged(this, null, null, null);

    }

    private void MoveToSuperTitleHandler(object sender, System.EventArgs e)
    {
    }

    private void ConnectEvent(object sender, EventArgs e)
    {
      MessageBox.Show(@"ConnectEvent: " + e.ToString());
    }

    private void ShowAboutDialog(object sender, EventArgs e)
    {
      FormAbout fa = new FormAbout();
      fa.ShowDialog();
    }

    private void CreateFooterItem(object sender, EventArgs e)
    {
      IDesignerHost host = (IDesignerHost)GetService(typeof(IDesignerHost));
      DataGridColumnFooterItem fi = (DataGridColumnFooterItem)host.CreateComponent(typeof(DataGridColumnFooterItem));

      Debug.Assert(EmptyFooterItem.Column != null && EmptyFooterItem.FooterRow != null, "EmptyFooterItem.Column = null || EmptyFooterItem.FooterRow = null");

      //fi.SetFooterCellBind(Grid, EmptyFooterItem.Column, EmptyFooterItem.FooterRow);
      int footerRowIndex = EmptyFooterItem.FooterRow.Index;
      if (footerRowIndex >= 0)
      {
        EmptyFooterItem.Column.Footer.Items[footerRowIndex] = fi;
      }
      SelService.SetSelectedComponents(new object[] { fi });
    }

    private void DeleteFooterItem(object sender, EventArgs e)
    {
      //if (!EmptyFooterItem == null) return;

      ICollection sel = SelService.GetSelectedComponents();
      if (sel.Count != 1) return;

      foreach (object o in sel)
      {
        DataGridColumnFooterItem fi = o as DataGridColumnFooterItem;
        if (fi != null)
        {
          fi.Dispose();
          return;
        }
      }
    }

    protected override void SelService_SelectionChanged(object sender, EventArgs e)
    {
      base.SelService_SelectionChanged(sender, e);

      {
        EmptyFooterItem.FooterRow = null;
        EmptyFooterItem.Column = null;
        EmptyFooterItemDesignerVerb.Visible = false;
      }

      if (DesignManager != null)
        DesignManager.SelServiceSelectionChanged(sender, e);

      Control.Invalidate();

      var selCol = GetSelectionIfOne as DataGridColumn;
      if (selCol != null && selCol.Grid == Grid)
      {
        int colIdx = Grid.DataToRawCol(selCol.VisibleIndex);
        Grid.ClampInView(new GridCoord(colIdx, ((IBaseGridControlInternal)Grid).Row), true , false);
      }
    }

    protected override void SelService_SelectionChanging(object sender, EventArgs e)
    {
      base.SelService_SelectionChanging(sender, e);
    }

    protected override void ChangeService_ComponentAdding(object sender, ComponentEventArgs e)
    {
      base.ChangeService_ComponentAdding(sender, e);
    }

    protected override void ChangeService_ComponentAdded(object sender, ComponentEventArgs e)
    {
      base.ChangeService_ComponentAdded(sender, e);

      if (Grid == null || Grid.Disposing) return;

      //if (this.toolStripSelected && e.Component is ToolStrip)
      //  this.toolStripSelected = false;

//      DataGridColumn col = e.Component as DataGridColumn;
//      if (col != null && !Grid.InInitialization)
//      {
//        object sel1 = GetSelectionIfOne;
//        DataGridColumn selCol = sel1 as DataGridColumn;
//        if (selCol != null && selCol.Grid == Grid)
//          Grid.StaticColumns.Add(col);
//        else if (sel1 == Component)
//          Grid.StaticColumns.Add(col);
////        EhLibUtils.DoNothing();
//      }

      DataGridColumnFooterItem fi = e.Component as DataGridColumnFooterItem;
      if (fi != null)
      {
        object sel1 = GetSelectionIfOne;
        DataGridEh selGrid = sel1 as DataGridEh;
        if (selGrid != null && 
            EmptyFooterItem.Grid == Grid &&
            EmptyFooterItem.Column != null &&
            EmptyFooterItem.FooterRow != null)
        {
          int footerRowIndex = EmptyFooterItem.FooterRow.Index;
          if (footerRowIndex >= 0)
          {
            EmptyFooterItem.Column.Footer.Items[footerRowIndex] = fi;
            //fi.SetFooterCellBind(Grid, EmptyFooterItem.Column, EmptyFooterItem.FooterRow);
          }
        }
      }

      if (DesignManager != null)
        DesignManager.ComponentAdded(e);
    }

    protected override void ChangeService_ComponentRemoving(object sender, ComponentEventArgs e)
    {
      base.ChangeService_ComponentRemoving(sender, e);
    }

    protected override void ChangeService_ComponentRemoved(object sender, ComponentEventArgs e)
    {
      base.ChangeService_ComponentRemoved(sender, e);

      if (Grid == null || Grid.Disposing) return;

      DataGridColumnFooterItem fi = e.Component as DataGridColumnFooterItem;
      if (fi != null)
      {
        foreach(DataGridFooterRow row in Grid.Footer.Rows)
        {
          ChangeService.OnComponentChanged(row, null, null, null);
        }
        foreach (DataGridColumn ci in Grid.Columns)
        {
          ChangeService.OnComponentChanged(ci, null, null, null);
          ChangeService.OnComponentChanged(ci.Footer, null, null, null);
        }
      }

      DataGridColumn col = e.Component as DataGridColumn;
      if (col != null && Grid.StaticColumns.IndexOf(col) >= 0)
        Grid.StaticColumns.Remove(col);

      if (DesignManager != null)
        DesignManager.ComponentRemoved(e);
    }

    protected override void ChangeService_ComponentChanged(object sender, ComponentChangedEventArgs e)
    {
      base.ChangeService_ComponentChanged(sender, e);

      if (Grid == null || Grid.Disposing) return;

      if (DesignManager != null)
        DesignManager.ComponentChanged(e);
    }

    protected virtual Component GetHitTestComponent(Point point)
    {
      BaseGridState state = Grid.CheckSizingState(point.X, point.Y);
      if (state == BaseGridState.ColSizing)
        return null;

      GridCoord cellHit = Grid.CalcCellCoordFromPoint(point.X, point.Y);
      int dataColHit = cellHit.X - Grid.StartDataColIndex;
      if (cellHit.X >= Grid.StartDataColIndex &&
          dataColHit < Grid.VisibleColumns.Count)
      {
        DataGridColumn column = Grid.VisibleColumns[dataColHit];

        if (cellHit.Y == Grid.TitleRowIndex)
        {

          ISelectionService selSrv = SelService;

          if (Grid.Title.MultiTitle.Active)
          {
            DataGridBaseCellMan cell = (DataGridBaseCellMan)Grid.CellManByColRow(cellHit.X, cellHit.Y);
            DataGridTitleCellMan titleCell = (cell as DataGridTitleCellMan);
            if (titleCell != null)
            {
              DataGridTitleNode tn = titleCell.GetMultiTitleNodeAtPos(point);
              if (tn != null)
              {
                if (tn.NodeType == DataGridTitleNodeType.ColumnTitle)
                  return tn.ColumnTitle.Column;
                else
                  return tn.SuperTitle;
              }
            }
          }
          else
          {
            if ((selSrv != null) && (column != null))
            {
              return column;
            }
          }
        }
        else if (cellHit.Y >= Grid.RowCount)
        {
          int localColIndex;
          int localRowIndex;
          Grid.CellManByColRow(cellHit.X, cellHit.Y, out localColIndex, out localRowIndex);
          if (localRowIndex < column.Footer.Items.Count)
          {
            DataGridColumnFooterItem result = column.Footer.Items[localRowIndex];
            if (result != null)
              return result;
            else
              return EmptyFooterItem;
          }
        }
      }
      return null;
    }

    internal static void ShowErrorDialog(IUIService uiService, Exception ex, Control dataGridView)
    {
      if (uiService != null)
      {
        uiService.ShowError(ex);
      }
      else
      {
        string message = ex.Message;
        if (string.IsNullOrEmpty(message))
        {
          message = ex.ToString();
        }
        MessageBox.Show(dataGridView, message, null, MessageBoxButtons.OK, MessageBoxIcon.Exclamation,
                MessageBoxDefaultButton.Button1, 0);
      }
    }

    internal static void ShowErrorDialog(IUIService uiService, string errorString, Control dataGridView)
    {
      if (uiService != null)
      {
        uiService.ShowError(errorString);
      }
      else
      {
        MessageBox.Show(dataGridView, errorString, null, MessageBoxButtons.OK, MessageBoxIcon.Exclamation,
                MessageBoxDefaultButton.Button1, 0);
      }
    }

    private void SelectEmptyFooterItem(Point location)
    {
      BaseGridState state = Grid.CheckSizingState(location.X, location.Y);
      if (state == BaseGridState.ColSizing)
        return;

      GridCoord cellHit = Grid.CalcCellCoordFromPoint(location.X, location.Y);
      int dataColHit = cellHit.X - Grid.StartDataColIndex;
      if (cellHit.X >= Grid.StartDataColIndex &&
          dataColHit < Grid.VisibleColumns.Count)
      {
        DataGridColumn column = Grid.VisibleColumns[dataColHit];
        if (cellHit.Y >= Grid.RowCount)
        {
          int localColIndex;
          int localRowIndex;
          Grid.CellManByColRow(cellHit.X, cellHit.Y, out localColIndex, out localRowIndex);
          if (localRowIndex < column.Footer.Items.Count)
          {
            DataGridColumnFooterItem result = column.Footer.Items[localRowIndex];
            if (result != null)
              return;
            else
            {
              SelService.SetSelectedComponents(new object[] { Grid });

              EmptyFooterItem.Grid = Grid;
              EmptyFooterItem.Column = column;
              EmptyFooterItem.FooterRow = Grid.Footer.Rows[localRowIndex];
              EmptyFooterItemDesignerVerb.Visible = true;

              //ISelectionService selSrv = SelService;
              //selSrv.SetSelectedComponents(new object[] { EmptyFooterItem });
              Control.Invalidate();
            }
          }
        }
      }
    }

    private void WmMouseUp(ref Message m, MouseButtons button)
    {
      //int x = NativeMethods.SignedLOWORD(m.LParam);
      //int y = NativeMethods.SignedHIWORD(m.LParam);
      //Point mousePos = new Point(x, y);
      //Point screenMousePos = Grid.PointToScreen(mousePos);

      //Component hitTestComponent = GetHitTestComponent(mousePos);

      //if (Grid.GridState == BaseGridState.Normal &&
      //    hitTestComponent != null && 
      //    button == MouseButtons.Left)
      //{
      //  //ISelectionService selSrv = SelService;
      //  //selSrv.SetSelectedComponents(new object[] { hitTestComponent });
      //  EhLibUtils.DoNothing();
      //}
      //else if (button == MouseButtons.Right)
      //{
      //  //menu.Show(control, new Point(control.Width, 0));

      //  IMenuCommandService service = (IMenuCommandService)GetService(typeof(IMenuCommandService));
      //  if (service != null)
      //  {
      //    AddGlobalMenu(service);
      //    service.ShowContextMenu(MenuCommands.SelectionMenu, screenMousePos.X, screenMousePos.Y);
      //    RemoveGlobalMenu(service);
      //  }
      //}
      //else
      {
        base.WndProc(ref m);
      }
    }

    private void WmMouseDown(ref Message m, MouseButtons button)
    {
      //int x = NativeMethods.SignedLOWORD(m.LParam);
      //int y = NativeMethods.SignedHIWORD(m.LParam);
      //Point mousePos = new Point(x, y);

      //Component hitTestComponent = GetHitTestComponent(mousePos);

      //if (hitTestComponent != null)
      //{
      //  if (button == MouseButtons.Left)
      //  {
      //    ISelectionService selSrv = SelService;
      //    selSrv.SetSelectedComponents(new object[] { hitTestComponent });
      //  }
      //}
      //else
      {
        base.WndProc(ref m);
      }
    }

    private void WmMouseMove(ref Message m)
    {
      //MouseButtons buttons = Control.MouseButtons;
      //int x = NativeMethods.SignedLOWORD(m.LParam);
      //int y = NativeMethods.SignedHIWORD(m.LParam);
      //Point mousePos = new Point(x, y);

      //Component hitTestComponent = GetHitTestComponent(mousePos);

      //if (hitTestComponent != null &&
      //    buttons == MouseButtons.Left &&
      //    Grid.GridState == BaseGridState.Normal)
      //{
      //  GridCoord cellHit = Grid.CalcCellCoordFromPoint(x, y);

      //  Grid.StartColMoving(cellHit.X, cellHit.X, x, y);
      //}
      //else
      {
        base.WndProc(ref m);
      }
    }

    private void WmNCHitTest(ref Message m)
    {
      base.WndProc(ref m);
    }
    #endregion
  }

  public class DataGridDummyFooterItemDesigner : ComponentDesigner
  {

    //private DesignerVerbCollection verbs;
    public DataGridDummyFooterItemDesigner()
    {
    }

    #region Properties
    public override DesignerVerbCollection Verbs
    {
      get
      {
        return CreateDesignVerbs();
      }
    }
    #endregion 

    #region Methods
    protected virtual DesignerVerbCollection CreateDesignVerbs()
    {
      DesignerVerbCollection verbs;
      verbs = new DesignerVerbCollection();

      verbs.Add(new DesignerVerb("Create Footer Item", null));

      return verbs;
    }

    protected void AddSuperTitleHandler(object sender, EventArgs e)
    {
      IComponentChangeService chService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
      chService.OnComponentChanged(this, null, null, null);
    }
    #endregion 
  }

  //public class DataGridTestActionList : DesignerActionList
  //{
  //  public DataGridTestActionList(IComponent component) : base(component)
  //  {
  //  }

  //  public override DesignerActionItemCollection GetSortedActionItems()
  //  {
  //    DesignerActionItemCollection items = new DesignerActionItemCollection();
  //    items.Add(new DesignerActionMethodItem(this, "SelectTitle", "Select Title", true));
  //    items.Add(new DesignerActionMethodItem(this, "SelectColumnOptions", "Select ColumnOptions", true));
  //    return items;
  //  }

  //  public void SelectTitle()
  //  {
  //    DataGridEh grid = (Component as DataGridEh);
  //    var selService = (ISelectionService)GetService(typeof(ISelectionService));
  //    selService.SetSelectedComponents(new object[] { grid.Title });
  //  }

  //  public void SelectColumnOptions()
  //  {
  //    DataGridEh grid = (Component as DataGridEh);
  //    var selService = (ISelectionService)GetService(typeof(ISelectionService));
  //    selService.SetSelectedComponents(new object[] { grid.ColumnOptions });
  //  }

  //}

}
