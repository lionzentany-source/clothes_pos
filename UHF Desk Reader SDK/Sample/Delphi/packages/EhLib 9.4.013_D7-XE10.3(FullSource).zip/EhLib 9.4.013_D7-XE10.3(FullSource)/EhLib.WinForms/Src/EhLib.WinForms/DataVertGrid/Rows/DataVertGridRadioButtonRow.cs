﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of row in a DataVertGridEh control that displays a readio button user interface (UI).
  /// </summary>
  [DataVertGridRowDesignTimeVisible(true)]
  public class DataVertGridRadioButtonRow : DataVertGridRow, IRadioButtonDataCellHolder
  {

    #region private consts
    //private static readonly object EventKey_GetCheckboxState = new object();
    #endregion private consts

    #region privates
    #endregion privates

    public DataVertGridRadioButtonRow()
    {

    }

    #region properties
    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object TrueValue
    {
      get { return DataCell.TrueValue; }
      set { DataCell.TrueValue = value; }
    }

    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object FalseValue
    {
      get { return DataCell.FalseValue; }
      set { DataCell.FalseValue = value; }
    }

    [DefaultValue(FlatStyle.Standard)]
    public FlatStyle FlatStyle
    {
      get { return DataCell.FlatStyle; }
      set { DataCell.FlatStyle = value; }
    }
    #endregion

    #region run-rime properties
    [Browsable(false)]
    public new RadioButtonDataCellManager DataCell
    {
      get { return (RadioButtonDataCellManager)base.InternalCellManager; }
    }
    #endregion

    #region events
    #endregion events

    #region Methods
    protected override BaseDataCellManager CreateTemplateCell()
    {
      return new RadioButtonDataCellManager();
    }

    public void SetCheckedStateAsChecked(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      bool listItemState;
      bool curState = GetCheckedState(propAxisBar, listItemBar);

      if (curState == false)
      {
        //foreach (object li in Grid.DataLink.CurrencyManager.List)
        foreach (var li in Grid.ListItems)
        {
          listItemState = GetCheckedState(this, li);
          if ((li != listItemBar) && (listItemState == true) && (PropDescr != null))
            PropDescr.SetValue(li, false);
        }
      }
      Debug.Assert(PropDescr != null, @"PropDescr != null");
      PropDescr.SetValue(((DataGridRow)listItemBar).SourceItem, true);
    }

    public virtual bool GetCheckedState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      object value = propAxisBar.GetListItemBarValue(listItemBar);
      bool result = GetCheckedStateFromValue(value);
      return result;
    }

    public bool GetCheckedStateFromValue(object value)
    {
      if ((value != null) && (value.Equals(true)))
        return true;
      else
        return false;
    }
    #endregion

  }

  //[DataVertGridDataCellDesignTimeVisible(true)]
  //public class DataVertGridRadioButtonDataCellManager : DataVertGridBaseDataCellManager
  //{
  //  #region privates
  //  private RadioButtonDataCellWorker cellWorker;
  //  #endregion privates

  //  public DataVertGridRadioButtonDataCellManager()
  //  {
  //    cellWorker = new RadioButtonDataCellWorker(this);
  //  }

  //  #region properties
  //  [DefaultValue(null)]
  //  [TypeConverter(typeof(StringConverter))]
  //  public object TrueValue
  //  {
  //    get
  //    {
  //      return cellWorker.TrueValue;
  //    }
  //    set
  //    {
  //      cellWorker.TrueValue = value;
  //    }
  //  }

  //  [DefaultValue(null)]
  //  [TypeConverter(typeof(StringConverter))]
  //  public object FalseValue
  //  {
  //    get
  //    {
  //      return cellWorker.FalseValue;
  //    }
  //    set
  //    {
  //      cellWorker.FalseValue = value;
  //    }
  //  }

  //  [DefaultValue(FlatStyle.Standard)]
  //  public FlatStyle FlatStyle
  //  {
  //    get
  //    {
  //      return cellWorker.FlatStyle;
  //    }
  //    set
  //    {
  //      cellWorker.FlatStyle = value;
  //    }
  //  }
  //  #endregion

  //  #region Methods
  //  public bool GetCheckedStateFromValue(object value)
  //  {
  //    return cellWorker.GetCheckedStateFromValue(value);
  //  }

  //  public void SetCheckedStateAsChecked(DataVertGridRow row, DataAxisGridListItemBar listItemBar)
  //  {
  //    cellWorker.SetCheckedStateAsChecked(row, listItemBar);
  //  }

  //  public virtual bool GetCheckedState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    return cellWorker.GetCheckedState(propAxisBar, listItemBar);
  //  }

  //  public RadioButtonState GetRadioButtonState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    return cellWorker.GetRadioButtonState(propAxisBar, listItemBar);
  //  }

  //  public void SetCheckedState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, bool isChecked)
  //  {
  //    cellWorker.SetCheckedState(propAxisBar, listItemBar, isChecked);
  //  }

  //  public object GetDataValueFromCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, bool isChecked)
  //  {
  //    return cellWorker.GetDataValueFromCheckState(propAxisBar, listItemBar, isChecked);
  //  }

  //  public bool NextCheckedState(bool checkedState)
  //  {
  //    return cellWorker.NextCheckedState(checkedState);
  //  }

  //  public virtual void Toggle(int dataColIndex, int dataRowIndex)
  //  {
  //    cellWorker.Toggle(dataColIndex, dataRowIndex);
  //  }

  //  protected override void PaintForeground(DataAxisGridDataCellPaintEventArgs e)
  //  {
  //    cellWorker.PaintForeground(e);
  //  }

  //  protected internal override void OnKeyDown(KeyEventArgs e)
  //  {
  //    cellWorker.OnKeyDown(e);
  //  }

  //  protected internal override void OnKeyUp(KeyEventArgs e)
  //  {
  //    cellWorker.OnKeyUp(e);
  //  }

  //  protected internal override void OnMouseDown(DataAxisGridDataCellMouseEventArgs e)
  //  {
  //    base.OnMouseDown(e);
  //    cellWorker.OnMouseDown(e);
  //  }

  //  protected internal override void OnMouseMove(DataAxisGridDataCellMouseEventArgs e)
  //  {
  //    base.OnMouseMove(e);
  //    //cellWorker.OnMouseMove(e);
  //  }

  //  protected internal override void OnMouseUp(DataAxisGridDataCellMouseEventArgs e)
  //  {
  //    cellWorker.OnMouseUp(e);
  //    base.OnMouseUp(e);
  //  }

  //  protected internal override void OnMouseEnter(DataAxisGridDataCellEnterEventArgs e)
  //  {
  //    Grid.InvalidateCell(e.ColIndex, e.RowIndex);
  //    base.OnMouseEnter(e);
  //  }

  //  protected internal override void OnMouseLeave(DataAxisGridDataCellLeaveEventArgs e)
  //  {
  //    Grid.InvalidateCell(e.ColIndex, e.RowIndex);
  //    base.OnMouseLeave(e);
  //    cellWorker.OnMouseLeave(e);
  //  }
  //  #endregion Methods
  //}

}
