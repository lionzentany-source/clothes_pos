﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  /// <summary>
  ///  Test control.
  ///  TestControl is intended for use only inside the library.
  /// </summary>
  [DesignerCategory("Code")]
  [Designer("EhLib.WinForms.Design.TestControlDesigner, EhLib.WinForms.Design")]
  [ToolboxItem(false)]
  //[ToolboxBitmap(typeof(DataGridEh), "ToolboxBitmaps.EhLib_DataGrid.bmp")]
  ////[ToolboxBitmap(typeof(DataGridEh))]
  //[ComplexBindingProperties("DataSource", "DataMember")]
  [Description("Test Control")]
  public class TestControl : Control
  {
    public TestControl()
    {
      //InitializeComponent();
    }

    protected override void Dispose(bool disposing)
    {
      base.Dispose(disposing);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
      //base.OnPaint(pe);
      e.Graphics.DrawEllipse(SystemPens.ControlDark, ClientRectangle);
    }

    public string TestProperty { get; set; }

    public override ISite Site
    {
      get
      {
        return base.Site;
      }
      set
      {
        base.Site = value;

        if (value != null)
        {
          INestedContainer nc = (INestedContainer)this.Site.GetService(typeof(INestedContainer));
          if (nc != null)
          {
            //...
            //nc.Add(Title, "Title");
          }
        }
      }
    }

  }
}
