﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Drawing;
using System.Diagnostics;

// ReSharper disable All

namespace EhLib.WinForms
{

  //public enum UpDownButtonId
  //{
  //  Up = 1,
  //  Down = 2,
  //}

  internal enum InternalUpDownButtonId
  {
    None = 0,
    Up = 1,
    Down = 2,
  }

  public class InEditUpDownControlMouseDownEventArgs : InEditControlMouseDownEventArgs
  {

    public InEditUpDownControlMouseDownEventArgs(EditItemControl ec, MouseEventArgs e) : base(ec, e)
    {
      if (e.Y < ec.Bounds.Height / 2)
        ButtonId = UpDownButtonId.Up;
      else
        ButtonId = UpDownButtonId.Down;
    }

    protected override Rectangle GetMouseCaptureBounds(EditItemControl ec, Point mousePos)
    {
      if (mousePos.Y < ec.Bounds.Height / 2)
        return new Rectangle(0, 0, ec.Width, ec.Height / 2);
      else
        return new Rectangle(0, ec.Height / 2, ec.Width, ec.Height - ec.Height / 2);
    }

    public UpDownButtonId ButtonId { get; internal set; }

    //public bool Handled { get; set; }
    //public bool AutoRepeat { get; set; }
    //public int NextAutoRepeatDelay { get; set; }
  }

  public class UpDownButtonDownEventArgs : DownEventArgs
  {
    public UpDownButtonDownEventArgs(bool autoRepeat, int nextAutoRepeatDelay, UpDownButtonId upDownButtonId) : base(autoRepeat, nextAutoRepeatDelay)
    {
      UpDownButtonId = upDownButtonId;
    }

    public UpDownButtonId UpDownButtonId { get; internal set; }
  }

  public class UpDownButtonClickEventArgs : InEditControlClickEventArgs
  {
    public UpDownButtonClickEventArgs(UpDownButtonId upDownButtonId)
    {
      UpDownButtonId = upDownButtonId;
    }

    public UpDownButtonId UpDownButtonId { get; internal set; }
  }

  public class UpDownButtonContextPaintEventArgs : EditItemContextPaintEventArgs
  {
    public UpDownButtonContextPaintEventArgs(EditItem editItem, Rectangle clientRect, Color backColor,
      bool pressed, bool hot, bool disabled, bool drawBackground, bool drawForeground, 
      bool inControlBorderMerging, GraphicsContext graphicsContext, Point? mousePos, InEditControlMouseDownEventArgs mouseDownEventArgs) 
        : base(editItem, clientRect, backColor, pressed, hot, disabled, drawBackground, drawForeground, 
               inControlBorderMerging, graphicsContext, mousePos, mouseDownEventArgs)
    {
      InEditUpDownControlMouseDownEventArgs upDownMouseDownEventArgs = null;
      if (mouseDownEventArgs != null)
      {
        upDownMouseDownEventArgs = mouseDownEventArgs as InEditUpDownControlMouseDownEventArgs;
        Debug.Assert(upDownMouseDownEventArgs != null, "mouseDownEventArgs is not InEditUpDownControlMouseDownEventArgs!!!");
      }

      int halfHeight = clientRect.Height / 2;
      UpButtonBounds = new Rectangle(clientRect.X, clientRect.Y, clientRect.Width, halfHeight);
      
      Rectangle downButtonBounds = new Rectangle(clientRect.X, clientRect.Y + halfHeight, clientRect.Width, halfHeight);
      if (halfHeight != (clientRect.Height + 1) / 2)
        downButtonBounds.Y++;
      DownButtonBounds = downButtonBounds;

      if (upDownMouseDownEventArgs != null && mousePos.HasValue && clientRect.Contains(mousePos.Value))
      {
        if (upDownMouseDownEventArgs.ButtonId == UpDownButtonId.Up && mousePos.Value.Y < halfHeight)
        {
          UpButtonHot = true;
          UpButtonPressed = true;
          DownButtonHot = false;
          DownButtonPressed = false;
        }
        else if (upDownMouseDownEventArgs.ButtonId == UpDownButtonId.Down && mousePos.Value.Y >= halfHeight)
        {
          UpButtonHot = false;
          UpButtonPressed = false;
          DownButtonHot = true;
          DownButtonPressed = true;
        }
        else
        {
          UpButtonHot = false;
          UpButtonPressed = false;
          DownButtonHot = false;
          DownButtonPressed = false;
        }
      }
      else
      {
        UpButtonPressed = false;
        DownButtonPressed = false;
        UpButtonHot = false;
        DownButtonHot = false;
        if (mousePos.HasValue && clientRect.Contains(mousePos.Value))
        {
          if (mousePos.Value.Y < halfHeight)
            UpButtonHot = true;
          else
            DownButtonHot = true;
        }
      }
    }

    public bool UpButtonHot { get; set; }
    public bool UpButtonPressed { get; set; }
    public Rectangle UpButtonBounds { get; set; }
    public bool DownButtonHot { get; set; }
    public bool DownButtonPressed { get; set; }
    public Rectangle DownButtonBounds { get; set; }

  }

  public class InEditUpDownButton : EditItem
  {

    #region private consts
    private static readonly object EventKeyPaint = new object();
    private static readonly object EventKeyDown = new object();
    private static readonly object EventKeyClick = new object();
    #endregion

    #region constructor
    public InEditUpDownButton()
    {
    }
    #endregion

    #region events
    public event EventHandler<UpDownButtonDownEventArgs> Down
    {
      add
      {
        Events.AddHandler(EventKeyDown, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDown, value);
      }
    }

    public event EventHandler<UpDownButtonClickEventArgs> Click
    {
      add
      {
        Events.AddHandler(EventKeyClick, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyClick, value);
      }
    }

    public event EventHandler<UpDownButtonContextPaintEventArgs> Paint
    {
      add
      {
        Events.AddHandler(EventKeyPaint, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyPaint, value);
      }
    }
    #endregion

    #region methods
    protected override EditItemControl CreateInEditWinControl()
    {
      return new InEditUpDownButtonControl(this);
    }

    public override DownEventArgs CreateDownEventArgs(InEditControlMouseDownEventArgs mouseDownEventArgs)
    {
      UpDownButtonId buttonId = ((InEditUpDownControlMouseDownEventArgs)mouseDownEventArgs).ButtonId;
      return new UpDownButtonDownEventArgs(false, DefaultTimerInterval, buttonId);
    }

    public override void DefaultHandleDownAction(DownEventArgs e)
    {
      if (e.Handled) return;
      if (DefaultAction)
        EditControl.HandleInEditControlDownAction(this, e);
    }

    protected override void HandleDownEvent(DownEventArgs e)
    {
      var ude = e as UpDownButtonDownEventArgs;
      if (ude != null)
      {
        var eh = Events[EventKeyDown] as EventHandler<UpDownButtonDownEventArgs>;
        if (eh != null)
          eh(this, ude);
      }
    }

    public override InEditControlClickEventArgs CreateInEditControlClickEventArgs(MouseEventArgs mouseEventArgs, Rectangle inEditControlBounds)
    {
      UpDownButtonId buttonId;

      if (mouseEventArgs.Y < inEditControlBounds.Height / 2)
        buttonId = UpDownButtonId.Up;
      else
        buttonId = UpDownButtonId.Down;

      return new UpDownButtonClickEventArgs(buttonId);
    }

    protected override void HandleClickEvent(InEditControlClickEventArgs e)
    {
      var ude = e as UpDownButtonClickEventArgs;
      if (ude != null)
      {
        var eh = Events[EventKeyClick] as EventHandler<UpDownButtonClickEventArgs>;
        if (eh != null)
          eh(this, ude);
      }
    }

    protected internal override EditItemContextPaintEventArgs CreatePaintEventArgs(Rectangle clientRect,
      GraphicsContext graphicsContext, Color backColor, bool pressed, bool hot, bool disabled, Nullable<Point> mousePos, InEditControlMouseDownEventArgs mouseDownEventArgs)
    {
      return new UpDownButtonContextPaintEventArgs(this, clientRect, backColor, pressed, hot, disabled,
        true, true, false, graphicsContext, mousePos, mouseDownEventArgs);
    }

    protected override void HandlePaintEvent(EditItemContextPaintEventArgs e)
    {
      var eh = Events[EventKeyPaint] as EventHandler<UpDownButtonContextPaintEventArgs>;
      if (eh != null)
        eh(this, (UpDownButtonContextPaintEventArgs)e);
    }

    protected internal override void OnPaintBackground(EditItemContextPaintEventArgs e)
    {
      UpDownButtonContextPaintEventArgs ude = e as UpDownButtonContextPaintEventArgs;
      Debug.Assert(ude != null, "method OnPaintBackground / e is not UpDownButtonContextPaintEventArgs");

      bool themed = Application.RenderWithVisualStyles;
      Rectangle btnRect = e.ClientRect;
      if (themed) btnRect.Inflate(1, 1);

      //e.Graphics.FillRectangle(new SolidBrush(Color.Red), e.ClientRect);

      int halfHeight = btnRect.Height / 2;
      int startDownButton = halfHeight;
      if (halfHeight != (btnRect.Height + 1) / 2)
        startDownButton++;


      /* Draw the up and down buttons */
      //InternalUpDownButtonId pushedButton = InternalUpDownButtonId.None;

      //if (e.MouseDownEventArgs != null &&
      //    e.MouseIsInCaptureBounds)
      //{
      //  if (MouseDownEventArgs.ButtonId == UpDownButtonId.Up)
      //    pushedButton = InternalUpDownButtonId.Up;
      //  else
      //    pushedButton = InternalUpDownButtonId.Down;
      //}

      if (Application.RenderWithVisualStyles)
      {
        VisualStyleRenderer vsr;

        if (ude.UpButtonPressed)
          vsr = new VisualStyleRenderer(VisualStyleElement.Spin.Up.Pressed);
        else if (ude.UpButtonHot)
          vsr = new VisualStyleRenderer(VisualStyleElement.Spin.Up.Hot);
        else if (e.Disabled)
          vsr = new VisualStyleRenderer(VisualStyleElement.Spin.Up.Disabled);
        else
          vsr = new VisualStyleRenderer(VisualStyleElement.Spin.Up.Normal);

        vsr.DrawBackground(e.Graphics, new Rectangle(btnRect.Left, btnRect.Top, btnRect.Width, halfHeight));

        if (ude.DownButtonPressed)
          vsr.SetParameters(VisualStyleElement.Spin.Down.Pressed);
        else if (ude.DownButtonHot)
          vsr.SetParameters(VisualStyleElement.Spin.Down.Hot);
        else if (e.Disabled)
          vsr.SetParameters(VisualStyleElement.Spin.Down.Disabled);
        else
          vsr.SetParameters(VisualStyleElement.Spin.Down.Normal);

        vsr.DrawBackground(e.Graphics, new Rectangle(btnRect.Left, btnRect.Top + startDownButton, btnRect.Width, halfHeight));
      }
      else
      {
        ControlPaint.DrawScrollButton(e.Graphics,
                                      new Rectangle(btnRect.Left, btnRect.Top, btnRect.Width, halfHeight),
                                      ScrollButton.Up,
                                      ude.UpButtonPressed ?
                                        ButtonState.Pushed :
                                        (e.Disabled ? ButtonState.Inactive : ButtonState.Normal));

        ControlPaint.DrawScrollButton(e.Graphics,
                                      new Rectangle(btnRect.Left, btnRect.Top + startDownButton, btnRect.Width, halfHeight),
                                      ScrollButton.Down,
                                      ude.DownButtonPressed ?
                                        ButtonState.Pushed :
                                        (e.Disabled ? ButtonState.Inactive : ButtonState.Normal));
      }

      if (halfHeight != (btnRect.Height + 1) / 2)
      {
        // When control has odd height, a line needs to be drawn below the buttons with the backcolor.
        using (Pen pen = new Pen(e.BackColor))
        {
          //Rectangle clientRect = btnRect;
          //e.Graphics.DrawLine(pen, clientRect.Left, clientRect.Bottom - 1, clientRect.Right - 1, clientRect.Bottom - 1);
          e.Graphics.DrawLine(pen, btnRect.Left, btnRect.Top + halfHeight, btnRect.Right - 1, btnRect.Top + halfHeight);
        }
      }


    }

    protected internal override void OnPaintForeground(EditItemContextPaintEventArgs e)
    {
      //e.Graphics.DrawRectangle(new Pen(Color.Red), e.ClientRect);
    }

    #endregion
  }

  internal class InEditUpDownButtonControl : EditItemControl
  {

    //private const int DEFAULT_TIMER_INTERVAL = 500;

    //// Button state
    //private InternalUpDownButtonId pushed = InternalUpDownButtonId.None;
    //private InternalUpDownButtonId captured = InternalUpDownButtonId.None;
    private InternalUpDownButtonId mouseOverButton = InternalUpDownButtonId.None;

    protected new InEditUpDownControlMouseDownEventArgs MouseDownEventArgs
    {
      get { return (InEditUpDownControlMouseDownEventArgs)base.MouseDownEventArgs; }
      set { base.MouseDownEventArgs = value; }
    }

    //// Timer
    //private Timer timer;
    //private int timerInterval;

    //private bool doubleClickFired = false;

    #region constructor
    public InEditUpDownButtonControl(EditItem editItem) : base(editItem)
    {
      //SetStyle(ControlStyles.Opaque | ControlStyles.FixedHeight | ControlStyles.FixedWidth, true);
      SetStyle(ControlStyles.Selectable, false);
    }
    #endregion constructor

    protected override InEditControlMouseDownEventArgs CreateInEditControlMouseDownEventArgs(MouseEventArgs mouseEventArgs)
    {
      return new InEditUpDownControlMouseDownEventArgs(this, mouseEventArgs);
    }

    //private void BeginButtonPress(MouseEventArgs e)
    //{

    //  int halfHeight = Size.Height / 2;

    //  if (e.Y < halfHeight)
    //  {
    //    pushed = InternalUpDownButtonId.Up;
    //    captured = InternalUpDownButtonId.Up;
    //    Invalidate();
    //  }
    //  else
    //  {
    //    pushed = InternalUpDownButtonId.Down;
    //    captured = InternalUpDownButtonId.Down;
    //    Invalidate();
    //  }

    //  Capture = true;

    //  OnUpDown(new UpDownEventArgs(InternalUpDownButtonIdToUpDownButtonId(pushed)));

    //  StartTimer();
    //}

    //private void EndButtonPress()
    //{

    //  pushed = InternalUpDownButtonId.None;
    //  captured = InternalUpDownButtonId.None;

    //  StopTimer();
    //  Capture = false;
    //  Invalidate();
    //}

    //protected override void OnMouseDown(MouseEventArgs e)
    //{
    //  //this.parent.FocusInternal();
    //  EditItem.EditControl.Focus();

    //  if (/*!parent.ValidationCancelled &&*/ e.Button == MouseButtons.Left)
    //  {
    //    BeginButtonPress(e);
    //  }
    //  //if (e.Clicks == 2 && e.Button == MouseButtons.Left)
    //  //{
    //  //  doubleClickFired = true;
    //  //}

    //  Debug.Assert(!(pushed != InternalUpDownButtonId.None && captured == InternalUpDownButtonId.None),
    //               "Invalid button pushed/captured combination");

    //  //parent.OnMouseDown(parent.TranslateMouseEvent(this, e));
    //}

    protected override void OnMouseMove(MouseEventArgs e)
    {
      base.OnMouseMove(e);

      //Logic for seeing which button is Hot if any
      Rectangle rectUp = ClientRectangle;
      Rectangle rectDown = ClientRectangle;

      rectUp.Height /= 2;
      rectDown.Y += rectDown.Height / 2;

      //Check if the mouse is on the upper or lower button. Note that it could be in neither.
      if (rectUp.Contains(e.X, e.Y) && mouseOverButton != InternalUpDownButtonId.Up)
      {
        mouseOverButton = InternalUpDownButtonId.Up;
        Invalidate();
      }
      else if (rectDown.Contains(e.X, e.Y) && mouseOverButton != InternalUpDownButtonId.Down)
      {
        mouseOverButton = InternalUpDownButtonId.Down;
        Invalidate();
      }

      // At no stage should a button be pushed, and the mouse
      // not captured.
      //Debug.Assert(!(pushed != InternalUpDownButtonId.None && captured == InternalUpDownButtonId.None),
      //             "Invalid button pushed/captured combination");

      //parent.OnMouseMove(parent.TranslateMouseEvent(this, e));
    }

    //protected override void OnMouseUp(MouseEventArgs e)
    //{

    //  if (/*!Parent.ValidationCancelled && */e.Button == MouseButtons.Left)
    //  {
    //    EndButtonPress();
    //  }

    //  Debug.Assert(!(pushed != InternalUpDownButtonId.None && captured == InternalUpDownButtonId.None),
    //               "Invalid button pushed/captured combination");

    //  //Point pt = new Point(e.X, e.Y);
    //  //pt = PointToScreen(pt);

    //  //MouseEventArgs me = parent.TranslateMouseEvent(this, e);
    //  //if (e.Button == MouseButtons.Left)
    //  //{
    //  //  if (!parent.ValidationCancelled && UnsafeNativeMethods.WindowFromPoint(pt.X, pt.Y) == Handle)
    //  //  {
    //  //    if (!doubleClickFired)
    //  //    {
    //  //      this.parent.ProcessClick(me);
    //  //    }
    //  //    else
    //  //    {
    //  //      doubleClickFired = false;
    //  //      this.parent.OnDoubleClick(me);
    //  //      this.parent.OnMouseDoubleClick(me);
    //  //    }
    //  //  }
    //  //  doubleClickFired = false;
    //  //}

    //  //parent.OnMouseUp(me);
    //}

    //protected override void OnMouseLeave(EventArgs e)
    //{
    //  mouseOverButton = InternalUpDownButtonId.None;
    //  Invalidate();

    //  //parent.OnMouseLeave(e);
    //}

    protected override void OnPaint(PaintEventArgs e)
    {
      base.OnPaint(e);

      //bool themed = Application.RenderWithVisualStyles;
      //Rectangle btnRect = ClientRectangle;
      ////Rectangle clientRect = btnRect;
      //if (themed) btnRect.Inflate(1, 1);

      //e.Graphics.FillRectangle(new SolidBrush(Color.Red), ClientRectangle);

      //int halfHeight = btnRect.Height / 2;
      //int startDownButton = halfHeight;
      //if (halfHeight != (btnRect.Height + 1) / 2)
      //  startDownButton++;


      // /* Draw the up and down buttons */
      //InternalUpDownButtonId pushedButton = InternalUpDownButtonId.None;

      //if (MouseDownEventArgs != null &&
      //    MouseIsInCaptureBounds)
      //{
      //  if (MouseDownEventArgs.ButtonId == UpDownButtonId.Up)
      //    pushedButton = InternalUpDownButtonId.Up;
      //  else
      //    pushedButton = InternalUpDownButtonId.Down;
      //}

      //if (Application.RenderWithVisualStyles)
      //{
      //  VisualStyleRenderer vsr;
      //  if (mouseOverButton == InternalUpDownButtonId.Up)
      //    vsr = new VisualStyleRenderer(VisualStyleElement.Spin.Up.Hot);
      //  else
      //    vsr = new VisualStyleRenderer(VisualStyleElement.Spin.Up.Normal);

      //  if (!Enabled)
      //  {
      //    vsr.SetParameters(VisualStyleElement.Spin.Up.Disabled);
      //  }
      //  else if (pushedButton == InternalUpDownButtonId.Up)
      //  {
      //    vsr.SetParameters(VisualStyleElement.Spin.Up.Pressed);
      //  }

      //  vsr.DrawBackground(e.Graphics, new Rectangle(btnRect.Left, btnRect.Top, btnRect.Width, halfHeight));

      //  if (!Enabled)
      //  {
      //    vsr.SetParameters(VisualStyleElement.Spin.Down.Disabled);
      //  }
      //  else if (pushedButton == InternalUpDownButtonId.Down)
      //  {
      //    vsr.SetParameters(VisualStyleElement.Spin.Down.Pressed);
      //  }
      //  else
      //  {
      //    if (mouseOverButton == InternalUpDownButtonId.Down)
      //      vsr.SetParameters(VisualStyleElement.Spin.Down.Hot);
      //    else
      //      vsr.SetParameters(VisualStyleElement.Spin.Down.Normal);
      //  }

      //  vsr.DrawBackground(e.Graphics, new Rectangle(btnRect.Left, btnRect.Top + startDownButton, btnRect.Width, halfHeight));
      //}
      //else
      //{
      //  ControlPaint.DrawScrollButton(e.Graphics,
      //                                new Rectangle(0, 0, Width, halfHeight),
      //                                ScrollButton.Up,
      //                                pushedButton == InternalUpDownButtonId.Up ?
      //                                  ButtonState.Pushed :
      //                                  (Enabled ? ButtonState.Normal : ButtonState.Inactive));

      //  ControlPaint.DrawScrollButton(e.Graphics,
      //                                new Rectangle(0, startDownButton, Width, halfHeight),
      //                                ScrollButton.Down,
      //                                pushedButton == InternalUpDownButtonId.Down ?
      //                                  ButtonState.Pushed :
      //                                  (Enabled ? ButtonState.Normal : ButtonState.Inactive));
      //}

      //if (halfHeight != (btnRect.Height + 1) / 2)
      //{
      //  // When control has odd height, a line needs to be drawn below the buttons with the backcolor.
      //  using (Pen pen = new Pen(Parent.BackColor))
      //  {
      //    //Rectangle clientRect = btnRect;
      //    //e.Graphics.DrawLine(pen, clientRect.Left, clientRect.Bottom - 1, clientRect.Right - 1, clientRect.Bottom - 1);
      //    e.Graphics.DrawLine(pen, btnRect.Left, btnRect.Top + halfHeight, btnRect.Right - 1, btnRect.Top + halfHeight);
      //  }
      //}

      ////base.OnPaint(e); // raise paint event, just in case this inner class goes public some day
    }

    //protected virtual void OnUpDown(UpDownEventArgs upevent)
    //{
    //  EditItem.OnUpDown(upevent);
    //}

    //protected void StartTimer()
    //{
    //  //parent.OnStartTimer();
    //  if (timer == null)
    //  {
    //    timer = new Timer();
    //    timer.Tick += TimerHandler;
    //  }

    //  timerInterval = DEFAULT_TIMER_INTERVAL;

    //  timer.Interval = timerInterval;
    //  timer.Start();
    //}

    //protected void StopTimer()
    //{
    //  if (timer != null)
    //  {
    //    timer.Stop();
    //    timer.Dispose();
    //    timer = null;
    //  }
    //  //parent.OnStopTimer();
    //}

    //private void TimerHandler(object source, EventArgs args)
    //{

    //  if (!Capture)
    //  {
    //    EndButtonPress();
    //    return;
    //  }

    //  OnUpDown(new UpDownEventArgs(InternalUpDownButtonIdToUpDownButtonId(pushed)));

    //  // Accelerate timer.
    //  timerInterval = timerInterval * 7;
    //  timerInterval = timerInterval / 10;

    //  if (timerInterval < 1)
    //  {
    //    timerInterval = 1;
    //  }

    //  timer.Interval = timerInterval;
    //}

    //protected UpDownButtonId InternalUpDownButtonIdToUpDownButtonId(InternalUpDownButtonId btnId)
    //{
    //  Debug.Assert(btnId != InternalUpDownButtonId.None);
    //  if (btnId == InternalUpDownButtonId.Down)
    //    return UpDownButtonId.Down;
    //  else
    //    return UpDownButtonId.Up;
    //}

  }

}
