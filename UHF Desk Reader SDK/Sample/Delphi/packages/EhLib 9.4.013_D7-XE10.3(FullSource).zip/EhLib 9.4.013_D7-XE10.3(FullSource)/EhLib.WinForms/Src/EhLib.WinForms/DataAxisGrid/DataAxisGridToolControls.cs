﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EhLib.WinForms
{
  //[AttributeUsage(AttributeTargets.Class)]
  //public class DataAxisGridPropBarDesignTimeVisibleAttribute : Attribute
  //{
  //  private bool visible;

  //  public DataAxisGridPropBarDesignTimeVisibleAttribute(bool visible)
  //  {
  //    this.visible = visible;
  //  }

  //  public DataAxisGridPropBarDesignTimeVisibleAttribute()
  //  {
  //    this.visible = true;
  //  }

  //  public bool Visible
  //  {
  //    get
  //    {
  //      return visible;
  //    }
  //  }

  //  public override bool Equals(object obj)
  //  {
  //    if (obj == this)
  //    {
  //      return true;
  //    }

  //    DataAxisGridPropBarDesignTimeVisibleAttribute other = obj as DataAxisGridPropBarDesignTimeVisibleAttribute;
  //    return other != null && other.Visible == visible;
  //  }

  //  public override int GetHashCode()
  //  {
  //    return GetType().GetHashCode() ^ (visible ? -1 : 0);
  //  }

  //  public override bool IsDefaultAttribute()
  //  {
  //    return (this.Visible == true);
  //  }
  //}

  [AttributeUsage(AttributeTargets.Class)]
  public class DataCellDesignTimeVisibleAttribute : DesignTimeCollectionEditorItemVisibleAttribute
  {
    //private bool visible;

    public DataCellDesignTimeVisibleAttribute(bool visible) : base(visible)
    {
      //this.visible = visible;
    }

    public DataCellDesignTimeVisibleAttribute() : base()
    {
      //this.visible = true;
    }

    //public bool Visible
    //{
    //  get
    //  {
    //    return visible;
    //  }
    //}

    public static readonly DataCellDesignTimeVisibleAttribute Default = new DataCellDesignTimeVisibleAttribute(true);

    //public override bool Equals(object obj)
    //{
    //  if (obj == this)
    //  {
    //    return true;
    //  }

    //  DataCellDesignTimeVisibleAttribute other = obj as DataCellDesignTimeVisibleAttribute;
    //  return other != null && other.Visible == visible;
    //}

    //public override int GetHashCode()
    //{
    //  return GetType().GetHashCode() ^ (visible ? -1 : 0);
    //}

    //public override bool IsDefaultAttribute()
    //{
    //  return (this.Visible == true);
    //}
  }
}
