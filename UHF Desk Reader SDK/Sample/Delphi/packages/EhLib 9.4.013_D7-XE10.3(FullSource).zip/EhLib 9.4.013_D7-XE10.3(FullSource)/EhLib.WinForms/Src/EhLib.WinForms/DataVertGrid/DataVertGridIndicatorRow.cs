﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Drawing.Drawing2D;

namespace EhLib.WinForms
{

  /// <summary>
  /// Contains properties for customizing top indicator row in <see cref="DataVertGridEh"/>.
  /// </summary>
  /// <remarks>
  /// You can retrieve an instance of this class through the <see cref="DataVertGridEh.IndicatorRow"/> property.
  /// </remarks>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  [ToolboxItem(false)]
  [DesignerCategory("Code")]
  public class DataVertGridIndicatorRow : Component
  {

    #region private consts
    #endregion private consts

    #region privates
    private Font font;
    private Font defaultFont;
    private bool visible;
    private bool showRecNo;
    private DataVertGridEh grid;
    #endregion

    public DataVertGridIndicatorRow(DataVertGridEh grid)
    {
      this.grid = grid;
    }

    #region design-time properties
    [DefaultValue(false)]
    public bool Visible
    {
      get
      {
        return visible;
      }

      set
      {
        if (visible != value)
        {
          visible = value;
          Grid.InternalUpdateRowsList();
        }
      }
    }

    [DefaultValue(false)]
    public bool ShowRecNo
    {
      get
      {
        return showRecNo;
      }

      set
      {
        if (showRecNo != value)
        {
          showRecNo = value;
          Grid.InternalUpdateRowsList();
        }
      }
    }

    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public Font Font
    {
      get
      {
        if (font != null)
          return font;
        else
          return DefaultFont();
      }

      set
      {
        font = value;
        FontChanged();
      }
    }
    #endregion

    #region design-time properties
    [Browsable(false)]
    public DataVertGridEh Grid
    {
      get { return grid; }
    }
    #endregion

    #region methods

    //Font
    protected virtual Font DefaultFont()
    {
      if (defaultFont == null)
      {
        defaultFont = new Font(Grid.Font.Name,
                               Grid.Font.Size / 100 * 80,
                               FontStyle.Regular,
                               Grid.Font.Unit,
                               Grid.Font.GdiCharSet);
      }
      return defaultFont;
    }

    protected virtual bool ShouldSerializeFont()
    {
      return (!ReferenceEquals(Font, defaultFont));
    }

    public virtual void ResetFont()
    {
      font = null;
      FontChanged();
    }

    protected virtual void FontChanged()
    {
      if (Grid != null)
        Grid.UpdateBaseFixedBands();
    }

    public virtual void UpdateDefaultFont()
    {
      defaultFont = new Font(Grid.Font.Name,
                             Grid.Font.Size / 100 * 80,
                             FontStyle.Regular,
                             Grid.Font.Unit,
                             Grid.Font.GdiCharSet);
      ResetFont();
    }

    //Other
    #endregion
  }

  public class DataVertGridIndicatorDataCellMan : DataVertGridBaseIndicatorCellMan
  {
    //Painting
   protected internal override void OnPaintForeground(BaseGridCellPaintEventArgs e)
    {
      int widthReducer = 0;
      Rectangle sectRect;

      if (BoundGrid.IndicatorRow.ShowRecNo)
      {
        sectRect = e.ClientRect;
        sectRect.Width = e.ClientRect.Width - widthReducer;
        PaintRowNumber(e.Grid, e.GraphicsContext, sectRect, e.State, e.AreaColIndex, e.AreaRowIndex);
      }
    }

    protected internal virtual void PaintRowNumber(BaseGridControl grid, GraphicsContext gc,
      Rectangle paintRect, BasePaintCellStates state, int areaColIndex, int areaRowIndex)
    {
      //TextFormatFlags aligntFlags;

      //aligntFlags = TextFormatFlags.Left | TextFormatFlags.VerticalCenter;
      Font font = BoundGrid.IndicatorRow.Font;
      Color foreColor = BoundGrid.ForeColor;

      if ((state & BasePaintCellStates.Selected) != 0)
        foreColor = BoundGrid.GetDrawStyle().GetFixedSelectedForeColor(BoundGrid, BoundGrid.FixedBackFiller.Color, foreColor);

      Rectangle dataRect = paintRect;

      string text = GetDisplayText(grid, areaColIndex, areaRowIndex);
      BoundGrid.PaintingDrawText(gc, text, font, dataRect, foreColor, 
        HorizontalAlignment.Center, VerticalAlignment.Center, false);

    }

    //Other
    public override string GetDisplayText(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      DataVertGridEh dataGrid = grid as DataVertGridEh;
      int pos = areaColIndex + 1;
      if (pos > 0 &&
          dataGrid.CurrencyManager != null && 
          dataGrid.CurrencyManager.Count > 0)
      {
        return pos.ToString();
      }
      else
      {
        return "";
      }
    }

    protected internal override void OnGetCellBorderParams(BaseGridCellBorderEventArgs e)
    {
      base.OnGetCellBorderParams(e);

      if (e.BorderType == GridCellBorderSide.Right || e.BorderType == GridCellBorderSide.Left)
      {
        GridLine gl = BoundGrid.TitleBar.VertLine;
        e.Visible = gl.Visible;
        e.Color = gl.Color;
        e.Style = gl.Style;
        e.IsExtent = true;
      }
      else
      {
        GridLine gl = BoundGrid.TitleBar.HorzLine;
        e.Visible = gl.Visible;
        e.Color = gl.Color;
        e.Style = gl.Style;
        e.IsExtent = true;
      }
    }

  }
}