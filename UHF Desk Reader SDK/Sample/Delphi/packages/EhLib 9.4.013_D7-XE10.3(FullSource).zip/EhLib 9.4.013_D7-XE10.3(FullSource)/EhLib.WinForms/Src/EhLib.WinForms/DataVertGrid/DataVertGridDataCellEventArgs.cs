﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2019 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  /// <summary>
  /// Base event args class for event args that contain event data in cells of a DataVertGridEh control.
  /// </summary>
  public class DataVertGridVirtualDataCellEventArgs : EventArgs
  {
    public DataVertGridVirtualDataCellEventArgs(DataAxisGridDataBarCellEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataVertGridRow Row
    {
      get { return (DataVertGridRow)CellArgs.PropAxisBar; }
    }

    public DataVertGridColumn ListItem
    {
      get { return (DataVertGridColumn)CellArgs.ListItemBar; }
    }

    protected internal DataAxisGridDataBarCellEventArgs CellArgs { get; set; }
  }

  /// <summary>
  /// Event args for some events for a data cell a DataVertGridEh control
  /// like OnDataCellClick, OnDataCellContentClick
  /// </summary>
  public class DataVertGridDataCellEventArgs : BaseGridCellEventArgs
  {
    private readonly DataVertGridRow row;
    private readonly object listItem;

    public DataVertGridDataCellEventArgs(BaseGridControl grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect,
      DataVertGridRow row, object listItem) :
      base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect)
    {
      this.row = row;
      this.listItem = listItem;
      this.Handled = false;
    }

    public DataVertGridRow Row
    {
      get { return this.row; }
    }

    public object ListItem
    {
      get { return this.listItem; }
    }

    public bool Handled { get; set; }
  }

  /// <summary>
  /// Event args for painting event in the data cell of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellPaintEventArgs : EventArgs
  {
    public DataVertGridDataCellPaintEventArgs(DataAxisGridDataCellPaintEventArgs cellEventArgs)
    {
      CellArgs = cellEventArgs;
    }

    public DataVertGridRow Row
    {
      get { return (DataVertGridRow)CellArgs.PropAxisBar; }
    }

    public DataVertGridColumn Column
    {
      get { return (DataVertGridColumn)CellArgs.ListItemBar; }
    }

    public new DataAxisGridDataCellPaintEventArgs CellArgs { get; internal set; }

    public bool Handled
    {
      get { return CellArgs.Handled; }
      set { CellArgs.Handled = value; }
    }

    public virtual void PaintBackground(DataVertGridDataCellPaintEventArgs e)
    {
      e.CellArgs.PaintBackground(e.CellArgs);
    }

    public virtual void PaintForeground(DataVertGridDataCellPaintEventArgs e)
    {
      e.CellArgs.PaintForeground(e.CellArgs);
    }

    //public virtual void PaintForegroundServiceArea(DataGridDataCellPaintEventArgs e)
    //{
    //  BaseDataCellManager dataCellManager = e.CellArgs.CellManager as BaseDataCellManager;
    //  if (dataCellManager != null)
    //    dataCellManager.OnPaintServiceArea(e.CellArgs);
    //}
  }

  //public class DataVertGridDataCellContentPaintEventArgs : EventArgs
  //{
  //  private readonly DataVertGridDataCellPaintEventArgs dataCellPaintEventArgs;
  //  private readonly Rectangle cellContentRect;

  //  public DataVertGridDataCellContentPaintEventArgs(DataVertGridDataCellPaintEventArgs dataCellPaintEventArgs, Rectangle cellContentRect)
  //  {
  //    this.dataCellPaintEventArgs = dataCellPaintEventArgs;
  //    this.cellContentRect = cellContentRect;
  //  }

  //  public DataVertGridDataCellPaintEventArgs DataCellPaintEventArgs
  //  {
  //    get { return this.dataCellPaintEventArgs; }
  //  }

  //  public Rectangle CellContentRect
  //  {
  //    get { return this.cellContentRect; }
  //  }

  //  public DataVertGridRow Row
  //  {
  //    get { return dataCellPaintEventArgs.Row; }
  //  }

  //  public DataVertGridColumn Column
  //  {
  //    get { return dataCellPaintEventArgs.Column; }
  //  }

  //  public BasePaintCellStates State
  //  {
  //    get { return dataCellPaintEventArgs.CellArgs.State; }
  //  }
  //  public Graphics Graphics
  //  {
  //    get { return dataCellPaintEventArgs.CellArgs.Graphics; }
  //  }

  //  public int DataColIndex
  //  {
  //    get { return dataCellPaintEventArgs.CellArgs.DataColIndex; }
  //  }

  //  public int DataRowIndex
  //  {
  //    get { return dataCellPaintEventArgs.CellArgs.DataRowIndex; }
  //  }
  //}

  /// <summary>
  /// Event args for painting cell content event in the data cell of a DataaVertGridEh control
  /// </summary>
  public class DataVertGridDataCellContentPaintEventArgs : EventArgs
  {
    public DataVertGridDataCellContentPaintEventArgs(DataAxisGridDataCellContentPaintEventArgs cellEventArgs)
    {
      CellArgs = cellEventArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public new DataAxisGridDataCellContentPaintEventArgs CellArgs { get; internal set; }

    public bool Handled
    {
      get { return CellArgs.Handled; }
      set { CellArgs.Handled = value; }
    }

    public virtual void PaintContent(DataGridDataCellContentPaintEventArgs e)
    {
      e.CellArgs.PaintContent(e.CellArgs);
    }

  }

  /// <summary>
  /// Event args for DataCellManagerNeeded event of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellManagerNeededEventArgs : EventArgs
  {
    private readonly DataVertGridRow row;
    private readonly DataVertGridColumn listItem;
    private BaseDataCellManager cellManager;

    public DataVertGridDataCellManagerNeededEventArgs(DataVertGridRow row, DataVertGridColumn listItem)
    {
      this.row = row;
      this.listItem = listItem;
    }

    public DataVertGridRow Row
    {
      get { return this.row; }
    }

    public DataVertGridColumn ListItem
    {
      get { return this.listItem; }
    }

    public BaseDataCellManager CellManager
    {
      get { return this.cellManager; }
      set { cellManager = value; }
    }

  }

  /// <summary>
  /// Event args for DataCellClientAreaNeeded event for the data cell of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellClientAreaNeededEventArgs : DataVertGridVirtualDataCellEventArgs
  {
    public DataVertGridDataCellClientAreaNeededEventArgs(DataAxisGridDataCellClientAreaNeededEventArgs cellArgs) : base(cellArgs)
    {
      CellArgs = cellArgs;
    }

    public new DataAxisGridDataCellClientAreaNeededEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for requesting the data cell format parameters of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellFormatParamsNeededEventArgs : DataVertGridVirtualDataCellEventArgs
  {
    public DataVertGridDataCellFormatParamsNeededEventArgs(DataAxisGridDataCellFormatParamsNeededEventArgs cellEventArgs) : base(cellEventArgs)
    {
      CellArgs = cellEventArgs;
    }

    public new DataAxisGridDataCellFormatParamsNeededEventArgs CellArgs { get; internal set; }
  }

  // TODO: Restore
  //public class DataVertGridProgressBarDataCellFormatParamsNeededEventArgs : DataVertGridDataCellFormatParamsNeededEventArgs, IDataAxisGridProgressBarDataCellFormatParamsNeededEventArgs
  //{
  //  public DataVertGridProgressBarDataCellFormatParamsNeededEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell
  //    ) : base(propAxisBar, listItemBar, cell)
  //  {
  //  }

  //  public Color BarFillColor { get; set; }
  //  public Color BarFrameColor { get; set; }
  //}

  //public class DataVertGridDataCellDisplayValueNeededEventArgs : DataAxisGridDataCellDisplayValueNeededEventArgs
  //{
  //  public DataVertGridDataCellDisplayValueNeededEventArgs(PropertyAxisBar propAxisBar,
  //    BaseDataCellManager cellMan, object value) : base(propAxisBar, cellMan, value)
  //  {
  //  }

  //  public DataVertGridRow Row
  //  {
  //    get { return (DataVertGridRow)PropAxisBar; }
  //  }
  //}

  /// <summary>
  /// Event args for DataCellDisplayValueNeeded event in the data cell of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellDisplayValueNeededEventArgs : EventArgs
  {
    public DataVertGridDataCellDisplayValueNeededEventArgs(DataAxisGridDataCellDisplayValueNeededEventArgs cellEventArgs)
    {
      CellArgs = cellEventArgs;
    }

    public DataVertGridRow Row
    {
      get { return (DataVertGridRow)CellArgs.PropAxisBar; }
    }

    public DataVertGridColumn Column
    {
      get { return (DataVertGridColumn)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellDisplayValueNeededEventArgs CellArgs { get; internal set; }

    public object Value
    {
      get { return CellArgs.Value; }
    }

    public object DisplayValue
    {
      get { return CellArgs.DisplayValue; }
      set { CellArgs.DisplayValue = value; }
    }

    public bool Handled
    {
      get { return CellArgs.Handled; }
      set { CellArgs.Handled = value; }
    }

    public object GetDisplayValue(DataVertGridDataCellDisplayValueNeededEventArgs e)
    {
      e.CellArgs.GetDisplayValue(e.CellArgs);
      return e.DisplayValue;
    }
  }

  /// <summary>
  /// Event args for CanModifyStateNeeded event in the data cell of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellCanModifyStateNeededEventArgs : EventArgs
  {
    public DataVertGridDataCellCanModifyStateNeededEventArgs(DataAxisGridDataCellCanModifyStateNeededEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataVertGridRow Row
    {
      get { return (DataVertGridRow)CellArgs.PropAxisBar; }
    }

    public DataVertGridColumn Column
    {
      get { return (DataVertGridColumn)CellArgs.ListItemBar; }
    }

    public bool CanModify
    {
      get { return CellArgs.CanModify; }
      set { CellArgs.CanModify = value; }
    }

    public DataAxisGridDataCellCanModifyStateNeededEventArgs CellArgs { get; internal set; }

    public bool Handled
    {
      get { return CellArgs.Handled; }
      set { CellArgs.Handled = value; }
    }
  }

  /// <summary>
  /// Provides data for mouse related routed events in data cells of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellMouseEventArgs : EventArgs
  {
    public DataVertGridDataCellMouseEventArgs(DataAxisGridDataCellMouseEventArgs cellEventArgs)
    {
      CellArgs = cellEventArgs;
    }

    public DataVertGridRow Row
    {
      get { return (DataVertGridRow)CellArgs.PropAxisBar; }
    }

    public DataVertGridColumn Column
    {
      get { return (DataVertGridColumn)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellMouseEventArgs CellArgs { get; internal set; }

    public bool Handled
    {
      get { return CellArgs.Handled; }
      set { CellArgs.Handled = value; }
    }
  }

  /// <summary>
  /// Provides data for mouse enter event in data cells of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellEnterEventArgs : EventArgs
  {
    public DataVertGridDataCellEnterEventArgs(DataAxisGridDataCellEnterEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataVertGridRow Row
    {
      get { return (DataVertGridRow)CellArgs.PropAxisBar; }
    }

    public DataVertGridColumn Column
    {
      get { return (DataVertGridColumn)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellEnterEventArgs CellArgs { get; internal set; }

    //public bool Handled
    //{
    //  get { return CellArgs.Handled; }
    //  set { CellArgs.Handled = value; }
    //}

  }

  /// <summary>
  /// Provides data for mouse leave event in cells of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellLeaveEventArgs : EventArgs
  {
    public DataVertGridDataCellLeaveEventArgs(DataAxisGridDataCellLeaveEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataVertGridRow Row
    {
      get { return (DataVertGridRow)CellArgs.PropAxisBar; }
    }

    public DataVertGridColumn Column
    {
      get { return (DataVertGridColumn)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellLeaveEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for requesting if editor can be shown in the data cell of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellCanShowEditorStateNeededEventArgs : EventArgs
  {
    public DataVertGridDataCellCanShowEditorStateNeededEventArgs(DataAxisGridDataCellCanShowEditorStateNeededEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataVertGridRow Row
    {
      get { return (DataVertGridRow)CellArgs.PropAxisBar; }
    }

    public DataVertGridColumn Column
    {
      get { return (DataVertGridColumn)CellArgs.ListItemBar; }
    }

    public bool CanShowEditor
    {
      get { return CellArgs.CanShowEditor; }
      set { CellArgs.CanShowEditor = value; }
    }

    public DataAxisGridDataCellCanShowEditorStateNeededEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for DataCellEditorParamsNeeded event in a data cell of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellEditorParamsEventArgs : EventArgs
  {
    public DataVertGridDataCellEditorParamsEventArgs(DataAxisGridDataCellEditorParamsNeededEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataVertGridRow Row
    {
      get { return (DataVertGridRow)CellArgs.PropAxisBar; }
    }

    public DataVertGridColumn Column
    {
      get { return (DataVertGridColumn)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellEditorParamsNeededEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for DataCellEditValueNeeded event in the data cell of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellEditValueNeededEventArgs : EventArgs
  {
    public DataVertGridDataCellEditValueNeededEventArgs(DataAxisGridDataCellEditValueNeededEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataVertGridRow Row
    {
      get { return (DataVertGridRow)CellArgs.PropAxisBar; }
    }

    //TODO : DataGridRow Row is needed
    //public DataGridRow Row
    //{
    //  get { return (DataGridRow)CellArgs.ListItemBar; }
    //}

    public DataAxisGridDataCellEditValueNeededEventArgs CellArgs { get; internal set; }

    public object Value
    {
      get { return CellArgs.Value; }
      set { CellArgs.Value = value; }
    }

    public object EditValue
    {
      get { return CellArgs.EditValue; }
      set { CellArgs.EditValue = value; }
    }

    public bool Handled
    {
      get { return CellArgs.Handled; }
      set { CellArgs.Handled = value; }
    }
  }

  /// <summary>
  /// Event args for DataCellEditorOccupy event in the data cell of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellEditorOccupyEventArgs : EventArgs
  {

    public DataVertGridDataCellEditorOccupyEventArgs(DataAxisGridDataCellEditorOccupyEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataVertGridRow Row
    {
      get { return (DataVertGridRow)CellArgs.PropAxisBar; }
    }

    public DataVertGridColumn Column
    {
      get { return (DataVertGridColumn)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellEditorOccupyEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for DataCellEditorRelease event in the data cell of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellEditorReleaseEventArgs : EventArgs
  {

    public DataVertGridDataCellEditorReleaseEventArgs(DataAxisGridDataCellEditorReleaseEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataVertGridRow Row
    {
      get { return (DataVertGridRow)CellArgs.PropAxisBar; }
    }

    public DataVertGridColumn Column
    {
      get { return (DataVertGridColumn)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellEditorReleaseEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for parsing event in the data cell editor of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellParseValueEventArgs : EventArgs
  {

    public DataVertGridDataCellParseValueEventArgs(DataAxisGridDataCellParseValueEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataVertGridRow Row
    {
      get { return (DataVertGridRow)CellArgs.PropAxisBar; }
    }

    public DataVertGridColumn Column
    {
      get { return (DataVertGridColumn)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellParseValueEventArgs CellArgs { get; internal set; }

    protected virtual void ParseValue(DataGridDataCellParseValueEventArgs e)
    {
      e.CellArgs.ParseValue(e.CellArgs);
    }

    public object InValue
    {
      get { return CellArgs.InValue; }
      set { CellArgs.InValue = value; }
    }

    public object OutValue
    {
      get { return CellArgs.OutValue; }
      set { CellArgs.OutValue = value; }
    }

    public bool Handled
    {
      get { return CellArgs.Handled; }
      set { CellArgs.Handled = value; }
    }
  }

  /// <summary>
  /// Event args for ToolTipInfoNeeded event in the data cell a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellToolTipInfoEventArgs : DataGridVirtualDataCellEventArgs
  {

    public DataVertGridDataCellToolTipInfoEventArgs(DataAxisGridDataCellToolTipInfoEventArgs cellArgs) : base(cellArgs)
    {
      CellArgs = cellArgs;
    }

    public new DataAxisGridDataCellToolTipInfoEventArgs CellArgs { get; internal set; }

    public string ToolTipText
    {
      get
      {
        return CellArgs.ToolTipText;
      }
      set
      {
        CellArgs.ToolTipText = value;
      }
    }
  }

  /// <summary>
  /// Event args for ContextMenuStripNeeded event in the data cell of a DataVertGridEh control
  /// </summary>
  public class DataVertGridDataCellContextMenuStripNeededEventArgs : EventArgs
  {
    public DataVertGridDataCellContextMenuStripNeededEventArgs(DataAxisGridDataCellContextMenuStripNeededEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellContextMenuStripNeededEventArgs CellArgs { get; internal set; }

    public ContextMenuStrip ContextMenuStrip
    {
      get { return CellArgs.ContextMenuStrip; }
      set { CellArgs.ContextMenuStrip = value; }
    }

    public bool Handled
    {
      get { return CellArgs.Handled; }
      set { CellArgs.Handled = value; }
    }

    public virtual void DoContextMenuStripNeeded(DataVertGridDataCellContextMenuStripNeededEventArgs e)
    {
      e.CellArgs.DoContextMenuStripNeeded(e.CellArgs);
    }
  }

}
