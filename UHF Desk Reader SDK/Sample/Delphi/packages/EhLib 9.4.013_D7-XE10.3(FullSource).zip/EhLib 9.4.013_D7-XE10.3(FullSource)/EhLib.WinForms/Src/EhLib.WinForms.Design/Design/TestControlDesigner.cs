﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2019 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace EhLib.WinForms.Design
{
  public class TestControlDesigner : ControlDesigner
  {

    public TestControlDesigner()
    {
    }

    public override void Initialize(IComponent component)
    {
      base.Initialize(component);

      Component cmp = component as Component;
      TestControl testControl = component as TestControl;
      string tname = cmp.GetType().ToString();
      tname = component.GetType().ToString();
      if (testControl != null)
      {
        MessageBox.Show("TestControlDesigner. testControl != null. Component type is " + tname.ToString());
      }
      else
      {
        MessageBox.Show("TestControlDesigner. testControl == null. Component type is " + tname.ToString());
      }

      Debug.Assert(component != null, "component is null");
      Debug.Assert(component as TestControl != null, "component is not a TestControl");
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
      }
      base.Dispose(disposing);
    }

    public override DesignerActionListCollection ActionLists
    {
      get
      {
        DesignerActionListCollection actionLists;
        //if (actionLists == null)
        {
          actionLists = new DesignerActionListCollection();
          actionLists.Add(new TestControlActionList(this));
        }
        return actionLists;
      }
    }

    public override DesignerVerbCollection Verbs
    {
      get
      {
        DesignerVerbCollection dvc = new DesignerVerbCollection();

        dvc.Add(new DesignerVerb("About EhLib.WinForms", ShowAboutDialog));

        return dvc;
      }
    }

    private void ShowAboutDialog(object sender, EventArgs e)
    {
      FormAbout fa = new FormAbout();
      fa.ShowDialog();
    }

  }

  public class TestControlActionList : DesignerActionList
  {
    public TestControlActionList(TestControlDesigner owner) : base(owner.Component)
    {
      Owner = owner;
    }

    public TestControlDesigner Owner
    {
      get;
      internal set;
    }

    public override DesignerActionItemCollection GetSortedActionItems()
    {
      DesignerActionItemCollection items = new DesignerActionItemCollection();
      items.Add(new DesignerActionMethodItem(this, "ShowAboutDialog", "About EhLib.WinForms ...", true));
      items.Add(new DesignerActionPropertyItem("Dock", "Dock"));
      return items;
    }

    public void ShowAboutDialog()
    {
      FormAbout fa = new FormAbout();
      fa.ShowDialog();
    }

    public DockStyle Dock
    {
      get { return (Owner.Component as Control).Dock; }
      set { GetPropertyByName("Dock").SetValue(Owner.Component, value); }
    }

    private PropertyDescriptor GetPropertyByName(String propName)
    {
      PropertyDescriptor prop = TypeDescriptor.GetProperties(Owner.Component)[propName];
      if (prop == null)
      {
        throw new ArgumentException("Propery {0} does not exist", propName);
      }
      return prop;
    }

  }

}
