﻿namespace EhLib.WinForms.Design
{
  partial class DataGridDesignManagerControl
  {
    /// <summary> 
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary> 
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Component Designer generated code

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DataGridDesignManagerControl));
      this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
      this.panel1 = new System.Windows.Forms.Panel();
      this.framePanel = new EhLib.WinForms.PanelEh();
      this.managerGrid = new EhLib.WinForms.Design.DataGridDesignManagerGrid();
      this.dataGridTextColumn1 = new EhLib.WinForms.DataGridTextColumn();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tbAdd = new System.Windows.Forms.ToolStripButton();
      this.tbDelete = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.tbMoveUp = new System.Windows.Forms.ToolStripButton();
      this.tbMoveDown = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.tbShowEditor = new System.Windows.Forms.ToolStripButton();
      ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
      this.framePanel.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.managerGrid)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // bindingSource1
      // 
      this.bindingSource1.CurrentChanged += new System.EventHandler(this.bindingSource1_CurrentChanged);
      // 
      // panel1
      // 
      this.panel1.Cursor = System.Windows.Forms.Cursors.SizeWE;
      this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
      this.panel1.Location = new System.Drawing.Point(0, 0);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(10, 436);
      this.panel1.TabIndex = 8;
      this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
      this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
      this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
      this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
      // 
      // framePanel
      // 
      this.framePanel.Controls.Add(this.managerGrid);
      this.framePanel.Controls.Add(this.toolStrip1);
      this.framePanel.CustomBorderColor = System.Drawing.Color.DarkOrange;
      this.framePanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.framePanel.Location = new System.Drawing.Point(10, 0);
      this.framePanel.Name = "framePanel";
      this.framePanel.Size = new System.Drawing.Size(418, 436);
      this.framePanel.TabIndex = 9;
      // 
      // managerGrid
      // 
      this.managerGrid.AutoSizeColumnOptions.FitToClient = true;
      this.managerGrid.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(248)))), ((int)(((byte)(239)))));
      // 
      // 
      // 
      this.managerGrid.Border.BorderSides.Bottom.Visible = false;
      this.managerGrid.Border.BorderSides.Left.Visible = false;
      this.managerGrid.Border.BorderSides.Right.Visible = false;
      this.managerGrid.Border.Color = System.Drawing.Color.DarkOrange;
      this.managerGrid.Border.Style = EhLib.WinForms.ControlBorderStyle.Custom;
      this.managerGrid.ColumnOptions.AllowMoveColumns = false;
      this.managerGrid.ColumnOptions.AllowShowEditor = false;
      this.managerGrid.DataSource = this.bindingSource1;
      this.managerGrid.Dock = System.Windows.Forms.DockStyle.Fill;
      // 
      // managerGrid.IndicatorColumn
      // 
      this.managerGrid.IndicatorColumn.Visible = false;
      this.managerGrid.LineOptions.HorzLines = false;
      this.managerGrid.Location = new System.Drawing.Point(0, 25);
      this.managerGrid.Name = "managerGrid";
      this.managerGrid.ReadOnly = true;
      this.managerGrid.Selection.AllowedSelection.All = false;
      this.managerGrid.Selection.AllowedSelection.Cells = false;
      this.managerGrid.Selection.AllowedSelection.Columns = false;
      this.managerGrid.Selection.AllowedSelection.Rows = false;
      this.managerGrid.Size = new System.Drawing.Size(416, 409);
      this.managerGrid.StaticColumns.AddRange(new EhLib.WinForms.PropertyAxisBar[] {
            this.dataGridTextColumn1});
      this.managerGrid.TabIndex = 7;
      // 
      // managerGrid.Title
      // 
      this.managerGrid.Title.HorzLine.Visible = true;
      // 
      // managerGrid.TreeViewArea
      // 
      this.managerGrid.TreeViewArea.Visible = true;
      this.managerGrid.TreeViewArea.ExpandedStateSet += new System.EventHandler<EhLib.WinForms.DataGridTreeViewNodeExpandedStateSetEventArgs>(this.dataGridEh1_TreeViewArea_ExpandedStateSet);
      this.managerGrid.TreeViewArea.NodeStateNeeded += new System.EventHandler<EhLib.WinForms.DataGridTreeViewNodeStateNeededEventArgs>(this.dataGridEh1_TreeViewArea_NodeStateNeeded);
      this.managerGrid.SelectionChanged += new System.EventHandler<EhLib.WinForms.DataGridSelectionChangeOperationEventArgs>(this.dataGridEh1_SelectionChanged);
      this.managerGrid.SizeChanged += new System.EventHandler(this.dataGridEh1_SizeChanged);
      // 
      // dataGridTextColumn1
      // 
      this.dataGridTextColumn1.DataPropertyName = "Name";
      this.dataGridTextColumn1.FillWeight = 417F;
      this.dataGridTextColumn1.FormatString = null;
      this.dataGridTextColumn1.Name = "dataGridTextColumn1";
      // 
      // dataGridTextColumn1.Title
      // 
      this.dataGridTextColumn1.Title.Text = "DataGrid Designer";
      this.dataGridTextColumn1.Width = 417;
      this.dataGridTextColumn1.DataCellDisplayValueNeeded += new System.EventHandler<EhLib.WinForms.DataGridDataCellDisplayValueNeededEventArgs>(this.DataGridTextColumn1_DataCellDisplayValueNeeded);
      this.dataGridTextColumn1.DataCellPaint += new System.EventHandler<EhLib.WinForms.DataGridDataCellPaintEventArgs>(this.dataGridTextColumn1_DataCellPaint);
      this.dataGridTextColumn1.DataCellContentPaint += new System.EventHandler<EhLib.WinForms.DataGridDataCellContentPaintEventArgs>(this.DataGridTextColumn1_DataCellContentPaint);
      // 
      // toolStrip1
      // 
      this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tbAdd,
            this.tbDelete,
            this.toolStripSeparator1,
            this.tbMoveUp,
            this.tbMoveDown,
            this.toolStripSeparator2,
            this.tbShowEditor});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
      this.toolStrip1.Size = new System.Drawing.Size(416, 25);
      this.toolStrip1.TabIndex = 0;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tbAdd
      // 
      this.tbAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
      this.tbAdd.Image = ((System.Drawing.Image)(resources.GetObject("tbAdd.Image")));
      this.tbAdd.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tbAdd.Name = "tbAdd";
      this.tbAdd.Size = new System.Drawing.Size(33, 22);
      this.tbAdd.Text = "Add";
      // 
      // tbDelete
      // 
      this.tbDelete.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
      this.tbDelete.Image = ((System.Drawing.Image)(resources.GetObject("tbDelete.Image")));
      this.tbDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tbDelete.Name = "tbDelete";
      this.tbDelete.Size = new System.Drawing.Size(44, 22);
      this.tbDelete.Text = "Delete";
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
      // 
      // tbMoveUp
      // 
      this.tbMoveUp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
      this.tbMoveUp.Image = ((System.Drawing.Image)(resources.GetObject("tbMoveUp.Image")));
      this.tbMoveUp.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tbMoveUp.Name = "tbMoveUp";
      this.tbMoveUp.Size = new System.Drawing.Size(58, 22);
      this.tbMoveUp.Text = "Move up";
      // 
      // tbMoveDown
      // 
      this.tbMoveDown.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
      this.tbMoveDown.Image = ((System.Drawing.Image)(resources.GetObject("tbMoveDown.Image")));
      this.tbMoveDown.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tbMoveDown.Name = "tbMoveDown";
      this.tbMoveDown.Size = new System.Drawing.Size(74, 22);
      this.tbMoveDown.Text = "Move down";
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
      // 
      // tbShowEditor
      // 
      this.tbShowEditor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
      this.tbShowEditor.Image = ((System.Drawing.Image)(resources.GetObject("tbShowEditor.Image")));
      this.tbShowEditor.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tbShowEditor.Name = "tbShowEditor";
      this.tbShowEditor.Size = new System.Drawing.Size(40, 22);
      this.tbShowEditor.Text = "Edit...";
      this.tbShowEditor.Click += new System.EventHandler(this.tbShowEditor_Click);
      // 
      // DataGridDesignManagerControl
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.Controls.Add(this.framePanel);
      this.Controls.Add(this.panel1);
      this.Name = "DataGridDesignManagerControl";
      this.Size = new System.Drawing.Size(428, 436);
      ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
      this.framePanel.ResumeLayout(false);
      this.framePanel.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.managerGrid)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);

    }

    #endregion

    private EhLib.WinForms.Design.DataGridDesignManagerGrid managerGrid;
    private EhLib.WinForms.DataGridTextColumn dataGridTextColumn1;
    private System.Windows.Forms.BindingSource bindingSource1;
    private System.Windows.Forms.Panel panel1;
    private EhLib.WinForms.PanelEh framePanel;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tbAdd;
    private System.Windows.Forms.ToolStripButton tbDelete;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ToolStripButton tbMoveUp;
    private System.Windows.Forms.ToolStripButton tbMoveDown;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    private System.Windows.Forms.ToolStripButton tbShowEditor;
  }
}
