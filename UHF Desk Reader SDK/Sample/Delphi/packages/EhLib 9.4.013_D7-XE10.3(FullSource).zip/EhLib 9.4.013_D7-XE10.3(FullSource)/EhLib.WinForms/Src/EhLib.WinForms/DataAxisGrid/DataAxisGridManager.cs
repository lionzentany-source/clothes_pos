﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  /// <summary>
  /// Extended version of ToolStripMenuItem that supports click without closing menu. 
  /// </summary>
  /// <seealso cref="System.Windows.Forms.ToolStripMenuItem" />
  [ToolboxItem(false)]
  [System.ComponentModel.DesignerCategory("Code")]
  public class ToolStripMenuItemEh : ToolStripMenuItem
  {
    private bool closeMenuOnClick = true;

    public ToolStripMenuItemEh()
    {
    }

    public bool CloseMenuOnClick
    {
      get
      {
        return closeMenuOnClick;
      }

      set
      {
        closeMenuOnClick = value;
      }
    }

    protected override ToolStripDropDown CreateDefaultDropDown()
    {
      //return base.CreateDefaultDropDown();
      return new ToolStripDropDownMenuEh();
    }

    public DataAxisGrid GetDataGrid()
    {
      //Owner 
      ToolStripItem ownerItem = this;
      while (true)
      {
        if (ownerItem.Owner is DataGridContextMenuStrip)
          break;
        if (ownerItem.OwnerItem == null)
          break;
        ownerItem = ownerItem.OwnerItem;
      }
      DataGridContextMenuStrip strip = ownerItem.Owner as DataGridContextMenuStrip;
      if (strip != null)
        return strip.Grid;
      else
        return null;
    }

    //OnClosing += ContextMenuClosing;
    //      searchBoxToolPopupMenu.ItemClicked += ContextMenuItemClicked;

  }


  /// <summary>
  /// Extended version of ContextMenuStrip that supports click without closing menu. 
  /// </summary>
  /// <seealso cref="System.Windows.Forms.ContextMenuStrip" />
  [ToolboxItem(false)]
  [System.ComponentModel.DesignerCategory("Code")]
  public class DataGridContextMenuStrip : ContextMenuStrip
  {
    public DataAxisGrid Grid { get; set; }

    public Collection<ToolStripItemReturnData> ReturnItems = new Collection<ToolStripItemReturnData>();

    protected override void OnItemClicked(ToolStripItemClickedEventArgs e)
    {
      ToolStripMenuItemEh tsmi = e.ClickedItem as ToolStripMenuItemEh;
      if (tsmi == null || tsmi.CloseMenuOnClick == true)
      {
        base.OnItemClicked(e);
      }
    }

    protected override void OnClosed(ToolStripDropDownClosedEventArgs e)
    {
      base.OnClosed(e);
      foreach (ToolStripItemReturnData retData in ReturnItems)
      {
        retData.ContextMenuStrip.Items.Add(retData.ToolStripItem);
      }
      ReturnItems.Clear();
    }
  }

}
