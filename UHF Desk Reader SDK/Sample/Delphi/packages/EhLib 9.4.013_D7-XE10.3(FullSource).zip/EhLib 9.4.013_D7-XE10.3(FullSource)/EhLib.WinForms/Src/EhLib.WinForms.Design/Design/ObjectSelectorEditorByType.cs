﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Diagnostics;
using System.Drawing.Design;

namespace EhLib.WinForms.Design
{

  public class ObjectSelectorEditorByType : ObjectSelectorEditor
  {
    protected override void FillTreeWithData(Selector selector,
            ITypeDescriptorContext context, IServiceProvider provider)
    {
      base.FillTreeWithData(selector, context, provider);

      Type propType = context.PropertyDescriptor.PropertyType;

      selector.AddNode("(null)", null, null);

      ITypeDiscoveryService discoveryService = (ITypeDiscoveryService)context.GetService(typeof(ITypeDiscoveryService));
      ICollection inEditControlTypes = discoveryService.GetTypes(propType, false);

      foreach (Type t in inEditControlTypes)
      {
        //if (t == propType)
        //  continue;

        if (t.IsAbstract)
          continue;

        if (!t.IsPublic && !t.IsNestedPublic)
          continue;

        selector.AddNode(t.ToString(), t, null);
      }

      selector.ShowLines = true;
      selector.ExpandAll();
    }

    public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value)
    {
      object result = base.EditValue(context, provider, value);
      if ((result != prevValue) && ((result is Type) || (result == null)))
      {
        //if ((prevValue != null) && (prevValue is IComponent))
        //  ((IComponent)prevValue).Dispose();
        Type resultType = (Type)result;

        if (result != null)
        {
          if (resultType.IsSubclassOf(typeof(Component)))
          {
            Debug.Assert(context != null, @"context != null");
            IDesignerHost host = (IDesignerHost)context.GetService(typeof(IDesignerHost));
            result = host.CreateComponent(resultType);
          }
          else
          {
            result = Activator.CreateInstance(resultType);
          }
        }
      }
      return result;
    }

    public override void SetValue(object value)
    {
      base.SetValue(value);
    }
  }

  public class PrintServiceComponentEditor : ObjectSelectorEditorByType
  {
    public override UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context)
    {
      if (context == null)
        return base.GetEditStyle(context);

      object value = context.PropertyDescriptor.GetValue(context.Instance);
      if (value == null)
        return base.GetEditStyle(context);
      else
        return UITypeEditorEditStyle.Modal;
    }

    public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value)
    {
      if (GetEditStyle(context) == UITypeEditorEditStyle.Modal && value != null)
      {
        PageSetupDialog d = new PageSetupDialog();
        if (d.Execute((BasePrintServiceComponent)value))
        {
          IComponentChangeService desTimeChangeService = (IComponentChangeService)context.GetService(typeof(IComponentChangeService));
          desTimeChangeService.OnComponentChanged(context.Instance, null, null, null);
        }

        return value;
      }
      else
      {
        return base.EditValue(context, provider, value);
      }
    }

    public override void SetValue(object value)
    {
      base.SetValue(value);
    }
  }

}