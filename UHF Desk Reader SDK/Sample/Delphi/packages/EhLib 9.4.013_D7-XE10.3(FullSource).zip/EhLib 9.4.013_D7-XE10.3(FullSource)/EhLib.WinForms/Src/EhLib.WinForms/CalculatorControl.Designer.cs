﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

namespace EhLib.WinForms
{
  partial class CalculatorControl
  {
    /// <summary> 
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary> 
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Component Designer generated code

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.beBackSpace = new ButtonEh();
      this.beOk = new ButtonEh();
      this.bePlus = new ButtonEh();
      this.beDot = new ButtonEh();
      this.bePluMin = new ButtonEh();
      this.be0 = new ButtonEh();
      this.be1DivX = new ButtonEh();
      this.beMinus = new ButtonEh();
      this.be3 = new ButtonEh();
      this.be2 = new ButtonEh();
      this.be1 = new ButtonEh();
      this.bePercent = new ButtonEh();
      this.beMulti = new ButtonEh();
      this.be6 = new ButtonEh();
      this.be5 = new ButtonEh();
      this.be4 = new ButtonEh();
      this.beClear = new ButtonEh();
      this.beSqrt = new ButtonEh();
      this.beDiv = new ButtonEh();
      this.be9 = new ButtonEh();
      this.be8 = new ButtonEh();
      this.be7 = new ButtonEh();
      this.calculatorBox1 = new CalculatorBox();
      this.SuspendLayout();
      // 
      // beBackSpace
      // 
      this.beBackSpace.Focusable = false;
      this.beBackSpace.ForeColor = System.Drawing.Color.Red;
      this.beBackSpace.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.beBackSpace.Location = new System.Drawing.Point(194, 98);
      this.beBackSpace.Name = "beBackSpace";
      this.beBackSpace.Size = new System.Drawing.Size(34, 28);
      this.beBackSpace.TabIndex = 22;
      this.beBackSpace.Text = "<-";
      this.beBackSpace.UseVisualStyleBackColor = true;
      this.beBackSpace.Click += new System.EventHandler(this.Button_Click);
      // 
      // beOk
      // 
      this.beOk.Focusable = false;
      this.beOk.ForeColor = System.Drawing.Color.Red;
      this.beOk.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.beOk.Location = new System.Drawing.Point(156, 131);
      this.beOk.Name = "beOk";
      this.beOk.Size = new System.Drawing.Size(72, 28);
      this.beOk.TabIndex = 21;
      this.beOk.Text = "Ok";
      this.beOk.UseVisualStyleBackColor = true;
      this.beOk.Click += new System.EventHandler(this.Button_Click);
      // 
      // bePlus
      // 
      this.bePlus.Focusable = false;
      this.bePlus.ForeColor = System.Drawing.Color.Red;
      this.bePlus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.bePlus.Location = new System.Drawing.Point(118, 131);
      this.bePlus.Name = "bePlus";
      this.bePlus.Size = new System.Drawing.Size(34, 28);
      this.bePlus.TabIndex = 20;
      this.bePlus.Text = "+";
      this.bePlus.UseVisualStyleBackColor = true;
      this.bePlus.Click += new System.EventHandler(this.Button_Click);
      // 
      // beDot
      // 
      this.beDot.Focusable = false;
      this.beDot.ForeColor = System.Drawing.Color.Blue;
      this.beDot.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.beDot.Location = new System.Drawing.Point(80, 131);
      this.beDot.Name = "beDot";
      this.beDot.Size = new System.Drawing.Size(34, 28);
      this.beDot.TabIndex = 19;
      this.beDot.Text = ".";
      this.beDot.UseVisualStyleBackColor = true;
      this.beDot.Click += new System.EventHandler(this.Button_Click);
      // 
      // bePluMin
      // 
      this.bePluMin.Focusable = false;
      this.bePluMin.ForeColor = System.Drawing.Color.Blue;
      this.bePluMin.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.bePluMin.Location = new System.Drawing.Point(42, 131);
      this.bePluMin.Name = "bePluMin";
      this.bePluMin.Size = new System.Drawing.Size(34, 28);
      this.bePluMin.TabIndex = 18;
      this.bePluMin.Text = "+/-";
      this.bePluMin.UseVisualStyleBackColor = true;
      this.bePluMin.Click += new System.EventHandler(this.Button_Click);
      // 
      // be0
      // 
      this.be0.Focusable = false;
      this.be0.ForeColor = System.Drawing.Color.Blue;
      this.be0.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.be0.Location = new System.Drawing.Point(4, 131);
      this.be0.Name = "be0";
      this.be0.Size = new System.Drawing.Size(34, 28);
      this.be0.TabIndex = 17;
      this.be0.Text = "0";
      this.be0.UseVisualStyleBackColor = true;
      this.be0.Click += new System.EventHandler(this.Button_Click);
      // 
      // be1DivX
      // 
      this.be1DivX.Focusable = false;
      this.be1DivX.ForeColor = System.Drawing.Color.Blue;
      this.be1DivX.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.be1DivX.Location = new System.Drawing.Point(156, 98);
      this.be1DivX.Name = "be1DivX";
      this.be1DivX.Size = new System.Drawing.Size(34, 28);
      this.be1DivX.TabIndex = 16;
      this.be1DivX.Text = "1/x";
      this.be1DivX.UseVisualStyleBackColor = true;
      this.be1DivX.Click += new System.EventHandler(this.Button_Click);
      // 
      // beMinus
      // 
      this.beMinus.Focusable = false;
      this.beMinus.ForeColor = System.Drawing.Color.Red;
      this.beMinus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.beMinus.Location = new System.Drawing.Point(118, 98);
      this.beMinus.Name = "beMinus";
      this.beMinus.Size = new System.Drawing.Size(34, 28);
      this.beMinus.TabIndex = 15;
      this.beMinus.Text = "-";
      this.beMinus.UseVisualStyleBackColor = true;
      this.beMinus.Click += new System.EventHandler(this.Button_Click);
      // 
      // be3
      // 
      this.be3.Focusable = false;
      this.be3.ForeColor = System.Drawing.Color.Blue;
      this.be3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.be3.Location = new System.Drawing.Point(80, 98);
      this.be3.Name = "be3";
      this.be3.Size = new System.Drawing.Size(34, 28);
      this.be3.TabIndex = 14;
      this.be3.Text = "3";
      this.be3.UseVisualStyleBackColor = true;
      this.be3.Click += new System.EventHandler(this.Button_Click);
      // 
      // be2
      // 
      this.be2.Focusable = false;
      this.be2.ForeColor = System.Drawing.Color.Blue;
      this.be2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.be2.Location = new System.Drawing.Point(42, 98);
      this.be2.Name = "be2";
      this.be2.Size = new System.Drawing.Size(34, 28);
      this.be2.TabIndex = 13;
      this.be2.Text = "2";
      this.be2.UseVisualStyleBackColor = true;
      this.be2.Click += new System.EventHandler(this.Button_Click);
      // 
      // be1
      // 
      this.be1.Focusable = false;
      this.be1.ForeColor = System.Drawing.Color.Blue;
      this.be1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.be1.Location = new System.Drawing.Point(4, 98);
      this.be1.Name = "be1";
      this.be1.Size = new System.Drawing.Size(34, 28);
      this.be1.TabIndex = 12;
      this.be1.Text = "1";
      this.be1.UseVisualStyleBackColor = true;
      this.be1.Click += new System.EventHandler(this.Button_Click);
      // 
      // bePercent
      // 
      this.bePercent.Focusable = false;
      this.bePercent.ForeColor = System.Drawing.Color.Blue;
      this.bePercent.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.bePercent.Location = new System.Drawing.Point(156, 65);
      this.bePercent.Name = "bePercent";
      this.bePercent.Size = new System.Drawing.Size(34, 28);
      this.bePercent.TabIndex = 11;
      this.bePercent.Text = "%";
      this.bePercent.UseVisualStyleBackColor = true;
      this.bePercent.Click += new System.EventHandler(this.Button_Click);
      // 
      // beMulti
      // 
      this.beMulti.Focusable = false;
      this.beMulti.ForeColor = System.Drawing.Color.Red;
      this.beMulti.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.beMulti.Location = new System.Drawing.Point(118, 65);
      this.beMulti.Name = "beMulti";
      this.beMulti.Size = new System.Drawing.Size(34, 28);
      this.beMulti.TabIndex = 10;
      this.beMulti.Text = "*";
      this.beMulti.UseVisualStyleBackColor = true;
      this.beMulti.Click += new System.EventHandler(this.Button_Click);
      // 
      // be6
      // 
      this.be6.Focusable = false;
      this.be6.ForeColor = System.Drawing.Color.Blue;
      this.be6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.be6.Location = new System.Drawing.Point(80, 65);
      this.be6.Name = "be6";
      this.be6.Size = new System.Drawing.Size(34, 28);
      this.be6.TabIndex = 9;
      this.be6.Text = "6";
      this.be6.UseVisualStyleBackColor = true;
      this.be6.Click += new System.EventHandler(this.Button_Click);
      // 
      // be5
      // 
      this.be5.Focusable = false;
      this.be5.ForeColor = System.Drawing.Color.Blue;
      this.be5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.be5.Location = new System.Drawing.Point(42, 65);
      this.be5.Name = "be5";
      this.be5.Size = new System.Drawing.Size(34, 28);
      this.be5.TabIndex = 8;
      this.be5.Text = "5";
      this.be5.UseVisualStyleBackColor = true;
      this.be5.Click += new System.EventHandler(this.Button_Click);
      // 
      // be4
      // 
      this.be4.Focusable = false;
      this.be4.ForeColor = System.Drawing.Color.Blue;
      this.be4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.be4.Location = new System.Drawing.Point(4, 65);
      this.be4.Name = "be4";
      this.be4.Size = new System.Drawing.Size(34, 28);
      this.be4.TabIndex = 7;
      this.be4.Text = "4";
      this.be4.UseVisualStyleBackColor = true;
      this.be4.Click += new System.EventHandler(this.Button_Click);
      // 
      // beClear
      // 
      this.beClear.Focusable = false;
      this.beClear.ForeColor = System.Drawing.Color.Red;
      this.beClear.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.beClear.Location = new System.Drawing.Point(194, 33);
      this.beClear.Name = "beClear";
      this.beClear.Size = new System.Drawing.Size(34, 60);
      this.beClear.TabIndex = 6;
      this.beClear.Text = "C";
      this.beClear.UseVisualStyleBackColor = true;
      this.beClear.Click += new System.EventHandler(this.Button_Click);
      // 
      // beSqrt
      // 
      this.beSqrt.Focusable = false;
      this.beSqrt.ForeColor = System.Drawing.Color.Blue;
      this.beSqrt.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.beSqrt.Location = new System.Drawing.Point(156, 33);
      this.beSqrt.Name = "beSqrt";
      this.beSqrt.Size = new System.Drawing.Size(34, 28);
      this.beSqrt.TabIndex = 5;
      this.beSqrt.Text = "sqrt";
      this.beSqrt.UseVisualStyleBackColor = true;
      this.beSqrt.Click += new System.EventHandler(this.Button_Click);
      // 
      // beDiv
      // 
      this.beDiv.Focusable = false;
      this.beDiv.ForeColor = System.Drawing.Color.Red;
      this.beDiv.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.beDiv.Location = new System.Drawing.Point(118, 33);
      this.beDiv.Name = "beDiv";
      this.beDiv.Size = new System.Drawing.Size(34, 28);
      this.beDiv.TabIndex = 4;
      this.beDiv.Text = "/";
      this.beDiv.UseVisualStyleBackColor = true;
      this.beDiv.Click += new System.EventHandler(this.Button_Click);
      // 
      // be9
      // 
      this.be9.Focusable = false;
      this.be9.ForeColor = System.Drawing.Color.Blue;
      this.be9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.be9.Location = new System.Drawing.Point(80, 33);
      this.be9.Name = "be9";
      this.be9.Size = new System.Drawing.Size(34, 28);
      this.be9.TabIndex = 3;
      this.be9.Text = "9";
      this.be9.UseVisualStyleBackColor = true;
      this.be9.Click += new System.EventHandler(this.Button_Click);
      // 
      // be8
      // 
      this.be8.Focusable = false;
      this.be8.ForeColor = System.Drawing.Color.Blue;
      this.be8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.be8.Location = new System.Drawing.Point(42, 33);
      this.be8.Name = "be8";
      this.be8.Size = new System.Drawing.Size(34, 28);
      this.be8.TabIndex = 2;
      this.be8.Text = "8";
      this.be8.UseVisualStyleBackColor = true;
      this.be8.Click += new System.EventHandler(this.Button_Click);
      // 
      // be7
      // 
      this.be7.Focusable = false;
      this.be7.ForeColor = System.Drawing.Color.Blue;
      this.be7.ImeMode = System.Windows.Forms.ImeMode.NoControl;
      this.be7.Location = new System.Drawing.Point(4, 33);
      this.be7.Name = "be7";
      this.be7.Size = new System.Drawing.Size(34, 28);
      this.be7.TabIndex = 1;
      this.be7.Text = "7";
      this.be7.UseVisualStyleBackColor = true;
      this.be7.Click += new System.EventHandler(this.Button_Click);
      // 
      // calculatorBox1
      // 
      this.calculatorBox1.Location = new System.Drawing.Point(6, 2);
      this.calculatorBox1.Name = "calculatorBox1";
      this.calculatorBox1.Size = new System.Drawing.Size(219, 27);
      this.calculatorBox1.TabIndex = 0;
      this.calculatorBox1.Text = "calculatorBox1";
      this.calculatorBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CalculatorBox1_KeyDown);
      this.calculatorBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CalculatorBox1_KeyPress);
      // 
      // CalculatorControl
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.Controls.Add(this.beBackSpace);
      this.Controls.Add(this.beOk);
      this.Controls.Add(this.bePlus);
      this.Controls.Add(this.beDot);
      this.Controls.Add(this.bePluMin);
      this.Controls.Add(this.be0);
      this.Controls.Add(this.be1DivX);
      this.Controls.Add(this.beMinus);
      this.Controls.Add(this.be3);
      this.Controls.Add(this.be2);
      this.Controls.Add(this.be1);
      this.Controls.Add(this.bePercent);
      this.Controls.Add(this.beMulti);
      this.Controls.Add(this.be6);
      this.Controls.Add(this.be5);
      this.Controls.Add(this.be4);
      this.Controls.Add(this.beClear);
      this.Controls.Add(this.beSqrt);
      this.Controls.Add(this.beDiv);
      this.Controls.Add(this.be9);
      this.Controls.Add(this.be8);
      this.Controls.Add(this.be7);
      this.Controls.Add(this.calculatorBox1);
      this.Name = "CalculatorControl";
      this.Size = new System.Drawing.Size(231, 163);
      this.ResumeLayout(false);

    }

    #endregion

    private CalculatorBox calculatorBox1;
    private ButtonEh be7;
    private ButtonEh be8;
    private ButtonEh be9;
    private ButtonEh beDiv;
    private ButtonEh beSqrt;
    private ButtonEh beClear;
    private ButtonEh bePercent;
    private ButtonEh beMulti;
    private ButtonEh be6;
    private ButtonEh be5;
    private ButtonEh be4;
    private ButtonEh be1DivX;
    private ButtonEh beMinus;
    private ButtonEh be3;
    private ButtonEh be2;
    private ButtonEh be1;
    private ButtonEh beOk;
    private ButtonEh bePlus;
    private ButtonEh beDot;
    private ButtonEh bePluMin;
    private ButtonEh be0;
    private ButtonEh beBackSpace;
  }
}
