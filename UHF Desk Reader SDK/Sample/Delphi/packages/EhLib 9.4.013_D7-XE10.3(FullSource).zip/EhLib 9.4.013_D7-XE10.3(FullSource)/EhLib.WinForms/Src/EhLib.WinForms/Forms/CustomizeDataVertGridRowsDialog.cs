﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  public partial class CustomizeDataVertGridRowsDialog : BaseCustomizePropBarsDialog
  {

    public CustomizeDataVertGridRowsDialog()
    {
      InitializeComponent();

      VisiblePropBarsGrid.Title.Visible = false;
      label1.Text = @"Visible Rows";
      label2.Text = @"Hiden Rows";
      Text = @"Rows setup";
      this.toolTip1.SetToolTip(this.bShowSelected, "Show rows");
      this.toolTip1.SetToolTip(this.bHideSelected, "Hide rows");
    }

    public static bool ShowCustomizeRowsDialog(DataVertGridEh grid)
    {
      CustomizeDataVertGridRowsDialog dialog = new CustomizeDataVertGridRowsDialog();
      return dialog.ShowDialog(grid);
    }

    protected override void InitData()
    {
      base.InitData();
    }
  }
}
