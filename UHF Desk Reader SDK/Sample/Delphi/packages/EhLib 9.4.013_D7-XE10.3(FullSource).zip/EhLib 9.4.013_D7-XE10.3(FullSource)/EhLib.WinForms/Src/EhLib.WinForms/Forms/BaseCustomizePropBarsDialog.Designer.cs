﻿namespace EhLib.WinForms
{
  partial class BaseCustomizePropBarsDialog
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BaseCustomizePropBarsDialog));
      this.bOk = new System.Windows.Forms.Button();
      this.bCancel = new System.Windows.Forms.Button();
      this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
      this.visiblePropBarsGrid = new EhLib.WinForms.DataGridEh();
      this.bsVisiblePropBars = new System.Windows.Forms.BindingSource(this.components);
      this.visGridNameColumn = new EhLib.WinForms.DataGridTextColumn();
      this.panel1 = new System.Windows.Forms.Panel();
      this.bSetWidth = new System.Windows.Forms.Button();
      this.imageList1 = new System.Windows.Forms.ImageList(this.components);
      this.bMoveDown = new System.Windows.Forms.Button();
      this.bMoveUp = new System.Windows.Forms.Button();
      this.bShowSelected = new System.Windows.Forms.Button();
      this.bHideSelected = new System.Windows.Forms.Button();
      this.hiddenPropBarsGrid = new EhLib.WinForms.DataGridEh();
      this.bsHiddenPropBars = new System.Windows.Forms.BindingSource(this.components);
      this.hidGridNameColumn = new EhLib.WinForms.DataGridTextColumn();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
      this.tableLayoutPanel1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.visiblePropBarsGrid)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bsVisiblePropBars)).BeginInit();
      this.panel1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.hiddenPropBarsGrid)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bsHiddenPropBars)).BeginInit();
      this.SuspendLayout();
      // 
      // bOk
      // 
      this.bOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.bOk.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.bOk.Location = new System.Drawing.Point(307, 421);
      this.bOk.Name = "bOk";
      this.bOk.Size = new System.Drawing.Size(78, 22);
      this.bOk.TabIndex = 8;
      this.bOk.Text = "OK";
      // 
      // bCancel
      // 
      this.bCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.bCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.bCancel.Location = new System.Drawing.Point(393, 421);
      this.bCancel.Name = "bCancel";
      this.bCancel.Size = new System.Drawing.Size(78, 22);
      this.bCancel.TabIndex = 9;
      this.bCancel.Text = "Cancel";
      // 
      // tableLayoutPanel1
      // 
      this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.tableLayoutPanel1.ColumnCount = 3;
      this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
      this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
      this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
      this.tableLayoutPanel1.Controls.Add(this.visiblePropBarsGrid, 0, 1);
      this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 1);
      this.tableLayoutPanel1.Controls.Add(this.hiddenPropBarsGrid, 2, 1);
      this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
      this.tableLayoutPanel1.Controls.Add(this.label2, 2, 0);
      this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
      this.tableLayoutPanel1.Name = "tableLayoutPanel1";
      this.tableLayoutPanel1.RowCount = 2;
      this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
      this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
      this.tableLayoutPanel1.Size = new System.Drawing.Size(459, 394);
      this.tableLayoutPanel1.TabIndex = 12;
      // 
      // visiblePropBarsGrid
      // 
      this.visiblePropBarsGrid.AutoSizeColumnOptions.FitToClient = true;
      this.visiblePropBarsGrid.DataSource = this.bsVisiblePropBars;
      this.visiblePropBarsGrid.Dock = System.Windows.Forms.DockStyle.Fill;
      // 
      // 
      // 
      this.visiblePropBarsGrid.EmptyDataInfo.Text = null;
      // 
      // 
      // 
      this.visiblePropBarsGrid.IndicatorColumn.ShowRowIndicator = false;
      this.visiblePropBarsGrid.IndicatorColumn.Visible = false;
      this.visiblePropBarsGrid.Location = new System.Drawing.Point(3, 27);
      this.visiblePropBarsGrid.Name = "visibleColumnsGrid";
      this.visiblePropBarsGrid.ReadOnly = true;
      // 
      // 
      // 
      this.visiblePropBarsGrid.SearchBox.Enabled = true;
      this.visiblePropBarsGrid.SearchBox.FilterOnTyping = true;
      this.visiblePropBarsGrid.SearchBox.VisibleButtons.FindNext = false;
      this.visiblePropBarsGrid.SearchBox.VisibleButtons.FindPrior = false;
      this.visiblePropBarsGrid.SearchBox.VisibleButtons.OptionsPopupMenu = false;
      this.visiblePropBarsGrid.Selection.RowSelect = true;
      this.visiblePropBarsGrid.Size = new System.Drawing.Size(193, 364);
      this.visiblePropBarsGrid.StaticColumns.AddRange(new EhLib.WinForms.PropertyAxisBar[] {
            this.visGridNameColumn});
      this.visiblePropBarsGrid.TabIndex = 13;
      // 
      // visGridNameColumn
      // 
      this.visGridNameColumn.DataPropertyName = "Name";
      this.visGridNameColumn.FillWeight = 190F;
      this.visGridNameColumn.Name = "visGridNameColumn";
      // 
      // 
      // 
      this.visGridNameColumn.Title.Text = "Name";
      this.visGridNameColumn.Title.ToolTipText = null;
      this.visGridNameColumn.Width = 190;
      this.visGridNameColumn.DataCellMouseDoubleClick += new System.EventHandler<EhLib.WinForms.DataGridDataCellMouseEventArgs>(this.VisGridNameColumn_DataCellMouseDoubleClick);
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.bSetWidth);
      this.panel1.Controls.Add(this.bMoveDown);
      this.panel1.Controls.Add(this.bMoveUp);
      this.panel1.Controls.Add(this.bShowSelected);
      this.panel1.Controls.Add(this.bHideSelected);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panel1.Location = new System.Drawing.Point(202, 27);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(54, 364);
      this.panel1.TabIndex = 3;
      // 
      // bSetWidth
      // 
      this.bSetWidth.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.bSetWidth.ImageKey = "SetWidth.png";
      this.bSetWidth.ImageList = this.imageList1;
      this.bSetWidth.Location = new System.Drawing.Point(3, 65);
      this.bSetWidth.Name = "bSetWidth";
      this.bSetWidth.Size = new System.Drawing.Size(28, 23);
      this.bSetWidth.TabIndex = 4;
      this.toolTip1.SetToolTip(this.bSetWidth, "Set Width");
      this.bSetWidth.UseVisualStyleBackColor = true;
      this.bSetWidth.Click += new System.EventHandler(this.SetWidth_Click);
      // 
      // imageList1
      // 
      this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
      this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
      this.imageList1.Images.SetKeyName(0, "TriangleUp-16x16.png");
      this.imageList1.Images.SetKeyName(1, "TriangleRight-16x16.png");
      this.imageList1.Images.SetKeyName(2, "TriangleDown-16x16.png");
      this.imageList1.Images.SetKeyName(3, "TriangleLeft-16x16.png");
      this.imageList1.Images.SetKeyName(4, "SetWidth.png");
      // 
      // bMoveDown
      // 
      this.bMoveDown.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.bMoveDown.ImageKey = "TriangleDown-16x16.png";
      this.bMoveDown.ImageList = this.imageList1;
      this.bMoveDown.Location = new System.Drawing.Point(3, 140);
      this.bMoveDown.Name = "bMoveDown";
      this.bMoveDown.Size = new System.Drawing.Size(28, 23);
      this.bMoveDown.TabIndex = 3;
      this.toolTip1.SetToolTip(this.bMoveDown, "Move Down");
      this.bMoveDown.UseVisualStyleBackColor = true;
      this.bMoveDown.Click += new System.EventHandler(this.MoveDown_Click);
      // 
      // bMoveUp
      // 
      this.bMoveUp.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.bMoveUp.ImageKey = "TriangleUp-16x16.png";
      this.bMoveUp.ImageList = this.imageList1;
      this.bMoveUp.Location = new System.Drawing.Point(3, 111);
      this.bMoveUp.Name = "bMoveUp";
      this.bMoveUp.Size = new System.Drawing.Size(28, 23);
      this.bMoveUp.TabIndex = 2;
      this.toolTip1.SetToolTip(this.bMoveUp, "Move Up");
      this.bMoveUp.UseVisualStyleBackColor = true;
      this.bMoveUp.Click += new System.EventHandler(this.MoveUp_Click);
      // 
      // bShowSelected
      // 
      this.bShowSelected.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.bShowSelected.ImageKey = "TriangleLeft-16x16.png";
      this.bShowSelected.ImageList = this.imageList1;
      this.bShowSelected.Location = new System.Drawing.Point(3, 210);
      this.bShowSelected.Name = "bShowSelected";
      this.bShowSelected.Size = new System.Drawing.Size(48, 23);
      this.bShowSelected.TabIndex = 1;
      this.toolTip1.SetToolTip(this.bShowSelected, "Show columns");
      this.bShowSelected.UseVisualStyleBackColor = true;
      this.bShowSelected.Click += new System.EventHandler(this.ShowSelected_Click);
      // 
      // bHideSelected
      // 
      this.bHideSelected.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.bHideSelected.ImageKey = "TriangleRight-16x16.png";
      this.bHideSelected.ImageList = this.imageList1;
      this.bHideSelected.Location = new System.Drawing.Point(3, 181);
      this.bHideSelected.Name = "bHideSelected";
      this.bHideSelected.Size = new System.Drawing.Size(48, 23);
      this.bHideSelected.TabIndex = 0;
      this.toolTip1.SetToolTip(this.bHideSelected, "Hide columns");
      this.bHideSelected.UseVisualStyleBackColor = true;
      this.bHideSelected.Click += new System.EventHandler(this.HideSelected_Click);
      // 
      // hiddenPropBarsGrid
      // 
      this.hiddenPropBarsGrid.AutoSizeColumnOptions.FitToClient = true;
      this.hiddenPropBarsGrid.DataSource = this.bsHiddenPropBars;
      this.hiddenPropBarsGrid.Dock = System.Windows.Forms.DockStyle.Fill;
      // 
      // 
      // 
      this.hiddenPropBarsGrid.EmptyDataInfo.Text = null;
      // 
      // 
      // 
      this.hiddenPropBarsGrid.IndicatorColumn.ShowRowIndicator = false;
      this.hiddenPropBarsGrid.IndicatorColumn.Visible = false;
      this.hiddenPropBarsGrid.Location = new System.Drawing.Point(262, 27);
      this.hiddenPropBarsGrid.Name = "hiddenColumnsGrid";
      this.hiddenPropBarsGrid.ReadOnly = true;
      // 
      // 
      // 
      this.hiddenPropBarsGrid.SearchBox.Enabled = true;
      this.hiddenPropBarsGrid.SearchBox.FilterOnTyping = true;
      this.hiddenPropBarsGrid.SearchBox.VisibleButtons.FindNext = false;
      this.hiddenPropBarsGrid.SearchBox.VisibleButtons.FindPrior = false;
      this.hiddenPropBarsGrid.SearchBox.VisibleButtons.OptionsPopupMenu = false;
      this.hiddenPropBarsGrid.Selection.RowSelect = true;
      this.hiddenPropBarsGrid.Size = new System.Drawing.Size(194, 364);
      this.hiddenPropBarsGrid.StaticColumns.AddRange(new EhLib.WinForms.PropertyAxisBar[] {
            this.hidGridNameColumn});
      this.hiddenPropBarsGrid.TabIndex = 1;
      // 
      // 
      // 
      this.hiddenPropBarsGrid.Title.Visible = false;
      // 
      // hidGridNameColumn
      // 
      this.hidGridNameColumn.DataPropertyName = "Name";
      this.hidGridNameColumn.FillWeight = 191F;
      this.hidGridNameColumn.Name = "hidGridNameColumn";
      // 
      // 
      // 
      this.hidGridNameColumn.Title.Text = "Name";
      this.hidGridNameColumn.Title.ToolTipText = null;
      this.hidGridNameColumn.Width = 191;
      this.hidGridNameColumn.DataCellMouseDoubleClick += new System.EventHandler<EhLib.WinForms.DataGridDataCellMouseEventArgs>(this.HidGridNameColumn_DataCellMouseDoubleClick);
      // 
      // label1
      // 
      this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.label1.Location = new System.Drawing.Point(3, 0);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(193, 24);
      this.label1.TabIndex = 14;
      this.label1.Text = "Visible Columns";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // label2
      // 
      this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.label2.Location = new System.Drawing.Point(262, 0);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(194, 24);
      this.label2.TabIndex = 15;
      this.label2.Text = "Hidden Columns";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // BaseCustomizePropBarsDialog
      // 
      this.AcceptButton = this.bOk;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.CancelButton = this.bCancel;
      this.ClientSize = new System.Drawing.Size(480, 454);
      this.Controls.Add(this.tableLayoutPanel1);
      this.Controls.Add(this.bOk);
      this.Controls.Add(this.bCancel);
      this.Name = "BaseCustomizePropBarsDialog";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Columns setup";
      this.tableLayoutPanel1.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.visiblePropBarsGrid)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bsVisiblePropBars)).EndInit();
      this.panel1.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.hiddenPropBarsGrid)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bsHiddenPropBars)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    public System.Windows.Forms.Button bOk;
    public System.Windows.Forms.Button bCancel;
    protected System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    protected System.Windows.Forms.Panel panel1;
    protected System.Windows.Forms.Button bShowSelected;
    protected System.Windows.Forms.Button bHideSelected;
    protected System.Windows.Forms.Label label1;
    protected System.Windows.Forms.Label label2;
    protected System.Windows.Forms.Button bMoveUp;
    protected System.Windows.Forms.Button bMoveDown;
    protected System.Windows.Forms.ImageList imageList1;
    protected System.Windows.Forms.ToolTip toolTip1;
    protected System.Windows.Forms.Button bSetWidth;
    private DataGridEh hiddenPropBarsGrid;
    private DataGridEh visiblePropBarsGrid;
    private DataGridTextColumn visGridNameColumn;
    private DataGridTextColumn hidGridNameColumn;
    private System.Windows.Forms.BindingSource bsVisiblePropBars;
    private System.Windows.Forms.BindingSource bsHiddenPropBars;
  }
}