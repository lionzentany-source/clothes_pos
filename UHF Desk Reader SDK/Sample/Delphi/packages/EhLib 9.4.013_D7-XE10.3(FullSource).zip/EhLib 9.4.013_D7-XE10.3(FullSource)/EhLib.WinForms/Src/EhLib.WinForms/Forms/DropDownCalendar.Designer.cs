﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

namespace EhLib.WinForms
{
  partial class DropDownCalendar
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
      this.SuspendLayout();
      // 
      // monthCalendar1
      // 
      this.monthCalendar1.Location = new System.Drawing.Point(0, 0);
      this.monthCalendar1.MaxSelectionCount = 1;
      this.monthCalendar1.Name = "monthCalendar1";
      this.monthCalendar1.TabIndex = 2;
      // 
      // DropDownCalendar
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.ClientSize = new System.Drawing.Size(284, 262);
      this.Controls.Add(this.monthCalendar1);
      this.KeyPreview = true;
      this.Name = "DropDownCalendar";
      this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DropDownCalendar_KeyDown);
      this.Controls.SetChildIndex(this.monthCalendar1, 0);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.MonthCalendar monthCalendar1;
  }
}
