﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of row in a DataVertGridEh control that displays a combo box user interface (UI).
  /// </summary>
  [DataVertGridRowDesignTimeVisible(true)]
  public class DataVertGridComboBoxRow : DataVertGridRow, IComboBoxDataCellHolder
  {
    #region private consts
    private static readonly object EventKeyCustomAreaPaint = new object();
    #endregion

    public DataVertGridComboBoxRow()
    {

    }

    #region design-time properties
    [DefaultValue(ComboBoxCompound.TextEditor)]
    public ComboBoxCompound Compound
    {
      get
      {
        return DataCell.Compound;
      }
      set
      {
        DataCell.Compound = value;
      }
    }

    [AttributeProvider(typeof(IListSource))]
    [DefaultValue(null)]
    [RefreshProperties(RefreshProperties.Repaint)]
    [Category("Data")]
    //[Description("DataGridView_ComboBoxColumnDataSourceDescr")]
    public object DataSource
    {
      get
      {
        return DataCell.DataSource;
      }
      set
      {
        DataCell.DataSource = value;
      }
    }

    [DefaultValue("")]
    [TypeConverter("System.Windows.Forms.Design.DataMemberFieldConverter")]
    [Editor("System.Windows.Forms.Design.DataMemberFieldEditor", typeof(UITypeEditor))]
    [Category("Data")]
    //[Description("DataGridView_ComboBoxColumnDisplayMemberDescr")]
    public string DisplayMember
    {
      get
      {
        return DataCell.DisplayMember;
      }
      set
      {
        DataCell.DisplayMember = value;
      }
    }

    [DefaultValue("")]
    [Editor("System.Windows.Forms.Design.DataMemberFieldEditor", typeof(UITypeEditor))]
    [TypeConverter("System.Windows.Forms.Design.DataMemberFieldConverter")]
    [Category("Data")]
    //[Description("DataGridView_ComboBoxColumnValueMemberDescr")]
    public string ValueMember
    {
      get
      {
        return DataCell.ValueMember;
      }
      set
      {
        DataCell.ValueMember = value;
      }
    }

    [Editor("System.Windows.Forms.Design.StringCollectionEditor", typeof(System.Drawing.Design.UITypeEditor))]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public ObjectCollection Items
    {
      get
      {
        return DataCell.Items;
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public new EditButton EditButton
    {
      get
      {
        return base.EditButton;
      }

      set
      {
        base.EditButton = value;
      }
    }

    [DefaultValue(16)]
    public int CustomAreaWidth
    {
      get
      {
        return DataCell.CustomAreaWidth;
      }
      set
      {
        DataCell.CustomAreaWidth = value;
      }
    }

    public new bool AllowShowEditor
    {
      get { return base.AllowShowEditor; }
      set { base.AllowShowEditor = value; }
    }
    #endregion

    #region runtime Properties
    [Browsable(false)]
    public new ComboBoxDataCellManager DataCell
    {
      get { return base.InternalCellManager as ComboBoxDataCellManager; }
    }

    public bool LookupMode
    {
      get
      {
        return DataCell.LookupMode;
      }
    }
    #endregion

    #region events
    public event EventHandler<ComboBoxCustomAreaPaintEventArgs> CustomAreaPaint
    {
      add
      {
        Events.AddHandler(EventKeyCustomAreaPaint, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyCustomAreaPaint, value);
      }
    }
    #endregion events

    #region methods
    protected override BaseDataCellManager CreateTemplateCell()
    {
      return new ComboBoxDataCellManager();
    }

    void IComboBoxDataCellHolder.OnCustomAreaPaint(ComboBoxCustomAreaPaintEventArgs e)
    {
      OnCustomAreaPaint(e);
    }

    void IComboBoxDataCellHolder.DataListChanged(object sender, ListChangedEventArgs e)
    {

    }

    void IComboBoxDataCellHolder.CellManagerLookupModeChanged()
    {

    }

    protected virtual void OnCustomAreaPaint(ComboBoxCustomAreaPaintEventArgs e)
    {
      var handler = Events[EventKeyCustomAreaPaint] as EventHandler<ComboBoxCustomAreaPaintEventArgs>;
      if (handler != null)
      {
        handler(this, e);
      }
      if (!e.Handled)
      {
        using (Pen pen = new Pen(ForeColor))
        {
          Rectangle drawRect = e.AreaRect;
          e.Graphics.FillRectangle(new SolidBrush(BackColor), e.AreaRect);
          drawRect.Inflate(-1, -1);
          Rectangle frameRect = drawRect;
          frameRect.Width = frameRect.Width - 1;
          frameRect.Height = frameRect.Height - 1;
          e.Graphics.DrawRectangle(pen, frameRect);
          e.Graphics.DrawLine(pen, frameRect.Location, new Point(frameRect.Right, frameRect.Bottom));
          e.Graphics.DrawLine(pen, new Point(frameRect.Left, frameRect.Bottom), new Point(frameRect.Right, frameRect.Top));
        }
      }
    }

    //protected internal virtual void ValueMemberPropertyChanged()
    //{
    //  UpdateDefaultPadding();
    //}
    #endregion methods

  }

}
