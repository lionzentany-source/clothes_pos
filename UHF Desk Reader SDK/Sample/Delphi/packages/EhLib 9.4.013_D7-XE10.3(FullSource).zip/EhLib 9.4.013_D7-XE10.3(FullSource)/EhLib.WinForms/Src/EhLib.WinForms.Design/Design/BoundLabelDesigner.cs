﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Diagnostics;
using System.Windows.Forms.Design;

namespace EhLib.WinForms.Design
{
  public class BoundLabelEditor : ObjectSelectorEditor
  {
    protected override void FillTreeWithData(Selector selector,
            ITypeDescriptorContext context, IServiceProvider provider)
    {
      base.FillTreeWithData(selector, context, provider);

      selector.AddNode("(null)", null, null);

      ITypeDiscoveryService discoveryService = (ITypeDiscoveryService)context.GetService(typeof(ITypeDiscoveryService));
      ICollection inEditControlTypes = discoveryService.GetTypes(typeof(BoundLabel), false);

      foreach (Type t in inEditControlTypes)
      {
        //if (t == typeof(BoundLabel))
        //  continue;

        if (t.IsAbstract)
          continue;

        if (!t.IsPublic && !t.IsNestedPublic)
          continue;

        selector.AddNode(t.ToString(), t, null);
      }

      selector.ShowLines = true;
      selector.ExpandAll();
    }

    public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value)
    {
      object result = base.EditValue(context, provider, value);

      if ((result != prevValue) && ((result is Type) || (result == null)))
      {
        if ((prevValue != null) && (prevValue is IComponent))
          ((IComponent)prevValue).Dispose();
        Type resultType = (Type)result;
        if (result != null)
        {
          Debug.Assert(context != null, @"context != null");
          IDesignerHost host = (IDesignerHost)context.GetService(typeof(IDesignerHost));
          result = (BoundLabel)host.CreateComponent(resultType);
        }
      }

      return result;
    }

  }

  public class BoundLabelDesigner : ControlDesigner
  {

    public override SelectionRules SelectionRules
    {
      get
      {
        return SelectionRules.Locked;
      }
    }

  }
}
