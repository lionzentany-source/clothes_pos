﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of row in a DataVertGridEh control that displays a DateTime picker user interface (UI).
  /// </summary>
  [DataVertGridRowDesignTimeVisible(true)]
  public class DataVertGridDateTimeRow : DataVertGridRow
  {
    public DataVertGridDateTimeRow()
    {

    }

    #region Properties
    [Browsable(false)]
    public new DateTimeDataCellManager DataCell
    {
      get { return (DateTimeDataCellManager)base.InternalCellManager; }
    }

    [DefaultValue("d")]
    public string DateFormatString
    {
      get { return DataCell.DateFormatString; }
      set { DataCell.DateFormatString = value; }
    }

    [DefaultValue("t")]
    public string TimeFormatString
    {
      get { return DataCell.TimeFormatString; }
      set { DataCell.TimeFormatString = value; }
    }

    [DefaultValue(true)]
    public bool HideTimeWhenZero
    {
      get { return DataCell.HideTimeWhenZero; }
      set { DataCell.HideTimeWhenZero = value; }
    }

    [DefaultValue(" ")]
    public string DateTimePartSeparator
    {
      get { return DataCell.DateTimePartSeparator; }
      set { DataCell.DateTimePartSeparator = value; }
    }

    public new bool AllowShowEditor
    {
      get { return base.AllowShowEditor; }
      set { base.AllowShowEditor = value; }
    }
    #endregion

    #region methods
    protected override BaseDataCellManager CreateTemplateCell()
    {
      return new DateTimeDataCellManager();
    }
    #endregion

  }

}
