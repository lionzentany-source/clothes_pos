﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{
  //public enum TreeNodeState
  //{
  //  Expanded,
  //  Collapsed
  //}

  abstract public class TreeNodeStateRenderer
  {
    abstract public Size GetNodeStateGlyphSize(Graphics graphics, bool isExpanded);

    abstract public void DrawNodeStateGlyph(Graphics graphics, Rectangle bounds, bool isExpanded, bool isHot);
  }

  public class ExplorerStyleTreeNodeStateRenderer : StandardTreeNodeStateRenderer
  {
    VisualStyleRenderer OpenedRenderer = new VisualStyleRenderer("Explorer::TreeView", 2, 2);
    VisualStyleRenderer ClosedRenderer = new VisualStyleRenderer("Explorer::TreeView", 2, 1);

    public override Size GetNodeStateGlyphSize(Graphics graphics, bool isExpanded)
    {
      if (Application.RenderWithVisualStyles && OpenedRenderer != null && ClosedRenderer != null)
      {
        VisualStyleRenderer renderer = new VisualStyleRenderer(VisualStyleElement.TreeView.Glyph.Opened);
        if (isExpanded)
          renderer = OpenedRenderer;
        else
          renderer = ClosedRenderer;

        Size result = renderer.GetPartSize(graphics, ThemeSizeType.Draw);
        return result;
      }
      else
      {
        return base.GetNodeStateGlyphSize(graphics, isExpanded);
      }
    }

    public override void DrawNodeStateGlyph(Graphics graphics, Rectangle bounds, bool isExpanded, bool isHot)
    {
      if (Application.RenderWithVisualStyles && OpenedRenderer != null && ClosedRenderer != null)
      {
        VisualStyleRenderer renderer;

        if (isExpanded)
          renderer = OpenedRenderer;
        else
          renderer = ClosedRenderer;

        renderer.DrawBackground(graphics, bounds);
      }
      else
      {
        base.DrawNodeStateGlyph(graphics, bounds, isExpanded, isHot);
      }
    }
  }

  public class FlatTriangleTreeNodeStateRenderer : TreeNodeStateRenderer
  {
    public override Size GetNodeStateGlyphSize(Graphics graphics, bool isExpanded)
    {
      return new Size(12, 12);
    }

    public override void DrawNodeStateGlyph(Graphics graphics, Rectangle bounds, bool isExpanded, bool isHot)
    {
      Image treeImage;
      if (isExpanded)
        treeImage = Properties.Resources.ExpandedTriangle;
      else
        treeImage = Properties.Resources.CollapsedTriangle;

      Rectangle imageArea = new Rectangle(Point.Empty, treeImage.Size);
      imageArea = EhLibUtils.RectCenter(imageArea, bounds);
      imageArea.X = imageArea.Left + 2;

      graphics.DrawImage(treeImage, imageArea);
    }
  }

  public class ClassicTreeNodeStateRenderer : TreeNodeStateRenderer
  {
    public override Size GetNodeStateGlyphSize(Graphics graphics, bool isExpanded)
    {
      return new Size(9, 9);
    }

    public override void DrawNodeStateGlyph(Graphics graphics, Rectangle bounds, bool isExpanded, bool isHot)
    {

      Rectangle signRect = new Rectangle(Point.Empty, GetNodeStateGlyphSize(graphics, isExpanded));
      signRect.Width -= 1;
      signRect.Height -= 1;
      signRect = EhLibUtils.RectCenter(signRect, bounds);

      graphics.DrawRectangle(new Pen(SystemColors.ButtonShadow), signRect);

      using (Pen linePen = new Pen(SystemColors.WindowText))
      {
        Rectangle crossRect = EhLib.WinForms.EhLibUtils.ChangeRectangle(signRect, +2, +2, -4, -4);
        graphics.DrawLine(linePen, new Point(crossRect.Left, (crossRect.Top + crossRect.Bottom) / 2), 
                                   new Point(crossRect.Right, (crossRect.Top + crossRect.Bottom) / 2));
        if (!isExpanded)
        {
          graphics.DrawLine(linePen, new Point((crossRect.Left + crossRect.Right) / 2, crossRect.Top), 
                                     new Point((crossRect.Left + crossRect.Right) / 2, crossRect.Bottom));
        }
      }
    }
  }

  public class StandardTreeNodeStateRenderer : ClassicTreeNodeStateRenderer
  {
    public override Size GetNodeStateGlyphSize(Graphics graphics, bool isExpanded)
    {
      if (Application.RenderWithVisualStyles)
      {
        VisualStyleRenderer renderer = new VisualStyleRenderer(VisualStyleElement.TreeView.Glyph.Opened);
        if (isExpanded)
          renderer = new VisualStyleRenderer(VisualStyleElement.TreeView.Glyph.Opened);
        else
          renderer = new VisualStyleRenderer(VisualStyleElement.TreeView.Glyph.Closed);

        Size result = renderer.GetPartSize(graphics, ThemeSizeType.Draw);
        return result;
      }
      else
      {
        return base.GetNodeStateGlyphSize(graphics, isExpanded);
      }
    }

    public override void DrawNodeStateGlyph(Graphics graphics, Rectangle bounds, bool isExpanded, bool isHot)
    {
      if (Application.RenderWithVisualStyles)
      {
        VisualStyleRenderer renderer;

        if (isExpanded)
          renderer = new VisualStyleRenderer(VisualStyleElement.TreeView.Glyph.Opened);
        else
          renderer = new VisualStyleRenderer(VisualStyleElement.TreeView.Glyph.Closed);

        renderer.DrawBackground(graphics, bounds);
      }
      else
      {
        base.DrawNodeStateGlyph(graphics, bounds, isExpanded, isHot);
      }
    }
  }

}
