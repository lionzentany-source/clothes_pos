﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of column in a DataGridEh control that displays masked text box user interface (UI).
  /// </summary>
  [DataGridColumnDesignTimeVisible(true)]
  public class DataGridMaskedTextColumn : DataGridColumn
  {
    public DataGridMaskedTextColumn()
    {

    }

    #region Properties
    [Browsable(false)]
    public new MaskedTextDataCellManager DataCell
    {
      get { return (MaskedTextDataCellManager)base.InternalCellManager; }
    }

    [
    RefreshProperties(RefreshProperties.Repaint),
    DefaultValue(""),
    MergableProperty(false),
    Localizable(true),
    Editor("EhLib.WinForms.Design.MaskPropertyEditor", typeof(UITypeEditor))
    ]
    public string Mask
    {
      get { return DataCell.Mask; }
      set { DataCell.Mask = value; }
    }

    [
    RefreshProperties(RefreshProperties.Repaint),
    DefaultValue('\0') // This property is shadowed by MaskedTextBoxDesigner.
    ]
    public char PasswordChar
    {
      get { return DataCell.PasswordChar; }
      set { DataCell.PasswordChar = value; }
    }


    [DefaultValue(false)]
    [RefreshProperties(RefreshProperties.Repaint)]
    public new bool UseSystemPasswordChar
    {
      get { return DataCell.UseSystemPasswordChar; }
      set { DataCell.UseSystemPasswordChar = value; }
    }

    [
    RefreshProperties(RefreshProperties.Repaint),
    Localizable(true),
    DefaultValue('_')
    ]
    public char PromptChar
    {
      get { return DataCell.PromptChar; }
      set { DataCell.PromptChar = value; }
    }

    [
    RefreshProperties(RefreshProperties.Repaint),
    DefaultValue(MaskFormat.IncludeLiterals)
    ]
    public MaskFormat TextMaskFormat
    {
      get { return DataCell.TextMaskFormat; }
      set { DataCell.TextMaskFormat = value; }
    }

    [
    DefaultValue(InsertKeyMode.Default)
    ]
    public InsertKeyMode InsertKeyMode
    {
      get { return DataCell.InsertKeyMode; }
      set { DataCell.InsertKeyMode = value; }
    }

    [
    RefreshProperties(RefreshProperties.Repaint),
    DefaultValue(MaskFormat.IncludeLiterals)
    ]
    public MaskFormat CutCopyMaskFormat
    {
      get { return DataCell.CutCopyMaskFormat; }
      set { DataCell.CutCopyMaskFormat = value; }
    }

    [
    DefaultValue(true)
    ]
    public bool AllowPromptAsInput
    {
      get { return DataCell.AllowPromptAsInput; }
      set { DataCell.AllowPromptAsInput = value; }
    }

    [
    DefaultValue(false)
    ]
    public bool BeepOnError
    {
      get { return DataCell.BeepOnError; }
      set { DataCell.BeepOnError = value; }
    }

    [
    DefaultValue(true)
    ]
    public bool SkipLiterals
    {
      get { return DataCell.SkipLiterals; }
      set { DataCell.SkipLiterals = value; }
    }

    [
    DefaultValue(true)
    ]
    public bool ResetOnPrompt
    {
      get { return DataCell.ResetOnPrompt; }
      set { DataCell.ResetOnPrompt = value; }
    }

    [
    DefaultValue(true)
    ]
    public bool ResetOnSpace
    {
      get { return DataCell.ResetOnSpace; }
      set { DataCell.ResetOnSpace = value; }
    }

    [
    DefaultValue(false)
    ]
    public bool RejectInputOnFirstFailure
    {
      get { return DataCell.RejectInputOnFirstFailure; }
      set { DataCell.RejectInputOnFirstFailure = value; }
    }

    [
    RefreshProperties(RefreshProperties.Repaint),
    ]
    public CultureInfo Culture
    {
      get { return DataCell.Culture; }
      set { DataCell.Culture = value; }
    }

    public new bool AllowShowEditor
    {
      get { return base.AllowShowEditor; }
      set { base.AllowShowEditor = value; }
    }
    #endregion

    #region methods
    protected override BaseDataCellManager CreateTemplateCell()
    {
      return new MaskedTextDataCellManager();
    }
    #endregion

  }

}
