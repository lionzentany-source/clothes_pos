//------------------------------------------------------------------------------
// <copyright file=�*.cs� company=�EhLib Team�>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

namespace EhLib.WinForms
{
  partial class DataGridSimpleFilterDialog
  {
    public System.Windows.Forms.Label labelShowRecordsWhere;
    public System.Windows.Forms.Control Bevel1;
    public System.Windows.Forms.Label labelUseUnderscore;
    public System.Windows.Forms.Label labelUseAsterisk;
    public System.Windows.Forms.ComboBox ComboBox2;
    public System.Windows.Forms.ComboBox ComboBox1;
    public System.Windows.Forms.TextBox Edit2;
    public System.Windows.Forms.TextBox Edit1;
    public System.Windows.Forms.RadioButton rbOr;
    public System.Windows.Forms.RadioButton rbAnd;
    public System.Windows.Forms.Button bOk;
    public System.Windows.Forms.Button bCancel;
    public System.Windows.Forms.ComboBox DBComboBoxEh1;
    public System.Windows.Forms.ComboBox DBComboBoxEh2;

    // Clean up any resources being used.
    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        if (components != null)
        {
          components.Dispose();
        }
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code
    private void InitializeComponent()
    {
      this.labelShowRecordsWhere = new System.Windows.Forms.Label();
      this.Bevel1 = new System.Windows.Forms.Control();
      this.labelUseUnderscore = new System.Windows.Forms.Label();
      this.labelUseAsterisk = new System.Windows.Forms.Label();
      this.ComboBox2 = new System.Windows.Forms.ComboBox();
      this.ComboBox1 = new System.Windows.Forms.ComboBox();
      this.Edit2 = new System.Windows.Forms.TextBox();
      this.Edit1 = new System.Windows.Forms.TextBox();
      this.rbOr = new System.Windows.Forms.RadioButton();
      this.rbAnd = new System.Windows.Forms.RadioButton();
      this.bOk = new System.Windows.Forms.Button();
      this.bCancel = new System.Windows.Forms.Button();
      this.DBComboBoxEh1 = new System.Windows.Forms.ComboBox();
      this.DBComboBoxEh2 = new System.Windows.Forms.ComboBox();
      this.SuspendLayout();
      // 
      // labelShowRecordsWhere
      // 
      this.labelShowRecordsWhere.Location = new System.Drawing.Point(6, 7);
      this.labelShowRecordsWhere.Name = "labelShowRecordsWhere";
      this.labelShowRecordsWhere.Size = new System.Drawing.Size(100, 13);
      this.labelShowRecordsWhere.TabIndex = 0;
      this.labelShowRecordsWhere.Text = "Show records where:";
      // 
      // Bevel1
      // 
      this.Bevel1.Location = new System.Drawing.Point(4, 27);
      this.Bevel1.Name = "Bevel1";
      this.Bevel1.Size = new System.Drawing.Size(399, 8);
      this.Bevel1.TabIndex = 1;
      // 
      // labelUseUnderscore
      // 
      this.labelUseUnderscore.Location = new System.Drawing.Point(6, 131);
      this.labelUseUnderscore.Name = "labelUseUnderscore";
      this.labelUseUnderscore.Size = new System.Drawing.Size(400, 13);
      this.labelUseUnderscore.TabIndex = 2;
      this.labelUseUnderscore.Text = "Use \'_\' to represent any single character";
      // 
      // labelUseAsterisk
      // 
      this.labelUseAsterisk.Location = new System.Drawing.Point(6, 151);
      this.labelUseAsterisk.Name = "labelUseAsterisk";
      this.labelUseAsterisk.Size = new System.Drawing.Size(400, 13);
      this.labelUseAsterisk.TabIndex = 3;
      this.labelUseAsterisk.Text = "Use \'%\' to represent any series of characters";
      // 
      // ComboBox2
      // 
      this.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.ComboBox2.Items.AddRange(new object[] {
            "",
            "equals",
            "does not equal",
            "is greate than",
            "is greate than or equall to",
            "is less than",
            "is less than or equall to",
            "like",
            "not like",
            "in",
            "not in",
            "is blank",
            "is not blank"});
      this.ComboBox2.Location = new System.Drawing.Point(8, 92);
      this.ComboBox2.Name = "ComboBox2";
      this.ComboBox2.Size = new System.Drawing.Size(191, 21);
      this.ComboBox2.TabIndex = 4;
      // 
      // ComboBox1
      // 
      this.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.ComboBox1.Items.AddRange(new object[] {
            "",
            "equals",
            "does not equal",
            "is greate than",
            "is greate than or equall to",
            "is less than",
            "is less than or equall to",
            "like",
            "not like",
            "in",
            "not in",
            "is blank",
            "is not blank"});
      this.ComboBox1.Location = new System.Drawing.Point(8, 39);
      this.ComboBox1.Name = "ComboBox1";
      this.ComboBox1.Size = new System.Drawing.Size(191, 21);
      this.ComboBox1.TabIndex = 0;
      // 
      // Edit2
      // 
      this.Edit2.Location = new System.Drawing.Point(210, 105);
      this.Edit2.Name = "Edit2";
      this.Edit2.Size = new System.Drawing.Size(191, 20);
      this.Edit2.TabIndex = 5;
      this.Edit2.Visible = false;
      // 
      // Edit1
      // 
      this.Edit1.Location = new System.Drawing.Point(210, 52);
      this.Edit1.Name = "Edit1";
      this.Edit1.Size = new System.Drawing.Size(191, 20);
      this.Edit1.TabIndex = 1;
      this.Edit1.Visible = false;
      // 
      // rbOr
      // 
      this.rbOr.Location = new System.Drawing.Point(105, 69);
      this.rbOr.Name = "rbOr";
      this.rbOr.Size = new System.Drawing.Size(53, 17);
      this.rbOr.TabIndex = 3;
      this.rbOr.Text = "&Or";
      // 
      // rbAnd
      // 
      this.rbAnd.Checked = true;
      this.rbAnd.Location = new System.Drawing.Point(38, 69);
      this.rbAnd.Name = "rbAnd";
      this.rbAnd.Size = new System.Drawing.Size(47, 17);
      this.rbAnd.TabIndex = 2;
      this.rbAnd.TabStop = true;
      this.rbAnd.Text = "&And";
      // 
      // bOk
      // 
      this.bOk.BackColor = System.Drawing.SystemColors.ButtonFace;
      this.bOk.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.bOk.Location = new System.Drawing.Point(237, 188);
      this.bOk.Name = "bOk";
      this.bOk.Size = new System.Drawing.Size(78, 22);
      this.bOk.TabIndex = 6;
      this.bOk.Text = "OK";
      this.bOk.UseVisualStyleBackColor = false;
      // 
      // bCancel
      // 
      this.bCancel.BackColor = System.Drawing.SystemColors.ButtonFace;
      this.bCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.bCancel.Location = new System.Drawing.Point(323, 188);
      this.bCancel.Name = "bCancel";
      this.bCancel.Size = new System.Drawing.Size(78, 22);
      this.bCancel.TabIndex = 7;
      this.bCancel.Text = "Cancel";
      this.bCancel.UseVisualStyleBackColor = false;
      // 
      // DBComboBoxEh1
      // 
      this.DBComboBoxEh1.Location = new System.Drawing.Point(207, 39);
      this.DBComboBoxEh1.Name = "DBComboBoxEh1";
      this.DBComboBoxEh1.Size = new System.Drawing.Size(191, 21);
      this.DBComboBoxEh1.TabIndex = 0;
      // 
      // DBComboBoxEh2
      // 
      this.DBComboBoxEh2.Location = new System.Drawing.Point(207, 92);
      this.DBComboBoxEh2.Name = "DBComboBoxEh2";
      this.DBComboBoxEh2.Size = new System.Drawing.Size(193, 21);
      this.DBComboBoxEh2.TabIndex = 0;
      // 
      // DataGridSimpleFilterDialog
      // 
      this.AcceptButton = this.bOk;
      this.AutoScroll = true;
      this.BackColor = System.Drawing.SystemColors.ButtonFace;
      this.CancelButton = this.bCancel;
      this.ClientSize = new System.Drawing.Size(410, 218);
      this.Controls.Add(this.labelShowRecordsWhere);
      this.Controls.Add(this.Bevel1);
      this.Controls.Add(this.labelUseUnderscore);
      this.Controls.Add(this.labelUseAsterisk);
      this.Controls.Add(this.ComboBox2);
      this.Controls.Add(this.ComboBox1);
      this.Controls.Add(this.rbOr);
      this.Controls.Add(this.rbAnd);
      this.Controls.Add(this.bOk);
      this.Controls.Add(this.bCancel);
      this.Controls.Add(this.DBComboBoxEh1);
      this.Controls.Add(this.DBComboBoxEh2);
      this.Controls.Add(this.Edit1);
      this.Controls.Add(this.Edit2);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Location = new System.Drawing.Point(734, 312);
      this.Name = "DataGridSimpleFilterDialog";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Custom filter";
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TDBGridEhSimpleFilterDialog_FormClosing);
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    private System.ComponentModel.IContainer components;
  }
}
