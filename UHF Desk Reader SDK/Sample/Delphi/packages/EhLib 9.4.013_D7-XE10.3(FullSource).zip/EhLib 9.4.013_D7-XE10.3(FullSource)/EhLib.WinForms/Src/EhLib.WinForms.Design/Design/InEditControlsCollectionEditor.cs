﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;

namespace EhLib.WinForms.Design
{
  public class InEditControlsCollectionEditor : MultiTypedCollectionEditor
  {
    public InEditControlsCollectionEditor(Type type) : base(type)
    {
    }

    protected override Type CollectionItemBaseType()
    {
      return typeof(EditItem);
    }

    protected override Type CollectionItemVisibleAttributeType()
    {
      return typeof(EditItemDesignTimeVisibleAttribute);
    }

    protected override object SetItems(object editValue, object[] value)
    {
      //DataAxisGridStaticPropBarCollection stBars = (DataAxisGridStaticPropBarCollection)editValue;
      //stBars.BeginUpdate();
      try
      {
        return base.SetItems(editValue, value);
      }
      finally
      {
        //stBars.EndUpdate();
        //((IDataAxisGridInternal)Context.Instance).SetPropBarsOrderFromViewOrderedBars();
        //var changeService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
        //changeService.OnComponentChanged(stBars.Grid, null, null, null);
      }
    }

  }

  [AttributeUsage(AttributeTargets.Class)]
  public sealed class EditItemDesignTimeVisibleAttribute : DesignTimeCollectionEditorItemVisibleAttribute
  {

    public EditItemDesignTimeVisibleAttribute(bool visible) : base(visible)
    {
    }

    public EditItemDesignTimeVisibleAttribute()
    {
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2104:DoNotDeclareReadOnlyMutableReferenceTypes")]
    public static readonly EditItemDesignTimeVisibleAttribute Default = new EditItemDesignTimeVisibleAttribute(true);
  }

}
