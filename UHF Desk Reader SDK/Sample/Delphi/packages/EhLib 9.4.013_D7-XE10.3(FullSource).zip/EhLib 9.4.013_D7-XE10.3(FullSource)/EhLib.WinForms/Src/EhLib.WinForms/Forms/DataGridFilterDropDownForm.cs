﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  public partial class DataGridFilterDropDownForm : FilterDropDownForm
  {
    readonly DataGridMenuButtonEh sortButton1;
    readonly DataGridMenuButtonEh sortButton2;
    // ReSharper disable once PrivateFieldCanBeConvertedToLocalVariable
    readonly DataGridMenuButtonEh lineMenuButton1;

    readonly DataGridMenuButtonEh clearFilterButton;
    readonly DataGridMenuButtonEh clearColumnFilterButton;
    readonly DataGridMenuButtonEh customFilterButton;

    // ReSharper disable once PrivateFieldCanBeConvertedToLocalVariable
    readonly DataGridMenuButtonEh lineMenuButton2;
    //TDBGridMenuButtonEh FLineMenuButton3;
    //TDBGridMenuButtonEh FLineMenuButton4;

    readonly List<DataGridFilterFormListRecord> gridFilterValues = new List<DataGridFilterFormListRecord>();
    private DataGridColumnTitleFilter colFilter;
    private Rectangle screenFilterBtnRect;

    public DataGridFilterDropDownForm()
    {
      InitializeComponent();

      this.SuspendLayout();

      sortButton1 = new DataGridMenuButtonEh();
      sortButton1.Text = @"(" + Properties.Resources.STFilterListItem_SortingByAscend + @")";
      //FSortButton1.ActionItem = ListboxItemEhSortAsc;
      sortButton1.Click += MenuButtonClick;
      sortButton1.Height = MenuItemHeight;
      sortButton1.CaptionMargin = LeftMargin;
      sortButton1.SortState = SortOrder.Ascending;
      sortButton1.DropDownForm = this;
      sortButton1.Top = 0;
      sortButton1.Dock = DockStyle.Top;
      sortButton1.TabIndex = 0;

      sortButton2 = new DataGridMenuButtonEh();
      sortButton2.Text = @"(" + Properties.Resources.STFilterListItem_SortingByDescend + @")";
      //FSortButton2.ActionItem = ListboxItemEhSortDes;
      sortButton2.Click += MenuButtonClick;
      sortButton2.Height = MenuItemHeight;
      sortButton2.CaptionMargin = LeftMargin;
      sortButton2.SortState = SortOrder.Descending;
      sortButton2.DropDownForm = this;
      sortButton2.Top = sortButton1.Top + sortButton1.Height;
      sortButton2.Dock = DockStyle.Top;
      sortButton2.TabIndex = 1;

      lineMenuButton1 = new DataGridMenuButtonEh();
      lineMenuButton1.Text = EhLibUtils.LineCaption;
      lineMenuButton1.Enabled = false;
      lineMenuButton1.Height = 5;
      lineMenuButton1.CaptionMargin = LeftMargin;
      lineMenuButton1.DropDownForm = this;
      lineMenuButton1.Top = sortButton2.Top + sortButton2.Height;
      lineMenuButton1.Dock = DockStyle.Top;

      clearFilterButton = new DataGridMenuButtonEh();
      clearFilterButton.Text = Properties.Resources.STFilterListItem_ClearFilter;
      //FClearFilterButton.ActionItem = ListboxItemEhClearFilter;
      clearFilterButton.Click += MenuButtonClick;
      clearFilterButton.Height = MenuItemHeight;
      clearFilterButton.CaptionMargin = LeftMargin;
      clearFilterButton.DropDownForm = this;
      clearFilterButton.Top = lineMenuButton1.Top + lineMenuButton1.Height;
      clearFilterButton.Dock = DockStyle.Top;
      clearFilterButton.TabIndex = 2;

      clearColumnFilterButton = new DataGridMenuButtonEh();
      clearColumnFilterButton.Text = Properties.Resources.STFilterListItem_ClearFilterInColumn;
      //FClearColumnFilterButton.ActionItem = ListboxItemEhClearColumnFilter;
      clearColumnFilterButton.Click += MenuButtonClick;
      clearColumnFilterButton.Height = MenuItemHeight;
      clearColumnFilterButton.CaptionMargin = LeftMargin;
      clearColumnFilterButton.DropDownForm = this;
      clearColumnFilterButton.Top = clearFilterButton.Top + clearFilterButton.Height;
      clearColumnFilterButton.Dock = DockStyle.Top;
      clearColumnFilterButton.TabIndex = 3;

      customFilterButton = new DataGridMenuButtonEh();
      customFilterButton.Text = Properties.Resources.STFilterListItem_CustomFilter;
      //FCustomFilterButton.ActionItem = ListboxItemEhDialog;
      customFilterButton.Click += MenuButtonClick;
      customFilterButton.Height = MenuItemHeight;
      customFilterButton.CaptionMargin = LeftMargin;
      customFilterButton.DropDownForm = this;
      customFilterButton.Top = clearColumnFilterButton.Top + clearColumnFilterButton.Height;
      customFilterButton.Dock = DockStyle.Top;
      customFilterButton.TabIndex = 4;

      lineMenuButton2 = new DataGridMenuButtonEh();
      lineMenuButton2.Text = EhLibUtils.LineCaption;
      lineMenuButton2.Enabled = false;
      lineMenuButton2.Height = 5;
      lineMenuButton2.CaptionMargin = LeftMargin;
      lineMenuButton2.DropDownForm = this;
      lineMenuButton2.Top = customFilterButton.Top + customFilterButton.Height;
      lineMenuButton2.Dock = DockStyle.Top;

      panelGrid.TabIndex = 5;
      searchTextBox.TabIndex = 6;
      clearSearchButton.TabIndex = 7;
      ValuesDataGrid.TabIndex = 8;
      panelBottom.TabIndex = 8;
      bOk.TabIndex = 9;
      bCancel.TabIndex = 10;


      lineMenuButton2.Parent = this;
      customFilterButton.Parent = this;
      clearColumnFilterButton.Parent = this;
      clearFilterButton.Parent = this;

      lineMenuButton1.Parent = this;
      sortButton2.Parent = this;
      sortButton1.Parent = this;

      this.ResumeLayout(false);

      DefaultSize = new Size(Size.Width, 500);
    }

    private void MenuButtonClick(object sender, EventArgs e)
    {
      DataGridSortCollection sortMarkers;

      if (sender == sortButton1)
      {
        Close(DialogResult.None);
        sortMarkers = colFilter.ColumnTitle.Column.Grid.Title.SortMarking.SortMarkers;
        sortMarkers.SetSortStateInternal(colFilter.ColumnTitle.Column, ListSortDirection.Ascending);
        //sortMarkers.CommitChanges();
        colFilter.ColumnTitle.Column.Grid.Title.SortMarking.ApplySortMakers();
      }
      else if (sender == sortButton2)
      {
        Close(DialogResult.None);
        sortMarkers = colFilter.ColumnTitle.Column.Grid.Title.SortMarking.SortMarkers;
        sortMarkers.SetSortStateInternal(colFilter.ColumnTitle.Column, ListSortDirection.Descending);
        //sortMarkers.CommitChanges();
        colFilter.ColumnTitle.Column.Grid.Title.SortMarking.ApplySortMakers();
      }
      else if (sender == clearFilterButton)
      {
        DataGridTitleFilter titleFilter = colFilter.ColumnTitle.Column.Grid.Title.Filter;

        Close(DialogResult.None);
        titleFilter.Clear();
        titleFilter.ApplyFilter();
      }
      else if (sender == clearColumnFilterButton)
      {
        Close(DialogResult.None);
        colFilter.Clear();
        colFilter.ColumnTitle.Column.Grid.Title.Filter.ApplyFilter();
      }
      else if (sender == customFilterButton)
      {
        Close(DialogResult.None);
        if (colFilter.ShowCustomFilterDialog())
        {
          colFilter.ColumnTitle.Column.Grid.Title.Filter.ApplyFilter();
        }
      }
    }

    internal void InitData(Collection<DataGridFilterFormListRecord> filterValues, DataGridColumnTitleFilter colFilter, 
      Rectangle screenFilterBtnRect)
    {
      this.colFilter = colFilter;
      this.screenFilterBtnRect = screenFilterBtnRect;
      SelectAllRow.KeyValue = null;
      SelectAllRow.DisplayValue = "(" + Properties.Resources.DataGridMenu_SelectAll + ")";
      SelectAllRow.RowSelected = false;
      SelectAllRow.RowType = 1;
      SelectAllRow.SelectedCountState = 0;

      ValuesDataGrid.DataSource = null;

      gridFilterValues.Clear();
      gridFilterValues.Add(SelectAllRow);
      gridFilterValues.AddRange(filterValues);
      foreach(DataGridFilterFormListRecord rec in filterValues)
      {
        if (String.IsNullOrEmpty(rec.DisplayValue))
          rec.DisplayValue = "(" + Properties.Resources.STFilter_Empty_Values + ")";
      }

      ValuesDataGrid.DataSource = gridFilterValues;

      foreach (DataGridRow row in ValuesDataGrid.Rows)
      {
        if (((DataGridFilterFormListRecord)row.SourceItem).RowSelected)
          row.Selected = true;
      }

      if (colFilter.DropDownFormSize != Size.Empty)
        Size = colFilter.DropDownFormSize;
      else
        Size = DefaultSize;

      ActiveControl = ValuesDataGrid;
    }

    protected override void OnDeactivate(EventArgs e)
    {
//-      var mouseButtons = MouseButtons;
      var mouseButtonsAsyn = EhLibUtils.MouseButtonsAsync;
      Point pos = Cursor.Position;
      if (mouseButtonsAsyn == MouseButtons.Left && screenFilterBtnRect.Contains(pos))
        EhLibUtils.DoNothing();
      else
        base.OnDeactivate(e);
    }
  }

  [DesignTimeVisible(false)]
  [ToolboxItem(false)]
  public class DataGridMenuButtonEh : Button
  {
    private bool mouseOnControl;

    public DataGridMenuButtonEh()
    {
    }

    public int CaptionMargin { get; set; }
    public FilterDropDownForm DropDownForm { get; set; }
    public SortOrder SortState { get; set; }

    protected override void OnMouseEnter(EventArgs e)
    {
      base.OnMouseEnter(e);
      mouseOnControl = true;
    }

    protected override void OnMouseLeave(EventArgs e)
    {
      base.OnMouseLeave(e);
      mouseOnControl = false;
    }

    public bool IsLine()
    {
      if (Text == EhLibUtils.LineCaption)
        return true;
      else
        return false;
    }

    protected override void OnPaint(PaintEventArgs pevent)
    {
      Rectangle rect = ClientRectangle;
      Color backColor;
      Color foreColor;

      if (Focused || mouseOnControl)
      {
        backColor = SystemColors.Highlight;
        foreColor = SystemColors.HighlightText;
      }
      else
      {
        backColor = SystemColors.ButtonFace;
        foreColor = SystemColors.WindowText;
      }
      //if (!Application.RenderWithVisualStyles)
      //if (false)
      //{
      //  //VisualStyleRenderer render = new VisualStyleRenderer(VisualStyleElement.Button.PushButton.Normal);
      //} else
      //{

      using (
        SolidBrush btnBrush = new SolidBrush(backColor))
      {
        pevent.Graphics.FillRectangle(btnBrush, rect);
      }

      rect.Inflate(-1, -1);
      if (IsLine())
      {
        Point st = new Point(rect.Left, (rect.Top + rect.Bottom) / 2);
        Point fp = new Point(rect.Right, (rect.Top + rect.Bottom) / 2);
        pevent.Graphics.DrawLine(new Pen(SystemColors.ButtonShadow, 1), st, fp);
      }

      //}

      if (!IsLine())
      {

        Rectangle textRect = rect;
        textRect.X = textRect.Left + CaptionMargin;

        TextFormatFlags fmtFlags =
          TextFormatFlags.VerticalCenter |
          TextFormatFlags.Left |
          TextFormatFlags.PreserveGraphicsClipping |
          TextFormatFlags.NoPadding;

        TextRenderer.DrawText(pevent.Graphics, Text, Font, textRect, foreColor, fmtFlags);
      }

    }

  }

}
