﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Represents a row in a <see cref = "DataVertGridEh" /> control.
  /// </summary>
  /// <remarks>
  /// The DataVertGridRow class represents a logical row in a DataVertGridEh control.
  /// 
  /// You can retrieve rows through the Rows collection of the control.
  /// 
  /// Unlike a <see cref="DataVertGridColumn"/>, which matches the items in the 
  /// DataSource list,
  /// <see cref="DataVertGridRow"/> is used mainly to adjust the appearance and 
  /// behavior of the user interface (UI), such as row height and row cell format.
  /// </remarks>
  [DesignerCategory("Code")]
  [TypeConverter(typeof(ExpandableObjectConverter))]
  [DesignTimeVisible(false)]
  [ToolboxItem(false)]
  [DataVertGridRowDesignTimeVisible(true)]
  public class DataVertGridRow : PropertyAxisBar, IGridLineHost
 {

    #region private consts
    private static readonly object EventKeyDataCellDisplayValueNeeded = new object();
    private static readonly object EventKeyDataCellPaint = new object();
    private static readonly object EventKeyDataCellContentPaint = new object();
    private static readonly object EventKeyDataCellClientAreaNeeded = new object();
    private static readonly object EventKeyDataCellPaintCustomArea = new object();
    private static readonly object EventKeyDataCellFormatParamsNeeded = new object();

    private static readonly object EventKeyDataCellMouseDown = new object();
    private static readonly object EventKeyDataCellMouseMove = new object();
    private static readonly object EventKeyDataCellMouseUp = new object();
    private static readonly object EventKeyDataCellMouseClick = new object();
    private static readonly object EventKeyDataCellMouseDoubleClick = new object();
    private static readonly object EventKeyDataCellMouseEnter = new object();
    private static readonly object EventKeyDataCellMouseLeave = new object();
    private static readonly object EventKeyDataCellMouseHover = new object();

    private static readonly object EventKeyDataCellCanModifyStateNeeded = new object();
    private static readonly object EventKeyDataCellCanShowEditorStateNeeded = new object();
    private static readonly object EventKeyDataCellEditorParamsNeeded = new object();
    private static readonly object EventKeyDataCellEditValueNeeded = new object();
    private static readonly object EventKeyDataCellParseValue = new object();
    private static readonly object EventKeyDataCellEditorOccupy = new object();
    private static readonly object EventKeyDataCellEditorRelease = new object();

    private static readonly object EventKeyDataCellToolTipInfo = new object();
    private static readonly object EventKeyDataCellContextMenuStripNeeded = new object();

    private static readonly object EventKeyDataCellManagerNeeded = new object();
    #endregion

    #region privates
    private int height = 64;
    private readonly GridLine vertLine;

    internal bool WidthStored;
    internal bool SelectedInternal;
    internal float FillWeightInternal = 100;
    internal bool OmitFromWidthCalculation;
    //private BaseDataCellManager dataCell;
    #endregion

    public DataVertGridRow()
    {
      this.vertLine = new GridLine(this);
    }

    #region design-time properties

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public new DataVertGridRowTitle Title
    {
      get { return (DataVertGridRowTitle)base.Title; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridLine VertLine
    {
      get
      {
        return vertLine;
      }
    }
    #endregion

    #region events
    public event EventHandler<DataVertGridDataCellManagerNeededEventArgs> DataCellManagerNeeded
    {
      add { this.Events.AddHandler(EventKeyDataCellManagerNeeded, value); }
      remove { this.Events.RemoveHandler(EventKeyDataCellManagerNeeded, value); }
    }

    public event EventHandler<DataVertGridDataCellPaintEventArgs> DataCellPaint
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellPaint, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellPaint, value);
      }
    }

    /// <summary>
    /// Occurs when a cell content in the grid data cell needs to be drawn.
    /// </summary>
    public event EventHandler<DataGridDataCellContentPaintEventArgs> DataCellContentPaint
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellContentPaint, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellContentPaint, value);
      }
    }

    public event EventHandler<DataVertGridDataCellPaintEventArgs> DataCellPaintCustomArea
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellPaintCustomArea, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellPaintCustomArea, value);
      }
    }

    public event EventHandler<DataVertGridDataCellClientAreaNeededEventArgs> DataCellClientAreaNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellClientAreaNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellClientAreaNeeded, value);
      }
    }

    public event EventHandler<DataVertGridDataCellDisplayValueNeededEventArgs> DataCellDisplayValueNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellDisplayValueNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellDisplayValueNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when the cell editor requests and sets its readonly state.
    /// </summary>
    public event EventHandler<DataVertGridDataCellCanModifyStateNeededEventArgs> DataCellCanModifyStateNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellCanModifyStateNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellCanModifyStateNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a "data" cell paint params like BackColor, Font, etc should be specified.
    /// By default these params are assigned from row properties
    /// </summary>
    public event EventHandler<DataVertGridDataCellFormatParamsNeededEventArgs> DataCellFormatParamsNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellFormatParamsNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellFormatParamsNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when the grid is going to show the data cell editor.
    /// </summary>
    /// <remarks>
    /// Set e.CanShowEditor to false to prevent editor showing.
    /// </remarks>
    public event EventHandler<DataVertGridDataCellCanShowEditorStateNeededEventArgs> DataCellCanShowEditorStateNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellCanShowEditorStateNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellCanShowEditorStateNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a data cell editor params such as BackColor, Font, etc should be specified.
    /// </summary>
    public event EventHandler<DataVertGridDataCellEditorParamsEventArgs> DataCellEditorParamsNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellEditorParamsNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellEditorParamsNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager converts datasource cell value to the value for the editor.
    /// </summary>
    public event EventHandler<DataVertGridDataCellEditValueNeededEventArgs> DataCellEditValueNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellEditValueNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellEditValueNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager converts a value from the editor to the value for datasource.
    /// </summary>
    public event EventHandler<DataVertGridDataCellParseValueEventArgs> DataCellParseValue
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellParseValue, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellParseValue, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager occupy the editor before open to show and edit value.
    /// </summary>
    /// <remarks>
    /// The grid uses a shared cell editor for rows of same type.
    /// </remarks>
    public event EventHandler<DataVertGridDataCellEditorOccupyEventArgs> DataCellEditorOccupy
    {
      add
      {
        Events.AddHandler(EventKeyDataCellEditorOccupy, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellEditorOccupy, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager releases the shared editor for using in other rows.
    /// </summary>
    /// <remarks>
    /// If you changed properties or events in the DataCellEditorOccupy event handler,
    /// you should restore properties and events in this event handler.
    /// </remarks>
    public event EventHandler<DataVertGridDataCellEditorReleaseEventArgs> DataCellEditorRelease
    {
      add
      {
        Events.AddHandler(EventKeyDataCellEditorRelease, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellEditorRelease, value);
      }
    }

    //Other Data Cell Manager events

    /// <summary>
    /// Occurs when a cell manager requests info to show in tooltip window.
    /// </summary>
    /// <remarks>
    /// For text data, assign the text to e.ToolTipText property by the text you want to be shown in tooltip window.
    /// </remarks>
    public event EventHandler<DataVertGridDataCellToolTipInfoEventArgs> DataCellToolTipInfoNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellToolTipInfo, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellToolTipInfo, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager requests ContextMenuStrip before MenuStrip is shown.
    /// </summary>
    /// <remarks>
    /// Assign e.ContextMenuStrip property by the MenuStrip you want to be shown.
    /// </remarks>
    public event EventHandler<DataVertGridDataCellContextMenuStripNeededEventArgs> DataCellContextMenuStripNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellContextMenuStripNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellContextMenuStripNeeded, value);
      }
    }
    #endregion

    #region runtime properties
    [Browsable(false)]
    public bool IsColumnVisible
    {
      get
      {
        if (Grid == null)
          return Visible;
        else
          return Visible && Grid.RowCanBeVisible(this);
      }
    }

    [Browsable(false)]
    public new DataVertGridEh Grid
    {
      get
      {
        return (DataVertGridEh)base.Grid;
      }

      protected internal set
      {
        base.Grid = value;
      }
    }

    [Browsable(false)]
    public bool IsDataBound
    {
      get { return (PropDescr != null); }
    }

    [DefaultValue(false)]
    [Browsable(false)]
    public bool Selected
    {
      get
      {
        return false;
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Browsable(false)]
    public virtual int Height
    {
      get { return height; }
      internal set { height = value; }
    }

    //[Browsable(false)]
    //public BaseDataCellManager DataCell
    //{
    //  get
    //  {
    //    if (dataCell == null)
    //    {
    //      dataCell = CreateTemplateCell();
    //      dataCell.BoundPropAxisBar = this;
    //    }
    //    return dataCell;
    //  }
    //}

    /// <summary>
    /// The cell for a new virtual row.
    /// New virtual row - is a row that does not have an appropriate entry in the DatGrid.Rows collection.
    /// </summary>
    [Browsable(false)]
    public virtual BaseDataCellManager NewVirtualRowCell
    {
      get
      {
        return DefaultCellManager;
      }
    }

    [DefaultValue(null)]
    public virtual ContextMenuStrip ContextMenuStrip
    {
      get { return InternalCellManager.ContextMenuStrip; }
      set { InternalCellManager.ContextMenuStrip = value; }
    }

    [DefaultValue(false)]
    public virtual bool ReadOnly
    {
      get { return InternalCellManager.ReadOnly; }
      set { InternalCellManager.ReadOnly = value; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridRowHeightOptions HeightOptions
    {
      get
      {
        return InternalCellManager.HeightOptions;
      }
    }
    #endregion

    #region internal fields and properties
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    protected EditButton EditButton
    {
      get
      {
        return InternalCellManager.EditButton;
      }

      set
      {
        InternalCellManager.EditButton = value;
      }
    }

    //[DefaultValue(false)]
    //protected internal bool AllowShowEditor
    //{
    //  get { return DataCell.AllowShowEditor; }
    //  set { DataCell.AllowShowEditor = value; }
    //}
    #endregion

    #region Methods
    //IGridLineHost
    void IGridLineHost.GridLineChanged(GridLine gl)
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    protected virtual void GridLineChanged(GridLine gl)
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    bool IGridLineHost.GridLineDefaultVisible(GridLine gl)
    {
      return Grid.RowOptions.HorzLine.Visible;
    }

    Color IGridLineHost.GridLineDefaultColor(GridLine gl)
    {
      return Grid.RowOptions.HorzLine.Color;
    }

    DashStyle IGridLineHost.GridLineDefaultStyle(GridLine gl)
    {
      return Grid.RowOptions.HorzLine.Style;
    }


    //Padding
    protected override void PaddingChanged()
    {
      if (Grid != null)
        Grid.UpdateBaseFixedBands();
    }

    //HorzAlign
    public override HorizontalAlignment DefaultHorzAlign()
    {
      return HorizontalAlignment.Left;
    }

    //VertAlign
    public override VerticalAlignment DefaultVertAlign()
    {
      return Grid.RowOptions.VertAlign;
    }

    //ForeColor
    public override Color DefaultForeColor()
    {
      if (Grid != null)
        return Grid.RowOptions.ForeColor;
      else
        return SystemColors.WindowText;
    }

    //Font
    protected override void FontChanged()
    {
      if (Grid != null)
        Grid.UpdateRowHeights();
    }

    public override Font DefaultFont()
    {
      if (Grid != null)
        return Grid.RowOptions.Font;
      else
        return null;
    }

    //AllowShowEditor
    public override bool DefaultAllowShowEditor()
    {
      if (Grid != null)
        return Grid.RowOptions.AllowShowEditor;
      else
        return false;
    }

    //Mouse
    protected internal override void HandleMouseDownEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseDown] as EventHandler<DataVertGridDataCellMouseEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleMouseMoveEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseMove] as EventHandler<DataVertGridDataCellMouseEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleMouseUpEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseUp] as EventHandler<DataVertGridDataCellMouseEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleMouseClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseClick] as EventHandler<DataVertGridDataCellMouseEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleMouseDoubleClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseDoubleClick] as EventHandler<DataVertGridDataCellMouseEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleMouseEnterEvent(DataAxisGridDataCellEnterEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseEnter] as EventHandler<DataVertGridDataCellEnterEventArgs>;
      if (eh != null)
      {
        var hea = new DataVertGridDataCellEnterEventArgs(e);
        eh(this, hea);
      }
    }

    protected internal override void HandleMouseLeaveEvent(DataAxisGridDataCellLeaveEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseLeave] as EventHandler<DataVertGridDataCellLeaveEventArgs>;
      if (eh != null)
      {
        var hea = new DataVertGridDataCellLeaveEventArgs(e);
        eh(this, hea);
      }
    }

    protected internal override void HandleMouseHoverEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellMouseHover] as EventHandler<DataVertGridDataCellMouseEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    //Other
    protected internal override void PaintCellBackground(BaseDataCellManager cellMan, DataAxisGridDataCellPaintEventArgs e)
    {
      Color baseColor = e.BackColor;
      int alpha = 255;
      bool drawSelection = false;

      Rectangle selectionRect = e.ClientRect;

      if (Grid.Background.Visible && baseColor == Grid.BackColor)
      {
        // Paint nothing
      }
      else
      {
        if (Grid.Background.Visible && baseColor.A == 255)
          baseColor = Color.FromArgb(Grid.Background.GridOpacityOptions.CellsOpacity, baseColor);

        e.BackFilledColor = baseColor;
        using (SolidBrush fillBrush = new SolidBrush(baseColor))
        {
          Grid.PaintingFillRectangle(e.Graphics, fillBrush, e.ClientRect);
        }
      }

      if (((BasePaintCellStates.Current & e.State) != 0) ||
                ((BasePaintCellStates.RowSelected & e.State) != 0))
      {
        if (Grid.Background.Visible)
          alpha = Grid.Background.GridOpacityOptions.FocusCellOpacity;
        else
          alpha = 255;
        drawSelection = true;
      }

      if (drawSelection)
      {
        Grid.DrawStyle.DataSelectionRenderer.DrawFocusRectangle(
          e.Graphics, selectionRect, Grid.IsActiveControl(), false, alpha, false, false);
      }
    }

    protected internal override void SpecifyPaintParams(DataAxisGridDataCellPaintEventArgs e)
    {
      if (((BasePaintCellStates.Current & e.State) != 0) ||
          ((BasePaintCellStates.RowSelected & e.State) != 0)
      )
      {
        DataVertGridEh grid = e.PropAxisBar.Grid as DataVertGridEh;
        e.ForePaintColor = grid.DrawStyle.DataSelectionRenderer.ForeFocusColor;
        if (e.ForePaintColor == Color.Empty)
          e.ForePaintColor = e.ForeColor;
      }
      else
      {
        e.ForePaintColor = e.ForeColor;
      }
    }

    protected override BaseDataCellManager CreateTemplateCell()
    {
      return new BlankDataCellManager();
    }

    protected override DataAxisGridBarTitle CreateDataAxisGridBarTitle()
    {
      return new DataVertGridRowTitle(this);
    }

    protected override void GridChanged()
    {
      base.GridChanged();
      InternalCellManager.BoundGrid = Grid;
      UpdateDefaultPadding();
    }

    public override BaseGridCellManager GetDataCellManager(DataAxisGridListItemBar listItemBar)
    {
      return GetColumnCellManager(listItemBar as DataVertGridColumn);
    }

    public BaseDataCellManager GetColumnCellManager(DataVertGridColumn listItem)
    {
      return InternalGetColumnCellManager(listItem);
    }

    protected internal BaseDataCellManager InternalGetColumnCellManager(DataVertGridColumn listItem)
    {
      DataVertGridDataCellManagerNeededEventArgs e = new DataVertGridDataCellManagerNeededEventArgs(this, listItem);
      HandleDataCellManagerNeededEvent(e);
      if (e.CellManager == null)
        e.CellManager = DefaultCellManager;
      return e.CellManager;
    }

    protected virtual void HandleDataCellManagerNeededEvent(DataVertGridDataCellManagerNeededEventArgs e)
    {
      Grid.HandleDataCellManagerNeededEvent(e);

      var eh = this.Events[EventKeyDataCellManagerNeeded] as EventHandler<DataVertGridDataCellManagerNeededEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    protected internal override void HandleCanShowEditorStateNeededEvent(DataAxisGridDataCellCanShowEditorStateNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellCanShowEditorStateNeeded] as EventHandler<DataVertGridDataCellCanShowEditorStateNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellCanShowEditorStateNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditorParamsNeededEvent(DataAxisGridDataCellEditorParamsNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellEditorParamsNeeded] as EventHandler<DataVertGridDataCellEditorParamsEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellEditorParamsEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal virtual int CalcHeight()
    {
      int height;
      int maxHeight = CalcDefaultRowHeight(); 

      if (Grid.VisibleColumns.Count > 0)
      {
        foreach (DataVertGridColumn listItem in Grid.VisibleColumns)
        {
          height = CalcRowHeightForListItem(listItem);
          if (height > maxHeight)
            maxHeight = height;
        }
      }

      height = Title.CalcHeight();
      if (height > maxHeight)
        maxHeight = height;

      return maxHeight;
    }

    protected internal virtual int CalcDefaultRowHeight()
    {
      int th;

      if (HeightOptions.Unit == GridRowHeightUnit.TextLine)
        th = EhLibUtils.GetFontHeight(DefaultCellManager.GetFont(this)) * HeightOptions.ContentHeight;
      else
        th = HeightOptions.ContentHeight;
      th = th + Padding.Top + Padding.Bottom;
      return th;
    }

    protected internal virtual int CalcRowHeightForListItem(DataVertGridColumn listItemBar)
    {
      BaseDataCellManager listItemDataCell = GetColumnCellManager(listItemBar);

      if (listItemDataCell != null)
        return listItemDataCell.ProcessCalcCellHeight(this, listItemBar, Grid.DataColumnWidth);
      else
        return CalcDefaultRowHeight();
    }

    protected internal override void OnPullValue(DataAxisGridDataCellPullValueEventArgs e)
    {
      e.Value = GetColumnValue(e.ListItemBar);
      e.Handled = true;
    }

    protected internal override void OnPushValue(DataAxisGridDataCellPushValueEventArgs e)
    {
      DataAxisGridListItemBar listItem = e.ListItemBar;

      if (PropDescr == null)
        throw new InvalidOperationException("PropDescr == null");

      if (Grid.CurrencyManager.Current == listItem.SourceItem)
        Grid.DataLink.SetCurrentRowValue(PropDescr, e.Value);
      else
        PropDescr.SetValue(listItem.SourceItem, e.Value);
    }

    public virtual object GetColumnValue(DataAxisGridListItemBar listItem)
    {
      if (DataValueSource == DataValueSource.ListItem)
      {
        return listItem;
      }
      else if (PropDescr == null || listItem == null)
      {
        return null;
      }
      else
      {
        object srcRow = listItem.SourceItem;
        return PropDescr.GetValue(srcRow);
      }
    }

    public virtual string GetColumnDisplayText(DataAxisGridListItemBar listItem)
    {
      //object srcRow = row.srcRow;
      if (listItem == null) return null;

      object value = GetColumnValue(listItem);
      return GetValueDisplayText(value);
    }

    public virtual string GetValueDisplayText(object value)
    {
      TypeConverter srcConverter = null;
      TypeConverter targetConverter = EhLibUtils.GetCachedStringConverter();
      if (DataType != null)
        srcConverter = TypeDescriptor.GetConverter(DataType);
      object result = EhLibManager.DefaultEhLibManager.ValueConverter.FormatValue(
        value, typeof(string), srcConverter, targetConverter, "", null, "", null);
      return result.ToString();
    }

    public override void Invalidate()
    {
      if (Grid != null)
        Grid.InvalidateGrid();
    }

    public virtual string GetDisplayText(DataVertGridColumn listItemBar)
    {
      BaseDataCellManager cell = InternalGetColumnCellManager(listItemBar);
      //DataVertGridRowDataCell dataCell = (cell as DataVertGridRowDataCell);
      if (cell != null)
        return cell.GetDisplayText(this, listItemBar);
      else
        //TODO VisibleIndex?
        return null;// cell.GetDisplayText(VisibleIndex, row.VisibleIndex);
    }

    //public virtual ContextMenuStrip GetContextMenuStripAtRow(object listItem)
    //{
    //  return DataCell.ContextMenuStrip;
    //}

    //public virtual bool CanModifyValueAtColumn(object listItem)
    //{
    //  return !DataCell.ReadOnly;
    //}

    //TODO Postpone.
    //protected override void OnCellContentClick(DataVertGridDataCellEventArgs e)
    //{
    //  //DataVertGridDataCellEventHandler eh = this.Events[EventKeyDataCellContentClick] as DataVertGridDataCellEventHandler;
    //  //if (eh != null)
    //  //{
    //  //  eh(this, e);
    //  //}
    //}

    public override Collection<object> GetEditUniqueValues()
    {
      var srcVals = new List<object>();
      var resVals = new Collection<object>();

      foreach (object listItem in Grid.DataLink.List)
      {
        object val = PropDescr.GetValue(listItem);
        srcVals.Add(val);
      }

      srcVals.Sort(EhLibUtils.DBCompareValues);

      if (srcVals.Count == 0)
        return null;

      object ats = srcVals[0];
      resVals.Add(ats);

      for (int i = 1; i < srcVals.Count; i++)
      {
        if (EhLibUtils.DBCompareValues(ats, srcVals[i]) != 0)
        {
          ats = srcVals[i];
          resVals.Add(ats);
        }
      }

      return resVals;
    }

    protected internal override void UpdatedInList()
    {
      base.UpdatedInList();
    }

    protected internal override void CellFontChanged()
    {
      if (Grid != null)
        Grid.UpdateRowHeights();
    }

    protected internal override void RowHeightAutoExpandChanged()
    {
      if (Grid != null)
        Grid.RowHeightAutoExpandChanged();
    }

    public override bool HeightOptionsDefaultAutoExpand(GridRowHeightOptions heightOptions)
    {
      if (Grid != null)
        return Grid.RowOptions.HeightOptions.AutoExpand;
      else
        return false;
    }

    public override int HeightOptionsDefaultContentHeight(GridRowHeightOptions heightOptions)
    {
      if (Grid != null)
        return Grid.RowOptions.HeightOptions.ContentHeight;
      else
        return 1;
    }

    public override int HeightOptionsDefaultMaxContentHeight(GridRowHeightOptions heightOptions)
    {
      if (Grid != null)
        return Grid.RowOptions.HeightOptions.MaxContentHeight;
      else
        return 0;
    }

    public override GridRowHeightUnit HeightOptionsDefaultUnit(GridRowHeightOptions heightOptions)
    {
      if (Grid != null)
        return Grid.RowOptions.HeightOptions.Unit;
      else
        return GridRowHeightUnit.TextLine;
    }

    protected internal override void GridCellPosToDataCellPos(int gridColIndex, int gridRowIndex, out int areaColIndex, out int areaRowIndex)
    {
      areaColIndex = gridColIndex - Grid.FixedColCount;
      areaRowIndex = gridRowIndex - Grid.FixedRowCount;
    }

    protected internal override void DataCellPosToGridCellPos(int areaColIndex, int areaRowIndex, out int gridColIndex, out int gridRowIndex)
    {
      gridColIndex = areaColIndex + Grid.FixedColCount;
      gridRowIndex = areaRowIndex + Grid.FixedRowCount;
    }

    protected internal override void OnGetDataCellBorderParams(BaseGridCellBorderEventArgs e)
    {
      if (e.BorderType == GridCellBorderSide.Right || e.BorderType == GridCellBorderSide.Left)
      {
        GridLine gl = Grid.RowOptions.HorzLine;
        e.Visible = gl.Visible;
        e.Color = gl.Color;
        e.Style = gl.Style;
        e.IsExtent = true;
      }
      else
      {
        e.Visible = Grid.LineOptions.VertLines;
        e.Color = Grid.LineOptions.BrightColor;
        e.Style = DashStyle.Solid;
        e.IsExtent = true;
      }
    }

    //protected internal override DataAxisGridDataCellPaintEventArgs GetDataCellPaintParams(BaseGridCellManager cellManager, Graphics graphics,
    //  int colIndex, int rowIndex, Rectangle paintRect, BasePaintCellStates state, int areaColIndex, int areaRowIndex,
    //  Point inCellMousePos, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, DataAxisGridListAxisItemViewState listAxisItemViewState)
    //{
    //  return new DataVertGridDataCellPaintEventArgs(cellManager, graphics, colIndex, rowIndex, paintRect, state, areaColIndex, areaRowIndex,
    //    inCellMousePos, propAxisBar, listItemBar, listAxisItemViewState);
    //}

    protected internal override void HandleDataCellPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellPaint] as EventHandler<DataVertGridDataCellPaintEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellPaintEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellContentPaintEvent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellContentPaint] as EventHandler<DataVertGridDataCellContentPaintEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellContentPaintEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellCustomAreaPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellPaintCustomArea] as EventHandler<DataVertGridDataCellPaintEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellPaintEventArgs(e);
        eh(this, ge);
      }
    }

    //protected internal override DataAxisGridDataCellClientAreaNeededEventArgs CreateDataCellClientAreaNeededEventArgs(PropertyAxisBar propAxisBar,
    //    DataAxisGridListItemBar listItemBar, Rectangle cellRect, BaseDataCellManager cellMan)
    //{
    //  return new DataAxisGridDataCellClientAreaNeededEventArgs(propAxisBar, listItemBar, cellRect, cellMan);
    //}

    protected internal override void HandleDataCellClientAreaNeededEvent(DataAxisGridDataCellClientAreaNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellClientAreaNeeded] as EventHandler<DataVertGridDataCellClientAreaNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellClientAreaNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDisplayValueNeededEvent(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellDisplayValueNeeded] as EventHandler<DataVertGridDataCellDisplayValueNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellDisplayValueNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleCanModifyStateNeededEvent(DataAxisGridDataCellCanModifyStateNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellCanModifyStateNeeded] as EventHandler<DataVertGridDataCellCanModifyStateNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellCanModifyStateNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleFormatParamsNeededEvent(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellFormatParamsNeeded] as EventHandler<DataVertGridDataCellFormatParamsNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellFormatParamsNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditValueNeededEvent(DataAxisGridDataCellEditValueNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellEditValueNeeded] as EventHandler<DataVertGridDataCellEditValueNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellEditValueNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleParseValueEvent(DataAxisGridDataCellParseValueEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellParseValue] as EventHandler<DataVertGridDataCellParseValueEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellParseValueEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditorOccupyEvent(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
      var eh = Events[EventKeyDataCellEditorOccupy] as EventHandler<DataVertGridDataCellEditorOccupyEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellEditorOccupyEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditorReleaseEvent(DataAxisGridDataCellEditorReleaseEventArgs e)
    {
      var eh = Events[EventKeyDataCellEditorRelease] as EventHandler<DataVertGridDataCellEditorReleaseEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellEditorReleaseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellToolTipInfoNeeded(DataAxisGridDataCellToolTipInfoEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellToolTipInfo] as EventHandler<DataVertGridDataCellToolTipInfoEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellToolTipInfoEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellContextMenuStripNeededEvent(DataAxisGridDataCellContextMenuStripNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellContextMenuStripNeeded] as EventHandler<DataVertGridDataCellContextMenuStripNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellContextMenuStripNeededEventArgs(e);
        eh(this, ge);
      }
    }
    #endregion

    #region events
    #endregion

  }

}
