﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{
  public interface IComboBoxDataCellHolder
  {
    void OnCustomAreaPaint(ComboBoxCustomAreaPaintEventArgs e);
    void DataListChanged(object sender, ListChangedEventArgs e);
    void CellManagerLookupModeChanged();
  }

  /// <summary>
  /// Defines a type of data cell manager that displays a combo box user interface (UI) in the grid cell.
  /// </summary>
  //[DataCellDesignTimeVisible(true)]
  //[ToolboxItem(true)]
  public class ComboBoxDataCellManager : BaseDataCellManager, IObjectCollectionObserver, IComboBoxDropDownBoxOwner
  {
    //private BindingSource bindingSource;
    private CurrencyManager dataManager;
    private object dataSource;
    private bool dataSourceInitialized;
    private BindingMemberInfo displayMember;
    private BindingMemberInfo valueMember;
    private PropertyDescriptor displayMemberProperty;
    private PropertyDescriptor valueMemberProperty;
    private ObjectCollection items;
    private ComboBoxCompound compound;
    private int customAreaWidth = 16;
    private int dropDownBoxVisibleRowCount = 20;
    private int dropDownBoxWidth = 0;
    private readonly BindingSource bindingSource;
    private bool lookupMode;
    private readonly ComboBoxDropDownBox dropDownBox;

    //public DataGridComboBoxDataCell(DataGridColumn column) : base(column)
    public ComboBoxDataCellManager()
    {
      //bindingSource = new BindingSource();
      displayMember = new BindingMemberInfo();
      valueMember = new BindingMemberInfo();
      bindingSource = new BindingSource();

      dataManager = bindingSource.CurrencyManager;
      dataManager.ListChanged += CurrencyManagerListChanged;
      dropDownBox = new ComboBoxDropDownBox(this);
    }

    #region Design-time Properties
    [DefaultValue(ComboBoxCompound.TextEditor)]
    public ComboBoxCompound Compound
    {
      get
      {
        return compound;
      }
      set
      {
        if (value != compound)
        {
          compound = value;
          OnCompoundChanged();
        }
      }
    }

    [DefaultValue(null)]
    [RefreshProperties(RefreshProperties.Repaint)]
    [AttributeProvider(typeof(IListSource))]
    public object DataSource
    {
      get
      {
        return dataSource;
      }
      set
      {

        if (DataSource != value)
        {
          //dataManager = null;
          dataSourceInitialized = false;

          UnwireDataSource();
          dataSource = value;
          WireDataSource(value);

          ResetDataSourceConnection();
        }
      }
    }

    [DefaultValue("")]
    [TypeConverter("System.Windows.Forms.Design.DataMemberFieldConverter ")]
    [Editor("System.Windows.Forms.Design.DataMemberFieldEditor", typeof(System.Drawing.Design.UITypeEditor))]
    public string DisplayMember
    {
      get
      {
        return displayMember.BindingMember;
      }

      set
      {
        if (value != displayMember.BindingMember)
        {
          displayMember = new BindingMemberInfo(value);
          ResetDataSourceConnection();
        }
      }
    }

    [DefaultValue("")]
    [TypeConverter("System.Windows.Forms.Design.DataMemberFieldConverter")]
    [Editor("System.Windows.Forms.Design.DataMemberFieldEditor", typeof(System.Drawing.Design.UITypeEditor))]
    public string ValueMember
    {
      get
      {
        return valueMember.BindingMember;
      }
      set
      {
        if (value != valueMember.BindingMember)
        {
          valueMember = new BindingMemberInfo(value);
          ResetDataSourceConnection();
        }
      }
    }

    [Editor("System.Windows.Forms.Design.StringCollectionEditor", typeof(System.Drawing.Design.UITypeEditor))]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public ObjectCollection Items
    {
      get
      {
        if (items == null)
          items = new ObjectCollection(this);
        return items;
      }
    }

    [DefaultValue(16)]
    public int CustomAreaWidth
    {
      get
      {
        return customAreaWidth;
      }

      set
      {
        if (value != customAreaWidth)
        {
          customAreaWidth = value;
          InvalidateGrid();
        }
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public ComboBoxDropDownBox DropDownBox
    {
      get
      {
        return dropDownBox;
      }
    }
    #endregion

    #region run-time properties
    private CurrencyManager DataManager
    {
      get
      {
        return dataManager;
      }
    }

    private PropertyDescriptor DisplayMemberProperty
    {
      get
      {
        return displayMemberProperty;
      }
    }

    private PropertyDescriptor ValueMemberProperty
    {
      get
      {
        return valueMemberProperty;
      }
    }

    /// <summary>
    /// Gets the default type of the <see cref="ComboBoxDataCellManager"/> editor. 
    /// By default it returns reference to <see cref="DataAxisGridComboBoxEditControl"/> class.
    /// </summary>
    protected override Type DefaultEditorType
    {
      get
      {
        return typeof(DataAxisGridComboBoxEditControl);
      }
    }

    //public new DataGridComboBoxColumn Column
    //{
    //  get
    //  {
    //    return (base.Column as DataGridComboBoxColumn);
    //  }
    //}

    /// <summary>
    /// Gets a value indicating whether the lookup mode is active. Look mode is active when ValueMember property is assigned. 
    /// </summary>
    public bool LookupMode
    {
      get
      {
        return lookupMode;
      }
    }
    #endregion

    #region methods
    protected internal override void OnDisplayValueNeeded(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      if (e.PropAxisBar != null)
      {
        if (LookupMode)
        {
          object displayValue;
          object keyValue = e.Value;
          e.Handled = true;
          if (LookupDisplayValue(keyValue, out displayValue))
          {
            if (displayValue == null)
              e.DisplayValue = "";
            else
              e.DisplayValue = displayValue.ToString();
          }
          else
          {
            e.DisplayValue = null;
          }
        }
        else
        {
          base.OnDisplayValueNeeded(e);
        }
      }
      else
        e.DisplayValue = null;
    }

    //public virtual string GetValueDisplayText(object value)
    //{
    //  if (LookupMode)
    //  {
    //    object displayValue;
    //    if (LookupDisplayValue(value, out displayValue))
    //    {
    //      if (displayValue == null)
    //        return "";
    //      else
    //        return displayValue.ToString();
    //    }
    //    else
    //    {
    //      return null;
    //    }
    //  }
    //  else
    //  {
    //    if (value != null && !(value is string))
    //      return value.ToString();
    //    else
    //      return "";
    //  }
    //}

    private bool LookupDisplayValue(object keyValue, out object displayValue)
    {
      bool result = false;
      object rowItem;

      displayValue = null;

      IBindingList list = this.DataManager.List as IBindingList;
      if ((list != null) && list.SupportsSearching)
      {
        int index = list.Find(ValueMemberProperty, keyValue);
        if (index != -1)
        {
          rowItem = this.DataManager.List[index];
          displayValue = DisplayMemberProperty.GetValue(rowItem);
          result = true;
        }
      }
      else
      {
        foreach (object itemTmp in this.DataManager.List)
        {
          object value = ValueMemberProperty.GetValue(itemTmp);
          if (EhLibUtils.DBValueEqual(keyValue, value))
          {
            displayValue = DisplayMemberProperty.GetValue(itemTmp);
            result = true;
            break;
          }
        }
      }
      return result;
    }

    protected internal override void OnPaintContent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      Rectangle cellContentRect = e.CellContentRect;
      object listItem = null;
      if (e.ListItemBar != null)
      {
        listItem = e.ListItemBar.SourceItem;
      }
      //if (e.PropAxisBar != null && e.ListItemBar != null)
      //  listItem = e.PropAxisBar.GetListItemBarValue(e.ListItemBar);

      if (Compound == ComboBoxCompound.CustomAreaAndTextEditor)
      {
        Rectangle customAreaRect = e.CellContentRect;

        customAreaRect.Width = CustomAreaWidth;
        cellContentRect.Width = cellContentRect.Width - CustomAreaWidth;
        cellContentRect.X = cellContentRect.X + CustomAreaWidth;

        var ce = new ComboBoxCustomAreaPaintEventArgs(e.Graphics, customAreaRect, listItem);
        OnCustomAreaPaint(ce);
      }

      var te = new DataAxisGridDataCellContentPaintEventArgs(e.ParentCellPaintArgs, cellContentRect);
      PaintTextContent(te);
    }

    protected internal virtual void OnCustomAreaPaint(ComboBoxCustomAreaPaintEventArgs e)
    {
      var holder = BoundPropAxisBar as IComboBoxDataCellHolder;
      if (holder != null)
        holder.OnCustomAreaPaint(e);
    }

    protected virtual void PaintTextContent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      Color foreColor;
      Rectangle textRect;
      //bool wordWrap;

      foreColor = e.ParentCellPaintArgs.ForePaintColor;
      //if (((BasePaintCellStates.Current & e.State) != 0) ||
      //    ((BasePaintCellStates.RowSelected & e.State) != 0)
      //)
      //  fForeColor = SystemColors.HighlightText;
      //else
      //  fForeColor = Grid.ForeColor;

      string text = GetDisplayText(e.ParentCellPaintArgs.Grid, e.DataColIndex, e.DataRowIndex);
      if (text != null)
      {

        //TextFormatFlagsEh flags = TextFormatFlagsEh.Default;
        textRect = EhLibUtils.TrimPadding(e.CellContentRect, e.ParentCellPaintArgs.Padding);

        //wordWrap = false;
        //if (wordWrap)
        //  flags = flags | TextFormatFlagsEh.WordBreak;

        e.Grid.PaintingDrawText(e.GraphicsContext, text, e.ParentCellPaintArgs.Font, textRect, foreColor, HorzAlign, VertAlign, false);

      }

      CharacterRange[] charRanges;
      string searchingText = e.Grid.GetHighlightSearchingData(e.PropAxisBar, e.ListItemBar, text, out charRanges);
      if (String.IsNullOrEmpty(searchingText))
      {
        PaintHighlightedText(e, searchingText, charRanges);
      }
    }

    protected internal virtual void PaintHighlightedText(DataAxisGridDataCellContentPaintEventArgs e, string text, CharacterRange[] charRanges)
    {
      string cellText;
      string hiS;
      Rectangle textRect;
      bool wordWrap;
      Region oldClip;
      int outOfBounds = 0;
      //CharacterRange[] charRanges;
      Rectangle paintRect = e.CellContentRect;

      cellText = GetDisplayText(e.PropAxisBar, e.ListItemBar);
      hiS = text;
      if (string.IsNullOrEmpty(hiS) == true) return;

      //if (!Grid.SearchBox.CheckTextHit(e.Column, cellText, Grid.SearchBox.SearchingText)) return;

      //charRanges = Grid.SearchBox.GetHitRanges(e.Column, e.Row, cellText);

      textRect = EhLibUtils.TrimPadding(e.CellContentRect, e.ParentCellPaintArgs.Padding);

      wordWrap = CheckWordWrap(e.PropAxisBar, paintRect);

      Rectangle[] stringRegions = EhLibUtils.MeasureCharacterRanges(e.Graphics, cellText, Font,
        textRect, HorzAlign, VertAlign, wordWrap, charRanges);
      oldClip = e.Graphics.Clip;
      e.Graphics.SetClip(paintRect, CombineMode.Intersect);

      for (int i = 0; i < stringRegions.Length; i++)
      {
        Rectangle regRect = stringRegions[i];

        if (textRect.IntersectsWith(regRect))
        {
          using (var brush = new SolidBrush(Color.Yellow))
          {
            e.Graphics.FillRectangle(brush, regRect);
          }

          string drawText = cellText.Substring(charRanges[i].First, charRanges[i].Length);

          EhLibUtils.DrawText(e.Graphics, drawText, Font, regRect, ForeColor, HorizontalAlignment.Left, VerticalAlignment.Top, TextFormatFlagsEh.None);
        }
        else
        {
          outOfBounds = outOfBounds + 1;
        }
      }

      if (outOfBounds > 0)
      {
        string outOfBoundsStr = outOfBounds.ToString();
        Font ofbFont = new Font(Font.FontFamily, 6);
        Size ofbSize = EhLibUtils.MeasureText(e.Graphics, outOfBoundsStr, ofbFont, new Size(1, 1), CellTextWrapMode.NoWrap);
        Rectangle ofbRect = new Rectangle(textRect.Right - ofbSize.Width - 2, textRect.Top, ofbSize.Width + 2, ofbSize.Height + 2);

        e.Graphics.FillRectangle(new SolidBrush(Color.Yellow), ofbRect);
        EhLibUtils.DrawText(e.Graphics, outOfBoundsStr, ofbFont, ofbRect, ForeColor, HorizontalAlignment.Center, VerticalAlignment.Center, TextFormatFlagsEh.None);
        ofbFont.Dispose();
      }

      e.Graphics.Clip = oldClip;
    }

    protected internal override bool CheckWordWrap(PropertyAxisBar propAxisBar, Rectangle paintRect)
    {
      bool wordWrap = false;
      //TODO: Postpone. Add WrapMode mode. Inherite ComboboxCellMan from TextCellMan. So WrapMode already present
      //int oneLineHeight;
      //if (WrapMode == DataGridTextWrapMode.Auto)
      //{
      //  oneLineHeight = GetOneLineHeight();
      //  if (paintRect.Height > oneLineHeight)
      //    wordWrap = true;
      //}
      //else if (WrapMode == DataGridTextWrapMode.WordWrap)
      //{
      //  wordWrap = true;
      //}
      return wordWrap;
    }

    public override bool IsCharToEnterEditMode(KeyPressEventArgs e)
    {
      UnicodeCategory uc = char.GetUnicodeCategory(e.KeyChar);
      if (uc != UnicodeCategory.Control)
        return true;

      return base.IsCharToEnterEditMode(e);
    }

    protected internal override void OnEditorOccupy(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
      DataAxisGridComboBoxEditControl editor = (DataAxisGridComboBoxEditControl)e.Editor;
      //DataAxisGridDataCellEditorParamsNeededEventArgs de = editorParams as DataAxisGridDataCellEditorParamsNeededEventArgs;

      editor.Font = e.EditorParams.Font;
      editor.ReadOnly = e.EditorParams.ReadOnly;
      editor.Padding = e.EditorParams.Padding;

      editor.PrepareEditorForEdit(e.SelectAll);
      //editor.TextAlign = HorzAlign;
      editor.SelectedIndex = -1;

      editor.DataSource = DataSource;
      editor.DisplayMember = DisplayMember;
      editor.ValueMember = ValueMember;

      editor.SetEditButton(EditButton);
      foreach (var ei in InEditControls)
        editor.InEditControls.Add(ei);
      //editor.SetExternalEditButton(EditButton);
      // TODO: RETURN editor.EditButton = EditButton;
      editor.Compound = Compound;
      editor.Items.Clear();
      editor.Items.AddRange(Items.ToArray());

      editor.ExternalDropDownBox = DropDownBox;
      editor.DropDownBox.HeightInRows = dropDownBoxVisibleRowCount;
      editor.DropDownBox.Width = dropDownBoxWidth;

      if (LookupMode)
      {
        editor.SelectedValue = e.Value;
        //if (de.ListItemBar != null)
        //  editor.SelectedValue = propAxisBar.GetValue(listItemBar);
        //  editValue = de.PropAxisBar.GetValue(de.ListItemBar);
        //else
        //  editValue = null;
      }
      else
      {
        //editor.EditorEditValue = CellManager.GetDisplayText(editorParams.AreaColIndex, editorParams.AreaRowIndex);
        editor.EditorEditValue = e.Value;
      }
    }

    protected override void OnEditorRelease(DataAxisGridDataCellEditorReleaseEventArgs e)
    {
      DataAxisGridComboBoxEditControl editor = (DataAxisGridComboBoxEditControl)e.Editor;

      editor.DataSource = null;
      editor.DisplayMember = null;
      editor.ValueMember = "";
      editor.Items.Clear();
      editor.SelectedIndex = -1;

      editor.SetEditButton(null);
      editor.InEditControls.Clear();
      //editor.SetExternalEditButton(null);
      // TODO: RETURN editor.EditButton = null;

      dropDownBoxVisibleRowCount = editor.DropDownBox.HeightInRows;
      dropDownBoxWidth = editor.DropDownBox.Width;

      editor.ExternalDropDownBox = null;
    }

    public virtual string GetCellNonfitToolTipText(BaseGridCellEventArgs e)
    {
      CellTextWrapMode wrapMode;
      SizeF sf;
      Graphics g = EhLibUtils.DisplayGraphicsCash;
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = e.Grid as DataAxisGrid;
      AxisObjectsByDataColRowIndex(axisGrid, e.AreaColIndex, e.AreaRowIndex, out propAxisBar, out listItemBar);

      string cellText = GetDisplayText(propAxisBar, listItemBar);

      DataAxisGridDataCellFormatParamsNeededEventArgs fpe = CreateProcessFormatParams(axisGrid, propAxisBar, listItemBar);

      Rectangle clientRect = GetCellClientRect(propAxisBar, listItemBar, e.CellRect);
      Rectangle contentRect = CalcContentRect(clientRect);
      Rectangle textRect = EhLibUtils.TrimPadding(contentRect, fpe.Padding);

      bool wordWrap = CheckWordWrap(propAxisBar, textRect);
      if (wordWrap)
        wrapMode = CellTextWrapMode.WordWrap;
      else
        wrapMode = CellTextWrapMode.NoWrap;

      sf = EhLibUtils.MeasureText(g, cellText, fpe.Font, textRect.Size, wrapMode);
      //sf = g.MeasureString(cellText, Grid.Font, new PointF(0, 0), StringFormat.GenericTypographic);

      if (sf.Width > textRect.Width)
        return cellText;
      else
        return "";
    }

    protected internal override void OnMouseEnter(DataAxisGridDataCellEnterEventArgs e)
    {
      base.OnMouseEnter(e);

      if (e.Grid.IsShowDataCellsNonfitTooltips())
      {
        string cellText = GetCellNonfitToolTipText(e);

        if (!string.IsNullOrEmpty(cellText))
        {
          (e.Grid as DataAxisGrid).ShowCellNonFitToolTip(cellText, this, e);
        }
      }
    }

    protected internal override void OnMouseLeave(BaseGridCellLeaveEventArgs e)
    {
      base.OnMouseLeave(e);
      (e.Grid as DataAxisGrid).HideCellNonFitToolTip();
    }

    //public virtual int GetOneLineHeight()
    //{
    //  return CalcDefaultRowHeight();
    //}

    void IObjectCollectionObserver.OnCollectionChangeAction(ObjectCollection collection, CollectionExtendedChangeAction action, int index, object oldItem, object newItem)
    {
      if (action == CollectionExtendedChangeAction.CollectionChanging ||
          action == CollectionExtendedChangeAction.ItemAdding ||
          action == CollectionExtendedChangeAction.ItemChanging ||
          action == CollectionExtendedChangeAction.ItemRemoving)
      {
        CheckNoDataSource();
      }
      else
      {
        ItemsChanged();
      }
    }

    int IObjectCollectionObserver.OnCompareCollectionItems(object item1, object item2)
    {
      string itemName1 = item1.ToString();
      string itemName2 = item2.ToString();

      CompareInfo compInfo = (Application.CurrentCulture).CompareInfo;
      return compInfo.Compare(itemName1, itemName2, CompareOptions.StringSort);
    }

    private void CheckNoDataSource()
    {
      if (DataSource != null)
      {
        throw new ArgumentException("DataSource and Items can not be used at the same time");
      }
    }

    private void ItemsChanged()
    {
      ResetItemsConnection();
    }

    private void ResetItemsConnection()
    {
      if (DataSource == null)
      {
        if (Items.Count > 0)
        {
          //TODO: Postpone. Fibish support of Items property
          //bindingSource.DataSource = Items;
          //bindingSource.DataMember = "";
        }
        else
        {
          //bindingSource.DataSource = null;
          //bindingSource.DataMember = "";
        }
      }
    }

    private void WireDataSource(object dataSource)
    {
      IComponent component = dataSource as IComponent;
      if (component != null)
      {
        component.Disposed += this.DataSource_Disposed;
      }

      ISupportInitializeNotification dsInit = this.DataSource as ISupportInitializeNotification;
      if (dsInit != null)
      {
        dsInit.Initialized += DataSource_Initialized;
        dataSourceInitialized = dsInit.IsInitialized;
      }
      else if (dataSource != null)
        dataSourceInitialized = true;

    }

    private void UnwireDataSource()
    {
      IComponent component = this.DataSource as IComponent;
      if (component != null)
      {
        component.Disposed -= DataSource_Disposed;
      }

      ISupportInitializeNotification dsInit = this.DataSource as ISupportInitializeNotification;
      if (dsInit != null)
      {
        dsInit.Initialized -= DataSource_Initialized;
      }
    }

    private void DataSource_Disposed(object sender, EventArgs e)
    {
      this.DataSource = null;
    }

    private void DataSource_Initialized(object sender, EventArgs e)
    {
      dataSourceInitialized = true;
      ResetDataSourceConnection();
    }

    private void CurrencyManagerListChanged(object sender, ListChangedEventArgs e)
    {
      DataListChanged(sender, e);
      if (e.ListChangedType == ListChangedType.PropertyDescriptorChanged)
      {
        InitializeDisplayMemberPropertyDescriptor();
        InitializeValueMemberPropertyDescriptor();
      }
      //Grid.CurrencyManagerListChanged(sender, e);
    }

    void DataListChanged(object sender, ListChangedEventArgs e)
    {
      var holder = BoundPropAxisBar as IComboBoxDataCellHolder;
      if (holder != null)
        holder.DataListChanged(sender, e);
    }

    private void ResetDataSourceConnection()
    {
      if (!dataSourceInitialized) return;

      bindingSource.DataSource = DataSource;
      bindingSource.DataMember = displayMember.BindingPath;

      InitializeDisplayMemberPropertyDescriptor();
      InitializeValueMemberPropertyDescriptor();

      InvalidateGrid();
    }

    private void InitializeDisplayMemberPropertyDescriptor()
    {
      //CurrencyManager newDataManager = null;
      PropertyDescriptor newDisplayMemberProperty;

      if (DataSource != null  /* && displayMember != null */ /* && BoundGrid != null*/)
      {
        if (string.IsNullOrEmpty(displayMember.BindingMember))
        {
          newDisplayMemberProperty = null;
        }
        else
        {
          //newDataManager = (CurrencyManager)BoundGrid.BindingContext[DataSource, displayMember.BindingPath];
          newDisplayMemberProperty= DataManager.GetItemProperties().Find(displayMember.BindingField, true);
        }
      }
      else
      {
        newDisplayMemberProperty = null;
        //newDataManager = null;
      }

      if (newDisplayMemberProperty != displayMemberProperty)
      {
        displayMemberProperty = newDisplayMemberProperty;
        DisplayMemberPropertyChanged();
      }

      //if (newDataManager != dataManager)
      //{
      //  if (dataManager != null)
      //    dataManager.ListChanged -= CurrencyManagerListChanged;
      //  dataManager = newDataManager;
      //  if (dataManager != null)
      //    dataManager.ListChanged += CurrencyManagerListChanged;
      //  DisplayMemberPropertyChanged();
      //}
    }

    protected virtual void DisplayMemberPropertyChanged()
    {
      //DisplayMemberPropertyChanged();
      UpdateLookupMode();
    }

    private void InitializeValueMemberPropertyDescriptor()
    {
      PropertyDescriptor oldValueMemberProperty = ValueMemberProperty;

      if (DataManager != null)
      {
        if (string.IsNullOrEmpty(valueMember.BindingMember))
        {
          valueMemberProperty = null;
        }
        else
        {
          valueMemberProperty = this.DataManager.GetItemProperties().Find(valueMember.BindingField, true);
        }
      }
      else
      {
        valueMemberProperty = null;
      }

      if (!ReferenceEquals(oldValueMemberProperty, valueMemberProperty))
      {
        ValueMemberPropertyChanged();
      }
    }

    protected virtual void ValueMemberPropertyChanged()
    {
      //ValueMemberPropertyChanged();
      UpdateLookupMode();
    }

    protected void UpdateLookupMode()
    {
      bool newLookupMode = (ValueMemberProperty != null && DisplayMemberProperty != null);
      if (newLookupMode != lookupMode)
      {
        lookupMode = newLookupMode;
        LookupModeChanged();
      }
    }

    protected virtual void LookupModeChanged()
    {
      var holder = BoundPropAxisBar as IComboBoxDataCellHolder;
      if (holder != null)
        holder.CellManagerLookupModeChanged();
      //LookupModeChanged();
    }

    protected override bool EditButtonDefaultVisible()
    {
      return true;
    }

    public override HorizontalAlignment DefaultHorzAlign()
    {
      if (LookupMode)
        return HorizontalAlignment.Left;
      else
        return base.DefaultHorzAlign();
    }

    protected virtual void OnCompoundChanged()
    {
      InvalidateGrid();
    }

    protected internal override int GetOptimalCellContentWidth(int colIndex, int rowIndex, int dataColIndex, int dataRowIndex,
      DataAxisGridDataCellFormatParamsNeededEventArgs fpe)
    {
      int result = base.GetOptimalCellContentWidth(colIndex, rowIndex, dataColIndex, dataRowIndex, fpe);
      result = result + CustomAreaWidth;
      return result;
      //return CellWorker.GetOptimalCellContentWidth(baseWidth, colIndex, rowIndex, dataColIndex, dataRowIndex, listItemBar, fpe);
    }

    public override string GetTypeNameAbbr()
    {
      return "CmBx";
    }

    Color IComboBoxDropDownBoxOwner.GetBackColor()
    {
      return BackColor;
    }

    Color IComboBoxDropDownBoxOwner.GetForeColor()
    {
      return ForeColor;
    }

    Font IComboBoxDropDownBoxOwner.GetFont()
    {
      return Font;
    }
    #endregion

  }

  /// <summary>
  /// Edit control that edit value in a cell that is managed by <see cref="ComboBoxDataCellManager"/> component
  /// </summary>
  /// <remarks>
  /// You can retrieve an reference to the class through the <see cref="ComboBoxDataCellManager.DefaultEditorType"/> property.
  /// </remarks>
  /// <seealso cref="EhLib.WinForms.ComboBoxEh" />
  /// <seealso cref="EhLib.WinForms.IDataAxisGridCellInPlaceEditor" />
  [ToolboxItem(false)]
  [System.ComponentModel.DesignerCategory("Code")]
  public class DataAxisGridComboBoxEditControl : ComboBoxEh, IDataAxisGridCellInPlaceEditor
  {
    private DataAxisGrid ownerGrid;
    private BaseDataCellManager cellManager;
    private int rowIndex;
    private bool valueChanged;

    public DataAxisGridComboBoxEditControl()
    {
      this.TabStop = false;
      this.Border.Style = ControlBorderStyle.None;
      InitData();
    }

    private void InitData()
    {
      this.AutoSize = false;
    }

    public object EditorEditValue
    {
      get
      {
        if (LookupMode)
          return SelectedValue;
        else
          return Text;
      }

      set
      {
        if (value == null || value == DBNull.Value)
          Text = null;
        else
          Text = value.ToString();

        valueChanged = false;
      }
    }

    public DataAxisGrid EditorOwnerGrid
    {
      get { return this.ownerGrid; }
      set { this.ownerGrid = value; }
    }

    public BaseDataCellManager CellManager
    {
      get { return cellManager; }
      set { cellManager = value; }
    }

    public DataAxisGridDataCellEditorOccupyEventArgs CellPosData
    {
      get;
      set;
    }

    public ComboBoxDataCellManager ComboBoxCellManager
    {
      get { return (ComboBoxDataCellManager)CellManager; }
    }

    public int EditorTableRowIndex
    {
      get { return this.rowIndex; }
      set { this.rowIndex = value; }
    }

    public bool EditorValueChanged
    {
      get { return this.valueChanged; }
      set { this.valueChanged = value; }
    }

    public bool EditorWantsInputKey(Keys keyData, bool dataGridWantsInputKey)
    {
      switch (keyData & Keys.KeyCode)
      {
        case Keys.Right:
          if ((this.RightToLeft == RightToLeft.No && !(this.SelectionLength == 0 && this.SelectionStart == this.Text.Length)) ||
              (this.RightToLeft == RightToLeft.Yes && !(this.SelectionLength == 0 && this.SelectionStart == 0)))
          {
            return true;
          }
          break;

        case Keys.Left:
          if ((this.RightToLeft == RightToLeft.No && !(this.SelectionLength == 0 && this.SelectionStart == 0)) ||
              (this.RightToLeft == RightToLeft.Yes && !(this.SelectionLength == 0 && this.SelectionStart == this.Text.Length)))
          {
            return true;
          }
          break;

        case Keys.Down:
          int end = this.SelectionStart + this.SelectionLength;
          if (this.Text.IndexOf("\r\n", end, StringComparison.Ordinal) != -1)
          {
            return true;
          }
          break;

        case Keys.Up:
          if (!(Text.IndexOf("\r\n", StringComparison.Ordinal) < 0 ||
                SelectionStart + SelectionLength < Text.IndexOf("\r\n", StringComparison.Ordinal)))
          {
            return true;
          }
          break;

        case Keys.Home:
        case Keys.End:
          if (this.SelectionLength != this.Text.Length)
          {
            return true;
          }
          break;

        case Keys.Prior:
        case Keys.Next:
          if (this.valueChanged)
          {
            return true;
          }
          break;

        case Keys.Delete:
          if (this.SelectionLength > 0 ||
              this.SelectionStart < this.Text.Length)
          {
            return true;
          }
          break;

        //case Keys.Enter:
        //  if ((keyData & (Keys.Control | Keys.Shift | Keys.Alt)) == Keys.Shift && this.Multiline && this.AcceptsReturn)
        //  {
        //    return true;
        //  }
        //  break;

        case Keys.Escape:
          if (ListVisible &&
              ((keyData & (Keys.Control | Keys.Shift | Keys.Alt)) == 0))
          {
            return true;
          }
          break;

      }
      return !dataGridWantsInputKey;
    }

    public void PrepareEditorForEdit(bool selectAll)
    {
      if (selectAll)
        SelectAll();
      else
        this.SelectionStart = this.Text.Length;
    }

    protected override void OnTextChanged(EventArgs e)
    {
      base.OnTextChanged(e);
      this.valueChanged = true;
      ownerGrid.EditorTextChanged(e);
    }

    protected internal override void OnCustomAreaPaint(ComboBoxCustomAreaPaintEventArgs e)
    {
      base.OnCustomAreaPaint(e);
      if (!e.Handled)
      {
        ComboBoxCellManager.OnCustomAreaPaint(e);
      }
    }
  }
}
