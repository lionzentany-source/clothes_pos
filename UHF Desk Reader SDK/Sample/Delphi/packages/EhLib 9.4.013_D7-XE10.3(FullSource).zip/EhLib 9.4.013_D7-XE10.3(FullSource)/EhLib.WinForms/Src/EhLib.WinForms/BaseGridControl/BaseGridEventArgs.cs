﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  /// <summary>
  /// Represents the base class for classes that contain event data in cells of BaseGridControl.
  /// </summary>
  public class BaseGridCellEventArgs : EventArgs
  {
    private readonly int colIndex;
    private readonly int rowIndex;
    private readonly int areaRowIndex;
    private readonly int areaColIndex;
    private readonly Rectangle cellRect;

    public BaseGridCellEventArgs(BaseGridControl grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect)
    {
      this.colIndex = colIndex;
      this.rowIndex = rowIndex;
      this.areaColIndex = areaColIndex;
      this.areaRowIndex = areaRowIndex;
      this.cellRect = cellRect;
      Grid = grid;
    }

    public BaseGridControl Grid { get; internal set; }

    public int ColIndex
    {
      get { return colIndex; }
    }

    public int RowIndex
    {
      get { return rowIndex; }
    }

    public int AreaColIndex
    {
      get { return this.areaColIndex; }
    }

    public int AreaRowIndex
    {
      get { return this.areaRowIndex; }
    }

    public Rectangle CellRect
    {
      get { return cellRect; }
    }

    public override string ToString()
    {
      return string.Format("ColIndex = {0} RowIndex = {1}",
        ColIndex, RowIndex);
    }

  }

  /// <summary>
  /// Provides data for mouse related routed events in cells of BaseGridControl that do not 
  /// specifically involve mouse buttons or the mouse wheel.
  /// </summary>
  public class BaseGridCellMouseEventArgs : HandledEventArgs
  {
    private readonly int colIndex;
    private readonly int rowIndex;
    private readonly int areaRowIndex;
    private readonly int areaColIndex;
    private readonly Rectangle cellRect;

    private readonly int inCellX;
    private readonly int inCellY;
    private readonly MouseEventArgs gridMouseArgs;
    private readonly BaseGridCellManager cellManager;

    public BaseGridCellMouseEventArgs(
      BaseGridControl grid,
      BaseGridCellManager cellManager,
      int colIndex, int rowIndex,
      int areaColIndex, int areaRowIndex,
      int inCellX, int inCellY,
      Rectangle cellRect,
      MouseEventArgs e)
    {
      if (colIndex < -1)
        throw new ArgumentOutOfRangeException("colIndex");
      if (rowIndex < -1)
        throw new ArgumentOutOfRangeException("rowIndex");
      this.colIndex = colIndex;
      this.rowIndex = rowIndex;
      this.areaColIndex = areaColIndex;
      this.areaRowIndex = areaRowIndex;
      this.inCellX = inCellX;
      this.inCellY = inCellY;
      this.cellRect = cellRect;
      this.cellManager = cellManager;
      Grid = grid;
      gridMouseArgs = e;
    }

    public BaseGridControl Grid { get; internal set; }

    public BaseGridCellManager CellManager
    {
      get { return this.cellManager; }
    }

    public int ColIndex
    {
      get { return colIndex; }
    }

    public int RowIndex
    {
      get { return rowIndex; }
    }

    public int AreaColIndex
    {
      get { return this.areaColIndex; }
    }

    public int AreaRowIndex
    {
      get { return this.areaRowIndex; }
    }

    public int InCellX
    {
      get { return inCellX; }
    }

    public int InCellY
    {
      get { return inCellY; }
    }

    public MouseEventArgs GridMouseArgs
    {
      get { return gridMouseArgs; }
    }

    public MouseButtons Button
    {
      get { return gridMouseArgs.Button; }
    }

    public Rectangle CellRect
    {
      get { return cellRect; }
    }

    public override string ToString()
    {
      return string.Format("ColIndex = {0} RowIndex = {1} InCellX = {2} InCellY = {3} Button = {4}",
        ColIndex, RowIndex, InCellX, InCellY, Button);
    }
  }

  /// <summary>
  ///  Provides data for events in cells of BaseGridControl that requests information about cell borders 
  ///  like border visibility or border color.  
  /// </summary>
  public class BaseGridCellBorderEventArgs : EventArgs
  {
    private readonly int colIndex;
    private readonly int rowIndex;
    private readonly GridCellBorderSide borderType;
    private readonly int areaRowIndex;
    private readonly int areaColIndex;

    private bool visible;
    private Color color;
    private DashStyle style;
    private bool isExtent;

    public BaseGridCellBorderEventArgs(BaseGridControl grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, GridCellBorderSide borderType)
    {
      this.colIndex = colIndex;
      this.rowIndex = rowIndex;
      this.areaColIndex = areaColIndex;
      this.areaRowIndex = areaRowIndex;
      this.borderType = borderType;
      Grid = grid;
    }

    public BaseGridControl Grid { get; internal set; }

    public int ColIndex
    {
      get { return colIndex; }
    }

    public int RowIndex
    {
      get { return rowIndex; }
    }

    public int AreaColIndex
    {
      get { return this.areaColIndex; }
    }

    public int AreaRowIndex
    {
      get { return this.areaRowIndex; }
    }

    public GridCellBorderSide BorderType
    {
      get { return borderType; }
    }

    public bool Visible
    {
      get { return visible; }
      set { visible = value; }
    }

    public Color Color
    {
      get { return color; }
      set { color = value; }
    }

    public DashStyle Style
    {
      get { return style; }
      set { style = value; }
    }

    public bool IsExtent
    {
      get { return isExtent; }
      set { isExtent = value; }
    }
  }

  /// <summary>
  /// Event args for painting event in a cell of the BaseGridControl
  /// </summary>
  public class BaseGridCellPaintEventArgs : HandledEventArgs
  {
    private Rectangle cellRect;
    private Rectangle clientRect;
    private Rectangle cellAreaRect;
    private Point inCellMousePos;

    public BaseGridCellPaintEventArgs(BaseGridControl grid, BaseGridCellManager cellManager, GraphicsContext gc, int colIndex, int rowIndex,
      Rectangle cellRect, Rectangle cellAreaRect, BasePaintCellStates state, 
      int areaColIndex, int areaRowIndex, Point inCellMousePos)
    {
      GraphicsContext = gc;
      ColIndex = colIndex;
      RowIndex = rowIndex;
      this.cellRect = cellRect;
      clientRect = cellRect;
      this.cellAreaRect = cellAreaRect;
      State = state;
      AreaColIndex = areaColIndex;
      AreaRowIndex = areaRowIndex;
      this.inCellMousePos = inCellMousePos;
      CellManager = cellManager;
      Grid = grid;
      IsPaintBackground = true;
      IsPaintForeground = true;
    }

    public void Reset(GraphicsContext gc, int colIndex, int rowIndex, Rectangle cellRect, Rectangle cellAreaRect,
      BasePaintCellStates state, int areaColIndex, int areaRowIndex, Point inCellMousePos)
    {
      GraphicsContext = gc;
      ColIndex = colIndex;
      RowIndex = rowIndex;
      this.cellRect = cellRect;
      clientRect = cellRect;
      this.cellAreaRect = cellAreaRect;
      State = state;
      AreaColIndex = areaColIndex;
      AreaRowIndex = areaRowIndex;
      this.inCellMousePos = inCellMousePos;
    }

    #region properties
    public BaseGridControl Grid { get; internal set; }

    public BaseGridCellManager CellManager { get; private set; }

    public GraphicsContext GraphicsContext { get; private set; }

    public Graphics Graphics
    {
      get { return GraphicsContext.Graphics; }
    }

    public int ColIndex { get; private set; }

    public int RowIndex { get; private set; }

    public Rectangle CellAreaRect
    {
      get { return cellAreaRect; }
      set { cellAreaRect = value; }
    }

    public Rectangle CellRect
    {
      get { return cellRect; }
      set { cellRect = value; }
    }

    public Rectangle ClientRect
    {
      get { return clientRect; }
      set { clientRect = value; }
    }

    public BasePaintCellStates State { get; set; }

    public int AreaColIndex { get; private set; }

    public int AreaRowIndex { get; private set; }

    public Point InCellMousePos
    {
      get { return inCellMousePos; }
    }

    public int InEditItemsHeight { get; set; }

    public bool IsPaintBackground { get; set; }

    public bool IsPaintForeground { get; set; }
    #endregion

    #region methods
    public virtual void Paint(BaseGridCellPaintEventArgs e)
    {
      CellManager.OnPaint(e);
    }

    public virtual void PaintBackground(BaseGridCellPaintEventArgs e)
    {
      CellManager.OnPaintBackground(e);
    }

    public virtual void PaintForeground(BaseGridCellPaintEventArgs e)
    {
      CellManager.OnPaintForeground(e);
    }
    #endregion

  }

  /// <summary>
  /// Event args for requesting the data cell editor parameters of the BaseGridControl
  /// </summary>
  public class BaseGridCellEditorParamsNeededEventArgs : BaseGridCellEventArgs
  {
    private BaseGridCellManager cellManager;

    public BaseGridCellEditorParamsNeededEventArgs(BaseGridControl grid, BaseGridCellManager cellManager, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, Rectangle.Empty)
    {
      this.cellManager = cellManager;
    }

    public bool ReadOnly { get; set; }
    //public bool CanShowEditor { get; set; }
    public Type EditorType { get; set; }

    public BaseGridCellManager CellManager
    {
      get { return cellManager; }
    }
  }

  /// <summary>
  /// Event args for requesting if editor can be shown in the data cell of the BaseGridControl
  /// </summary>
  public class BaseGridCellCanShowEditorStateNeededEventArgs : BaseGridCellEventArgs
  {
    private BaseGridCellManager cellManager;

    public BaseGridCellCanShowEditorStateNeededEventArgs(BaseGridControl grid, BaseGridCellManager cellManager, 
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, Rectangle.Empty)
    {
      this.cellManager = cellManager;
    }

    public bool CanShowEditor { get; set; }

    public BaseGridCellManager CellManager
    {
      get { return cellManager; }
    }
  }

  /// <summary>
  /// Event args for requesting mouse cursor when mouse moves above a cell in BaseGridControl
  /// </summary>
  public class BaseGridCellQueryCursorEventArgs : BaseGridCellMouseEventArgs
  {
    private Cursor cursor;

    public BaseGridCellQueryCursorEventArgs(
      BaseGridControl grid,
      BaseGridCellManager cellManager,
      int colIndex, int rowIndex,
      int areaColIndex, int areaRowIndex,
      int inCellX, int inCellY,
      Rectangle cellRect,
      MouseEventArgs e) 
      : base (grid, cellManager, colIndex, rowIndex, areaColIndex, areaRowIndex, inCellX, inCellY, cellRect, e)
    {
    }

    public Cursor Cursor
    {
      get { return this.cursor; }
      set { this.cursor = value; }
    }

  }

  /// <summary>
  /// Event args for <see cref="BaseGridControl.OnPaint"/> method in <see cref="BaseGridControl"/> control
  /// </summary>
  public class BaseGridControlPaintEventArgs : ControlPaintEventArgs
  {
    public BaseGridControlPaintEventArgs(GraphicsContext graphicsContext, Control control)
      : base(graphicsContext, control)
    {
    }

    public override void Paint(ControlPaintEventArgs e)
    {
      (Control as BaseGridControl).PaintInternal(e.GraphicsContext);
    }
  }

  /// <summary>
  /// Provides data for mouse enter event in cells of BaseGridControl
  /// </summary>
  public class BaseGridCellEnterEventArgs : BaseGridCellEventArgs
  {
    private readonly int leaveColIndex;
    private readonly int leaveRowIndex;

    public BaseGridCellEnterEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int leaveColIndex, int leaveRowIndex)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect)
    {
      this.leaveColIndex = leaveColIndex;
      this.leaveRowIndex = leaveRowIndex;
    }

    public int LeaveColIndex
    {
      get { return leaveColIndex; }
    }

    public int LeaveRowIndex
    {
      get { return leaveRowIndex; }
    }

    public override string ToString()
    {
      return string.Format("ColIndex = {0} RowIndex = {1} LeaveColIndex = {2} LeaveRowIndex = {3}",
        ColIndex, RowIndex, LeaveColIndex, LeaveRowIndex);
    }

  }

  /// <summary>
  /// Provides data for mouse leave event in cells of BaseGridControl
  /// </summary>
  public class BaseGridCellLeaveEventArgs : BaseGridCellEventArgs
  {
    private readonly int enterColIndex;
    private readonly int enterRowIndex;

    public BaseGridCellLeaveEventArgs(BaseGridControl grid, 
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int enterColIndex, int enterRowIndex)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect)
    {
      this.enterColIndex = enterColIndex;
      this.enterRowIndex = enterRowIndex;
    }

    public int EnterColIndex
    {
      get { return enterColIndex; }
    }

    public int EnterRowIndex
    {
      get { return enterRowIndex; }
    }

    public override string ToString()
    {
      return string.Format("ColIndex = {0} RowIndex = {1} EnterColIndex = {2} EnterRowIndex = {3}",
        ColIndex, RowIndex, EnterColIndex, EnterRowIndex);
    }

  }

  /// <summary>
  /// Provides data for ContextMenuStripNeeded event in cells of BaseGridControl
  /// </summary>
  public class BaseGridCellContextMenuStripNeededEventArgs : HandledEventArgs
  {
    private readonly int colIndex;
    private readonly int rowIndex;
    private readonly int areaRowIndex;
    private readonly int areaColIndex;
    private readonly Rectangle cellRect;

    private readonly int inCellX;
    private readonly int inCellY;
    private readonly int mousePosX;
    private readonly int mousePosY;
    private readonly BaseGridCellManager cellManager;

    private ContextMenuStrip contextMenuStrip;

    public BaseGridCellContextMenuStripNeededEventArgs(
      BaseGridControl grid,
      BaseGridCellManager cellManager,
      int colIndex, int rowIndex,
      int areaColIndex, int areaRowIndex,
      int inCellX, int inCellY,
      Rectangle cellRect,
      int mousePosX, int mousePosY)
    {
      if (colIndex < -1)
        throw new ArgumentOutOfRangeException("colIndex");
      if (rowIndex < -1)
        throw new ArgumentOutOfRangeException("rowIndex");
      this.colIndex = colIndex;
      this.rowIndex = rowIndex;
      this.areaColIndex = areaColIndex;
      this.areaRowIndex = areaRowIndex;
      this.inCellX = inCellX;
      this.inCellY = inCellY;
      this.cellRect = cellRect;
      this.cellManager = cellManager;
      this.mousePosX = mousePosX;
      this.mousePosY = mousePosY;
    }

    public BaseGridCellManager CellManager
    {
      get { return this.cellManager; }
    }

    public int ColIndex
    {
      get { return colIndex; }
    }

    public int RowIndex
    {
      get { return rowIndex; }
    }

    public int AreaColIndex
    {
      get { return this.areaColIndex; }
    }

    public int AreaRowIndex
    {
      get { return this.areaRowIndex; }
    }

    public int InCellX
    {
      get { return inCellX; }
    }

    public int InCellY
    {
      get { return inCellY; }
    }

    public Rectangle CellRect
    {
      get { return cellRect; }
    }

    public int MousePosX
    {
      get { return mousePosX; }
    }

    public int MousePosY
    {
      get { return mousePosY; }
    }

    public ContextMenuStrip ContextMenuStrip
    {
      get { return this.contextMenuStrip; }
      set { this.contextMenuStrip = value; }
    }

    public override string ToString()
    {
      return string.Format("ColIndex = {0} RowIndex = {1} InCellX = {2} InCellY = {3}",
        ColIndex, RowIndex, InCellX, InCellY);
    }

    public virtual void DoContextMenuStripNeeded(BaseGridCellContextMenuStripNeededEventArgs e)
    {
      e.CellManager.OnContextMenuStripNeeded(e);
    }
  }

  /// <summary>
  /// Event args for painting event in a cells free area of the BaseGridControl
  /// </summary>
  public class BaseGridCellFreeAreaPaintEventArgs : HandledEventArgs
  {
    private GraphicsContext gc;
    private int colIndex;
    private int rowIndex;
    private Rectangle areaRect;
    private BaseGridCellManager cellManager;

    public BaseGridCellFreeAreaPaintEventArgs(BaseGridControl grid, BaseGridCellManager cellManager,
      GraphicsContext gc, int colIndex, int rowIndex, Rectangle areaRect)
    {
      this.gc = gc;
      this.colIndex = colIndex;
      this.rowIndex = rowIndex;
      this.areaRect = areaRect;
      this.cellManager = cellManager;
      Grid = grid;
    }

    #region properties
    public BaseGridControl Grid { get; internal set; }

    public BaseGridCellManager CellManager
    {
      get { return cellManager; }
    }

    public GraphicsContext GraphicsContext
    {
      get { return gc; }
    }

    public Graphics Graphics
    {
      get { return gc.Graphics; }
    }

    public int ColIndex
    {
      get { return colIndex; }
    }

    public int RowIndex
    {
      get { return rowIndex; }
    }

    public Rectangle AreaRect
    {
      get { return areaRect; }
      set { areaRect = value; }
    }
    #endregion

    #region methods
    public virtual void Paint(BaseGridCellFreeAreaPaintEventArgs e)
    {
      //if (CellManager != null)
      //  CellManager.OnPaint(e);
      //else
      Grid.OnCellFreeAreaPaint(e);
    }
    #endregion

  }

  /// <summary>
  /// Event args for <see cref="GridBackground.Paint"/>  painting event 
  /// </summary>
  public class GridBackgroundPaintEventArgs : HandledEventArgs
  {

    public GridBackgroundPaintEventArgs(GridBackground gridBackground, Graphics graphics, Rectangle clipRectangle)
    {
      GridBackground = gridBackground;
      Graphics = graphics;
      ClipRectangle = clipRectangle;

      GridAxisData vertAxis = gridBackground.Grid.VertAxis;
      GridAxisData horzAxis = gridBackground.Grid.HorzAxis;

      GridRollBounds = new Rectangle(horzAxis.FixedBoundary,
                                     vertAxis.FixedBoundary,
                                     horzAxis.ContraStart - horzAxis.FixedBoundary,
                                     vertAxis.ContraStart - vertAxis.FixedBoundary);

      GridClientBounds = new Rectangle(horzAxis.GridClientStart,
                                       vertAxis.GridClientStart,
                                       horzAxis.GridClientStop - horzAxis.GridClientStart,
                                       vertAxis.GridClientStop - vertAxis.GridClientStart);
    }

    #region properties
    public GridBackground GridBackground { get; internal set; }

    public Graphics Graphics { get; internal set; }

    public Rectangle ClipRectangle { get; internal set; }

    public Rectangle GridRollBounds { get; internal set; }

    public Rectangle GridClientBounds { get; internal set; }
    #endregion

    #region methods
    public virtual void Paint(GridBackgroundPaintEventArgs e)
    {
      GridBackground.OnPaint(e);
    }

    public virtual void FillBackgroundBounds(GridBackgroundPaintEventArgs e)
    {
      GridBackground.OnFillBackgroundBounds(e);
    }
    #endregion

  }

  /// <summary>
  /// Event args for CurrentCellPosChanged event
  /// </summary>
  public class BaseGridCurrentCellPosChangedEventArgs : EventArgs
  {

    public BaseGridCurrentCellPosChangedEventArgs(int oldColIndex, int oldRowIndex)
    {
      OldColIndex = oldColIndex;
      OldRowIndex = oldRowIndex;
    }

    #region properties
    public int OldColIndex { get; private set; }

    public int OldRowIndex { get; private set; }
    #endregion

  }
}
