﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// LocateTextDirection. Used in the <see cref="DataGridEh.SearchBox"/>.
  /// </summary>
  public enum LocateTextDirection
  {
    Up, Down, All
  }

  /// <summary>
  /// LocateTextMatching. Used in the <see cref="DataGridEh.SearchBox"/>.
  /// </summary>
  public enum LocateTextMatching
  {
    Whole, StartOf, AnyPartOf
  }

  /// <summary>
  /// The way to fill the area in the left part of the grid where there are no cells.
  /// </summary>
  public enum DataGridHorzCellFreeAreaFillStyle
  {                                                             
    GridBack, TitleExtend, GridDataExtend
  }

  /// <summary>
  /// The way to fill the area in the bottom part of the grid where there are no cells.
  /// </summary>
  public enum DataGridVertCellFreeAreaFillStyle
  {
    GridBack, ColumnSolid, ColumnGradient
  }

  /// <summary>
  /// Style of sortmarking glyphs in the DataGridEh title cells.
  /// </summary>
  public enum SortMarkerStyle
  {
    Default, Framed, Solid, Themed
  }

  //[Flags]
  //public enum GridAllowedSelections
  //{
  //  Rows = 1,
  //  Cells = 2,
  //  Columns = 4,
  //  All = 8
  //}

  /// <summary>
  /// State of the Grid when user select cells by mouse with press and drag operation.
  /// </summary>
  public enum DataGridState
  {
    Normal,
    ColumnsSelecting,
    RowsSelecting,
    CellsRectSelecting
  }

  /// <summary>
  /// Defines the methods and the need to wrap text in grid cells.
  /// </summary>
  public enum CellTextWrapMode
  {
    /// <summary>
    /// Determines the ability to wrap text automatically depending on the height of the cell.
    /// </summary>
    Auto,

    /// <summary>
    /// Wrap text on a word boundary.
    /// </summary>
    WordWrap,

    /// <summary>
    /// Do not wrap text to a new line.
    /// </summary>
    NoWrap,

    /// <summary>
    /// Draw text in single line even when a NewLine char is encountered.
    /// </summary>
    ForceSingleLine
    //, WordBreak
  }

  /// <summary>
  /// The list of search scopes for the search box in the DataGridEh.
  /// </summary>
  public enum DataGridSearchBoxScope
  {
    /// <summary>
    /// The search scope is current column.
    /// </summary>
    CurrentColumn,

    /// <summary>
    /// The search scope is entire grid.
    /// </summary>
    EntireGrid
  }

  /// <summary>
  /// Zones in the grid in the horizontal division of zones.
  /// </summary>
  public enum DataGridCellAreaHorzType
  {
    Invalid, Indicator, Data, Contra
  }

  /// <summary>
  /// Zones in the grid in the vertical division of zones.
  /// </summary>
  public enum DataGridCellAreaVertType
  {
    Invalid, Title, Data, Footer
  }

  public enum DataGridCellItemPaintTime
  {
    Always, Never, WhenHot, WhenAreaHot, WhenAreaHotOrActive
  }

  public enum DataGridActiveArea
  {
    Cell, Row
  }

  public enum DataGridColumnAutoSizeConsiderRowsMode
  {
    None,
    All,
    VisibleRows,
    ConsiderRowCount
    //,StopOnExcessTime
  }

  ///// <summary>
  ///// Units used to indicate cell height. Used to declare the property Height.
  ///// </summary>
  //public enum HeightUnits
  //{
  //  Pixels, TextLines
  //}

  /// <summary>
  /// The method of drawing data in the area where cells in a column were combined with the same values.
  /// </summary>
  public enum CellMergeDuplicatesPaintKind
  {
    ClassicPaint,
    MergedPaint,
    ClassicPaintBackground
  }

  /// <summary>
  /// The object in which the sorting will be applied.
  /// </summary>
  public enum DataGridSortSide
  {
    /// <summary>
    /// The sorting is applied in DataSource object 
    /// </summary>
    DataSource,

    /// <summary>
    /// The sorting is applied in DataGrid rows 
    /// </summary>
    DataGrid,

    /// <summary>
    /// No default sorting is applied. 
    /// The developer should perform sorting in the <see cref="DataGridTitle.InteractiveSortMarkingChanged"/> event.
    /// </summary>
    Custom
  }

  public struct CellAreaType
  {
    public DataGridCellAreaHorzType HorzType;
    public DataGridCellAreaVertType VertType;
  }

  /// <summary>
  /// Interface to access <see cref="DataGridEh "/> methods from the grid designer (at design-time).
  /// </summary>
  public interface IDataGridDesigner
  {
    void PaintCellDesignData(DataGridEh grid, Graphics graphics, int colIndex, int rowIndex, Rectangle rect, BasePaintCellStates state, BaseGridCellPaintEventArgs e);
    void PaintSuperTitleCellDesignData(DataGridEh grid, DataGridSuperTitle dataGridSuperTitle, Graphics graphics, Rectangle rect);
    void InteractiveSetColWidths(int colIndex, int newSize);
    void InteractiveMoveColumn(int fromIndex, int toIndex);
    void GridMouseDown(MouseEventArgs e);
    void GridMouseUp(MouseEventArgs e);
    void GridMouseMove(MouseEventArgs e);
    void GridEndInitialization(DataGridEh grid);
  }

  /// <summary>
  /// Displays data in a customizable grid.
  /// </summary>
  [DesignerCategory("Code")]
  [Designer("EhLib.WinForms.Design.DataGridDesigner, EhLib.WinForms.Design")]
  [ToolboxItem(true)]
  [ToolboxBitmap(typeof(DataGridEh), "ToolboxBitmaps.EhLib_DataGrid.bmp")]
  //[ToolboxBitmap(typeof(DataGridEh))]
  [ComplexBindingProperties("DataSource", "DataMember")]
  [Description("Displays rows and columns of data in a grid you can customize")]
  public class DataGridEh : DataAxisGrid
  {
    #region private consts
    private const string N0Str = "0";

    private static readonly object EventKeyDataCellDisplayValueNeeded = new object();
    private static readonly object EventKeyDataCellPaint = new object();
    private static readonly object EventKeyDataCellCustomAreaPaint = new object();
    private static readonly object EventKeyDataCellClientAreaNeeded = new object();
    private static readonly object EventKeyDataCellContentPaint = new object();
    private static readonly object EventKeyDataCellFormatParamsNeeded = new object();

    private static readonly object EventKeyDataCellMouseDown = new object();
    private static readonly object EventKeyDataCellMouseMove = new object();
    private static readonly object EventKeyDataCellMouseUp = new object();
    private static readonly object EventKeyDataCellMouseClick = new object();
    private static readonly object EventKeyDataCellMouseDoubleClick = new object();
    private static readonly object EventKeyDataCellMouseEnter = new object();
    private static readonly object EventKeyDataCellMouseLeave = new object();
    private static readonly object EventKeyDataCellMouseHover = new object();
    private static readonly object EventKeyDataCellContentClick = new object();

    private static readonly object EventKeyDataCellClick = new object(); //??

    private static readonly object EventKeyDataCellCanModifyStateNeeded = new object();
    private static readonly object EventKeyDataCellCanShowEditorStateNeeded = new object();
    private static readonly object EventKeyDataCellEditorParamsNeeded = new object();
    private static readonly object EventKeyDataCellEditValueNeeded = new object();
    private static readonly object EventKeyDataCellParseValue = new object();
    private static readonly object EventKeyDataCellEditorOccupy = new object();
    private static readonly object EventKeyDataCellEditorRelease = new object();

    private static readonly object EventKeyDataCellToolTipInfo = new object();
    private static readonly object EventKeyDataCellContextMenuStripNeeded = new object();

    private static readonly object EventKeyDataCellPullValue = new object();
    private static readonly object EventKeyDataCellPushValue = new object();
    private static readonly object EventKeyDataCellManagerNeeded = new object();

    //private static readonly object EventKeyColumnTitleContextMenuStripNeeded = new object();
    private static readonly object EventKeyDataGridSelectionChanged = new object();
    private static readonly object EventKeyDataGridRowHeightNeeded = new object();
    private static readonly object EventKeyDataGridHorzLineParamsNeeded = new object();
    private static readonly object EventKeyDataGridOrderedColumnsListChanged = new object();
    private static readonly object EventKeyDataGridVisibleRowsListChanged = new object();
    private static readonly object EventKeyDataGridColumnsListChanged = new object();
    private static readonly object EventKeyDataGridColumnWidthChanged = new object();
    private static readonly object EventKeyDataGridDisplayColumnsMoved = new object();

    private static readonly object EventKeyDefaultContextMenuStripNeeded = new object();
    private static readonly object EventKeyRowIsSelectable = new object();
    private static readonly object EventKeyDynamicColumnsCreating = new object();
    private static readonly object EventKeyGridSettingsWriting = new object();
    private static readonly object EventKeyGridColumnSettingsWriting = new object();
    private static readonly object EventKeyGridSettingsReading = new object();
    private static readonly object EventKeyGridColumnSettingsReading = new object();
    private static readonly object EventKeyRowVisibleStateNeeded = new object();
    private static readonly object EventKeyCellFreeAreaPaint = new object();
    private static readonly object EventKeyCurrentCellPosChanged = new object();
    #endregion private consts

    #region privates
    private readonly DataGridRows rows;

    internal readonly DataGridVisibleRows VisibleRowList;
    internal readonly DataGridSortedRows SortedRowList;
    internal readonly RowListsManager RowListsManager;

    private readonly DataGridFooter footer;
    private readonly DataGridColumnOptions columnOptions;
    private readonly DataGridRowOptions rowOptions;
    private readonly DataGridFooterCellManager footerCell;
    private readonly DataGridSelection selection;

    private readonly DataGridEmptyTitleCellMan emptyTitleCell;
    internal readonly DataGridTitleCellMan TitleCellMan;
    private readonly DataGridEmptyDataCellMan emptyDataCell;

    private readonly DataGridIndicatorDataCellMan indicatorCell;
    private readonly DataGridIndicatorTitleCellMan titleIndicatorCell;
    private bool gridIsEmpty;
    private readonly DataGridAutoSizeColumnOptions autoSizeColumnOptions;
    private DataGridIndicatorColumn indicatorColumn;
    private DataGridIndicatorTitle indicatorTitle;
    private DataGridTreeViewArea treeViewArea;
    private object addedSrcRow;
    private readonly GridEmptyDataInfo emptyDataInfo;

    private readonly DataGridSearchBox searchBox;
    private readonly DataGridLocateTextService locateTextService;

    private readonly DataGridAllowedOperations allowedOperations;
    private bool titleTreePainted;
    private bool[,] dataCellPaintedArray = new bool[0, 0];

    private DataGridState dataGridState = DataGridState.Normal;

    private readonly DataGridEditActions editActions;
    private int internalCurrentRowIndex;

    private Padding leftAlignDefaultPadding;
    private Padding centerAlignDefaultPadding;
    private Padding rightAlignDefaultPadding;

    private int defaultDataRowHeight;
    private int titleRowIndex;

    private DataGridSearchBoxControl searchBoxControl;
    public IDataGridDesigner DataGridDesigner;
    private DataGridPrintService printService;
    private readonly DataGridDataView dataView;
    private readonly BindingSource dataViewBindingSource;
    private readonly DataGridServiceCellManagerList extraCellManagers;
    private bool internalDataViewCurrencyManagerPositionSetting;
    private bool internalDataResetting;
    private bool inUpdateOutBoundaryIndents;
    #endregion

    #region constructor
    /// <summary>Initializes a new instance of the <see cref="DataGridEh"/> class.</summary>
    public DataGridEh()
    {
      //return;

      rows = new DataGridRows(this);
      VisibleRowList = new DataGridVisibleRows(this);
      SortedRowList = new DataGridSortedRows(this);
      RowListsManager = new RowListsManager(this);

      Options = GridOptions.DrawFocusSelected | GridOptions.Editing |
                 //GridOptions.RowSizing | 
                 GridOptions.ColSizing |
                 //GridOption.RowMoving | //GridOption.ColMoving | 
                 GridOptions.Tabs |
                 GridOptions.ContraHorzBoundaryLine | GridOptions.ContraVertBoundaryLine;

      this.ColCount = 2;
      this.RowCount = 2;

      columnOptions = new DataGridColumnOptions(this);
      UpdatePaddingsForSidePadding();

      rowOptions = new DataGridRowOptions(this);

      footer = new DataGridFooter(this);
      footerCell = new DataGridFooterCellManager();
      footerCell.BoundGrid = this;

      emptyTitleCell = new DataGridEmptyTitleCellMan();
      emptyTitleCell.BoundGrid = this;
      TitleCellMan = new DataGridTitleCellMan();
      TitleCellMan.BoundGrid = this;

      emptyDataCell = new DataGridEmptyDataCellMan();
      emptyDataCell.BoundGrid = this;
      indicatorCell = new DataGridIndicatorDataCellMan();
      indicatorCell.BoundGrid = this;
      titleIndicatorCell = new DataGridIndicatorTitleCellMan();
      titleIndicatorCell.BoundGrid = this;

      autoSizeColumnOptions = new DataGridAutoSizeColumnOptions(this);

      searchBox = new DataGridSearchBox(this);
      locateTextService = new DataGridLocateTextService(this);

      selection = new DataGridSelection(this);
      editActions = new DataGridEditActions(this);
      allowedOperations = new DataGridAllowedOperations(this);
      emptyDataInfo = new GridEmptyDataInfo(this);

      ContextMenuBuildingMode = ContextMenuBuildingMode.LocalAndGlobalMenuCompound;

      dataView = new DataGridDataView(this);
      dataViewBindingSource = new BindingSource();
      dataViewBindingSource.PositionChanged += DataViewCurrencyManagerPositionChanged;
      dataViewBindingSource.DataSource = dataView;

      extraCellManagers = new DataGridServiceCellManagerList(this);

      InitData();

      UpdateBaseFixedBands();
      UpdateColumnsList();
      RowListsManager.RebuildRows();
    }

    internal void InitData()
    {
      indicatorTitle = CreateIndicatorTitle();
      //keyboardOptions = CreateKeyKeyboardOptions();
      UpdateGridState();
    }

    protected override void DoDispose(bool disposing)
    {
      if (disposing)
      {
        if (Footer != null)
        {
          for (int i = Footer.Rows.Count - 1; i >= 0; i--)
          {
            DataGridFooterRow row = Footer.Rows[i];
            //Footer.Rows.Remove(row);
            row.Dispose();
          }
        }

        //Title.MultiTitle.DisposeSuperTitles();

        if (footer != null) footer.Dispose();
        if (footerCell != null) footerCell.Dispose();
        if (emptyTitleCell != null) emptyTitleCell.Dispose();
        if (TitleCellMan != null) TitleCellMan.Dispose();
        if (emptyDataCell != null) emptyDataCell.Dispose();
        if (indicatorCell != null) indicatorCell.Dispose();
        if (titleIndicatorCell != null) titleIndicatorCell.Dispose();
        if (searchBox != null) searchBox.Dispose();
        if (dataViewBindingSource != null)
        {
          dataViewBindingSource.DataSource = null;
          dataViewBindingSource.Dispose();
        }
        if (emptyDataInfo != null) emptyDataInfo.Dispose();
        if (indicatorTitle != null) indicatorTitle.Dispose();
        if (treeViewArea != null) treeViewArea.Dispose();
        if (indicatorColumn != null) indicatorColumn.Dispose();

        //StaticPropBars.Clear();
      }

      base.DoDispose(disposing);
    }
    #endregion

    #region >designtime properties

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataGridEmptyDataCellMan EmptyDataCell
    {
      get { return emptyDataCell; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    //[Editor(typeof(Design.DataGridColumnsEditor), typeof(UITypeEditor))]
    [Editor("EhLib.WinForms.Design.DataGridColumnsEditor" + EhLibUtils.EhLibDesignDesignerVersionInfo, "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    public DataGridStaticColumnCollection StaticColumns
    {
      get { return (DataGridStaticColumnCollection)base.StaticPropBars; }
    }

    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    //public List<DataGridColumn> StaticColumns2
    //{
    //  get { return staticColumns2; }
    //}

    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    //public List<DataGridColumnTitle> StaticColumnTitles2
    //{
    //  get { return staticColumnTitles2; }
    //}

    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    //public List<IMultiTitleNodeProvider> MultiTitleNodes
    //{
    //  get { return multiTitleNodes; }
    //}

    /// <summary>
    /// Contains properties for setting, managing multiselection and highlighting the current position in the grid.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridSelection Selection
    {
      get { return selection; }
    }

    /// <summary>
    /// Contains properties for customizing the display of all grid columns.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridColumnOptions ColumnOptions
    {
      get { return columnOptions; }
    }

    /// <summary>
    /// Contains properties for customizing the display of grid rows.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridRowOptions RowOptions
    {
      get { return rowOptions; }
    }

    /// <summary>
    /// Contains properties for creation and customizing a grid footer.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridFooter Footer
    {
      get { return footer; }
    }

    /// <summary>
    /// Contains properties for customizing display information when there are no records in the grid.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridEmptyDataInfo EmptyDataInfo
    {
      get { return emptyDataInfo; }
    }

    /// <summary>
    /// Contains properties for allowing / disallowing editing operations in the grid, such as adding, changing or deleting records.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridAllowedOperations AllowedOperations
    {
      get
      {
        return allowedOperations;
      }
    }

    /// <summary>
    /// Contains properties for customizing respond on pressing some keys.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public new DataGridKeyboardOptions KeyboardOptions
    {
      get
      {
        return (DataGridKeyboardOptions)base.KeyboardOptions;
      }
    }

    /// <summary>
    /// Contains properties for customizing title row.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridTitle Title
    {
      get { return (DataGridTitle)base.TitleBar; }
    }

    /// <summary>
    /// Contains properties for customizing horizontal scroll bar.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public new DataGridHorzScrollBar HorzScrollBar
    {
      get { return (DataGridHorzScrollBar)base.HorzScrollBar; }
    }

    /// <summary>
    /// Contains properties for customizing vertical scroll bar.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public new DataGridVertScrollBar VertScrollBar
    {
      get { return (DataGridVertScrollBar)base.VertScrollBar; }
    }

    /// <summary>
    /// Contains properties for automatic calculation of columns where a fixed width is not specified.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridAutoSizeColumnOptions AutoSizeColumnOptions
    {
      get { return autoSizeColumnOptions; }
    }

    /// <summary>
    /// Contains properties for customizing indicator column.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridIndicatorColumn IndicatorColumn
    {
      get
      {
        if (indicatorColumn == null)
          indicatorColumn = CreateIndicatorColumn();
        return indicatorColumn;
      }
    }

    /// <summary>
    /// Contains properties for customizing top-left indicator title cell.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridIndicatorTitle IndicatorTitle
    {
      get { return indicatorTitle; }
    }

    /// <summary>
    /// Contains properties and events for customizing tree node sign.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridTreeViewArea TreeViewArea
    {
      get
      {
        if (treeViewArea == null)
          treeViewArea = CreateTreeViewArea();
        return treeViewArea;
      }
    }

    /// <summary>
    /// Contains properties customizing clipboard operations.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridEditActions EditActions
    {
      get { return editActions; }
    }

    /// <summary>
    /// Contains properties and events for managing an object - SearchBox. 
    /// Using the SearchBox, user can conveniently search for data in the DataGridEh.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridSearchBox SearchBox
    {
      get { return searchBox; }
      //      set { FVertScrollBar = value; }
    }

    /// <summary>
    /// Gets or sets a value indicating whether columns are created automatically when the DataSource or DataMember properties are set.
    /// </summary>
    public bool AutoGenerateColumns
    {
      get { return AutoGeneratePropBars; }
      set { AutoGeneratePropBars = value; }
    }


    /// <summary>
    /// Contains properties for customizing dividing lines between grid cells.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridLineOptions LineOptions
    {
      get { return (DataGridLineOptions)GridLineColors; }
    }

    /// <summary>
    /// Gets or sets a value indicating whether visual styles are enabled when draw cells background.
    /// </summary>
    [Browsable(true)]
    public new bool UseVisualStyles
    {
      get
      {
        return base.UseVisualStyles;
      }

      set
      {
        base.UseVisualStyles = value;
      }
    }

    /// <summary>
    /// Defines the style of drawing background in the fixed area of a grid.
    /// </summary>
    [Browsable(true)]
    public new CellBackFiller FixedBackFiller
    {
      get
      {
        return base.FixedBackFiller;
      }
    }

    /// <summary>
    /// Contains properties customizing the grid background image.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public new GridBackground Background
    {
      get { return base.Background; }
    }

    /// <summary>
    /// Specifies how to build the context menu. The final context menu can be composed of several intermediate context menus.
    /// </summary>
    [DefaultValue(ContextMenuBuildingMode.LocalAndGlobalMenuCompound)]
    public ContextMenuBuildingMode ContextMenuBuildingMode
    {
      get;
      set;
    }

    /// <summary>
    /// Contains properties and methods to print or preview DataGridEh.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
    [Editor("EhLib.WinForms.Design.PrintServiceComponentEditor" + EhLibUtils.EhLibDesignDesignerVersionInfo, "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    [DefaultValue(null)]
    public DataGridPrintService PrintService
    {
      get
      {
        return printService;
      }
      set
      {
        if (printService != value)
        {
          if (printService != null)
            printService.Dispose();

          printService = value;
        }
      }
    }

    /// <summary>
    /// Collection of extra data cell managers that can be used in DataCellManagerNeeded event handler.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    [Editor("EhLib.WinForms.Design.DataGridDynaColumnCellsEditor" + EhLibUtils.EhLibDesignDesignerVersionInfo, "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    public DataGridServiceCellManagerList ExtraCellManagers
    {
      get { return extraCellManagers; }
    }

    #endregion designtime properties

    #region >runtime properties
    [Browsable(false)]
    public int TitleRowIndex
    {
      get { return titleRowIndex; }
    }

    [Browsable(false)]
    public bool GridIsEmpty
    {
      get { return gridIsEmpty; }
    }

    protected internal DataGridState DataGridState
    {
      get
      {
        return dataGridState;
      }
      set
      {
        dataGridState = value;
      }
    }

    [Browsable(false)]
    public override int CurrentDataColIndex
    {
      get { return Col - StartDataColIndex; }
    }

    [Browsable(false)]
    public override int CurrentDataRowIndex
    {
      get { return Row - FixedRowCount; }
    }

    [Browsable(false)]
    public DataGridReadOnlyColumnCollection DynamicColumns
    {
      get { return (DataGridReadOnlyColumnCollection)DynamicPropBars; }
    }

    /// <summary>Gets collection of columns combined by StaticColumns and DynamicColumns.</summary>
    [Browsable(false)]
    public DataGridMainColumnCollection Columns
    {
      get { return (DataGridMainColumnCollection)PropBars; }
    }

    /// <summary>Gets the view ordered columns. The columns ordered by DisplayIndex property value.</summary>
    [Browsable(false)]
    public DataGridReadOnlyColumnCollection ViewOrderedColumns
    {
      get { return (DataGridReadOnlyColumnCollection)ViewOrderedPropBars; }
    }

    /// <summary>Gets the visible and ordered columns.</summary>
    [Browsable(false)]
    public DataGridReadOnlyColumnCollection VisibleColumns
    {
      get { return (DataGridReadOnlyColumnCollection)VisiblePropBars; }
    }

    /// <summary>
    /// Collection of rows in DataGridEh.
    /// </summary>
    [Browsable(false)]
    public DataGridRows Rows
    {
      get { return rows; }
    }

    [Browsable(false)]
    public DataGridSortedRows SortedRows
    {
      get { return SortedRowList; }
    }

    /// <summary>
    /// Collection of visible rows in DataGridEh.
    /// </summary>
    [Browsable(false)]
    public DataGridVisibleRows VisibleRows
    {
      get { return VisibleRowList; }
    }

    /// <summary>
    /// Get DataGridDataView object, an internal data list that is binded to the external DataSource 
    /// and restrict list of items by the filters applyed in the DataGridEh. 
    /// </summary>
    [Browsable(false)]
    public DataGridDataView DataView
    {
      get { return dataView; }
    }

    [Browsable(false)]
    public BindingSource DataViewBindingSource
    {
      get { return dataViewBindingSource; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int CurrentColumnIndex
    {
      get
      {
        return Col - StartDataColIndex;
      }
      set
      {
        //Col = value + StartDataColIndex;
        InteractiveFocusCell(value + StartDataColIndex, Row, InteractiveActionSource.Other);
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int CurrentRowIndex
    {
      get
      {
        return InternalCurrentRowIndex;
      }

      set
      {
        if (value == -1)
          InternalCurrentRowIndex = -1;
        else
        {
          InteractiveFocusCell(Col, value + StartDataRowIndex, InteractiveActionSource.Other);
          //if (DataLink.Position != VisibleRows[value].Index)
          //  DataLink.Position = VisibleRows[value].Index;
          //else
          //  InternalCurrentRowIndex = value;
        }
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataGridRow CurrentRow
    {
      get
      {
        if (VisibleRows.Count == 0 || CurrentRowIndex == -1)
          return null;
        else
          return VisibleRows[CurrentRowIndex];
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int NewRowIndex
    {
      get
      {
        if (DataLink.CurrentListItemState == RowEditState.New)
          return Row;
        else if (AllowedOperations.AllowAdd)
          return VisibleRows.Count + FixedRowCount;
        else
          return -1;
      }
    }

    //[Browsable(false)]
    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    //public DataGridRow NewRow
    //{
    //  get;
    //  internal set;
    //}

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public new DataGridDrawStyle DrawStyle
    {
      get
      {
        return (DataGridDrawStyle)base.DrawStyle;
      }
      set
      {
        base.DrawStyle = value;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected internal int InternalCurrentRowIndex
    {
      get
      {
        return internalCurrentRowIndex;
      }

      set
      {
        if (internalCurrentRowIndex != value)
        {
          internalCurrentRowIndex = value;
          if (internalCurrentRowIndex != -1)
            Row = internalCurrentRowIndex + FixedRowCount;
          InvalidateRow(Row);
        }
      }
    }

    protected internal new DataGridScrollBarPanelControl HorzScrollBarPanelControl
    {
      get { return (DataGridScrollBarPanelControl)base.HorzScrollBarPanelControl; }
    }

    /// <summary>Gets the index of the indicator column or -1 if IndicatorColumn is not visible.</summary>
    [Browsable(false)]
    public int IndicatorColIndex
    {
      get
      {
        if (IndicatorColumn.Visible)
          return 0;
        else
          return -1;
      }
    }

    /// <summary>Gets the start index of the data columns.</summary>
    [Browsable(false)]
    public int StartDataColIndex
    {
      get
      {
        return IndicatorColIndex + 1;
      }
    }

    /// <summary>Gets the start index of the data rows.</summary>
    [Browsable(false)]
    public int StartDataRowIndex
    {
      get
      {
        return FixedRowCount;
      }
    }

    //[Browsable(false)]
    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    //public DataGridSettingsKeeper SettingsKeeper
    //{
    //  get { return settingsKeeper; }
    //}

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected internal override PropertyAxisBar CurrentPropBar
    {
      get
      {
        if (CurrentColumnIndex < VisibleColumns.Count)
          return VisibleColumns[CurrentColumnIndex];
        else
          return null;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected internal override DataAxisGridListItemBar CurrentListItemBar
    {
      get { return CurrentRow; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected override bool FullRedrawOnScroll
    {
      get
      {
        bool result = base.FullRedrawOnScroll;

        result = result | EmptyDataInfo.Showing;

        if (!result)
        {
          foreach (DataGridColumn col in VisibleColumns)
          {
            if (col.IsFullInvalidateOnVertScroll())
            {
              result = true;
              break;
            }
          }
        }
        return result;
      }
    }

    public override ISite Site
    {
      get
      {
        return base.Site;
      }
      set
      {
        base.Site = value;

        if (value != null)
        {
          //INestedContainer nc = (INestedContainer)this.Site.GetService(typeof(INestedContainer));
          //if (nc != null)
          //{
          //  //nc.Add(Title, "Title");

          //  //nc.Add(SearchBox, "SearchBox");
          //  ////nc.Add(StaticColumns, "StaticColumns");
          //  //nc.Add(Footer, "Footer");
          //  //nc.Add(HorzScrollBar, "HorzScrollBar");
          //  //nc.Add(VertScrollBar, "VertScrollBar");
          //  //nc.Add(IndicatorColumn, "IndicatorColumn");
          //  //nc.Add(IndicatorTitle, "IndicatorTitle");
          //  //nc.Add(TreeViewArea, "TreeViewArea");
          //}
        }
      }
    }

    /// <summary>Gets the windows control that service the search box area.</summary>
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataGridSearchBoxControl SearchBoxControl
    {
      get
      {
        if (searchBoxControl == null)
        {
          searchBoxControl = CreateSearchBoxControl();
          Controls.Add(searchBoxControl);
        }
        return searchBoxControl;
      }
    }
    #endregion runtime properties

    #region >events
    /// <summary>
    /// Occurs when the grid request the display value for the date cell position specified by Column and Row
    /// </summary>
    public event EventHandler<DataGridDataCellDisplayValueNeededEventArgs> DataCellDisplayValueNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellDisplayValueNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellDisplayValueNeeded, value);
      }
    }

    //public event KeyEventHandler MyKeyDown
    //{
    //  add
    //  remove
    //}

    public event EventHandler<DataGridDataCellEventArgs> DataCellClick
    {
      add
      {
        Events.AddHandler(EventKeyDataCellClick, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellClick, value);
      }
    }

    /// <summary>
    /// Occurs when the user clicks on the content part of the data cell with the mouse or keyboard.
    /// </summary>
    /// <remarks>
    ///   This event can be used to catch the click event on the text when DataGridTextColumn.CellDataIsLink or
    ///   click on the DataGridButtonColumn
    /// </remarks>
    public event EventHandler<DataGridDataCellEventArgs> DataCellContentClick
    {
      add
      {
        Events.AddHandler(EventKeyDataCellContentClick, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellContentClick, value);
      }
    }

    /// <summary>
    /// Occurs when the user presses a mouse button while the mouse pointer is 
    /// within the boundaries of a "data" cell.
    /// </summary>
    public event EventHandler<DataGridDataCellMouseEventArgs> DataCellMouseDown
    {
      add
      {
        Events.AddHandler(EventKeyDataCellMouseDown, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellMouseDown, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer moves over the boundaries of a "data" cell.
    /// </summary>
    public event EventHandler<DataGridDataCellMouseEventArgs> DataCellMouseMove
    {
      add
      {
        Events.AddHandler(EventKeyDataCellMouseMove, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellMouseMove, value);
      }
    }

    /// <summary>
    /// Occurs when the user releases a mouse button while over a "data" cell.
    /// </summary>
    public event EventHandler<DataGridDataCellMouseEventArgs> DataCellMouseUp
    {
      add
      {
        Events.AddHandler(EventKeyDataCellMouseUp, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellMouseUp, value);
      }
    }

    /// <summary>
    /// Occurs whenever the user clicks anywhere on a "data" cell with the mouse.
    /// </summary>
    [Description("Occurs whenever the user clicks anywhere on a \"data\" cell with the mouse")]
    public event EventHandler<DataGridDataCellMouseEventArgs> DataCellMouseClick
    {
      add
      {
        Events.AddHandler(EventKeyDataCellMouseClick, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellMouseClick, value);
      }
    }

    /// <summary>
    /// Occurs when a "data" cell within the DataGridEh is double-clicked.
    /// </summary>
    public event EventHandler<DataGridDataCellMouseEventArgs> DataCellMouseDoubleClick
    {
      add
      {
        Events.AddHandler(EventKeyDataCellMouseDoubleClick, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellMouseDoubleClick, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer enters a "data" cell.
    /// </summary>
    public event EventHandler<DataGridDataCellEnterEventArgs> DataCellMouseEnter
    {
      add
      {
        Events.AddHandler(EventKeyDataCellMouseEnter, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellMouseEnter, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer leaves a "data" cell.
    /// </summary>
    public event EventHandler<DataGridDataCellLeaveEventArgs> DataCellMouseLeave
    {
      add
      {
        Events.AddHandler(EventKeyDataCellMouseLeave, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellMouseLeave, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer rests on the "data" cell.
    /// </summary>
    public event EventHandler<DataGridDataCellMouseEventArgs> DataCellMouseHover
    {
      add
      {
        Events.AddHandler(EventKeyDataCellMouseHover, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellMouseHover, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager requests ContextMenuStrip before MenuStrip is shown.
    /// </summary>
    /// <remarks>
    /// Assign e.ContextMenuStrip property by the MenuStrip you want to be shown.
    /// </remarks>
    public event EventHandler<DataGridDataCellContextMenuStripNeededEventArgs> DataCellContextMenuStripNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellContextMenuStripNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellContextMenuStripNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when the grid take value from the DataSource to draw, edit or for other needs.
    /// </summary>
    /// <remarks>
    /// Set e.Handled to true if you take value inside for grid cell the event handler.
    /// </remarks>
    public event EventHandler<DataGridDataCellPullValueEventArgs> DataCellPullValue
    {
      add
      {
        Events.AddHandler(EventKeyDataCellPullValue, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellPullValue, value);
      }
    }

    /// <summary>
    /// Occurs when the grid write changed value from Editor to the DataSource.
    /// </summary>
    public event EventHandler<DataGridDataCellPushValueEventArgs> DataCellPushValue
    {
      add
      {
        Events.AddHandler(EventKeyDataCellPushValue, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellPushValue, value);
      }
    }

    /// <summary>
    /// Occurs every time when certain actions like MouseDown, MouseClick, ProcessPaint, ShowEditor etc
    /// should be processed in a specific cell position in the data area.
    /// </summary>
    /// <remarks>
    /// After the grid has received a cell manager, it calls the appropriate method in the manager 
    /// object so that the action is processed by the cell manager. The event handler must return 
    /// the correct cell manager for the specified column and row. By default, the grid uses 
    /// the manager specified in the Column.CellManager property.
    /// </remarks>    
    public event EventHandler<DataGridDataCellManagerNeededEventArgs> DataCellManagerNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellManagerNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellManagerNeeded, value);
      }
    }

    public event EventHandler<DataGridDefaultContextMenuStripNeededEventArgs> DefaultContextMenuStripNeeded
    {
      add { Events.AddHandler(EventKeyDefaultContextMenuStripNeeded, value); }
      remove { Events.RemoveHandler(EventKeyDefaultContextMenuStripNeeded, value); }
    }

    /// <summary>
    /// Occurs when user click in the indictor are to select row.
    /// The event handle can disable the selection of a row by setting the e.RowIsSelectable to false.
    /// </summary>
    public event EventHandler<DataGridRowIsSelectableEventArgs> RowIsSelectable
    {
      add { Events.AddHandler(EventKeyRowIsSelectable, value); }
      remove { Events.RemoveHandler(EventKeyRowIsSelectable, value); }
    }

    /// <summary>
    /// Occurs when a selected area in the grid is changed
    /// </summary>
    public event EventHandler<DataGridSelectionChangeOperationEventArgs> SelectionChanged
    {
      add
      {
        Events.AddHandler(EventKeyDataGridSelectionChanged, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataGridSelectionChanged, value);
      }
    }

    /// <summary>
    /// Occurs when a grid calculate a height of a data row.
    /// The event handle can write new value in the e.RowHeight property.
    /// </summary>
    public event EventHandler<DataGridRowHeightNeededEventArgs> RowHeightNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataGridRowHeightNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataGridRowHeightNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a grid draw horizontal line of a data cell. You can change line color, style or visibility.
    /// </summary>
    public event EventHandler<DataGridHorzLineParamsNeededEventArgs> HorzLineParamsNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataGridHorzLineParamsNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataGridHorzLineParamsNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when list of columns in Columns collection was changed.
    /// </summary>
    public event EventHandler ColumnsListChanged
    {
      add
      {
        Events.AddHandler(EventKeyDataGridColumnsListChanged, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataGridColumnsListChanged, value);
      }
    }

    /// <summary>
    /// Occurs when list of columns in OrderedColumns collection was changed. 
    /// </summary>
    /// <remarks>
    /// Orders of columns in OrderedColumns collection is defined by Column.DisplayIndex property.
    /// </remarks>    
    public event EventHandler OrderedColumnsListChanged
    {
      add
      {
        Events.AddHandler(EventKeyDataGridOrderedColumnsListChanged, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataGridOrderedColumnsListChanged, value);
      }
    }

    /// <summary>
    /// Occurs when list visible rows was changed. Visible list changes when filters are applied to the grid.
    /// </summary>
    public event EventHandler VisibleRowsListChanged
    {
      add
      {
        Events.AddHandler(EventKeyDataGridVisibleRowsListChanged, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataGridVisibleRowsListChanged, value);
      }
    }

    /// <summary>
    /// Occurs when the property Width of one of the columns was changes.
    /// </summary>
    public event EventHandler<DataGridColumnEventArgs> ColumnWidthChanged
    {
      add
      {
        Events.AddHandler(EventKeyDataGridColumnWidthChanged, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataGridColumnWidthChanged, value);
      }
    }

    /// <summary>
    /// Occurs when the display order of columns was changed.
    /// </summary>
    public event EventHandler<DataGridDisplayColumnsMovedEventArgs> DisplayColumnsMoved
    {
      add
      {
        Events.AddHandler(EventKeyDataGridDisplayColumnsMoved, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataGridDisplayColumnsMoved, value);
      }
    }

    /// <summary>
    /// Occurs before a grid opens cell editor when a data cell editor params 
    /// such as BackColor, Font, etc should be specified.
    /// </summary>
    public event EventHandler<DataGridDataCellEditorParamsEventArgs> DataCellEditorParamsNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellEditorParamsNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellEditorParamsNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager converts datasource cell value to the value for the editor.
    /// </summary>
    public event EventHandler<DataGridDataCellEditValueNeededEventArgs> DataCellEditValueNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellEditValueNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellEditValueNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager converts a value from the editor to the value for datasource.
    /// </summary>
    public event EventHandler<DataGridDataCellParseValueEventArgs> DataCellParseValue
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellParseValue, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellParseValue, value);
      }
    }

    /// <summary>
    /// Occurs when the data cell editor requests and sets its readonly state.
    /// </summary>
    public event EventHandler<DataGridDataCellCanModifyStateNeededEventArgs> DataCellCanModifyStateNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellCanModifyStateNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellCanModifyStateNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when the grid is going to show the data cell editor.
    /// </summary>
    /// <remarks>
    /// Set e.CanShowEditor to false to prevent editor showing.
    /// </remarks>
    public event EventHandler<DataGridDataCellCanShowEditorStateNeededEventArgs> DataCellCanShowEditorStateNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellCanShowEditorStateNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellCanShowEditorStateNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when grid creates dinamic column (or columns) for data property of DataSource.
    /// </summary>
    public event EventHandler<DataGridDynamicColumnsCreatingEventArgs> DynamicColumnsCreating
    {
      add
      {
        Events.AddHandler(EventKeyDynamicColumnsCreating, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDynamicColumnsCreating, value);
      }
    }

    /// <summary>
    /// Occurs when a grid writes grid settings to the dictionary of property values.
    /// The event is fired in the <see cref="GetStorableSettings()"/> method.
    /// </summary>
    public event EventHandler<DataGridStorableSettingsWritingEventArgs> GridSettingsWriting
    {
      add
      {
        Events.AddHandler(EventKeyGridSettingsWriting, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyGridSettingsWriting, value);
      }
    }

    /// <summary>
    /// Occurs when a grid writes column settings to the dictionary of property values.
    /// The event is fired in the <see cref="GetStorableSettings()"/> method.
    /// </summary>
    public event EventHandler<DataGridColumnStorableSettingsWritingEventArgs> GridColumnSettingsWriting
    {
      add
      {
        Events.AddHandler(EventKeyGridColumnSettingsWriting, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyGridColumnSettingsWriting, value);
      }
    }

    /// <summary>
    /// Occurs when a grid reads grid settings from the dictionary to property values.
    /// The event is fired in the <see cref="ReadStorableSettings(Dictionary{string, object})"/> method.
    /// </summary>
    public event EventHandler<DataGridStorableSettingsReadingEventArgs> GridSettingsReading
    {
      add
      {
        Events.AddHandler(EventKeyGridSettingsReading, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyGridSettingsReading, value);
      }
    }

    /// <summary>
    /// Occurs when a grid reads column settings from the dictionary to property values.
    /// The event is fired in the <see cref="ReadStorableSettings(Dictionary{string, object})"/> method.
    /// </summary>
    public event EventHandler<DataGridColumnStorableSettingsReadingEventArgs> GridColumnSettingsReading
    {
      add
      {
        Events.AddHandler(EventKeyGridColumnSettingsReading, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyGridColumnSettingsReading, value);
      }
    }

    /// <summary>
    /// Occurs when a "data" cell paint params like BackColor, Font, etc should be specified.
    /// </summary>
    /// <remarks>
    /// By default these params are assigned by column properties
    /// </remarks>    
    public event EventHandler<DataGridDataCellFormatParamsNeededEventArgs> DataCellFormatParamsNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellFormatParamsNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellFormatParamsNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell in the grid data area needs to be drawn.
    /// </summary>
    public event EventHandler<DataGridDataCellPaintEventArgs> DataCellPaint
    {
      add
      {
        Events.AddHandler(EventKeyDataCellPaint, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellPaint, value);
      }
    }

    /// <summary>
    /// Occurs when a custom area inside the data cell needs to be drawn.
    /// Write <see cref="DataCellClientAreaNeeded"/> event handler to specify the size of client rectangle and 
    /// define custom area outside the client.
    /// </summary>
    public event EventHandler<DataGridDataCellPaintEventArgs> DataCellCustomAreaPaint
    {
      add
      {
        Events.AddHandler(EventKeyDataCellCustomAreaPaint, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellCustomAreaPaint, value);
      }
    }

    /// <summary>
    /// Occurs when a client rectangle should be specified.
    /// The area outside the client rectangle is a custom area.
    /// </summary>
    public event EventHandler<DataGridDataCellClientAreaNeededEventArgs> DataCellClientAreaNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellClientAreaNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellClientAreaNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager occupy the editor before open and edit cell value.
    /// </summary>
    /// <remarks>
    /// The grid uses a shared cell editor for the columns of same types.
    /// </remarks>
    /// <seealso cref="DataCellEditorRelease" />
    public event EventHandler<DataGridDataCellEditorOccupyEventArgs> DataCellEditorOccupy
    {
      add
      {
        Events.AddHandler(EventKeyDataCellEditorOccupy, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellEditorOccupy, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager releases the shared editor for using in other columns.
    /// </summary>
    /// <remarks>
    /// If you changed properties or events in the DataCellEditorOccupy event handler,
    /// you should restore properties and events in this event handler.
    /// </remarks>
    /// <seealso cref="DataCellEditorOccupy" />
    public event EventHandler<DataGridDataCellEditorReleaseEventArgs> DataCellEditorRelease
    {
      add
      {
        Events.AddHandler(EventKeyDataCellEditorRelease, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellEditorRelease, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager requests info to show in tooltip window.
    /// </summary>
    /// <remarks>
    /// For text data, assign the text to e.ToolTipText property by the text you want to be shown in tooltip window.
    /// </remarks>
    public event EventHandler<DataGridDataCellToolTipInfoEventArgs> DataCellToolTipInfoNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellToolTipInfo, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellToolTipInfo, value);
      }
    }

    /// <summary>
    /// Occurs when a grid requset visible state for a row.
    /// </summary>
    /// <remarks>
    /// Typically, the grid updates the visibility of rows when the header filter or search bar filter is changed.
    /// To force the grid to update the list of visible rows, call the <see cref="UpdateVisibleRows()"/> method.
    /// </remarks>
    public event EventHandler<DataGridRowVisibleStateNeededEventArgs> RowVisibleStateNeeded
    {
      add
      {
        Events.AddHandler(EventKeyRowVisibleStateNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyRowVisibleStateNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when an area that does not contain cells needs to be drawn.
    /// </summary>
    public event EventHandler<DataGridCellFreeAreaPaintEventArgs> CellFreeAreaPaint
    {
      add
      {
        Events.AddHandler(EventKeyCellFreeAreaPaint, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyCellFreeAreaPaint, value);
      }
    }

    /// <summary>
    /// Occurs when position of the current cell is changed. 
    /// </summary>
    public event EventHandler<BaseGridCurrentCellPosChangedEventArgs> CurrentCellPosChanged
    {
      add
      {
        Events.AddHandler(EventKeyCurrentCellPosChanged, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyCurrentCellPosChanged, value);
      }
    }
    #endregion events

    #region >public methods
    public override void GetDrawSizingLineBound(out int startPos, out int finishPos, int lineIndex)
    {
      base.GetDrawSizingLineBound(out startPos, out finishPos, lineIndex);
      if ((GridState == BaseGridState.ColSizing) && (Title.MultiTitle.Active == true))
      {
        int columnIndex = RawToDataColumnIndex(lineIndex);
        if (columnIndex >= 0)
        {
          DataGridColumn column = VisibleColumns[columnIndex];
          Title.MultiTitle.FixSizingLineBound(ref startPos, ref finishPos, column);
        }
      }
    }

    public int RawToDataColumnIndex(int colIndex)
    {
      return colIndex - (FixedColCount - FrozenColCount);
    }

    public int DataToRawCol(int columnIndex)
    {
      return columnIndex + (FixedColCount - FrozenColCount);
    }

    public int RawToDataRowIndex(int rowIndex)
    {
      return rowIndex - FixedRowCount;
    }

    public int DataToRawRow(int dataRowIndex)
    {
      return dataRowIndex + FixedRowCount;
    }

    public GridCoord RawToDataCell(GridCoord rawGridCoord)
    {
      return new GridCoord(RawToDataColumnIndex(rawGridCoord.X), RawToDataRowIndex(rawGridCoord.Y));
    }

    public GridCoord DataToRawCell(GridCoord dataGridCoord)
    {
      return new GridCoord(DataToRawCol(dataGridCoord.X), DataToRawRow(dataGridCoord.Y));
    }

    public void GetColumnRowByDataColRowIndex(int areaColIndex, int areaRowIndex,
      out DataGridColumn column, out DataGridRow row)
    {
      if (areaColIndex < VisibleColumns.Count)
        column = VisibleColumns[areaColIndex];
      else
        column = null;

      if (areaRowIndex < VisibleRows.Count)
        row = VisibleRows[areaRowIndex];
      else
        row = null;
    }

    public void PutFocus()
    {
      FocusGrid();
    }

    public void MoveDisplayColumns(DataGridColumn[] columns, int toIndex)
    {
      MoveColumsByViewIndex(columns, toIndex);
      //if (Title.MultiTitle.Active)
      //  Title.MultiTitle.UpdateChildIndexFromColumnDisplayIndex();
    }
    #endregion

    #region >nopublic methods
    //AutoGenerateColumns
    protected virtual bool DefaultAutoGenerateColumns()
    {
      return DefaultAutoGeneratePropBars();
    }

    protected virtual bool ShouldSerializeAutoGenerateColumns()
    {
      return ShouldSerializeAutoGeneratePropBars();
    }

    public virtual void ResetAutoGenerateColumns()
    {
      ResetAutoGeneratePropBars();
    }

    //Others
    protected virtual DataGridSearchBoxControl CreateSearchBoxControl()
    {
      return new DataGridSearchBoxControl(this);
    }

    protected virtual DataGridTreeViewArea CreateTreeViewArea()
    {
      return new DataGridTreeViewArea(this);
    }

    protected internal override void ResetViewOrderedPropBars()
    {
      foreach (var axisBar in ViewOrderedPropBars)
        axisBar.DisplayIndexInternal = -1;
      PropBarsDisplayIndexChanged();

      //if (Title.MultiTitle.Active)
      //{
      //  List<DataGridColumn> colList = new List<DataGridColumn>();
      //  //List<PropertyAxisBar> propBarList = new List<PropertyAxisBar>();

      //  Title.MultiTitle.UpdateChildIndexFromColumnDisplayIndex();
      //  Title.MultiTitle.FillColumnsViewList(colList);

      //  //Fix  StaticColumns order from Title.MultiTitle created DisplayList
      //  //foreach (DataGridColumn col in StaticColumns)
      //  //  colList.Add(col);

      //  //colList.Sort((item1, item2) => (item1.DisplayIndex - item1.DisplayIndex));

      //  StaticColumns.BeginUpdate();
      //  try
      //  {
      //    StaticColumns.Clear();
      //    foreach (DataGridColumn col in colList)
      //    {
      //      col.DisplayIndexInternal = -1;
      //      StaticColumns.Add(col);
      //    }
      //  }
      //  finally
      //  {
      //    StaticColumns.EndUpdate();
      //  }
      //}
    }

    protected internal override void SetPropBarsOrderFromViewOrderedBars()
    {
      if (Title.MultiTitle.Active)
      {
        //List<DataGridColumn> colList = new List<DataGridColumn>();
        //foreach (PropertyAxisBar pb in PropBars)
        //  colList.Add((DataGridColumn)pb);
        //Title.MultiTitle.AdjustOrderedListForTreeList(colList);

        List<PropertyAxisBar> statColList = new List<PropertyAxisBar>();
        foreach (PropertyAxisBar col in ViewOrderedPropBars)
        {
          if (!col.AutoGenerated)
            statColList.Add(col);
        }
        StaticColumns.SetBarsOrder(statColList);
      }
    }

    protected override void OnReadOnlyChanged(EventArgs e)
    {
      base.OnReadOnlyChanged(e);
      if (!InInitialization)
      {
        HorzScrollBarPanelControl.RealignControls();
        VertScrollBarPanelControl.RealignControls();
      }
      UpdateBaseRowCount();
    }

    protected internal virtual void OnAllowedOperationsChanged(EventArgs e)
    {
      if (!InInitialization)
      {
        HorzScrollBarPanelControl.RealignControls();
        VertScrollBarPanelControl.RealignControls();
      }
    }

    protected internal override void AxisObjectsByDataColRowIndex(int dataColIndex, int dataRowIndex,
      out PropertyAxisBar propAxisBar, out DataAxisGridListItemBar listItemBar, out DataAxisGridListAxisItemViewState listAxisItemViewState)
    {
      if (dataColIndex >= 0 && dataColIndex < VisibleColumns.Count)
        propAxisBar = VisibleColumns[dataColIndex];
      else
        propAxisBar = null;

      if (dataRowIndex < VisibleRows.Count)
      {
        listItemBar = VisibleRows[dataRowIndex];

        RowEditState rowState = DataLink.CurrentListItemState;

        if (dataRowIndex == CurrentDataRowIndex)
        {
          if (rowState == RowEditState.Edit)
            listAxisItemViewState = DataAxisGridListAxisItemViewState.DataEdit;
          else if (rowState == RowEditState.New)
            listAxisItemViewState = DataAxisGridListAxisItemViewState.DataNew;
          else
            listAxisItemViewState = DataAxisGridListAxisItemViewState.DataBrowse;
        }
        else
        {
          listAxisItemViewState = DataAxisGridListAxisItemViewState.DataBrowse;
        }
      }
      else
      {
        listItemBar = null;

        if (dataRowIndex == VisibleRows.Count)
          listAxisItemViewState = DataAxisGridListAxisItemViewState.VirtualNew;
        else
          listAxisItemViewState = DataAxisGridListAxisItemViewState.VirtualEmpty;
      }
    }

    protected override GridKeyboardOptions CreateKeyboardOptions()
    {
      return new DataGridKeyboardOptions();
    }

    internal virtual bool OnIndicatorTitleMouseDownEvent(BaseGridCellMouseEventArgs e)
    {
      return false;
    }

    protected internal virtual void MultiTitleChanged()
    {
      //if (Columns.Updating || Columns.ViewsUpdating) return;
      InvalidateGrid();
      UpdateColumnsView();
      UpdateBaseFixedBands();
    }

    protected override DataAxisGridReadOnlyPropBarCollection CreatePropBarReadOnlyCollection(IList<PropertyAxisBar> list)
    {
      return new DataGridReadOnlyColumnCollection(this, list);
    }

    protected override DataAxisGridMainPropBarCollection CreatePropBarMainCollection(IList<PropertyAxisBar> list)
    {
      return new DataGridMainColumnCollection(this, list);
    }

    protected override DataAxisGridStaticPropBarCollection CreateStaticPropBarCollection()
    {
      return new DataGridStaticColumnCollection(this);
    }

    protected internal override DataAxisGridTitleBar CreateTitleBar()
    {
      return new DataGridTitle(this);
    }

    protected internal override void OnGetCellBorderParams(BaseGridCellManager cell, BaseGridCellBorderEventArgs e)
    {
      base.OnGetCellBorderParams(cell, e);

      if (e.ColIndex == -1 && ContraColCount > 0 && e.BorderType == GridCellBorderSide.Right)
        e.Visible = false;
      else if (LineOptions.GridBoundaries)
      {
        if ((e.BorderType == GridCellBorderSide.Right) &&
            (e.ColIndex == ColCount - 1) &&
            (e.RowIndex < RowCount))
        {
          e.Visible = true;
          if (e.RowIndex >= FixedRowCount)
            e.Color = LineOptions.DataBoundaryColor;
          e.Visible = true;
        }
        else if ((e.BorderType == GridCellBorderSide.Bottom) &&
            (e.RowIndex == RowCount - 1) &&
            (e.ColIndex < ColCount))
        {
          e.Visible = true;
          if (e.ColIndex >= FixedColCount)
            e.Color = LineOptions.DataBoundaryColor;
          e.IsExtent = true;
        }
      }

    }

    protected internal virtual void OnHorzLineParamsNeeded(DataGridHorzLineParamsNeededEventArgs e)
    {
      var eh = Events[EventKeyDataGridHorzLineParamsNeeded] as EventHandler<DataGridHorzLineParamsNeededEventArgs>;
      if (eh != null && !IsDisposed)
      {
        eh(this, e);
      }
    }

    protected override GridLineColors CreateGridLineColors()
    {
      return new DataGridLineOptions(this);
    }

    protected internal override bool DefaultAllowShowEditor()
    {
      return ColumnOptions.AllowShowEditor;
    }

    protected internal override void PrepareForShowEditor()
    {
      base.PrepareForShowEditor();
      if (VisibleRows.Count == 0 && AllowedOperations.AllowAdd)
        DataLink.AddNew();
    }

    protected internal override void ShowEditor(bool selectAll)
    {
      if (VisibleRows.Count == 0 && AllowedOperations.AllowAdd)
        DataLink.AddNew();

      base.ShowEditor(selectAll);
    }

    protected override void OnShowEditor()
    {
      Selection.CheckClear();
    }

    //protected internal override bool CanShowEditor()
    //{
    //  return !EditorBanned && ColumnOptions.CanShowEditor();
    //}

    protected internal override void EditorTextChanged(EventArgs e)
    {
      base.EditorTextChanged(e);
      if (EditorMode)
      {
        UpdateBaseRowCount();
      }
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
      int nextPageRow, prevPageRow;
      int oldcurrentColumnIndex = CurrentColumnIndex;
      int oldColIndex = Col;

      base.OnKeyDown(e);
      if (e.Handled) return;

      if (!e.Shift && !e.Alt && !e.Control)
      {
        switch (e.KeyCode)
        {
          case Keys.Down:
            if (VisibleRows.Count == 0 &&
                RowCount - FixedRowCount == 1 &&
                DataLink.CurrentListItemState == RowEditState.Browse &&
                AllowedOperations.AllowAdd)
            {
              DataLink.AddNew();
            }
            break;

          case Keys.Left:
            if (CurrentColumnIndex == 0 && oldcurrentColumnIndex == 0)
            {
              if (TreeViewArea.Visible)
              {
                DataGridTreeViewNodeStateNeededEventArgs nodeState = TreeViewArea.GetTreeNodeState(CurrentRow);
                if (nodeState.HasChildren && nodeState.Expanded)
                  TreeViewArea.SetTreeNodeExpandedState(CurrentRow, false);
                else
                {
                  object parent = nodeState.ParentItem;
                  if (parent != null)
                  {
                    int parentRowIndex = Rows.IndexOfSourceItem(parent);
                    if (parentRowIndex >= 0)
                      CurrentRowIndex = VisibleRows.IndexOf(Rows[parentRowIndex]);
                  }
                }
              }
            }
            break;

          case Keys.Right:
            if (TreeViewArea.Visible)
            {
              if ((Col == ColCount - 1 && oldColIndex == ColCount - 1) ||
                  Selection.RowSelect)
              {
                DataGridTreeViewNodeStateNeededEventArgs nodeState = TreeViewArea.GetTreeNodeState(CurrentRow);
                if (nodeState.HasChildren && !nodeState.Expanded)
                  TreeViewArea.SetTreeNodeExpandedState(CurrentRow, true);
              }
            }
            break;
        }
      }
      else if (e.Shift &&
          (Selection.CellsSelectionIsAllowed || Selection.RowsSelectionIsAllowed)
         )
      {
        GridCoord newFreeEndCell;
        GridCoord curFreeEndCell;

        if (Selection.RowsSelectionIsAllowed && !Selection.CellsSelectionIsAllowed)
        {
          if (Selection.FreeEndDataRowIndex >= 0)
            newFreeEndCell = new GridCoord(CurrentDataColIndex, Selection.FreeEndDataRowIndex);
          else
            newFreeEndCell = new GridCoord(CurrentDataColIndex, CurrentDataRowIndex);
        }
        else if (Selection.SelectionType == GridSelectionType.CellsBox)
          newFreeEndCell = Selection.FreeEndCell;
        else
          newFreeEndCell = new GridCoord(CurrentDataColIndex, CurrentDataRowIndex);
        curFreeEndCell = newFreeEndCell;
        switch (e.KeyCode)
        {
          case Keys.Up:
            newFreeEndCell.Y--;
            break;
          case Keys.Down:
            newFreeEndCell.Y++;
            break;
          case Keys.Left:
            if (newFreeEndCell.X > 0)
              newFreeEndCell.X--;
            break;
          case Keys.Right:
            newFreeEndCell.X++;
            break;
          case Keys.Home:
            newFreeEndCell.X = 0;
            break;
          case Keys.End:
            newFreeEndCell.X = Columns.Count - 1;
            break;
          case Keys.PageDown:
            CalcPageExtents(out nextPageRow, out prevPageRow);
            newFreeEndCell.Y = nextPageRow;
            break;
          case Keys.PageUp:
            CalcPageExtents(out nextPageRow, out prevPageRow);
            newFreeEndCell.Y = prevPageRow;
            break;
        }
        Restrict(ref newFreeEndCell, 0, 0, VisibleColumns.Count - 1, VisibleRows.Count - 1);
        if (Selection.CellsSelectionIsAllowed &&
           (curFreeEndCell != newFreeEndCell))
        {
          Selection.SetSelectedFreeEndCell(newFreeEndCell);
          ClampInView(DataToRawCell(newFreeEndCell), true, true);
        }
        else if (Selection.RowsSelectionIsAllowed &&
                (curFreeEndCell.Y != newFreeEndCell.Y))
        {
          newFreeEndCell.X = curFreeEndCell.X;
          if (Selection.AnchorDataRowIndex == -1)
            StartRowSelection(VisibleRows[CurrentRowIndex], true, false, false);
          Selection.SetFreeEndRow(newFreeEndCell.Y);
          ClampInView(DataToRawCell(newFreeEndCell), true, true);
        }
      }

      switch (e.KeyData & Keys.KeyCode)
      {
        case Keys.F2:
          {
            e.Handled = ProcessF2Key(e.KeyData);
            break;
          }

        case Keys.Tab:
          {
            e.Handled = ProcessTabKey(e.KeyData);
            break;
          }

        case Keys.Delete:
          {
            if (e.Control)
              e.Handled = ProcessControlDelete(e.KeyData);
            break;
          }

        case Keys.Oem7:
          {
            if (e.Control && !e.Shift && !e.Alt)
            {
              SetValueFromPrevious();
              e.Handled = true;
            }
            break;
          }
      }
    }

    protected override void OnKeyPress(KeyPressEventArgs e)
    {
      base.OnKeyPress(e);
    }

    protected override void OnKeyUp(KeyEventArgs e)
    {
      base.OnKeyUp(e);
      if (e.Handled) return;

      switch (e.KeyData & Keys.KeyCode)
      {
        case Keys.ControlKey:
          {
            if (Title.SortMarking.MultiSortMarkable)
              //SortMarkers.CommitChanges();
              Title.SortMarking.ApplySortMakers();
            break;
          }
      }
    }

    protected override bool IsInputKey(Keys keyData)
    {
      switch (keyData & Keys.KeyCode)
      {
        case Keys.Tab:
          {
            Keys altData = keyData & (Keys.Control | Keys.Shift | Keys.Alt);
            if ((altData == 0 || altData == Keys.Shift) && ((GridOptions.Tabs & Options) != 0))
              return KeyboardOptions.TabKeyAction == GridKeyboardAction.NextColCell;
            else
              break;
          }
      }
      return base.IsInputKey(keyData);
    }

    protected override bool ProcessKeyPreview(ref Message m)
    {
      bool result = base.ProcessKeyPreview(ref m);

      KeyEventArgs ke = new KeyEventArgs((Keys)(int)m.WParam | ModifierKeys);

      if (m.Msg == NativeMethods.WM_KEYDOWN || m.Msg == NativeMethods.WM_SYSKEYDOWN)
      {
        if (ProcessDataGridKeyPreview(ke))
          return true;
      }

      return result;
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
      if (((int)keyData == (int)SearchBox.Shortcut) &&
          (SearchBox.Enabled == true))
      {
        SearchBox.Visible = true;
        SearchBox.Active = true;
        return true;
      }
      else
        return base.ProcessCmdKey(ref msg, keyData);
    }

    protected override bool ProcessDialogKey(Keys keyData)
    {
      if (SearchBox.Active)
        return base.ProcessDialogKey(keyData);

      if (EditorMode &&
          ((IDataAxisGridCellInPlaceEditor)CellEditControl).EditorWantsInputKey(keyData, true))
      {
        return base.ProcessDialogKey(keyData);
      }

      Keys key = keyData & Keys.KeyCode;

      switch (key)
      {
        case Keys.Enter:
          {
            if (ProcessEnterKey(keyData))
              return true;
            else
              break;
          }
        case Keys.Escape:
          {
            if (ProcessEscapeKey(keyData))
              return true;
            else
              break;
          }
        case Keys.C:
        case Keys.Insert:
        case Keys.V:
        case Keys.X:
        case Keys.Delete:
          if (ProcessCopyKey(keyData))
            return true;
          else if (ProcessPasteKey(keyData))
            return true;
          else if (ProcessCutKey(keyData))
            return true;
          else
            break;
        case Keys.Tab:
          if (/*(KeyboardOptions.TabKeyAction == DataGridKeyboardActions.None) && */EditorMode)
          {
            if (HideEditor(true))
            {
              if (KeyboardOptions.TabKeyAction == GridKeyboardAction.NextColCell)
              {
                ProcessTabKey(keyData);
                return true;
              }
            }
            else
              return true; //Stayed in Editor
          }
          break;
      }

      return base.ProcessDialogKey(keyData);
    }

    protected internal override void OnEditorKeyDown(DataAxisGridEditorKeyEventArgs e)
    {
      KeyEventArgs ke = e.KeyEventArgs;
      if ((ke.KeyData & Keys.KeyCode) == Keys.Oem7 && 
               ke.Control && 
               !ke.Shift && 
               !ke.Alt)
      {
        object editValue;
        DataGridColumn column = e.PropAxisBar as DataGridColumn;
        if (GetEditValueFromPreviousRow(column, out editValue))
        {
          var iEditor = e.CellEditControl as IDataAxisGridCellInPlaceEditor;
          iEditor.EditorEditValue = editValue;
          iEditor.EditorValueChanged = true;
          e.Handled = true;
        }
      }
    }

    protected virtual bool GetEditValueFromPreviousRow(DataGridColumn column, out object value)
    {
      value = null;
      if (CurrentRow == null || CurrentColumnIndex < 0) return false;
      if (CurrentRow.VisibleIndex == 0) return false;

      BaseDataCellManager dataCellMan = CurrentCellMan as BaseDataCellManager;
      if (dataCellMan == null) return false;

      DataGridRow prevRow = VisibleRows[CurrentRow.VisibleIndex - 1];

      value = dataCellMan.GetEditValue(column, prevRow);
      return true;
    }

    public virtual void SetValueFromPrevious()
    {
      object editValue;
      if (CurrentColumnIndex < 0) return;
      DataGridColumn column = VisibleColumns[CurrentColumnIndex];

      if (GetEditValueFromPreviousRow(column, out editValue))
      {
        SafePushValue(column, editValue);
      }
    }

    protected virtual bool ProcessDataGridKeyPreview(KeyEventArgs e)
    {
      if (EditorMode &&
          ((IDataAxisGridCellInPlaceEditor)CellEditControl).EditorWantsInputKey(e.KeyData, true))
      {
        return false;
      }

      switch (e.KeyCode)
      {
        case Keys.Escape:
          {
            return ProcessEscapeKey(e.KeyData);
          }
      }
      return false;
    }

    protected override bool ProcessTabKey(Keys keyData)
    {
      HideEditor(true);
      return base.ProcessTabKey(keyData);
    }

    protected virtual bool ProcessControlDelete(Keys keyData)
    {
      if (AllowedOperations.AllowRemove && VisibleRows.Count > 0)
      {
        bool deleteConfirmed;
        if (EditActions.ConfirmDelete)
          deleteConfirmed = EditActions.ShowConfirmDeleteDialog();
        else
          deleteConfirmed = true;

        if (deleteConfirmed)
          DataLink.DeleteCurrent();
        return true;
      }
      else
      {
        return false;
      }
    }

    protected internal virtual void StartColumnSelection(DataGridColumn column, bool addToSelection)
    {

      Rectangle noScrollRect = Rectangle.Empty;

      dataGridState = DataGridState.ColumnsSelecting;
      //columnSelectIsSelect = !column.Selected;

      noScrollRect.X = HorzAxis.FixedBoundary;
      noScrollRect.Width = HorzAxis.RollClientLen;
      noScrollRect.Y = VertAxis.GridClientStart;
      noScrollRect.Height = VertAxis.GridClientStop - VertAxis.GridClientStart;

      MoveNScrollService.Capture(this, noScrollRect, ColSelectServiceEventHandler, true, false);

      if (addToSelection)
        Selection.AddSelectedColumn(column, !column.Selected);
      else
        Selection.SetSelectedColumn(column);
      Selection.InitAnchorCol(column.VisibleIndex);
    }

    protected internal virtual void ColSelectServiceEventHandler(MoveAndScrollService service, MouseEventArgs e)
    {
      int freeEndCol = Selection.FreeEndCol;

      if (e.X > MoveNScrollService.ClientRect.Right)
      {
        SafeScrollData(HorzAxis.GetScrollStep(), 0);
        freeEndCol = HorzAxis.RollLastVisCell + HorzAxis.FixedCellCount;
        freeEndCol = RawToDataColumnIndex(freeEndCol);
      }
      else if (e.X < MoveNScrollService.ClientRect.Left)
      {
        SafeScrollData(-HorzAxis.GetScrollStep(), 0);
        freeEndCol = HorzAxis.RollStartVisCell + HorzAxis.FixedCellCount;
        freeEndCol = RawToDataColumnIndex(freeEndCol);
      }
      else
      {
        GridCoord cellHit = MouseCoord(e.X, e.Y);
        if (cellHit.X >= 0)
        {
          freeEndCol = RawToDataColumnIndex(cellHit.X);
        }
      }
      Selection.SetFreeEndCol(freeEndCol);

    }

    protected internal virtual void StartRowSelection(DataGridRow row, bool addToSelection, bool captureMnsService, bool shiftMode)
    {

      bool canSelectRow;
      Rectangle noScrollRect = Rectangle.Empty;

      dataGridState = DataGridState.RowsSelecting;

      noScrollRect.X = HorzAxis.GridClientStart;
      noScrollRect.Width = HorzAxis.GridClientStop - HorzAxis.GridClientStart;
      noScrollRect.Y = VertAxis.FixedBoundary;
      noScrollRect.Height = VertAxis.RollClientLen;

      if (addToSelection == false || row.Selected == false)
        canSelectRow = CanSelectRow(row);
      else
        canSelectRow = true;

      if (canSelectRow)
      {
        if (captureMnsService)
          MoveNScrollService.Capture(this, noScrollRect, RowSelectServiceEventHandler, false, true);

        if (shiftMode)
          Selection.SetFreeEndRow(row.VisibleIndex);
        else
        {
          if (addToSelection)
            Selection.AddSelectedRow(row, !row.Selected);
          else
            Selection.SetSelectedRow(row);
          Selection.InitAnchorRow(row.VisibleIndex, row.Selected);
        }
      }
    }

    protected internal virtual bool CanSelectRow(DataGridRow row)
    {
      var eh = Events[EventKeyRowIsSelectable] as EventHandler<DataGridRowIsSelectableEventArgs>;
      if (eh != null && !IsDisposed)
      {
        DataGridRowIsSelectableEventArgs e = new DataGridRowIsSelectableEventArgs(row);
        e.RowIsSelectable = true;
        eh(this, e);
        return e.RowIsSelectable;
      }
      else
      {
        return true;
      }
    }

    protected internal virtual void RowSelectServiceEventHandler(MoveAndScrollService service, MouseEventArgs e)
    {
      int freeEndDataRowIndex = Selection.FreeEndDataRowIndex;
      if (e.Y > MoveNScrollService.ClientRect.Bottom)
      {
        SafeScrollData(0, HorzAxis.GetScrollStep());
        freeEndDataRowIndex = VertAxis.RollLastVisCell + VertAxis.FixedCellCount;
        freeEndDataRowIndex = RawToDataRowIndex(freeEndDataRowIndex);
      }
      else if (e.Y < MoveNScrollService.ClientRect.Top)
      {
        SafeScrollData(0, -HorzAxis.GetScrollStep());
        freeEndDataRowIndex = VertAxis.RollStartVisCell + VertAxis.FixedCellCount;
        freeEndDataRowIndex = RawToDataRowIndex(freeEndDataRowIndex);
      }
      else
      {
        GridCoord cellHit = MouseCoord(e.X, e.Y);
        if (cellHit.Y >= 0)
        {
          freeEndDataRowIndex = RawToDataRowIndex(cellHit.Y);
        }
      }
      if (freeEndDataRowIndex >= VisibleRows.Count)
        freeEndDataRowIndex = VisibleRows.Count - 1;
      //Debug.WriteLine("RowSelectServiceEventHandler: " + FreeEndDataRowIndex.ToString());
      Selection.SetFreeEndRow(freeEndDataRowIndex);

    }

    protected internal virtual void StartCellRectSelectionMode(MouseEventArgs e)
    {
      dataGridState = DataGridState.CellsRectSelecting;
      GridCoord cellHit = MouseCoord(e.X, e.Y);
      GridCoord dataCellHit = new GridCoord(RawToDataColumnIndex(cellHit.X), RawToDataRowIndex(cellHit.Y));

      if (dataCellHit.X < 0) dataCellHit.X = 0;
      if (dataCellHit.X >= VisibleColumns.Count) dataCellHit.X = ViewOrderedColumns.Count - 1;
      if (dataCellHit.Y < 0) dataCellHit.Y = 0;
      if (dataCellHit.Y >= VisibleRows.Count) dataCellHit.Y = VisibleRows.Count - 1;

      //Debug.Assert(dataCellHit.X >= 0 && dataCellHit.Y >= 0, "DataGridEh.StartCellRectSelectionMode << cellHit.X < 0 || cellHit.Y < 0 >> ");
      if (dataCellHit.X >= 0 && dataCellHit.Y >= 0)
        Selection.StartCellsRectSelection(new GridCoord(CurrentDataColIndex, CurrentDataRowIndex), dataCellHit);
    }

    protected virtual DataGridIndicatorColumn CreateIndicatorColumn()
    {
      return new DataGridIndicatorColumn(this);
    }

    protected virtual DataGridIndicatorTitle CreateIndicatorTitle()
    {
      return new DataGridIndicatorTitle(this);
    }

    protected override void OnResize(EventArgs e)
    {
      base.OnResize(e);
      UpdateSearchBox();
      UpdateFitColWidthsToClient();
    }

    protected override void ScrollBarShowingChanged()
    {
      base.ScrollBarShowingChanged();
      UpdateFitColWidthsToClient();
    }

    protected override bool CanResizeCol(int colIndex, int rowIndex, int xPos, int yPos, int inCellXPos, int inCellYPos)
    {
      bool result = base.CanResizeCol(colIndex, rowIndex, xPos, yPos, inCellXPos, inCellYPos);

      if (!result)
        return false;
      else if (VisibleColumns.Count == 0)
      {
        return false;
      }
      else
      {
        if (Title.MultiTitle.Active)
        {
          int dataColIndex = BaseToDataColIndex(colIndex);
          if (dataColIndex >= VisibleColumns.Count) return false;
          DataGridColumn column = VisibleColumns[dataColIndex];
          DataGridTitleNode titleNode = column.Title.TitleNode;
          DataGridTitleNode upNode = titleNode;

          int subTitleHeight = titleNode.Bounds.Height;
          while (upNode.Parent != Title.MultiTitle.Root)
          {
            if (upNode.Parent.VisibleItems[upNode.Parent.VisibleItems.Count - 1] == upNode)
            {
              upNode = upNode.Parent;
              subTitleHeight = subTitleHeight + upNode.Bounds.Height;
            }
            else
              break;
          }

          if (inCellYPos >= RowHeights[rowIndex] - subTitleHeight)
            return true;
          else
            return false;
        }
        else
        {
          return true;
        }
      }
    }

    public override void InteractiveFocusCell(int colIndex, int rowIndex, InteractiveActionSource actionSource)
    {
      if ((colIndex == Col) && (rowIndex == Row)) return;
      if (!PrepareChangeCellPos()) return;
      //if ((ModifierKeys & Keys.Shift) != 0) return;
      if (!DataLink.Active) return;

      if ((rowIndex - FixedRowCount) == VisibleRows.Count && AllowedOperations.AllowAdd)
        DataLink.AddNew();
      else if (rowIndex - FixedRowCount < VisibleRows.Count)
        DataLink.Position = VisibleRows[rowIndex - FixedRowCount].Index;

      if (Selection.RowSelect)
        MoveCurrent(Col, rowIndex, false, true);
      else
        FocusCell(colIndex, Row, false);
    }

    protected override void OnCurrentCellPosChanged(BaseGridCurrentCellPosChangedEventArgs e)
    {
      Selection.StopSelectionState();
      Selection.CheckClear();
      if (e.OldRowIndex != Row)
      {
        InvalidateRow(e.OldRowIndex);
        InvalidateRow(Row);
      }
      HorzScrollBarPanelControl.RealignControls();
      VertScrollBarPanelControl.RealignControls();

      HandleCurrentCellPosChangedEvent(e);
    }

    protected virtual void HandleCurrentCellPosChangedEvent(BaseGridCurrentCellPosChangedEventArgs e)
    {
      var eh = Events[EventKeyCurrentCellPosChanged] as EventHandler<BaseGridCurrentCellPosChangedEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    protected override void InteractiveSetColWidths(int colIndex, int newSize)
    {
      if (DesignMode && DataGridDesigner != null)
      {
        DataGridDesigner.InteractiveSetColWidths(colIndex, newSize);
        return;
      }

      if (colIndex >= StartDataColIndex)
      {
        DataGridColumn column = VisibleColumns[colIndex - StartDataColIndex];

        if (AutoSizeColumnOptions.FitToClient)
          SetColumnWidthFitClientMode(column, newSize);
        else
        {

          if (Selection.SelectionType == GridSelectionType.Columns &&
              column.Selected
             )
          {
            foreach (DataGridColumn col in VisibleColumns)
              if (col.Selected)
                col.Width = newSize;

          }
          else
          {
            column.Width = newSize;
          }
        }
      }
      else
        base.InteractiveSetColWidths(colIndex, newSize);

      if (EditorMode)
        UpdateCellEditorBounds();
    }

    public override PropertyAxisBar CreatePropBarFromType(Type type)
    {
      return DataGridManager.DefaultManager.GetDataGridColumnForType(type);
    }

    public override Type GetAxisBarTypeForDataType(Type type)
    {
      return DataGridManager.DefaultManager.GetDataGridColumnTypeForDataType(type);
    }

    protected override void InitDynaPropBar(PropertyAxisBar bar, DeepPropertyDescriptor prop)
    {
      base.InitDynaPropBar(bar, prop);

      DataGridColumn col = (DataGridColumn)bar;
      col.DefaultWidth = col.CalcDefaultWidth();
    }

    private void ColumnsDisplayProperiesChanged()
    {
      UpdateColumnsView();
    }

    protected internal override void PropertyAxisBarVisibleChanged(PropertyAxisBar propAxisBar, bool value)
    {
      if (InInitialization || PropBars.Updating) return;
      if (Title.MultiTitle.Active)
        ((DataGridColumn)propAxisBar).Title.TitleNode.VisibleChanged();
      base.PropertyAxisBarVisibleChanged(propAxisBar, value);
    }

    protected internal override bool PropBarCanBeVisible(PropertyAxisBar bar)
    {
      if (Title.MultiTitle.Active)
        return Title.MultiTitle.ColumnCanBeVisible((DataGridColumn)bar);
      else
        return true;
    }

    protected internal void UpdateColumnsList()
    {
      UpdatePropBarsList();
    }

    protected override void PropBarsListChanged()
    {
      //OnOrderedColumnsListChanged(new EventArgs()); //Not here. In the UpdateColumnsDisplayIndex() already present.
      if (Title.MultiTitle.Active)
        Title.MultiTitle.SynchroniseListContentWithGridColumns();
      base.PropBarsListChanged();
      if (!internalDataResetting)
      {
        UpdateRowsForChangedColumns();
        RecalcFooters();
      }
    }

    protected override void OnOrderedColumnsListChanged(EventArgs e)
    {
      var handler = (EventHandler)Events[EventKeyDataGridOrderedColumnsListChanged];
      if (handler != null)
        handler(this, e);
    }

    protected override void OnPropBarsListChanged(EventArgs e)
    {
      var handler = (EventHandler)Events[EventKeyDataGridColumnsListChanged];
      if (handler != null)
        handler(this, e);
    }

    protected internal virtual void OnVisibleRowListChanged(EventArgs e)
    {
      if (!Selection.KeepSelection)
        Selection.Clear();
      HandleVisibleRowListChangedEvent(e);
    }

    protected internal virtual void HandleVisibleRowListChangedEvent(EventArgs e)
    {
      var handler = (EventHandler)Events[EventKeyDataGridVisibleRowsListChanged];
      if (handler != null)
        handler(this, e);
    }

    protected internal override void SetPropBarDisplayIndex(PropertyAxisBar propertyAxisBar, int newDisplayIndex)
    {
      if (InInitialization) return;
      DataGridColumn curGridColumn;
      if (VisibleColumns.Count > 0)
        curGridColumn = VisibleColumns[CurrentColumnIndex];
      else
        curGridColumn = null;

      base.SetPropBarDisplayIndex(propertyAxisBar, newDisplayIndex);
      if (Columns.Updating) return;

      ColumnsDisplayProperiesChanged();

      if (curGridColumn != null)
        SetCurColByGridColumn(curGridColumn);
      if (EditorMode)
        UpdateCellEditorBounds();
    }

    protected override void VisibleColumnsListChanged()
    {
      if (Title.MultiTitle.Active)
        Title.MultiTitle.ColumnWidthsChanged();
    }

    protected internal virtual void UpdateColumnsView()
    {
      UpdatePropBarsView();
    }

    protected internal override void UpdatePropBarsView()
    {
      base.UpdatePropBarsView();
      UpdateGridState();
      UpdateBaseGridColumns();
      UpdateFitColWidthsToClient();
    }

    protected override void FillPropBarsViewOrderedList(List<PropertyAxisBar> voColList)
    {
      base.FillPropBarsViewOrderedList(voColList);
      if (Title.MultiTitle.Active)
      {
        List<DataGridColumn> coList = new List<DataGridColumn>();
        foreach (PropertyAxisBar pb in voColList)
          coList.Add((DataGridColumn)pb);
        Title.MultiTitle.AdjustOrderedListForTreeList(coList);
        voColList.Clear();
        voColList.AddRange(coList);
      }
    }

    protected override int CompareDisplayOrderColumns(PropertyAxisBar x, PropertyAxisBar y)
    {
      DataGridColumn xc = (DataGridColumn)x;
      DataGridColumn yc = (DataGridColumn)y;

      if (xc.Frozen != yc.Frozen)
      {
        if (xc.Frozen == DataGridColumnFrozenState.ToLeftSide)
          return -1;
        else if (yc.Frozen == DataGridColumnFrozenState.ToLeftSide)
          return 1;
        else if (xc.Frozen == DataGridColumnFrozenState.None)
          return -1;
        else if (yc.Frozen == DataGridColumnFrozenState.None)
          return 1;
        else
          return 0;
      }
      else if (xc.DisplayIndex < yc.DisplayIndex)
      {
        return -1;
      }
      else if (xc.DisplayIndex > yc.DisplayIndex)
      {
        return 1;
      }
      else
      {
        //if (x.DisplayIndexQuery && !y.DisplayIndexQuery)
        //  return -1;
        //else if (!x.DisplayIndexQuery && y.DisplayIndexQuery)
        //  return 1;
        //else if (x.DisplayIndexQuery && y.DisplayIndexQuery && x.DisplayIndexQueryIndex < y.DisplayIndexQueryIndex)
        //  return -1;
        //else if (x.DisplayIndexQuery && y.DisplayIndexQuery && x.DisplayIndexQueryIndex > y.DisplayIndexQueryIndex)
        //  return -1;
        //else 
        int xcIndex = Columns.IndexOf(xc);
        int ycIndex = Columns.IndexOf(yc);
        if (xcIndex < ycIndex)
          return -1;
        else if (xcIndex < ycIndex)
          return 1;
        else
          return 0;
      }
    }

    protected internal override void PropBarsUpdateCommitted()
    {
      //if (Title.MultiTitle.Active)
      //  Title.MultiTitle.SynchroniseListContentWithGridColumns();
      base.PropBarsUpdateCommitted();
      UpdateRowsForChangedColumns();
      InvalidateGrid();
    }

    internal void UpdateRowsForChangedColumns()
    {
      UpdateRowHeights();
      //titleRow.RecreateCells();
      //dummyDataRow.RecreateCells();
    }

    protected internal virtual void OnColumnWidthChanged(DataGridColumn column)
    {
      if ((InInitialization == true) || Columns.Updating) return;
      //if (Title.MultiTitle.Active)
      //  Title.MultiTitle.ColumnWidthsChanged();
      UpdateRowHeights();
      UpdateBaseGridColumns();

      var eh = Events[EventKeyDataGridColumnWidthChanged] as EventHandler<DataGridColumnEventArgs>;
      if (eh != null && !IsDisposed)
      {
        eh(this, new DataGridColumnEventArgs(column));
      }
    }

    protected internal virtual void OnDisplayColumnsMoved(DataGridDisplayColumnsMovedEventArgs e)
    {
      if ((InInitialization == true) || Columns.Updating) return;
      var eh = Events[EventKeyDataGridDisplayColumnsMoved] as EventHandler<DataGridDisplayColumnsMovedEventArgs>;
      if (eh != null && !IsDisposed)
      {
        eh(this, e);
      }
    }

    internal void UpdateBaseGridColumns()
    {
      if ((InInitialization == true) || Columns.Updating || IsDisposed) return;

      int newFixedColCount = 0;
      int leftFrozenCount = 0;
      int rightFrozenCount = 0;
      int newColCount;

      if (IndicatorColumn.Visible)
        newFixedColCount = 1;

      foreach (DataGridColumn col in VisibleColumns)
      {
        if (col.Frozen == DataGridColumnFrozenState.ToLeftSide)
          leftFrozenCount = leftFrozenCount + 1;
        else if (col.Frozen == DataGridColumnFrozenState.ToRightSide)
          rightFrozenCount = rightFrozenCount + 1;
        col.PerformLayout();
      }

      newFixedColCount = newFixedColCount + leftFrozenCount;

      SetFixedFrozenColCount(newFixedColCount, leftFrozenCount);

      newColCount = FixedColCount - FrozenColCount + VisibleColumns.Count - rightFrozenCount;
      if (VisibleColumns.Count == 0)
        newColCount = FixedColCount + 1;
      else if ((newColCount <= FixedColCount) && FrozenColCount > 0)
      {
        FrozenColCount = FrozenColCount - 1;
        FixedColCount = FixedColCount - 1;
      }
      else if ((newColCount <= FixedColCount) && rightFrozenCount > 0)
        rightFrozenCount = rightFrozenCount - 1;

      ColCount = newColCount;
      ContraColCount = rightFrozenCount;

      bool colWidthsChanged = false;

      for (int i = 0; i < VisibleColumns.Count; i++)
      {
        DataGridColumn col = VisibleColumns[i];
        int bi = StartDataColIndex + i;
        int newWidth = col.Width + LineOptions.VertLineSpace;
        if (ColWidths[bi] != newWidth)
        {
          ColWidths[bi] = newWidth;
          colWidthsChanged = true;
        }
      }

      if (colWidthsChanged)
      {
        if (Title.MultiTitle.Active)
          Title.MultiTitle.ColumnWidthsChanged();
      }

      UpdateBaseIndicatorCols();

      //-      if (Title.HeightOptions.AutoExpand)
      UpdateBaseFixedBands();
    }

    internal void SetFixedFrozenColCount(int newFixedColCount, int leftFrozenCount)
    {
      if (ColCount + 1 < newFixedColCount)
        ColCount = newFixedColCount + 1;
      if (newFixedColCount > FixedColCount)
      {
        FixedColCount = newFixedColCount;
        FrozenColCount = leftFrozenCount;
      }
      else
      {
        FrozenColCount = leftFrozenCount;
        FixedColCount = newFixedColCount;
      }
    }

    internal void UpdateDataRows()
    {
      InternalRebuildVisibleRows(false, false, false);
      CheckRecalcFooters();

      foreach (DataGridColumn column in Columns)
      {
        if (!string.IsNullOrEmpty(column.Title.Text) || (column.PropDescr != null))
          column.DefaultWidth = column.CalcDefaultWidth();
        else
          column.DefaultWidth = 64;
      }

      UpdateBaseGridColumns();
      UpdateDataRowHeights();

      UpdateBaseRowCount();
      UpdateBaseRowHeights();
      InvalidateGrid();
    }

    protected internal virtual void SortedRowListChanged()
    {
      VisibleRows.IndexesIsDirty = true;
      UpdateDataRows();
      UpdateGridRowIndexFromCurrencyManagerPosition();
      UpdateDataViewCurrencyManagerPosition();
    }

    /// <summary>
    /// Updates list of visible rows and refreshes the grid display
    /// </summary>
    public void UpdateVisibleRows()
    {
      UpdateDataRows();
    }

    protected internal virtual void InternalRebuildVisibleRows(bool stopOnEscape, bool stopOnAnyKey, bool useWaitCursor)
    {
      int ticks = Environment.TickCount;
      bool waitCursorSet = !( (Cursor.Current == Cursors.Default) || (Cursor.Current == null) );

      foreach (DataGridRow row in Rows)
      {
        row.Visible = OnCheckRowVisible(row);

        if ((stopOnEscape == true) && EhLibUtils.CheckKeyPressed(null, Keys.Escape, true))
          break;

        if ((stopOnAnyKey == true) && EhLibUtils.InteractiveIsAnyKeyPressed(null))
          break;

        if (useWaitCursor &&
            (Environment.TickCount - ticks > 1000) &&
            //((Cursor.Current == Cursors.Default) || (Cursor.Current == null)) &&
            (waitCursorSet == false))
        {
          Cursor.Show();
          Cursor.Current = Cursors.WaitCursor;
          waitCursorSet = true;
        }
      }

      if (waitCursorSet)
        Cursor.Current = null;

    }

    protected internal virtual void RebuildVisibleRows(bool stopOnEscape, bool stopOnAnyKey, bool useWaitCursor)
    {
      if (IsDisposed) return;
      DataLink.CheckBrowseMode();
      InternalRebuildVisibleRows(stopOnEscape, stopOnAnyKey, useWaitCursor);
      VisibleRows.EnsureIndexesActual();
      CheckRecalcFooters();
      UpdateBaseRowCount();
      UpdateGridRowIndexFromCurrencyManagerPosition();
      Invalidate();
    }

    public void RebuildVisibleRows()
    {
      RebuildVisibleRows(false, false, false);
    }

    protected internal virtual bool OnCheckRowVisible(DataGridRow row)
    {
      DataGridRowVisibleStateNeededEventArgs rve = new DataGridRowVisibleStateNeededEventArgs(row);
      ProcessRowVisibleStateNeeded(rve);
      return rve.RowVisible;
    }

    protected virtual void ProcessRowVisibleStateNeeded(DataGridRowVisibleStateNeededEventArgs rve)
    {
      HandleRowVisibleStateNeededEvent(rve);
      if (!rve.Handled)
        OnRowVisibleStateNeeded(rve);
    }

    protected internal virtual void OnRowVisibleStateNeeded(DataGridRowVisibleStateNeededEventArgs e)
    {
      bool searchBoxRowVisible = SearchBox.CheckRowVisible(e.Row);
      bool titleFilterRowVisible = Title.Filter.CheckRowVisible(e.Row);
      e.RowVisible = searchBoxRowVisible && titleFilterRowVisible;
    }

    protected virtual void HandleRowVisibleStateNeededEvent(DataGridRowVisibleStateNeededEventArgs e)
    {
      var eh = Events[EventKeyRowVisibleStateNeeded] as EventHandler<DataGridRowVisibleStateNeededEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    internal void LocateRow(DataGridRow findRow)
    {
      if (TreeViewArea.Visible)
      {
        foreach (DataGridRow row in Rows)
        {
          if (row == findRow)
          {
            DataGridRow curRow = row;
            while (curRow != null)
            {
              TreeViewArea.SetTreeNodeExpandedState(curRow, true);
              DataGridTreeViewNodeStateNeededEventArgs nodeState = TreeViewArea.GetTreeNodeState(curRow);
              int parentRowIndex = Rows.IndexOfSourceItem(nodeState.ParentItem);
              if (parentRowIndex >= 0)
                curRow = Rows[parentRowIndex];
              else
                curRow = null;
            }
          }
        }

        int findRowIndex = VisibleRows.IndexOf(findRow);
        if (findRowIndex >= 0)
        {
          CurrentRowIndex = findRowIndex;
          ClampInView(new GridCoord(Col, Row), true, true);
        }
      }
    }

    protected internal override void OnCurrentListItemStateChanged()
    {
      UpdateBaseRowCount();
    }

    protected internal override void OnCurrentListItemModifiedStateChanged()
    {
      UpdateBaseRowCount();
    }

    protected internal override void OnEditorHasValueToPushChanged()
    {
      UpdateBaseRowCount();
    }

    protected internal override void UpdateBaseFixedBands()
    {
      int fixedRowCount = 0;

      if (Title.Visible)
      {
        fixedRowCount = fixedRowCount + 1;
        titleRowIndex = 0;
      }
      else
      {
        titleRowIndex = -1;
      }

      FixedRowCount = fixedRowCount;

      if (TitleRowIndex >= 0)
      {
        if (Title.MultiTitle.Active)
        {
          int titleAreaHeight;
          //Title.MultiTitle.ResetNodesBound();
          if (Title.MultiTitle.Root.Items.Count == 0)
          {
            titleAreaHeight = Title.CalcTitleHeight() + Title.HorzLineSpace;
          }
          else
          {
            Title.MultiTitle.ResetNodesBound();
            titleAreaHeight = Title.MultiTitle.FullHeight;
          }

          RowHeights[TitleRowIndex] = titleAreaHeight;
          Title.Height = titleAreaHeight - Title.HorzLineSpace;
        }
        else
        {
          Title.Height = Title.CalcTitleHeight();
          RowHeights[TitleRowIndex] = Title.Height + Title.HorzLineSpace;
        }


        foreach (DataGridColumn c in VisibleColumns)
        {
          Size sz;
          if (Title.MultiTitle.Active)
          {
            sz = new Size(c.Width, c.Title.TitleNode.Bounds.Height);
            sz.Height = sz.Height - Title.HorzLineSpace;
          }
          else
            sz = new Size(c.Width, Title.Height);
          c.Title.UpdateMetrics(sz);
        }

      }
      else
      {
        Title.Height = 0;
      }

      if (Footer.Rows.Count > 0)
      {
        ContraRowCount = Footer.Rows.Count;
        for (int i = 0; i < Footer.Rows.Count; i++)
        {
          int topLineHeight;
          if (i == 0)
            topLineHeight = 1;
          else
            topLineHeight = 0;
          DataGridFooterRow ftr = Footer.Rows[i];
          RowHeights[RowCount + i] = ftr.Height + LineOptions.HorzLineSpace + topLineHeight;
        }
      }
      else
      {
        ContraRowCount = 0;
      }

      InvalidateGrid();
    }

    protected internal virtual void UpdateRowHeights()
    {
      UpdateBaseFixedBands();
      UpdateDataRowHeights();
      UpdateBaseRowHeights();
    }

    protected virtual void UpdateDataRowHeights()
    {
      int rowMaxHeight = RowOptions.MaxHeight();

      defaultDataRowHeight = CalcDefaultRowHeight();

      List<DataGridColumn> columnsToCalcHeight = new List<DataGridColumn>();
      ReadOnlyCollection<DataGridColumn> columnsToCalcHeightArgs = new ReadOnlyCollection<DataGridColumn>(columnsToCalcHeight);

      foreach (DataGridColumn col in VisibleColumns)
      {
        if (!col.DataRowHeightIsPermanent())
          columnsToCalcHeight.Add(col);
      }

      foreach (DataGridRow row in Rows)
      {
        int rowHeight = CalcRowHeight(row, columnsToCalcHeightArgs);
        if (rowHeight == -1)
          rowHeight = defaultDataRowHeight;
        if (rowMaxHeight > 0 && rowHeight > rowMaxHeight)
          rowHeight = rowMaxHeight;
        row.HeightInternal = rowHeight;
      }

      UpdateFootersHeight();
    }

    protected virtual void UpdateFootersHeight()
    {
      foreach (DataGridFooterRow footerRow in Footer.Rows)
      {
        footerRow.Height = footerRow.GetFooterHeight();
      }
    }

    protected virtual int CalcDefaultRowHeight()
    {
      int maxh = 0;

      if (VisibleColumns.Count == 0)
      {
        Size sz;

        if (RowOptions.HeightOptions.Unit == GridRowHeightUnit.TextLine)
        {
          sz = TextRenderer.MeasureText(EhLibUtils.DisplayGraphicsCash, N0Str, Font);
          maxh = sz.Height * RowOptions.HeightOptions.ContentHeight;
          maxh = maxh + ColumnOptions.SidePadding.Top + ColumnOptions.SidePadding.Bottom + LineOptions.HorzLineSpace;
        }
        else
        {
          maxh = RowOptions.HeightOptions.ContentHeight;
          maxh = maxh + ColumnOptions.SidePadding.Top + ColumnOptions.SidePadding.Bottom + LineOptions.HorzLineSpace;
        }
      }
      else
      {
        foreach (DataGridColumn col in VisibleColumns)
        {
          int colh = col.CalcDefaultRowHeight();
          if (colh > maxh)
            maxh = colh;
        }
      }

      return maxh;
    }

    protected virtual int CalcColumnsRowHeight(DataGridRow row, ReadOnlyCollection<DataGridColumn> columnsToCalcHeight)
    {
      int maxh;

      maxh = -1;
      foreach (DataGridColumn col in columnsToCalcHeight)
      {
        int colh = col.CalcRowHeight(row);
        if (colh > maxh)
          maxh = colh;
      }


      if (RowOptions.HeightOptions.MaxContentHeight > 0)
      {
        int rowMaxHeight;

        if (RowOptions.HeightOptions.Unit == GridRowHeightUnit.TextLine)
        {
          int fh = EhLibUtils.GetFontHeight(Font);
          rowMaxHeight = fh * RowOptions.HeightOptions.MaxContentHeight;
          rowMaxHeight = rowMaxHeight + Padding.Top + Padding.Bottom;
        }
        else
        {
          rowMaxHeight = RowOptions.HeightOptions.MaxContentHeight;
          rowMaxHeight = rowMaxHeight + Padding.Top + Padding.Bottom;
        }

        if (maxh > rowMaxHeight)
          maxh = rowMaxHeight;
      }

      return maxh;
    }

    public virtual void OnCalcRowHeight(DataGridRowHeightNeededEventArgs e)
    {
      int indicatorColCellHeight = 0;
      int dataCellsHeight;

      if (e.ColumnsToCalcHeight.Count > 0)
      {
        if (IndicatorColumn.Visible)
          indicatorColCellHeight = IndicatorColumn.CalcHeight(e.Row);

        dataCellsHeight = CalcColumnsRowHeight(e.Row, e.ColumnsToCalcHeight);

        //if (RowOptions.HeightOptions.AutoExpand)
        //  dataCellsHeight = CalcColumnsRowHeight(e.Row);
        //else
        //  dataCellsHeight = defaultDataRowHeight;

        e.RowHeight = Math.Max(indicatorColCellHeight, dataCellsHeight);
      }
      else
      {
        e.RowHeight = -1;            
      }
    }

    protected internal int CalcRowHeight(DataGridRow row)
    {
      List<DataGridColumn> columnsToCalcHeight = new List<DataGridColumn>();
      ReadOnlyCollection<DataGridColumn> columnsToCalcHeightArgs = new ReadOnlyCollection<DataGridColumn>(columnsToCalcHeight);

      foreach (DataGridColumn col in VisibleColumns)
      {
        if (!col.DataRowHeightIsPermanent())
          columnsToCalcHeight.Add(col);
      }

      int result = CalcRowHeight(row, columnsToCalcHeightArgs);
      int defaultDataRowHeight = CalcDefaultRowHeight();
      if (result < defaultDataRowHeight)
        result = defaultDataRowHeight;

      return result;
    }

    protected virtual int CalcRowHeight(DataGridRow row, ReadOnlyCollection<DataGridColumn> columnsToCalcHeight)
    {
      var eh = Events[EventKeyDataGridRowHeightNeeded] as EventHandler<DataGridRowHeightNeededEventArgs>;
      var e = new DataGridRowHeightNeededEventArgs(row, columnsToCalcHeight);
      if (eh != null && !IsDisposed)
      {
        eh(this, e);
        if (e.Handled)
          return e.RowHeight;
      }

      OnCalcRowHeight(e);
      return e.RowHeight;
    }

    protected virtual void UpdateBaseIndicatorCols()
    {
      if (IndicatorColumn.Visible && !internalDataResetting)
        ColWidths[0] = IndicatorColumn.CalcWidth();
    }

    internal virtual void UpdateGridState()
    {
      gridIsEmpty = (Columns.Count == 0) && (Rows.Count == 0);
    }

    protected internal override void CurrencyManagerListChanged(object sender, ListChangedEventArgs e)
    {
      if (IsDisposed) return;

      switch (e.ListChangedType)
      {
        case ListChangedType.Reset:
          if (internalDataResetting) break;
          internalDataResetting = true;
          try
          {
            RowListsManager.InternalClear();
            UpdateColumnsList();
            CheckPropBarsPropDescr();
            UpdateTitleSortMarkersFromDataLink();
          }
          finally
          {
            internalDataResetting = false;
          }

          RowListsManager.DataLinkEvent(-1, DataGridSourceListChangedType.ListChanged, RowEditState.Browse);
          //InternalRebuildRows();
          //UpdateDataRows();
          //if (CurrencyManager != null)
          //  CurrencyManagerPositionChanged(null, null);
          CurrencyManagerChangedNotifyColumns(sender, e);
          break;

        case ListChangedType.ItemMoved:
          RowListsManager.DataLinkEvent(-1, DataGridSourceListChangedType.ListChanged, RowEditState.Browse);
          CurrencyManagerChangedNotifyColumns(sender, e);
          break;

        case ListChangedType.ItemAdded:
          object row = CurrencyManager.List[e.NewIndex];
          if ((e.NewIndex < Rows.Count) && (addedSrcRow == row))
          {
            //EhLibUtils.DoNothing();
            //UpdateDataRow(e.NewIndex);
            //CheckRecalcFooters();
            RowListsManager.DataLinkEvent(e.NewIndex, DataGridSourceListChangedType.ItemChanged, RowEditState.Browse);

            var ce = new ListChangedEventArgs(ListChangedType.ItemChanged, e.NewIndex, e.PropertyDescriptor);
            CurrencyManagerChangedNotifyColumns(sender, ce);
          }
          else
          {
            //AddDataRow(e.NewIndex);
            //CheckRecalcFooters();
            //if (InternalCurrentRowIndex == -1)
            //  CurrencyManagerPositionChanged(sender, e);

            RowListsManager.DataLinkEvent(e.NewIndex, DataGridSourceListChangedType.ItemAdded, DataLink.CurrentListItemState);
            addedSrcRow = row;
            CurrencyManagerChangedNotifyColumns(sender, e);
          }
          break;

        case ListChangedType.ItemChanged:
          //UpdateDataRow(e.NewIndex);
          //CheckRecalcFooters();
          RowListsManager.DataLinkEvent(e.NewIndex, DataGridSourceListChangedType.ItemChanged, RowEditState.Browse);
          CurrencyManagerChangedNotifyColumns(sender, e);
          break;

        case ListChangedType.ItemDeleted:
          //DeleteItem(e.NewIndex);
          //CheckRecalcFooters();
          RowListsManager.DataLinkEvent(e.NewIndex, DataGridSourceListChangedType.ItemDeleted, RowEditState.Browse);
          CurrencyManagerChangedNotifyColumns(sender, e);
          break;

        default:
          UpdateColumnsList();
          RowListsManager.RebuildRows();
          CurrencyManagerChangedNotifyColumns(sender, e);
          break;
      }

      HorzScrollBarPanelControl.GridDataChanged();
    }

    protected internal virtual void CurrencyManagerChangedNotifyColumns(object sender, ListChangedEventArgs e)
    {
      foreach (DataGridColumn column in Columns)
        column.CurrencyManagerChanged(sender, e);
    }


    public void UpdateCurrentDataRowPosition()
    {
      UpdateGridRowIndexFromCurrencyManagerPosition();
      UpdateDataViewCurrencyManagerPosition();
    }

    protected internal override void CurrencyManagerPositionChanged(object sender, EventArgs e)
    {
      UpdateCurrentDataRowPosition();
    }

    protected internal virtual void DataViewCurrencyManagerListChanged(object sender, ListChangedEventArgs e)
    {

    }

    protected internal virtual void DataViewCurrencyManagerPositionChanged(object sender, EventArgs e)
    {
      if (internalDataViewCurrencyManagerPositionSetting) return;

      internalDataViewCurrencyManagerPositionSetting = true;
      try
      {
        if (dataViewBindingSource.Position >= 0)
          CurrentRowIndex = dataViewBindingSource.Position;
      }
      finally
      {
        internalDataViewCurrencyManagerPositionSetting = false;
      }
    }

    internal void UpdateGridRowIndexFromCurrencyManagerPosition()
    {
      if (CurrencyManager.Position >= 0 &&
          Rows.Count > CurrencyManager.Position)
      {
        InternalCurrentRowIndex = Rows[CurrencyManager.Position].VisibleIndex;
      }
      else
      {
        InternalCurrentRowIndex = -1;
      }
    }

    internal void UpdateDataViewCurrencyManagerPosition()
    {
      if (internalDataViewCurrencyManagerPositionSetting) return;

      internalDataViewCurrencyManagerPositionSetting = true;
      try
      {
        if (InternalCurrentRowIndex >= 0 && dataViewBindingSource.Count > 0)
          dataViewBindingSource.Position = InternalCurrentRowIndex;
      }
      finally
      {
        internalDataViewCurrencyManagerPositionSetting = false;
      }
    }

    internal void UpdateBaseRowCount()
    {
      int newRowCount;
      if (VisibleRows.Count == 0)
        newRowCount = FixedRowCount + 1;
      else
        newRowCount = FixedRowCount + VisibleRows.Count;

      if ((AllowedOperations.AllowAdd &&
            DataLink.CurrentListItemState != RowEditState.New)
          ||
           (DataLink.CurrentListItemState == RowEditState.New &&
            (DataLink.CurrentRowModified || DataLink.EditorHasValueToPush))
         )
      {
        if (VisibleRows.Count != 0)
          newRowCount = newRowCount + 1;
      }

      RowCount = newRowCount;
    }

    internal void UpdateBaseRowHeights()
    {
      for (int i = 0; i < VisibleRows.Count; i++)
      {
        RowHeights[FixedRowCount + i] = VisibleRows[i].Height + LineOptions.HorzLineSpace;
      }

      int defRowHeight = CalcDefaultRowHeight();
      if (LineOptions.VertLines)
        defRowHeight = defRowHeight + GridLineWidth;
      DefaultRowHeight = defRowHeight;

      for (int i = VisibleRows.Count; i < RowCount - FixedRowCount; i++)
      {
        RowHeights[FixedRowCount + i] = DefaultRowHeight;
      }

    }

    //private void InternalAddDataRow(int index, DataGridRow rawDataRow)
    //{
    //  InitDataRow(rawDataRow, index);
    //  Rows.Insert(index, rawDataRow);
    //}

    protected internal virtual void UpdateDataRow(int index)
    {
      Invalidate();
    }

    protected internal void GridDeleteRow(int rowIndex)
    {
      DeleteRow(rowIndex);
    }

    //private void ListViewDataBinding_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //  try
    //  {
    //    //if (SelectedIndices.Count > 0 && CurrencyManager.Position != SelectedIndices[0])
    //    //  CurrencyManager.Position = SelectedIndices[0];
    //  }
    //  catch
    //  {
    //  }
    //}

    public virtual CellAreaType GetCellAreaTypeByColRow(int colIndex, int rowIndex)
    {
      CellAreaType result = new CellAreaType();

      if (colIndex == -1 || colIndex >= FullColCount)
        result.HorzType = DataGridCellAreaHorzType.Invalid;
      else if (colIndex < FixedColCount - FrozenColCount)
        result.HorzType = DataGridCellAreaHorzType.Indicator;
      else if (colIndex < ColCount)
        result.HorzType = DataGridCellAreaHorzType.Data;
      else
        result.HorzType = DataGridCellAreaHorzType.Contra;

      if (rowIndex == -1 || rowIndex >= FullRowCount)
        result.VertType = DataGridCellAreaVertType.Invalid;
      else if (rowIndex < FixedRowCount)
        result.VertType = DataGridCellAreaVertType.Title;
      else if (rowIndex < RowCount)
        result.VertType = DataGridCellAreaVertType.Data;
      else
        result.VertType = DataGridCellAreaVertType.Footer;

      return result;
    }

    public virtual void DataCellIndexToGridCellIndex(int dataColIndex, int dataRowIndex, out int gridColIndex, out int gridRowIndex)
    {
      gridColIndex = dataColIndex + StartDataColIndex;
      gridRowIndex = dataRowIndex + StartDataRowIndex;
    }

    public override BaseGridCellManager CellManByColRow(int colIndex, int rowIndex, out int localColIndex, out int localRowIndex)
    {
      BaseGridCellManager result;
      int areaColOffset = 0;
      int areaRowOffset = 0;

      if (colIndex >= 0 && colIndex == IndicatorColIndex)
      {
        if (rowIndex >= 0 && rowIndex < FixedRowCount)
          result = titleIndicatorCell;
        else
        {
          result = indicatorCell;
          areaRowOffset = StartDataRowIndex;
        }
      }
      else if (rowIndex >= 0 && rowIndex < FixedRowCount)
      {
        areaColOffset = StartDataColIndex;

        if (gridIsEmpty)
          result = emptyTitleCell;
        else if (VisibleColumns.Count > 0)
          result = TitleCellMan;
        else
          result = TitleCellMan;
      }
      else if (rowIndex >= RowCount)
      {
        areaColOffset = StartDataColIndex;
        areaRowOffset = RowCount;

        if (gridIsEmpty)
          result = emptyDataCell;
        else
          result = footerCell;
      }
      else
      {
        areaColOffset = StartDataColIndex;
        areaRowOffset = StartDataRowIndex;

        if (gridIsEmpty || colIndex == -1)
          result = emptyDataCell;
        else
        {
          if (VisibleColumns.Count > 0)
          {
            DataGridColumn column = VisibleColumns[colIndex - StartDataColIndex];
            if (rowIndex - FixedRowCount < VisibleRows.Count)
              result = column.RowCells[VisibleRows[rowIndex - FixedRowCount]];
            else if (VisibleRows.Count == 0)
              result = column.NewVirtualRowCell;
            else
              result = column.NewVirtualRowCell;
          }
          else
            result = emptyDataCell;
        }
      }

      localColIndex = colIndex - areaColOffset;
      localRowIndex = rowIndex - areaRowOffset;

      return result;
    }

    public virtual DataGridBaseCellMan EmptyAreaCellColRow(int colIndex, int rowIndex)
    {
      return (DataGridBaseCellMan)CellManByColRow(colIndex, rowIndex);
    }

    protected virtual bool CheckSpecPaintCellAction(GraphicsContext gc, int colIndex, int rowIndex,
      ref Rectangle rect, BasePaintCellStates state)
    {
      if ((colIndex >= FixedColCount) &&
          (rowIndex < FixedRowCount) &&
          (Columns.Count > 0) &&
          (Title.Visible == true) &&
          (Title.MultiTitle.Active == true) &&
          (VisibleColumns.Count > 0))
      {
        if (titleTreePainted == true) return true;
        Rectangle titlePaintRect = new Rectangle();
        Point paintShift;

        titlePaintRect.X = (int)(HorzAxis.FixedBoundary - HorzAxis.RollStartVisPos);
        titlePaintRect.Width = HorzAxis.RollClientLen;
        titlePaintRect.Y = VertAxis.GridClientStart;
        titlePaintRect.Height = VertAxis.FixedBoundary;
        paintShift = titlePaintRect.Location;

        Title.MultiTitle.PaintTitleTree(gc, titlePaintRect, paintShift);
        titleTreePainted = true;
        return true;
      }
      else
      {
        return false;
      }

    }

    protected virtual bool CheckSpecPaintCellAreaAction(GraphicsContext gc, int colIndex, int rowIndex,
      ref Rectangle rect, BasePaintCellStates state)
    {
      int dataColIndex = colIndex - FixedColCount;
      int dataRowIndex = rowIndex - FixedRowCount;
      bool result = false;

      if ((dataColIndex >= 0) && (dataColIndex < VisibleColumns.Count) &&
          (dataRowIndex >= 0) && (dataRowIndex < VisibleRows.Count))
      {
        DataGridColumn col = VisibleColumns[dataColIndex];
        DataGridRow row = VisibleRows[dataRowIndex];
        if (col.MergeDuplicates)
        {
          DataGridRow masterRow;
          int masterRowIndex;
          int mergeRowCount;
          Rectangle masterCellRect;
          Rectangle paintRect;
          CellMergeDuplicatesPaintKind paintKind;

          if (IsCellPainted(colIndex, rowIndex)) return true;

          FillMergePaintInfo(rowIndex, row, col, rect, out masterRow, out masterRowIndex, out mergeRowCount, out masterCellRect, out paintKind);

          if (paintKind != CellMergeDuplicatesPaintKind.ClassicPaint)
          {
            result = true;
            if (paintKind == CellMergeDuplicatesPaintKind.MergedPaint)
            {
              List<Color> backFilledColors = new List<Color>();
              int gridMasterRowIndex = DataToRawRow(masterRowIndex);
              //int gridMasterBorderRowIndex = gridMasterRowIndex + mergeRowCount - 1;
              //              DrawBordersForCellArea(graphics, colIndex, gridMasterBorderRowIndex, ref masterCellRect, state);
              paintRect = CalcMergePaintRect(rowIndex, row, col, rect, masterRow, masterRowIndex, mergeRowCount, masterCellRect, paintKind);
              PaintMergedCellsBackground(gc, colIndex, rowIndex, masterCellRect, state, masterRow, masterRowIndex, mergeRowCount, paintRect, backFilledColors);
              PaintMergedCellsForeground(gc, colIndex, rowIndex, masterCellRect, state, masterRow, masterRowIndex, mergeRowCount, paintRect, backFilledColors);
              SetCellsPaintedState(colIndex, gridMasterRowIndex, 1, mergeRowCount, true);
            }
          }
        }
      }

      return result;
    }

    private Rectangle CalcMergePaintRect(int rowIndex, DataGridRow row, DataGridColumn column, Rectangle rect,
      DataGridRow masterRow, int masterRowIndex, int mergeRowCount, Rectangle masterCellRect,
      CellMergeDuplicatesPaintKind paintKind)
    {
      Rectangle paintRect = masterCellRect;

      if (paintRect.Y < VertAxis.FixedBoundary)
      {
        int delta = VertAxis.FixedBoundary - paintRect.Y;
        paintRect.Y = VertAxis.FixedBoundary;
        paintRect.Height = paintRect.Height - delta;
      }

      if (paintRect.Bottom > VertAxis.ContraStart)
        paintRect.Height = paintRect.Height - (paintRect.Bottom - VertAxis.ContraStart);

      return paintRect;
    }

    private void FillMergePaintInfo(int rowIndex, DataGridRow row, DataGridColumn column, Rectangle cellRect,
      out DataGridRow masterRow, out int masterRowIndex, out int mergeRowCount, out Rectangle masterCellRect,
      out CellMergeDuplicatesPaintKind paintKind)
    {
      masterRow = null;
      masterRowIndex = -1;
      mergeRowCount = -1;
      //clipRect = Rectangle.Empty;
      masterCellRect = cellRect;
      paintKind = CellMergeDuplicatesPaintKind.ClassicPaint;

      int dataRowIndex = RawToDataRowIndex(rowIndex);
      if (dataRowIndex >= column.MergeDuplicatesList.Count) return;

      MergeDuplicatesData mergeData = column.MergeDuplicatesList[dataRowIndex];
      if (mergeData == null) return;

      paintKind = CellMergeDuplicatesPaintKind.MergedPaint;
      masterCellRect = cellRect;

      if (mergeData.MasterDataRowIndex < dataRowIndex)
      {
        for (int i = mergeData.MasterDataRowIndex; i < dataRowIndex; i++)
        {
          int gridRowIndex = i + FixedRowCount;
          masterCellRect.Y = masterCellRect.Y - RowHeights[gridRowIndex];
        }
      }

      masterCellRect.Height = 0;
      for (int i = 0; i < mergeData.MergeRowCount; i++)
      {
        int gridRowIndex = i + mergeData.MasterDataRowIndex + FixedRowCount;
        masterCellRect.Height = masterCellRect.Height + RowHeights[gridRowIndex];
      }

      masterRowIndex = mergeData.MasterDataRowIndex;
      mergeRowCount = mergeData.MergeRowCount;
      masterRow = VisibleRows[masterRowIndex];
    }

    private void PaintMergedCellsBackground(GraphicsContext gc, int colIndex, int rowIndex, Rectangle rect,
      BasePaintCellStates state, DataGridRow masterRow, int masterRowIndex, int mergeRowCount,
      Rectangle paintRect, List<Color> backFilledColors)
    {
      Rectangle cellRect = rect;
      Color backFilledColor;
      for (int i = 0; i < mergeRowCount; i++)
      {
        int gridRowIndex = i + masterRowIndex + FixedRowCount;
        cellRect.Height = RowHeights[gridRowIndex];

        if (cellRect.Bottom > VertAxis.FixedBoundary &&
            cellRect.Top < VertAxis.ContraStart)
        {
          BasePaintCellStates cellPaintState = GetCellPaintState(colIndex, gridRowIndex, Focused);
          bool drawBottomBorder = (i == mergeRowCount - 1);
          Rectangle cellAreaRect = cellRect;

          DrawBordersForCellArea(gc, colIndex, gridRowIndex, ref cellAreaRect, state, true, drawBottomBorder);
          PaintMergedCellBackground(gc, colIndex, gridRowIndex, cellAreaRect, cellPaintState, out backFilledColor);
          backFilledColors.Add(backFilledColor);
        }
        else
        {
          backFilledColors.Add(Color.Empty);
        }

        cellRect.Y = cellRect.Y + cellRect.Height;
      }
    }

    private void PaintMergedCellBackground(GraphicsContext gc, int colIndex, int rowIndex, Rectangle cellRect,
      BasePaintCellStates state, out Color backFilledColor)
    {
      backFilledColor = Color.Empty;
      if (cellRect == Rectangle.Empty) return;

      //state = state & ~BasePaintCellStates.Focused;
      //state = state & ~BasePaintCellStates.Current;

      int areaColIndex;
      int areaRowIndex;

      BaseGridCellManager cell = CellManByColRow(colIndex, rowIndex, out areaColIndex, out areaRowIndex);
      Debug.Assert(cell != null, "BaseGridControl.PaintCell Cell = null");

      Point inCellMousePos = new Point(-1, -1);

      BaseGridCellPaintEventArgs pea =
        cell.GetCellPaintParams(this, gc, colIndex, rowIndex, cellRect, cellRect, state, areaColIndex, areaRowIndex, inCellMousePos);
      DataAxisGridDataCellPaintEventArgs dpea = pea as DataAxisGridDataCellPaintEventArgs;
      if (dpea != null)
      {
        dpea.IsPaintForeground = false;
      }

      cell.ProcessPaint(pea);
      backFilledColor = dpea.BackFilledColor;
    }

    private bool ColorIsDark(Color color)
    {
      float brightest = color.GetBrightness();
      if (color.A != 255)
      {
        float af = (float)color.A / 255;
        brightest = brightest / af;
      }
      return brightest < 0.5;
    }

    private void PaintMergedCellsForeground(GraphicsContext gc, int colIndex, int rowIndex, Rectangle rect,
      BasePaintCellStates state, DataGridRow masterRow, int masterRowIndex, int mergeRowCount,
      Rectangle paintRect, List<Color> backFilledColors)
    {
      Rectangle clipCellRect = rect;
      //Color backFilledColor;
      bool backFilledColorDark = ColorIsDark(backFilledColors[0]);
      bool nextBackFilledColorDark;
      int gridMasterRowIndex = masterRowIndex + FixedRowCount;
      bool firstHit = true;

      clipCellRect.Height = 0;

      for (int i = 0; i < mergeRowCount; i++)
      {
        int gridRowIndex = i + masterRowIndex + FixedRowCount;

        if (clipCellRect.Bottom + RowHeights[gridRowIndex] < VertAxis.FixedBoundary)
        {
          clipCellRect.Y = clipCellRect.Y + RowHeights[gridRowIndex];
        }
        else if (clipCellRect.Top >= VertAxis.ContraStart)
        {
          break;
        }
        else
        {
          if (firstHit)
          {
            backFilledColorDark = ColorIsDark(backFilledColors[i]);
            clipCellRect.Height = clipCellRect.Height + RowHeights[gridRowIndex];
            firstHit = false;
          }
          else
          {
            nextBackFilledColorDark = ColorIsDark(backFilledColors[i]);
            if (backFilledColorDark != nextBackFilledColorDark)
            {
              PaintMergedCellForeground(gc, colIndex, gridMasterRowIndex, rect, state,
                masterRow, masterRowIndex, mergeRowCount, paintRect, backFilledColorDark, clipCellRect);

              clipCellRect.Y = clipCellRect.Bottom;
              clipCellRect.Height = 0;
              backFilledColorDark = nextBackFilledColorDark;
            }
            clipCellRect.Height = clipCellRect.Height + RowHeights[gridRowIndex];
          }
        }
      }

      if (clipCellRect.Height > 0)
      {
        PaintMergedCellForeground(gc, colIndex, gridMasterRowIndex, rect, state,
          masterRow, masterRowIndex, mergeRowCount, paintRect, backFilledColorDark, clipCellRect);
      }
    }

    private void PaintMergedCellForeground(GraphicsContext gc, int colIndex, int rowIndex, Rectangle rect,
      BasePaintCellStates state, DataGridRow masterRow, int masterRowIndex, int mergeRowCount,
      Rectangle paintRect, bool backFilledColorDark, Rectangle clipCellRect)
    {
      if (paintRect == Rectangle.Empty) return;

      state = state & ~BasePaintCellStates.Focused;
      state = state & ~BasePaintCellStates.Current;

      int areaColIndex;
      int areaRowIndex;

      BaseGridCellManager cell = CellManByColRow(colIndex, rowIndex, out areaColIndex, out areaRowIndex);
      Debug.Assert(cell != null, "BaseGridControl.PaintCell Cell = null");

      Point inCellMousePos = new Point(-1, -1);

      BaseGridCellPaintEventArgs pea = cell.GetCellPaintParams(this, gc, colIndex, rowIndex, paintRect, paintRect, state, areaColIndex, areaRowIndex, inCellMousePos);
      DataAxisGridDataCellPaintEventArgs dpea = pea as DataAxisGridDataCellPaintEventArgs;
      if (dpea != null)
      {
        dpea.IsPaintBackground = false;
        if (backFilledColorDark)
          dpea.ForeColor = SystemColors.HighlightText;
      }

      Region oldClip = null;

      if (clipCellRect != Rectangle.Empty)
      {
        oldClip = gc.Graphics.Clip;
        gc.Graphics.SetClip(clipCellRect, CombineMode.Intersect);
      }

      cell.ProcessPaint(pea);

      if (oldClip != null)
        gc.Graphics.Clip = oldClip;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
      //e.Graphics.FillRectangle(SystemBrushes.ControlDark, ClientBounds);
      //return;

      titleTreePainted = false;
      ResetDataCellPaintedArray();
      base.OnPaint(e);
      if (EmptyDataInfo.Showing)
        EmptyDataInfo.PaintEmptyDataInfo(e.Graphics);
    }

    private void ResetDataCellPaintedArray()
    {
      if (dataCellPaintedArray.GetLength(0) != HorzAxis.RollVisCellCount || dataCellPaintedArray.GetLength(1) != VertAxis.RollVisCellCount)
      {
        dataCellPaintedArray = new bool[HorzAxis.RollVisCellCount, VertAxis.RollVisCellCount];
      }
      else
      {
        Array.Clear(dataCellPaintedArray, 0, dataCellPaintedArray.Length);
      }
    }

    private void SetCellsPaintedState(int colIndex, int rowIndex, int colCount, int rowCount, bool isPainted)
    {
      for (int ci = 0; ci < colCount; ci++)
      {
        int vci = colIndex + ci - HorzAxis.StartVisCell;
        for (int ri = 0; ri < rowCount; ri++)
        {
          int vri = rowIndex + ri - VertAxis.StartVisCell;
          if (vci >= 0 && vci < dataCellPaintedArray.GetLength(0) &&
              vri >= 0 && vri < dataCellPaintedArray.GetLength(1))
          {
            dataCellPaintedArray[vci, vri] = isPainted;
          }
        }
      }
    }

    private bool IsCellPainted(int colIndex, int rowIndex)
    {
      int visColIndex = colIndex - HorzAxis.StartVisCell;
      int visRowIndex = rowIndex - VertAxis.StartVisCell;
      return dataCellPaintedArray[visColIndex, visRowIndex];
    }

    //ProcessPaint
    protected override void PaintCell(GraphicsContext gc, int colIndex, int rowIndex, Rectangle rect, Rectangle cellAreaRect, BasePaintCellStates state)
    {
      if (!CheckSpecPaintCellAction(gc, colIndex, rowIndex, ref rect, state))
      {
        if (Selection.CellIsSelected(colIndex, rowIndex))
          state = state | BasePaintCellStates.Selected;

        base.PaintCell(gc, colIndex, rowIndex, rect, cellAreaRect, state);

        if (DesignMode)
        {
          IDesignerHost idh = (IDesignerHost)GetService(typeof(IDesignerHost));
          if (idh == null) return;
          //Debug.Assert(idh != null, "PaintCell DesignMode == true but GetService(typeof(IDesignerHost)) returns null");
          var grd = idh.GetDesigner(this) as IDataGridDesigner;
          if (grd != null)
            grd.PaintCellDesignData(this, gc.Graphics, colIndex, rowIndex, rect, state, null);
        }
      }
    }

    protected override void PaintCellArea(GraphicsContext gc, int colIndex, int rowIndex, Rectangle rect, BasePaintCellStates state)
    {
      if (!CheckSpecPaintCellAreaAction(gc, colIndex, rowIndex, ref rect, state))
      {
        Rectangle cellAreaRect = rect;
        DrawBordersForCellArea(gc, colIndex, rowIndex, ref rect, state);
        PaintCell(gc, colIndex, rowIndex, rect, cellAreaRect, state);
      }
    }

    private void DrawEmptyAreaCellLine(Graphics g, Color fromColor, Color toColor, DashStyle lStyle,
      Point fromPoint, Point toPoint)
    {
      if ((LineOptions.VertCellFreeAreaFillStyle == DataGridVertCellFreeAreaFillStyle.ColumnGradient) && (fromColor != toColor))
      {
        Point grFromPoint = fromPoint;
        grFromPoint.Y = grFromPoint.Y - 1;

        using (Brush grdntBr = new LinearGradientBrush(grFromPoint, toPoint, fromColor, toColor))
        {
          using (Pen grdntPen = new Pen(grdntBr))
          {
            if (lStyle != DashStyle.Solid)
            {
              PaintingDrawLine(g, BackColor, DashStyle.Solid, BackColor, fromPoint, toPoint);
            }
            grdntPen.DashStyle = lStyle;
            g.DrawLine(grdntPen, fromPoint, toPoint);
          }
        }
      }
      else
      {
        PaintingDrawLine(g, fromColor, lStyle, BackColor, fromPoint, toPoint);
      }
    }

    protected internal override void OnCellFreeAreaPaint(BaseGridCellFreeAreaPaintEventArgs e)
    {
      BasePaintCellStates cellPaintState;
      bool lineIsPaint;
      Color lineColor;
      DashStyle lineStyle;
      bool isExtent;
      Rectangle rect = e.AreaRect;

      if ((e.ColIndex < 0) && (e.RowIndex >= 0))
      {
        if (LineOptions.HorzCellFreeAreaFillStyle == DataGridHorzCellFreeAreaFillStyle.GridBack)
          base.PaintEmptyAreaCell(e.GraphicsContext, e.ColIndex, e.RowIndex, rect);
        else
        {
          if (e.ColIndex == -1 && e.RowIndex == RowCount)
          {
            ProcessGetCellBorders(e.ColIndex, e.RowIndex, GridCellBorderSide.Top, out lineIsPaint, out lineColor, out lineStyle, out isExtent);
            if (lineIsPaint)
            {
              PaintingDrawLine(e.Graphics, lineColor, lineStyle, BackColor, new Point(rect.Left, rect.Top), new Point(rect.Right - 1, rect.Top));
              rect.Y = rect.Y + 1;
              rect.Height = rect.Height - 1;
            }
          }

          DrawBordersForCellArea(e.GraphicsContext, e.ColIndex, e.RowIndex, ref rect, 0);

          int areaColIndex;
          int areaRowIndex;

          BaseGridCellManager cell = CellManByColRow(e.ColIndex, e.RowIndex, out areaColIndex, out areaRowIndex);
          Debug.Assert(cell != null, "DataGridEh.PaintCell Cell = null");

          //cell.GridCellPosToAreaCellPos(col, row, out areaColIndex, out areaRowIndex);

          if (e.RowIndex == Row)
            cellPaintState = BasePaintCellStates.CurrentRow;
          else
            cellPaintState = 0;

          BaseGridCellPaintEventArgs pea = cell.GetCellPaintEmptyAreaEventArgs
            (this, e.GraphicsContext, e.ColIndex, e.RowIndex, rect, cellPaintState, areaColIndex, areaRowIndex, new Point(-1, -1));

          cell.OnPaintEmptyArea(pea);
          //cell.PaintEmptyArea(g, col, row, ref rect, cellPaintState, areaColIndex, areaRowIndex);
        }
      }
      else if (e.ColIndex >= 0)
      {
        if (LineOptions.VertCellFreeAreaFillStyle == DataGridVertCellFreeAreaFillStyle.GridBack)
          base.PaintEmptyAreaCell(e.GraphicsContext, e.ColIndex, e.RowIndex, rect);
        else
        {
          Color fromColor, toColor;
          //BaseGridCellBorderEventArgs er = new BaseGridCellBorderEventArgs(col, RowCount - 1, col, RowCount - 1, GridCellBorderType.Right);
          //BaseGridCellBorderEventArgs el = new BaseGridCellBorderEventArgs(col, RowCount - 1, col, RowCount - 1, GridCellBorderType.Left);

          toColor = BackColor;

          ProcessGetCellBorders(e.ColIndex, RowCount - 1, GridCellBorderSide.Right, out lineIsPaint, out lineColor, out lineStyle, out isExtent);
          //OnGetCellBorderParams(er);

          if (lineIsPaint)
          {
            DrawEmptyAreaCellLine(e.Graphics, lineColor, toColor, lineStyle, new Point(rect.Right - 1, rect.Top), new Point(rect.Right - 1, rect.Bottom));
            rect.Width = rect.Width - 1;
          }

          if (e.ColIndex == ColCount)
          {
            ProcessGetCellBorders(e.ColIndex, RowCount - 1, GridCellBorderSide.Left, out lineIsPaint, out lineColor, out lineStyle, out isExtent);
            //OnGetCellBorderParams(el);
            if (lineIsPaint)
            {
              DrawEmptyAreaCellLine(e.Graphics, lineColor, toColor, lineStyle, new Point(rect.Left, rect.Top), new Point(rect.Left, rect.Bottom));
              rect.X = rect.X + 1;
              rect.Width = rect.Width - 1;
            }
          }

          fromColor = BackColor;
          int dataColumnIndex = RawToDataColumnIndex(e.ColIndex);
          if ((dataColumnIndex >= 0) && (VisibleColumns.Count > 0))
          {
            DataGridColumn column = VisibleColumns[dataColumnIndex];
            if (column.BackColor != BackColor)
            {
              fromColor = column.BackColor;
            }
          }

          if (!Background.Visible || fromColor != toColor)
          {
            if ((LineOptions.VertCellFreeAreaFillStyle == DataGridVertCellFreeAreaFillStyle.ColumnGradient) && (fromColor != toColor))
            {
              if (fromColor.A != 255)
                toColor = Color.FromArgb(fromColor.A, toColor);
              EhLibUtils.FillRectangleGradient(e.Graphics, rect, fromColor, toColor);
            }
            else
              EhLibUtils.FillRectangle(e.Graphics, rect, fromColor);
          }
        }
      }
      else
        base.OnCellFreeAreaPaint(e);
    }

    protected override BasePaintCellStates GetCellPaintState(int colIndex, int rowIndex, bool controlFocused)
    {
      BasePaintCellStates result = base.GetCellPaintState(colIndex, rowIndex, controlFocused);
      if (InternalCurrentRowIndex == -1)
      {
        result = result & ~BasePaintCellStates.Current;
        result = result & ~BasePaintCellStates.Selected;
        result = result & ~BasePaintCellStates.CurrentCol;
        result = result & ~BasePaintCellStates.CurrentRow;
      }
      return result;
    }

    protected internal override void HandleDataCellPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = Events[EventKeyDataCellPaint] as EventHandler<DataGridDataCellPaintEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellPaintEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellContentPaintEvent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      var eh = Events[EventKeyDataCellContentPaint] as EventHandler<DataGridDataCellContentPaintEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellContentPaintEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellCustomAreaPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = Events[EventKeyDataCellCustomAreaPaint] as EventHandler<DataGridDataCellPaintEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellPaintEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellClientAreaNeededEvent(DataAxisGridDataCellClientAreaNeededEventArgs e)
    {
      var eh = Events[EventKeyDataCellClientAreaNeeded] as EventHandler<DataGridDataCellClientAreaNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellClientAreaNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditorOccupyEvent(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
      var eh = Events[EventKeyDataCellEditorOccupy] as EventHandler<DataGridDataCellEditorOccupyEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellEditorOccupyEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditorReleaseEvent(DataAxisGridDataCellEditorReleaseEventArgs e)
    {
      var eh = Events[EventKeyDataCellEditorRelease] as EventHandler<DataGridDataCellEditorReleaseEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellEditorReleaseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditorParamsNeededEvent(DataAxisGridDataCellEditorParamsNeededEventArgs e)
    {
      var eh = Events[EventKeyDataCellEditorParamsNeeded] as EventHandler<DataGridDataCellEditorParamsEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellEditorParamsEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleCanShowEditorStateNeededEvent(DataAxisGridDataCellCanShowEditorStateNeededEventArgs e)
    {
      var eh = Events[EventKeyDataCellCanShowEditorStateNeeded] as EventHandler<DataGridDataCellCanShowEditorStateNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellCanShowEditorStateNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditValueNeededEvent(DataAxisGridDataCellEditValueNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellEditValueNeeded] as EventHandler<DataGridDataCellEditValueNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellEditValueNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleParseValueEvent(DataAxisGridDataCellParseValueEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellParseValue] as EventHandler<DataGridDataCellParseValueEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellParseValueEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellToolTipInfoNeeded(DataAxisGridDataCellToolTipInfoEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellToolTipInfo] as EventHandler<DataGridDataCellToolTipInfoEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellToolTipInfoEventArgs(e);
        eh(this, ge);
      }
    }

    //internal void ColumnTitleSortMarkerChanged(DataGridColumnTitle dataGridColumnTitle)
    //{
    //  throw new NotImplementedException();
    //}

    internal void UpdateTitleSortMarkersFromDataLink()
    {
      IList sortDescription = DataLink.GetDataSortDescription();
      if (sortDescription != null)
        Title.SortMarking.SortMarkers.UpdateDataFromListSortDescription(sortDescription);
    }

    internal void UpdateSearchBox()
    {
      Rectangle schBoxRect = new Rectangle();
      Rectangle cliRect = ClientBounds;

      if (!IsHandleCreated) return;
      if (searchBoxControl == null && SearchBox.Visible == false) return;

      schBoxRect.X = cliRect.Left;
      schBoxRect.Y = cliRect.Top;
      schBoxRect.Width = cliRect.Width - OutBoundaryData.RightIndent - VertScrollBarPanelControl.Width;
      schBoxRect.Height = SearchBoxControl.CalcAutoHeight();
      if (schBoxRect != SearchBoxControl.Bounds)
        SearchBoxControl.SetBounds(schBoxRect.Left, schBoxRect.Top, schBoxRect.Right, schBoxRect.Bottom);
    }

    protected internal override void UpdateOutBoundaryIndents()
    {
      //return;

      if (inUpdateOutBoundaryIndents) return;
      inUpdateOutBoundaryIndents = true;
      try
      {
        base.UpdateOutBoundaryIndents();

        if (searchBoxControl == null && SearchBox.Visible == false) return;
        SearchBoxControl.Visible = searchBox.Visible;
        if (SearchBox.Visible)
        {
          UpdateSearchBox();
          OutBoundaryData.TopIndent = OutBoundaryData.TopIndent + SearchBox.InGridHeight;
        }
      }
      finally
      {
        inUpdateOutBoundaryIndents = false;
      }
    }

    internal void LocateText(string s, DataGridLocateTextArgs args)
    {
      locateTextService.SearchText = s;
      locateTextService.SearchParams = args;
      locateTextService.SearchNext();
      locateTextService.SearchText = "";
      locateTextService.SearchParams = null;
    }

    protected override void OnEndInitialization()
    {
      if (VisiblePropBars == null) return;
      UpdateColumnsList();
      Footer.СompleteInitFooterItems();
      UpdateBaseFixedBands();
      InitColumnsFillWeight();
      RowListsManager.RebuildRows();
      UpdateGridState();
      if (DesignMode && DataGridDesigner != null)
        DataGridDesigner.GridEndInitialization(this);
    }

    protected internal virtual void OnColumnNameChanged(DataGridColumn dataGridColumn)
    {
      //
    }

    protected internal override void OnPropBarAdded(PropertyAxisBar propBar)
    {
      DataGridColumn column = (DataGridColumn)propBar;

      column.UpdateDefaultPadding();

      //if (!InInitialization)
      //{
      //  if (Title.MultiTitle.Active)
      //  {
      //    Title.MultiTitle.BeginUpdate();
      //    try
      //    {
      //      DataGridTitleNode node = null;

          //      if (column.DisplayIndex >= 0 && column.DisplayIndex < Columns.Count)
          //        node = Title.MultiTitle.GetNodeByDisplayIndex(column.DisplayIndex);

          //      if (node != null)
          //      {
          //        Title.MultiTitle.Subtitles.Insert(node.Index, column);
          //      }
          //      else
          //      {
          //        Title.MultiTitle.Subtitles.Add(column);
          //      }
          //    }
          //    finally
          //    {
          //      Title.MultiTitle.EndUpdate(false);
          //    }
          //  }
          //}
    }

    protected internal override void OnPropBarRemoved(PropertyAxisBar propBar)
    {
      //DataGridColumn column = (DataGridColumn)propBar;

      //if (!InInitialization)
      //{
      //  if (Title.MultiTitle.Active)
      //  {
      //    Title.MultiTitle.BeginUpdate();
      //    try
      //    {
      //      column.Title.TitleNode.Parent.Items.Remove(column.Title.TitleNode);
      //      //Title.MultiTitle. Subtitles.Add(column);
      //    }
      //    finally
      //    {
      //      Title.MultiTitle.EndUpdate(false);
      //    }
      //  }
      //}
    }

    public void BeginCurrentEdit()
    {
      DataLink.BeginCurrentEdit();
    }

    public void CancelCurrentEdit()
    {
      DataLink.CancelCurrentEdit();
    }

    public void EndCurrentEdit()
    {
      DataLink.EndCurrentEdit();
    }

    protected override void OnFontChanged(EventArgs e)
    {
      base.OnFontChanged(e);
      IndicatorColumn.UpdateDefaultFont();
      UpdateBaseIndicatorCols();
      UpdateRowHeights();
    }

    protected internal virtual void FooterAdded(DataGridFooterRow footer, int index)
    {
      if (InInitialization) return;

      foreach (DataGridColumn column in Columns)
      {
        column.GridFooterAdded(footer, index);
      }
      RecalcFooters();
    }

    protected internal virtual void FooterRemoved(DataGridFooterRow footer, int index)
    {
      if (InInitialization) return;

      foreach (DataGridColumn column in Columns)
      {
        column.GridFooterRemoved(footer, index);
      }
      UpdateHaveAggreageFunctionVar();
      CheckRecalcFooters();
    }

    protected internal virtual void FooterRowMoved(int oldIndex, int newIndex)
    {
      if (InInitialization) return;

      foreach (DataGridColumn column in Columns)
      {
        column.GridFooterRowMoved(oldIndex, newIndex);
      }
      UpdateHaveAggreageFunctionVar();
      CheckRecalcFooters();
    }

    internal void FooterCollectionListChanged()
    {
      if (InInitialization) return;
      if (IsDisposed) return;

      UpdateFootersHeight();
      UpdateBaseFixedBands();
    }

    public virtual void RecalcFooters()
    {
      foreach (DataGridColumn column in Columns)
      {
        foreach (DataGridColumnFooterItem columnFooter in column.Footer.Items)
        {
          //columnFooter.Recalc();
          if (columnFooter != null)
            columnFooter.Recalculate();
        }
      }
    }

    public virtual bool FooterHaveAggregateFunction()
    {
      return true;
      //foreach (DataGridColumn column in Columns)
      //{
      //  foreach (DataGridColumnFooterItem columnFooter in column.Footer.Items)
      //  {
      //    if (columnFooter != null && columnFooter.CalcValueFunction != null)
      //    {
      //      return true;
      //    }
      //  }
      //}
      //return false;
    }

    public virtual void CheckRecalcFooters()
    {
      if (FooterHaveAggregateFunction())
        RecalcFooters();
    }

    internal void FooterValueFunctionChanged(DataGridColumnFooterItem dataGridColumnFooter)
    {
      if (dataGridColumnFooter != null)
        dataGridColumnFooter.Recalculate();
      UpdateHaveAggreageFunctionVar();
      InvalidateGrid();
    }

    internal void UpdateHaveAggreageFunctionVar()
    {
      foreach (DataGridColumn column in Columns)
      {
        foreach (DataGridColumnFooterItem columnFooter in column.Footer.Items)
        {
          if (columnFooter != null && columnFooter.CalcValueFunction != null)
          {
            return;
          }
        }
      }
    }

    internal bool GetDesignHitTest(Point point)
    {

      BaseGridState state = BaseGridState.Normal;
      int index;
      int pos;
      int ofs;

      if (GridState == BaseGridState.ColMoving)
        return true;

      if (GridState == BaseGridState.Normal)
      {
        CalcSizingState(point.X, point.Y, out state, out index, out pos, out ofs);
      }

      if (state == BaseGridState.ColSizing)
      {
        //MessageBox.Show("State == BaseGridState.ColSizing", "GetDesignHitTest", MessageBoxButtons.OK, MessageBoxIcon.Information);
        return true;
      }

      Control childControl = GetChildAtPoint(point, GetChildAtPointSkip.None);

      if (childControl is BaseGridScrollBarPanelControl)
        return true;

      //GridCoord cellCoord = CalcCellCoordFromPoint(point.X, point.Y);
      //if ((cellCoord.X >= 1) && (cellCoord.Y == 0))
      //{
      //  //        MessageBox.Show(cellCoord.X.ToString() +":"+ cellCoord.Y.ToString());
      //  return true;
      //}

      return false;
    }

    protected override void OnCellMouseDown(BaseGridCellManager cell, BaseGridCellMouseEventArgs e)
    {
      CellAreaType area = GetCellAreaTypeByColRow(e.ColIndex, e.RowIndex);

      DataAxisGridDataCellMouseEventArgs de = e as DataAxisGridDataCellMouseEventArgs;
      BaseDataCellManager dataCell = cell as BaseDataCellManager;
      if (de != null && dataCell != null && !dataCell.CanMouseDownStartSelectionAtPos(de))
      {
        base.OnCellMouseDown(cell, e);
      }
      else if (area.HorzType == DataGridCellAreaHorzType.Data &&
          area.VertType == DataGridCellAreaVertType.Data &&
          Selection.RowSelect)
      {
        if (VisibleRows.Count > 0)
        {
          if ((Control.ModifierKeys & Keys.Control) != 0)
            Selection.InternalKeepSelection = true;
          try
          {
            base.OnCellMouseDown(cell, e);
          }
          finally
          {
            Selection.InternalKeepSelection = false;
          }

          if (Selection.RowsSelectionIsAllowed)
          {
            DataGridRow row = VisibleRows[e.AreaRowIndex];
            bool addToSelection = ((Control.ModifierKeys & Keys.Control) != 0) ||
                                  (Selection.KeepSelection) ||
                                  (row.Selected && Selection.SelectedRowCount == 1);
            bool shiftMode = (Control.ModifierKeys & Keys.Shift) != 0;
            StartRowSelection(row, addToSelection, true, shiftMode);
          }
        }
      }
      else if ((Control.ModifierKeys & Keys.Shift) != 0 &&
               (Col != e.ColIndex || Row != e.RowIndex) &&
               (area.HorzType == DataGridCellAreaHorzType.Data && area.VertType == DataGridCellAreaVertType.Data)
       )
      {
        //base.OnCellMouseDown(cell, e);
        StartCellRectSelectionMode(e.GridMouseArgs);
      }
      else
      {
        base.OnCellMouseDown(cell, e);
      }
    }

    protected override void OnCellMouseEnter(BaseGridCellManager cell, BaseGridCellEnterEventArgs e)
    {
      //if (ColumnOptions.EditItemOptions.ActiveArea == DataGridActiveArea.Row)
      //  InvalidateRow(e.RowIndex);
      base.OnCellMouseEnter(cell, e);
      InvalidateRow(e.RowIndex);
    }

    protected override void OnCellMouseLeave(BaseGridCellManager cell, BaseGridCellLeaveEventArgs e)
    {
      //if (ColumnOptions.EditItemOptions.ActiveArea == DataGridActiveArea.Row)
      //  InvalidateRow(e.RowIndex);
      base.OnCellMouseLeave(cell, e);
      InvalidateRow(e.RowIndex);
    }

    protected override void OnCellMouseMove(BaseGridCellManager cell, BaseGridCellMouseEventArgs e)
    {
      base.OnCellMouseMove(cell, e);
      if (Capture &&
         (e.GridMouseArgs.Button == MouseButtons.Left))
      {
        if (!e.CellRect.Contains(e.GridMouseArgs.Location) &&
            !GridMouseSpecialStateActive()
           )
        {
          if (Selection.CellsSelectionIsAllowed)
            StartCellRectSelectionMode(e.GridMouseArgs);
          //else if (Grid.Selection.CanSelectRows)
          //  ;
        }
      }
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
      if (DesignMode && DataGridDesigner != null)
      {
        DataGridDesigner.GridMouseDown(e);
      }
      else
      {
        base.OnMouseDown(e);
      }
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
      if (DesignMode &&
          DataGridDesigner != null &&
          GridState == BaseGridState.Normal)
      {
        DataGridDesigner.GridMouseMove(e);
        return;
      }

      base.OnMouseMove(e);

      switch (dataGridState)
      {
        case DataGridState.ColumnsSelecting:
        case DataGridState.RowsSelecting:
        case DataGridState.CellsRectSelecting:
          if (MoveNScrollService.Active)
            MoveNScrollService.MouseMove(e);
          break;
      }

      if (GridState == BaseGridState.ColMoving && DataGridTitleDragWin.GetTitleDragWin().Visible)
        DrawMove();
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
      if (DesignMode &&
          DataGridDesigner != null &&
          GridState == BaseGridState.Normal)
      {
        DataGridDesigner.GridMouseUp(e);
        return;
      }

      base.OnMouseUp(e);
      switch (dataGridState)
      {
        case DataGridState.ColumnsSelecting:
        case DataGridState.RowsSelecting:
        case DataGridState.CellsRectSelecting:
          if (MoveNScrollService.Active)
            MoveNScrollService.Release();
          break;
      }
      dataGridState = DataGridState.Normal;
    }

    protected override void OnMouseDoubleClick(MouseEventArgs e)
    {
      BaseGridState newState;

      //OnDoubleClick(e);

      if (DesignMode) return;

      if ((e.Button == MouseButtons.Left) &&
          (ColumnOptions.FitSizeOnSizingDoubleClick == true))
      {
        int sznIndex;
        int sznPos;
        int sznOfs;
        int dataColIndex;

        CalcSizingState(e.X, e.Y, out newState, out sznIndex, out sznPos, out sznOfs);

        if (newState == BaseGridState.ColSizing)
        {
          dataColIndex = RawToDataColumnIndex(sznIndex);

          if ((dataColIndex >= 0) && (dataColIndex < VisibleColumns.Count))
          {
            DataGridColumn col = VisibleColumns[dataColIndex];
            if (col.Selected)
            {
              foreach (DataGridColumn iCol in VisibleColumns)
                if (iCol.Selected)
                  iCol.Width = iCol.CalcDefaultWidth();
            }
            else
            {
              col.Width = col.CalcDefaultWidth();
            }

            GridState = BaseGridState.Normal;
            return;
          }
        }
      }

      base.OnMouseDoubleClick(e);
    }

    protected internal override void OnDataCellContentClick(DataAxisGridDataCellEventArgs e)
    {
      var eh = Events[EventKeyDataCellContentClick] as EventHandler<DataGridDataCellEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataGridDataCellEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseDownEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseDown] as EventHandler<DataGridDataCellMouseEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseMoveEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseMove] as EventHandler<DataGridDataCellMouseEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseUpEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseUp] as EventHandler<DataGridDataCellMouseEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseClick] as EventHandler<DataGridDataCellMouseEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseDoubleClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseDoubleClick] as EventHandler<DataGridDataCellMouseEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseEnter(DataAxisGridDataCellEnterEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseEnter] as EventHandler<DataGridDataCellEnterEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataGridDataCellEnterEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseLeave(DataAxisGridDataCellLeaveEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseLeave] as EventHandler<DataGridDataCellLeaveEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataGridDataCellLeaveEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseHoverEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseHover] as EventHandler<DataGridDataCellMouseEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    public void OnDataCellMouseDownDefaultHandler(DataGridDataCellMouseEventArgs e)
    {
      e.CellArgs.CellManager.OnMouseDown(e.CellArgs);
    }

    protected internal override void HandleDisplayValueNeededEvent(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellDisplayValueNeeded] as EventHandler<DataGridDataCellDisplayValueNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellDisplayValueNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void OnDataCellClick(DataAxisGridDataCellEventArgs e)
    {
      var eh = Events[EventKeyDataCellClick] as EventHandler<DataGridDataCellEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataGridDataCellEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal virtual void OnDataCellContentClick(DataGridDataCellEventArgs e)
    {
      var eh = Events[EventKeyDataCellContentClick] as EventHandler<DataGridDataCellEventArgs>;
      if (eh != null && !IsDisposed)
      {
        eh(this, e);
      }
    }

    protected override ContextMenuStrip GetCellContextMenuStrip(Point mousePos, int colIndex, int rowIndex)
    {
      return base.GetCellContextMenuStrip(mousePos, colIndex, rowIndex);
    }

    public virtual ContextMenuStrip GetDefaultContextMenuStrip()
    {
      int localColIndex, localRowIndex;
      DataGridColumn col;
      DataGridRow row;
      ContextMenuStrip menu = null;

      CellManByColRow(Col, Row, out localColIndex, out localRowIndex);
      if ((localColIndex >= 0) &&
          (localColIndex < VisibleColumns.Count) &&
          (localRowIndex >= 0) &&
          (localRowIndex < VisibleRows.Count))
      {
        col = VisibleColumns[localColIndex];
        row = VisibleRows[localRowIndex];
        menu = col.GetContextMenuStripAtRow(row); //ContextMenuStrip;
      }

      if (menu == null)
        menu = this.ContextMenuStrip;

      DataGridDefaultContextMenuStripNeededEventArgs ea = new DataGridDefaultContextMenuStripNeededEventArgs(menu);
      OnDefaultContextMenuStripNeeded(ea);
      menu = ea.ContextMenuStrip;

      return menu;
    }

    protected internal virtual void OnDefaultContextMenuStripNeeded(DataGridDefaultContextMenuStripNeededEventArgs e)
    {
      var eh = Events[EventKeyDefaultContextMenuStripNeeded] as EventHandler<DataGridDefaultContextMenuStripNeededEventArgs>;
      if (eh != null && !IsDisposed)
      {
        eh(this, e);
      }
    }

    //protected internal virtual void OnColumnTitleContextMenuStripNeeded(DataGridColumnTitleContextMenuStripNeededEventArgs e)
    //{
    //  var eh = Events[EventKeyColumnTitleContextMenuStripNeeded] as DataGridColumnTitleContextMenuStripNeededEventHandler;
    //  if (eh != null && !this.IsDisposed)
    //  {
    //    eh(this, e);
    //  }
    //}

    protected internal override void HandleDataCellContextMenuStripNeededEvent(DataAxisGridDataCellContextMenuStripNeededEventArgs e)
    {
      var eh = Events[EventKeyDataCellContextMenuStripNeeded] as EventHandler<DataGridDataCellContextMenuStripNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellContextMenuStripNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleCanModifyStateNeededEvent(DataAxisGridDataCellCanModifyStateNeededEventArgs e)
    {
      var eh = Events[EventKeyDataCellCanModifyStateNeeded] as EventHandler<DataGridDataCellCanModifyStateNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellCanModifyStateNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected override void CancelMode()
    {
      if (EhLibUtils.DebugIgnoreMouseCancelMode) return;
      base.CancelMode();
      if (dataGridState != DataGridState.Normal)
      {
        dataGridState = DataGridState.Normal;
        if (MoveNScrollService.Active)
          MoveNScrollService.Release();
        InvalidateGrid();
      }
    }

    protected override void CellCancelMode(int colIndex, int rowIndex)
    {
      BaseGridCellManager cell = CellManByColRow(colIndex, rowIndex);
      Debug.Assert(cell != null, "DataGridEh.PaintCell Cell = null");
      cell.OnMouseCaptureCanceled();

      base.CellCancelMode(colIndex, rowIndex);
    }

    protected override void TestSetCursor(MouseEventArgs e, ref Cursor newCursor)
    {
      base.TestSetCursor(e, ref newCursor);
      if (GridMouseSpecialStateActive()) return;
      if (newCursor != null) return;
      if (DesignMode) return;
      if (dataGridState == DataGridState.ColumnsSelecting)
      {
        newCursor = DrawStyle.DownArrowSelectCursor();
      }
      else if (dataGridState == DataGridState.RowsSelecting)
      {
        newCursor = DrawStyle.RightArrowSelectCursor();
      }
    }

    public override bool CheckBeginColumnDrag(ref int moveFromIndex, ref int moveToIndex, Point mousePos)
    {
      if (Title.MultiTitle.Active)
      {
        return Title.MultiTitle.CheckBeginColumnDrag(ref moveFromIndex, ref moveToIndex, mousePos);
      }
      else
      {
        if (moveFromIndex >= FixedColCount && moveFromIndex < ColCount)
          return true;
        else
          return false;
      }
    }

    public override void StartColMoving(int colIndex, int moveToIndex, int x, int y)
    {
      Point inCellPos;
      Rectangle cellRect;

      if (Title.MultiTitle.Active)
      {
        DataGridTitleNode tn = Title.MultiTitle.GetNodeAtGridAtPos(new Point(x, y), out inCellPos, out cellRect);
        Title.MultiTitle.TitleMovingFromNode = tn;
        Title.MultiTitle.TitleMovingBaseMouseY = tn.Bounds.Top + VertAxis.GridClientStart;
      }

      base.StartColMoving(colIndex, moveToIndex, x, y);
      Invalidate();
    }

    public override bool CheckColumnDrag(ref int moveFromIndex, ref int moveToIndex, Point mousePos)
    {
      if (Title.MultiTitle.Active)
      {
        return Title.MultiTitle.CheckColumnDrag(ref moveFromIndex, ref moveToIndex, mousePos);
      }
      else
      {
        return true;
      }
    }

    protected override void InteractiveMoveColumn(int fromIndex, int toIndex)
    {
      if (DesignMode && DataGridDesigner != null)
        DataGridDesigner.InteractiveMoveColumn(fromIndex, toIndex);
      else
        MoveColumn(fromIndex, toIndex);
    }

    protected internal override void MoveColumn(int fromIndex, int toIndex)
    {
      int dataFromColIndex = BaseToDataColIndex(fromIndex);
      int dataToColIndex = BaseToDataColIndex(toIndex);

      if (Title.MultiTitle.Active)
      {
        Title.MultiTitle.MoveColumn(dataFromColIndex, dataToColIndex);
      }
      else
      {
        int dataToColViewIndex;

        if (dataToColIndex == VisibleColumns.Count)
          dataToColViewIndex = ViewOrderedColumns.Count;
        else
          dataToColViewIndex = VisibleColumns[dataToColIndex].DisplayIndex;

        if (VisibleColumns[dataFromColIndex].Selected)
        {
          ReadOnlyCollection<DataGridColumn> selCols = Selection.GetSelectedColumns();
          MoveColumsByViewIndex(selCols, dataToColViewIndex);
          Selection.SetSelectedColumns(selCols);
        }
        else
        {
          var selCols = new DataGridColumn[1];
          selCols[0] = VisibleColumns[dataFromColIndex];
          MoveColumsByViewIndex(selCols, dataToColViewIndex);
        }
      }
    }

    protected override void GetColMovingLineBounds(out Point linePos, out int lineSize)
    {
      base.GetColMovingLineBounds(out linePos, out lineSize);
      if (Title.MultiTitle.Active)
      {
        int offset = Title.MultiTitle.TitleMovingFromNode.Bounds.Top;
        linePos.Y = linePos.Y + offset;
        lineSize = lineSize - offset;
      }
    }

    protected internal override void HideMove()
    {
      Rectangle cellToRect;
      //int MoveFromDataIndex;

      if (MoveToIndex == ColCount)
      {
        cellToRect = CellRect(MoveToIndex - 1, 0);
        cellToRect.Offset(ColWidths[MoveToIndex - 1], 0);
      }
      else
      {
        cellToRect = CellRect(MoveToIndex, 0);
      }

      //if (IsUseMultiTitle)
      //{
      //  MoveFromDataIndex = RawToDataColumn(FMoveFromIndex);
      //  ACellToRect.Top = ACellToRect.Bottom - FLeafFieldArr[MoveFromDataIndex].FLeaf.Height;
      //}

      cellToRect.Width = ColWidths[MoveFromIndex];

      cellToRect.Location = PointToScreen(cellToRect.Location);

      if (Title.MultiTitle.Active)
      {
        DataGridTitleNode fromNode = Title.MultiTitle.TitleMovingFromNode;
        cellToRect.Y = cellToRect.Y + fromNode.Bounds.Top;
        cellToRect.Width = fromNode.Bounds.Width;
        cellToRect.Height = fromNode.Bounds.Height;
      }

      if (MoveFromIndex < MoveToIndex)
      {
        cellToRect.Offset(-cellToRect.Width, 0);
      }

      DataGridTitleDragWin dragWin = DataGridTitleDragWin.GetTitleDragWin();
      dragWin.HideAnimated(cellToRect);

      //DataGridTitleDragWin.GetTitleDragWin().Hide();
    }

    protected internal override void DrawMove()
    {
      //base.DrawMove();

      DataGridTitleDragWin dragWin = DataGridTitleDragWin.GetTitleDragWin();
      if (GridState == BaseGridState.ColMoving)
      {
        Rectangle dragWinRect;
        Rectangle sourceBounds;
        int movePos;
        int moveSize;
        GetTitleDragWinBounds(out sourceBounds, out dragWinRect, out movePos, out moveSize);
        //Point tmp = dragWin.PointToClient(new Point(movePos, 0));
        //movePos = tmp.X;

        if (dragWin.Visible)
          dragWin.SetBounds(dragWinRect.X, dragWinRect.Y, dragWinRect.Width, dragWinRect.Height, movePos, moveSize);
        else
        {
          object drawObject;
          if (Title.MultiTitle.Active)
            drawObject = Title.MultiTitle.TitleMovingFromNode;
          else
            drawObject = VisibleColumns[RawToDataColumnIndex(MoveFromIndex)].Title;
          //- dragWin.StartShow(this, drawObject, dragWinRect.Location, dragWinRect.Width, dragWinRect.Height, movePos, moveSize);
          dragWin.StartShowAnimated(this, drawObject, sourceBounds, dragWinRect, movePos, moveSize);
        }
      }
    }

    private void GetTitleDragWinBounds(out Rectangle sourceBounds, out Rectangle bounds, out int movePos, out int lineSize)
    {
      bounds = Rectangle.Empty;
      Point scMousePos = Control.MousePosition;
      Rectangle cellFromRect = CellRect(MoveFromIndex, 0);
      cellFromRect.Width = ColWidths[MoveFromIndex];

      Point cellToPoint = Point.Empty;
      if (MoveToIndex == ColCount)
      {
        Rectangle cellRect = CellRect(MoveToIndex - 1, 0);
        cellToPoint.X = cellRect.Right;
        cellToPoint.Y = cellRect.Y;
      }
      else
      {
        cellToPoint = CellRect(MoveToIndex, 0).Location;
        cellToPoint.X = cellToPoint.X - 1;
      }

      if (cellToPoint.X > HorzAxis.ContraStart)
        cellToPoint.X = (int)Math.Min(HorzAxis.ContraStart, HorzAxis.RollStopVisPos + HorzAxis.FixedBoundary - 1);

      cellToPoint = PointToScreen(cellToPoint);

      cellFromRect.Size = new Size(cellFromRect.Width + 2, cellFromRect.Height + 2);
      cellFromRect.Location = PointToScreen(cellFromRect.Location);
      sourceBounds = cellFromRect;

      bounds.X = scMousePos.X - MoveFromCellOriginDistance;

      if (Title.MultiTitle.Active)
      {
        DataGridTitleNode fromNode = Title.MultiTitle.TitleMovingFromNode;
        bounds.Width = fromNode.Bounds.Width + 2;
        bounds.Height = fromNode.Bounds.Height + 2;
        bounds.Y = cellFromRect.Y + fromNode.Bounds.Top - 5 - bounds.Height;
        lineSize = VertAxis.GridClientLen - fromNode.Bounds.Top;
        sourceBounds.Y = cellFromRect.Y + fromNode.Bounds.Top;
        sourceBounds.Height = bounds.Height;
        sourceBounds.Width = bounds.Width;
      }
      else
      {
        bounds.Y = cellFromRect.Y - 5 - cellFromRect.Height;
        bounds.Size = cellFromRect.Size;
        lineSize = VertAxis.GridClientLen;
      }

      if (bounds.X < cellToPoint.X && bounds.Right < cellToPoint.X + 4)
      {
        bounds.Width = bounds.Width + (cellToPoint.X + 4 - bounds.Right);
      }
      else if (bounds.Right > cellToPoint.X && bounds.X > cellToPoint.X - 4)
      {
        bounds.Width = bounds.Width + (bounds.X - cellToPoint.X - 4);
        bounds.X = cellToPoint.X - 4;
      }

      movePos = cellToPoint.X;

    }

    private void SetCurColByGridColumn(DataGridColumn curGridColumn)
    {
      int curGridColumnIndex = -1;
      int colIndex;

      for (int i = 0; i < VisibleColumns.Count; i++)
      {
        if (VisibleColumns[i] == curGridColumn)
        {
          curGridColumnIndex = i;
          break;
        }
      }

      Debug.Assert(curGridColumnIndex >= 0, "DataGridEh.SetCurColByGridColumn curGridColumnIndex == -1");
      colIndex = DataToRawCol(curGridColumnIndex);
      MoveCurrent(colIndex, Row, false, false);
    }

    private void MoveColumsByViewIndex(IEnumerable<DataGridColumn> columns, int newViewIndex)
    {
      DataGridColumn insertBeforeColumn;
      //DataGridColumn afterColumn;
      int insertNewIndex;
      DataGridColumn curGridColumn = VisibleColumns[CurrentColumnIndex];
      List<DataGridColumn> newViewOrderedColumnsList = new List<DataGridColumn>();
      List<DataGridColumn> columnsToMove = new List<DataGridColumn>();
      List<DataGridColumn> columnsList = new List<DataGridColumn>(columns);

      foreach (DataGridColumn col in columnsList)
        Debug.Assert(col.Grid == this, "SetDisplayIndexForColumnsRange: DataGridColumn do not belong to Grid");

      //if (newViewIndex < VisibleColumns.Count)
      //{
      //  if (VisibleColumns[newViewIndex].Selected)
      //    return;
      //}

      foreach (DataGridColumn col in ViewOrderedColumns)
        newViewOrderedColumnsList.Add(col);

      for (int i = 0; i < newViewOrderedColumnsList.Count; i++)
      {
        DataGridColumn col = newViewOrderedColumnsList[i];
        if (columnsList.IndexOf(col) >= 0)
        {
          columnsToMove.Add(col);
          newViewOrderedColumnsList[i] = null;
        }
      }

      insertBeforeColumn = null;

      for (int i = newViewIndex; i < newViewOrderedColumnsList.Count; i++)
      {
        DataGridColumn col = newViewOrderedColumnsList[i];
        if (col != null)
        {
          insertBeforeColumn = col;
          break;
        }
      }

      newViewOrderedColumnsList.RemoveAll(col => col == null);

      if (insertBeforeColumn != null)
        insertNewIndex = newViewOrderedColumnsList.IndexOf(insertBeforeColumn);
      else
        insertNewIndex = newViewOrderedColumnsList.Count;

      newViewOrderedColumnsList.InsertRange(insertNewIndex, columnsToMove);

      //for (int i = newViewIndex; i < ViewOrderedColumns.Count; i++)
      //{
      //  DataGridColumn col = ViewOrderedColumns[i];
      //  if (columnsList.IndexOf(col) > 0)
      //    newViewIndex++;
      //  else
      //    break;
      //}

      //if (newViewIndex < VisibleColumns.Count)
      //{
      //  insertBeforeColumn = VisibleColumns[newViewIndex];
      //  insertNewIndex = newViewOrderedColumnsList.IndexOf(insertBeforeColumn);
      //  newViewOrderedColumnsList.InsertRange(insertNewIndex, columnsToMove);
      //}
      //else
      //{
      //  newViewOrderedColumnsList.AddRange(columnsToMove);
      //}

      //if (newViewIndex > 0)
      //  afterColumn = VisibleColumns[newViewIndex - 1];
      //else
      //  afterColumn = null;

      Debug.Assert(ViewOrderedColumns.Count == newViewOrderedColumnsList.Count, "SetDisplayIndexForColumnsRange: viewOrderedColumnsList.Count != newViewOrderedColumnsList.Count");

      Collection<PropertyAxisBar> newDispOrderedPropBars = new Collection<PropertyAxisBar>();
      foreach (DataGridColumn bar in newViewOrderedColumnsList)
        newDispOrderedPropBars.Add(bar);

      SetPropBarsDisplayOrder(newDispOrderedPropBars);

      SetCurColByGridColumn(curGridColumn);
      if (EditorMode)
        UpdateCellEditorBounds();

      ReadOnlyCollection<DataGridColumn> columnsCollection = new ReadOnlyCollection<DataGridColumn>(columnsList);
      var e = new DataGridDisplayColumnsMovedEventArgs(columnsCollection, newViewIndex, null);
      OnDisplayColumnsMoved(e);
    }

    public int BaseToDataColIndex(int baseColIndex)
    {
      int dataColIndex = baseColIndex - (FixedColCount - FrozenColCount);
      if (Columns.Count == 0)
        return -1;
      else
        return dataColIndex;
    }

    protected internal int DataToBaseColIndex(int dataColIndex)
    {
      return dataColIndex + FixedColCount;
    }

    protected internal void AddChangeSortMarking(DataGridColumn column)
    {
      bool isMultiSortMarking = ((ModifierKeys & Keys.Control) != 0) && Title.SortMarking.MultiSortMarkable;
      Title.SortMarking.SortMarkers.ChangeStateAsTitleClick(column, isMultiSortMarking);
      if (!isMultiSortMarking)
        //SortMarkers.CommitChanges();
        Title.SortMarking.ApplySortMakers();
    }

    protected internal void OnSortmarkingChangeCommitted()
    {
      HideEditor(true);
      DataLink.EndCurrentEdit();
      if (Title.SortMarking.SortSide == DataGridSortSide.DataGrid)
        SortedRows.ApplySorting(Title.SortMarking.SortMarkers);
      else if (Title.SortMarking.SortSide == DataGridSortSide.DataSource)
        DataLink.Sort(Title.SortMarking.SortMarkers);
      else
        EhLibUtils.DoNothing(); //TODO;
    }

    protected override BaseGridDrawStyle DefaultDrawStyle()
    {
      return EhLibRenderManager.DefaultEhLibRenderManager.DataGridDrawStyle;
    }

    protected internal virtual void RowSelectStateChanged()
    {
      if (Selection.RowSelect)
      {
        Options = (Options | GridOptions.RowSelect) & ~GridOptions.Editing;
      }
      else
        Options = Options & ~GridOptions.RowSelect;
      Invalidate();
    }

    public override bool GridMouseSpecialStateActive()
    {
      bool result = base.GridMouseSpecialStateActive();
      if (result)
        return true;
      else
      {
        if (dataGridState != DataGridState.Normal)
          return true;
        else
          return false;
      }
    }

    public virtual DataObject GetContentAsDataObject(DataGridExportArea area)
    {
      DataObject dataObject = new DataObject();

      DataGridTextExporter textExp = new DataGridTextExporter()
      {
        Grid = this,
        ImportArea = area,
        CellDelimiter = ((char)Keys.Tab).ToString(),
        LineBreak = "" + (char)Keys.Enter + (char)Keys.LineFeed,
        QuoteChar = ""
      };

      string gridAsStr = textExp.BuildExportString();

      dataObject.SetData(DataFormats.Text, false /*autoConvert*/, gridAsStr);
      dataObject.SetData(DataFormats.UnicodeText, false /*autoConvert*/, gridAsStr);

      DataGridLibTableDataExchangeExporter ehLibDataExchExp = new DataGridLibTableDataExchangeExporter()
      {
        Grid = this,
        ImportArea = area
      };

      object ehLibDataExch = ehLibDataExchExp.BuildExportObject();

      dataObject.SetData("EhLib.Table.DataExchange", false /*autoConvert*/, ehLibDataExch);

      return dataObject;
    }

    public virtual void PutContentFromDataObject(IDataObject dataObject)
    {
      if (dataObject.GetDataPresent(DataFormats.UnicodeText))
      {
        string strVal = (string)dataObject.GetData(DataFormats.UnicodeText);
        using (var textImp = new DataGridTextImporter())
        {
          textImp.Grid = this;
          textImp.DoImport(strVal);
        }
      }
    }

    public virtual void CopyContentToClipboard(DataGridExportArea area)
    {
      DataObject dataObject = GetContentAsDataObject(area);
      if (dataObject != null)
      {
        Clipboard.SetDataObject(dataObject, true);
      }
    }

    public virtual void PastContentFromClipboard()
    {
      IDataObject iData = Clipboard.GetDataObject();
      PutContentFromDataObject(iData);
    }

    protected bool ProcessCopyKey(Keys keyData)
    {
      if (!Focused) return false;
      Keys altCtlShiftMask = keyData & (Keys.Shift | Keys.Control | Keys.Alt);
      Keys keyCode = keyData & Keys.KeyCode;
      if ((altCtlShiftMask == Keys.Control && keyCode == Keys.Insert) ||
           (altCtlShiftMask == Keys.Control && keyCode == Keys.C) ||
           ((altCtlShiftMask == (Keys.Control | Keys.Shift)) && keyCode == Keys.C)
         )
      {
        CopyContentToClipboard(DataGridExportArea.SelectedArea);
        return true;
      }
      else
      {
        return false;
      }
    }

    protected bool ProcessPasteKey(Keys keyData)
    {
      if (!EditActions.CanPaste()) return false;
      if (!Focused) return false;

      Keys altCtlShiftMask = keyData & (Keys.Shift | Keys.Control | Keys.Alt);
      Keys keyCode = keyData & Keys.KeyCode;
      if ((altCtlShiftMask == Keys.Shift && keyCode == Keys.Insert) ||
           (altCtlShiftMask == Keys.Control && keyCode == Keys.V) ||
           ((altCtlShiftMask == (Keys.Control | Keys.Shift)) && keyCode == Keys.V)
         )
      {
        EditActions.Paste();
        return true;
      }
      else
      {
        return false;
      }
    }

    protected bool ProcessCutKey(Keys keyData)
    {
      if (!Focused) return false;
      Keys altCtlShiftMask = keyData & (Keys.Shift | Keys.Control | Keys.Alt);
      Keys keyCode = keyData & Keys.KeyCode;
      if (EditActions.CanCut() &&
          (altCtlShiftMask == Keys.Shift && keyCode == Keys.Delete) ||
          (altCtlShiftMask == Keys.Control && keyCode == Keys.X) ||
          ((altCtlShiftMask == (Keys.Control | Keys.Shift)) && keyCode == Keys.X)
         )
      {
        EditActions.Cut();
        return true;
      }
      else
      {
        return false;
      }
    }

    protected internal virtual void ColumnPaddingChanged(DataGridColumn dataGridColumn)
    {
      Invalidate();
    }

    protected internal override void UpdatePaddingsForSidePadding()
    {
      leftAlignDefaultPadding = ColumnOptions.SidePadding;
      leftAlignDefaultPadding.Right = 0;

      centerAlignDefaultPadding = ColumnOptions.SidePadding;
      centerAlignDefaultPadding.Right = 0;
      centerAlignDefaultPadding.Left = 0;

      rightAlignDefaultPadding = ColumnOptions.SidePadding;
      rightAlignDefaultPadding.Left = 0;
    }

    protected internal override void SidePaddingChanged()
    {
      UpdatePaddingsForSidePadding();
      UpdateRowHeights();
    }

    public override Padding GetDefaultPaddingForAlign(HorizontalAlignment horzAlign, VerticalAlignment vertAlign)
    {
      switch (horzAlign)
      {
        case HorizontalAlignment.Left:
          return leftAlignDefaultPadding;

        case HorizontalAlignment.Center:
          return centerAlignDefaultPadding;

        case HorizontalAlignment.Right:
          return rightAlignDefaultPadding;

        default:
          return Padding.Empty;
      }
    }

    protected internal override Padding GetDataCellSidePadding()
    {
      return ColumnOptions.SidePadding;
    }

    protected internal override VerticalAlignment DefaultVertAlign()
    {
      return ColumnOptions.VertAlign;
    }

    protected internal virtual void SetColWidthsToClient()
    {
      int rolClientWidth = HorzAxis.RollClientLen - (LineOptions.VertLineSpace * VisibleColumns.Count);
      float fullFillWeight = 0;
      int draftColWidths = 0;
      int restBit;
      int sign;

      foreach (DataGridColumn col in VisibleColumns)
      {
        float colfillWidth;
        if (col.OmitFromWidthCalculation == false)
        {
          colfillWidth = col.FillWeight;
          if (colfillWidth == 0) colfillWidth = 1;
          fullFillWeight = fullFillWeight + colfillWidth;
        }
        else
        {
          colfillWidth = col.Width;
          if (colfillWidth == 0) colfillWidth = 1;
          rolClientWidth = rolClientWidth - col.Width;
        }
      }

      foreach (DataGridColumn col in VisibleColumns)
      {
        float colfillWidth = col.FillWeight;
        if (colfillWidth == 0) colfillWidth = 1;
        if (col.OmitFromWidthCalculation == false)
        {
          col.WidthInternal = (int)Math.Round(colfillWidth / fullFillWeight * rolClientWidth);
          if (col.Width < 0) col.WidthInternal = 0;
          col.WidthStored = true;
          draftColWidths = draftColWidths + col.Width;
        }
      }

      restBit = rolClientWidth - draftColWidths;
      if (restBit > 0)
        sign = 1;
      else
      {
        sign = -1;
        restBit = -restBit;
      }

      foreach (DataGridColumn col in VisibleColumns)
      {
        if (col.OmitFromWidthCalculation == false)
        {
          if (restBit == 0) break;
          col.WidthInternal = col.Width + sign;
          if (col.Width < 0) col.WidthInternal = 0;
          restBit = restBit - 1;
        }
      }
    }

    protected internal virtual void UpdateFitColWidthsToClient()
    {
      int newColWidth;
      bool secondPass;

      if (InInitialization) return;
      if (!IsHandleCreated) return;
      if (!AutoSizeColumnOptions.FitToClient) return;

      foreach (DataGridColumn col in VisibleColumns)
        col.OmitFromWidthCalculation = false;

      SetColWidthsToClient();

      secondPass = false;
      foreach (DataGridColumn col in VisibleColumns)
      {
        newColWidth = col.AdjustWidth(col.Width);
        if (newColWidth != col.Width)
        {
          col.WidthInternal = newColWidth;
          col.OmitFromWidthCalculation = true;
          secondPass = true;
        }
      }

      if (secondPass)
        SetColWidthsToClient();

      UpdateBaseGridColumns();
      if (RowOptions.HeightOptions.AutoExpand)
        UpdateRowHeights();
    }

    protected internal virtual void InitColumnsFillWeight()
    {
      if (InInitialization) return;
      if (!AutoSizeColumnOptions.FitToClient) return;
      foreach (DataGridColumn col in VisibleColumns)
      {
        col.FillWeightInternal = col.Width;
      }
    }

    protected internal virtual void SetColumnWidthFitClientMode(DataGridColumn column, int newWidth)
    {
      //TODO: Node
      //TODO: Fix problem when newWidth goes out of grid right part.

      if (InInitialization) return;
      if (!AutoSizeColumnOptions.FitToClient) return;

      int rightClientWidth;
      int rightWidth = 0;
      int draftColWidths = 0;
      int restBit;
      int sign;

      for (int i = column.VisibleIndex + 1; i < VisibleColumns.Count; i++)
      {
        rightWidth = rightWidth + VisibleColumns[i].Width;
      }

      rightClientWidth = rightWidth + (column.Width - newWidth);

      for (int i = column.VisibleIndex + 1; i < VisibleColumns.Count; i++)
      {
        DataGridColumn iCol = VisibleColumns[i];

        iCol.Width = (int)Math.Round((float)iCol.Width / rightWidth * rightClientWidth);
        if (iCol.Width <= 0) iCol.Width = 1;
        iCol.WidthStored = true;
        draftColWidths = draftColWidths + iCol.Width;
      }

      restBit = rightClientWidth - draftColWidths;
      if (restBit > 0)
        sign = 1;
      else
      {
        sign = -1;
        restBit = -restBit;
      }

      for (int i = column.VisibleIndex + 1; i < VisibleColumns.Count; i++)
      {
        DataGridColumn iCol = VisibleColumns[i];

        if (restBit == 0) break;
        iCol.Width = iCol.Width + sign;
        restBit = restBit - 1;
      }

      column.WidthInternal = newWidth;
      column.WidthStored = true;

      InitColumnsFillWeight();
      UpdateFitColWidthsToClient();
    }

    protected internal override bool CanShowScrollBar(Orientation kind)
    {
      //return false;

      if ((kind == Orientation.Horizontal) &&
          (AutoSizeColumnOptions.FitToClient == true))
        return false;
      else
        return base.CanShowScrollBar(kind);
    }

    protected override BaseGridHorzScrollBar CreateHorzScrollBar()
    {
      return new DataGridHorzScrollBar(this, Orientation.Horizontal);
    }

    protected override BaseGridVertScrollBar CreateVertScrollBar()
    {
      return new DataGridVertScrollBar(this, Orientation.Vertical);
    }

    protected override BaseGridScrollBarPanelControl CreateHorzScrollBarPanelControl()
    {
      return new DataGridScrollBarPanelControl(this, Orientation.Horizontal);
    }

    protected internal virtual void OnSelectionChanged(DataGridSelectionChangeOperationEventArgs e)
    {
      Invalidate();
      HorzScrollBarPanelControl.GridSelectionChanged();

      var eh = Events[EventKeyDataGridSelectionChanged] as EventHandler<DataGridSelectionChangeOperationEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    protected internal override void CellLenChanged(GridAxisData axis, int index, int oldLen)
    {
      base.CellLenChanged(axis, index, oldLen);
      //GridLayoutChanged();
    }

    protected internal virtual GridKeyboardOptions CreateKeyKeyboardOptions()
    {
      return new GridKeyboardOptions();
    }

    protected override void OnValidating(CancelEventArgs e)
    {
      base.OnValidating(e);
      //if (inValidatingCode || EditorDataPushing) return;
      //inValidatingCode = true;
      //try
      //{
      //  if (EditorMode)
      //  {
      //    bool editorClosed = HideEditor(true);
      //    if (!editorClosed)
      //      e.Cancel = true;
      //  }
      //  //{
      //  //  e.Cancel = true;
      //  //  return;
      //  //}
      //  base.OnValidating(e);
      //}
      //finally
      //{
      //  inValidatingCode = false;
      //}
    }

    protected internal override void FixedFillOptionsChanged()
    {
      Footer.UpdateDefaults();
    }

    protected internal virtual void ColumnFrozenChanged(DataGridColumn dataGridColumn, DataGridColumnFrozenState frozen)
    {
      if (frozen != DataGridColumnFrozenState.None && 
          !InInitialization && 
          Title.MultiTitle.Active &&
          Site != null && 
          Site.DesignMode)
      {
        MessageBox.Show("Column.Frozen is not supported in MultiTitle mode.");
      }

      UpdateColumnsView();
    }

    protected override void RollPosChanged(long oldRowPosX, long oldRowPosY)
    {
      base.RollPosChanged(oldRowPosX, oldRowPosY);
      Columns.OnRollPosChanged();
    }

    protected internal virtual void AllowRowResizeChanged()
    {
      if (RowOptions.AllowResize)
        Options = Options | GridOptions.RowSizing;
      else
        Options = Options & ~GridOptions.RowSizing;
    }

    internal void RowHeightAutoExpandChanged()
    {
      if (!InInitialization)
        UpdateRowHeights();
    }

    internal void RowOptionsContentHeightInTextLinesChanged()
    {
      if (!InInitialization)
        UpdateRowHeights();
    }

    internal void RowOptionsMaxContentHeightInTextLinesChanged()
    {
      if (!InInitialization)
        UpdateRowHeights();
    }

    internal void RowOptionsHeightInPixelsChanged()
    {
      if (!InInitialization)
        UpdateRowHeights();
    }

    internal void RowOptionsMaxHeightInPixelsChanged()
    {
      if (!InInitialization)
        UpdateRowHeights();
    }

    internal virtual void ColumnHeightAutoExpandChanged()
    {
      RowHeightAffectPropertyChanged();
    }

    protected internal override void RowHeightAffectPropertyChanged()
    {
      if (!InInitialization)
        UpdateRowHeights();
    }

    protected internal new virtual object GetService(Type service)
    {
      return base.GetService(service);
    }

    // Prepare and Get Storable Settings
    public class GridSortWriteItem
    {
      public string ColumnID { get; set; }
      public string SortDirection { get; set; }
    }

    /// <summary>
    /// Create and return Dictionary that contains properties of grid and columns that should be 
    /// stored when application is closed. 
    /// </summary>
    /// <remarks>
    /// By default, the grid writes such parameters as: Width, Visibility and the order of the columns.
    /// You can override the list of storing values in the 
    /// <see cref="GridSettingsWriting"/> and <see cref="GridColumnSettingsWriting"/> events.
    /// </remarks>
    /// <seealso cref="ReadStorableSettings(Dictionary{string, object})" />
    public virtual Dictionary<string, object> GetStorableSettings()
    {
      DataGridStorableElements elements = DataGridManager.DefaultManager.GetDefaultGridStorableElements(this);
      return GetStorableSettings(elements);
    }

    public virtual Dictionary<string, object> GetStorableSettings(DataGridStorableElements elements)
    {
      var settings = new Dictionary<string, object>();
      var storeArgs = new DataGridStorableSettingsWritingEventArgs(settings, elements);
      ProcessGridSettingsWriting(storeArgs);

      if (Title.MultiTitle.Active)
      {
        Dictionary<string, object> multiTitleSettings = GetMultiTitleSettings(elements.ColumnElements);
        settings.Add("MultiTitleItems", multiTitleSettings);
      }
      else
      {
        Dictionary<string, object> columnsSettings = GetColumnsSettings(elements.ColumnElements);
        settings.Add("Columns", columnsSettings);
      }

      if (elements.ColumnElements.TitleSortMarker == true)
      {
        List<GridSortWriteItem> smSettings = GetSortMarkersSettings(storeArgs);
        //Dictionary<string, object> smSettings = GetSortMarkersSettings(storeArgs);
        if (smSettings != null)
          settings.Add("SortMarkers", smSettings);
      }

      return settings;
    }

    protected virtual List<GridSortWriteItem> GetSortMarkersSettings(DataGridStorableSettingsWritingEventArgs storeArgs)
    {
      if (storeArgs.Elements.ColumnElements.TitleSortMarker == true)
      {
        //Dictionary<string, object> smSettings = new Dictionary<string, object>();
        List<GridSortWriteItem> smSettings = new List<GridSortWriteItem>();
        foreach (var sm in Title.SortMarking.SortMarkers)
        {
          GridSortWriteItem wi = new GridSortWriteItem()
          {
            ColumnID = sm.Column.DataPropertyName,
            SortDirection = sm.SortDirection.ToString()
          };
          smSettings.Add(wi);
        }
        return smSettings;
      }
      else
      {
        return null;
      }
    }

    protected virtual void ProcessGridSettingsWriting(DataGridStorableSettingsWritingEventArgs e)
    {
      HandleGridSettingsWritingEvent(e);
      if (!e.Handled)
        OnGridSettingsWriting(e);
    }

    protected virtual void HandleGridSettingsWritingEvent(DataGridStorableSettingsWritingEventArgs e)
    {
      var eh = Events[EventKeyGridSettingsWriting] as EventHandler<DataGridStorableSettingsWritingEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    protected internal virtual void OnGridSettingsWriting(DataGridStorableSettingsWritingEventArgs e)
    {
      DataGridManager.DefaultManager.WriteGridSettings(this, e.Settings);
    }

    public virtual Dictionary<string, object> GetColumnsSettings(DataGridColumnStorableElements columnElements)
    {
      var columnsSettings = new Dictionary<string, object>();

      foreach (DataGridColumn col in Columns)
      {
        string keyValue;

        if (string.IsNullOrEmpty(col.Name))
          keyValue = col.DataPropertyName;
        else
          keyValue = col.Name;

        var colSettings = new Dictionary<string, object>();
        ProcessGridColumnSettingsWriting(new DataGridColumnStorableSettingsWritingEventArgs(col, colSettings, columnElements));

        columnsSettings.Add(keyValue, colSettings);
      }

      return columnsSettings;
    }

    public virtual Dictionary<string, object> GetMultiTitleSettings(DataGridColumnStorableElements columnElements)
    {
      return Title.MultiTitle.GetStorableSettings(columnElements);
    }

    protected virtual void ProcessGridColumnSettingsWriting(DataGridColumnStorableSettingsWritingEventArgs e)
    {
      HandleGridColumnSettingsWritingEvent(e);
      if (!e.Handled)
        OnGridColumnSettingsWriting(e);
    }

    protected virtual void HandleGridColumnSettingsWritingEvent(DataGridColumnStorableSettingsWritingEventArgs e)
    {
      var eh = Events[EventKeyGridColumnSettingsWriting] as EventHandler<DataGridColumnStorableSettingsWritingEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    protected internal virtual void OnGridColumnSettingsWriting(DataGridColumnStorableSettingsWritingEventArgs e)
    {
      DataGridManager.DefaultManager.WriteColumnSettings(this, e.Column, e.Settings, e.Elements);
    }

    // Parse and Read Storable Settings

    /// <summary>
    /// Read, parse and assign properties of a grid by values stored in the settings dictionary.
    /// </summary>
    /// <remarks>
    /// This method is called by the application developer at the moment when a new form is 
    /// created with the grid and it is necessary to restore the grid settings 
    /// (such as Width, Visibility and the order of the columns) 
    /// that were saved in the previous session.
    /// You can override the list of reading values in the 
    /// <see cref="GridSettingsReading"/> and <see cref="GridColumnSettingsReading"/> events.
    /// </remarks>
    /// <seealso cref="GetStorableSettings()" />
    public virtual void ReadStorableSettings(Dictionary<string, object> settings)
    {
      ProcessGridSettingsReading(new DataGridStorableSettingsReadingEventArgs(this, settings));

      if (Title.MultiTitle.Active)
      {
        object multiTitleSettingsObj;
        Dictionary<string, object> multiTitleSettings = null;
        if (settings.TryGetValue("MultiTitleItems", out multiTitleSettingsObj))
        {
          multiTitleSettings = multiTitleSettingsObj as Dictionary<string, object>;
        }
        if (multiTitleSettings != null)
          ReadMultiTitleSettings(multiTitleSettings);
      }
      else
      {
        object columnsSettingsObj;
        Dictionary<string, object> columnsSettings = null;
        if (settings.TryGetValue("Columns", out columnsSettingsObj))
        {
          columnsSettings = columnsSettingsObj as Dictionary<string, object>;
        }
        if (columnsSettings != null)
          ReadColumnsSettings(columnsSettings);
      }

      object sortMarkers;
      ArrayList sortMarkersSettings = null;
      if (settings.TryGetValue("SortMarkers", out sortMarkers))
      {
        sortMarkersSettings = sortMarkers as ArrayList;
      }
      if (sortMarkersSettings != null)
        ReadSortMarkersSettings(sortMarkersSettings);
    }

    protected virtual void ReadSortMarkersSettings(ArrayList sortMarkersSettings)
    {
      List<DataGridSortItem> smList = new List<DataGridSortItem>();

      foreach (object v in sortMarkersSettings)
      {
        DataGridSortItem dv = ReadSortMarker(v);
        if (dv != null)
          smList.Add(dv);
      }

      if (smList != null)
      {
        Title.SortMarking.SortMarkers.SetSortState(smList);
      }
    }

    protected virtual DataGridSortItem ReadSortMarker(object sortMarkerData)
    {
      DataGridColumn col = null;
      Nullable<ListSortDirection> sortDir = null;

      Dictionary<string, object> dv = sortMarkerData as Dictionary<string, object>;
      if (dv != null)
      {
        object colObj;
        if (dv.TryGetValue("ColumnID", out colObj))
        {
          string colID = colObj as string;
          if (!string.IsNullOrEmpty(colID))
          {
            col = Columns.FindColumnByName(colID);
            if (col == null)
              col = Columns.FindColumnByPropertyName(colID);
          }
        }

        object sortObj;
        if (dv.TryGetValue("SortDirection", out sortObj))
        {
          sortDir = (ListSortDirection)Enum.Parse(typeof(ListSortDirection), sortObj.ToString());
        }
      }

      if (col != null && sortDir.HasValue)
      {
        DataGridSortItem si = new DataGridSortItem()
        {
          Column = col,
          SortDirection = sortDir.Value
        };

        return si;
      }
      else
      {
        return null;
      }
    }

    protected virtual void ProcessGridSettingsReading(DataGridStorableSettingsReadingEventArgs e)
    {
      HandleGridSettingsReadingEvent(e);
      if (!e.Handled)
        OnGridSettingsReading(e);
    }

    protected virtual void HandleGridSettingsReadingEvent(DataGridStorableSettingsReadingEventArgs e)
    {
      var eh = Events[EventKeyGridSettingsReading] as EventHandler<DataGridStorableSettingsReadingEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    protected internal virtual void OnGridSettingsReading(DataGridStorableSettingsReadingEventArgs e)
    {
      DataGridManager.DefaultManager.ReadGridSettings(this, e.Settings);
    }

    public virtual void ReadColumnsSettings(Dictionary<string, object> columnsSettings)
    {
      Columns.BeginUpdate();
      try
      {
        foreach (KeyValuePair<string, object> colSet in columnsSettings)
        {
          DataGridColumn col;
          col = Columns.FindColumnByName(colSet.Key);
          if (col == null)
            col = Columns.FindColumnByPropertyName(colSet.Key);

          var columnSettings = colSet.Value as Dictionary<string, object>;
          if (col != null && columnSettings != null)
          {
            ProcessGridColumnSettingsReading(new DataGridColumnStorableSettingsReadingEventArgs(col, columnSettings));
          }
        }
      }
      finally
      {
        Columns.EndUpdate();
      }
    }

    public virtual void ReadMultiTitleSettings(Dictionary<string, object> mtSettings)
    {
      Columns.BeginUpdate();
      try
      {
        Title.MultiTitle.ReadStorableSettings(mtSettings);
      }
      finally
      {
        Columns.EndUpdate();
      }
    }

    protected virtual void ProcessGridColumnSettingsReading(DataGridColumnStorableSettingsReadingEventArgs e)
    {
      HandleGridColumnSettingsReadingEvent(e);
      if (!e.Handled)
        OnGridColumnSettingsReading(e);
    }

    protected virtual void HandleGridColumnSettingsReadingEvent(DataGridColumnStorableSettingsReadingEventArgs e)
    {
      var eh = Events[EventKeyGridColumnSettingsReading] as EventHandler<DataGridColumnStorableSettingsReadingEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    protected internal virtual void OnGridColumnSettingsReading(DataGridColumnStorableSettingsReadingEventArgs e)
    {
      DataGridManager.DefaultManager.ReadColumnSettings(this, e.Column, e.Settings);
    }

    //Other
    public override bool IsDrawHotState()
    {
      return base.IsDrawHotState() && DataGridState == DataGridState.Normal;
    }

    protected internal override string GetHighlightSearchingData(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, string cellText, out CharacterRange[] charRanges)
    {
      if ((SearchBox.HighlightSearchingText == true) &&
          (!string.IsNullOrEmpty(SearchBox.SearchingText)))
      {
        if (!SearchBox.CheckTextHit((DataGridColumn)propAxisBar, cellText, SearchBox.SearchingText))
        {
          charRanges = null;
          return null;
        }
        else
        {
          charRanges = SearchBox.GetHitRanges((DataGridColumn)propAxisBar, (DataGridRow)listItemBar, cellText);
          return SearchBox.SearchingText;
        }
      }
      else
      {
        charRanges = null;
        return null;
      }
    }

    protected internal override void SpecifyFormatParams(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
      if (e.ListItemBar != null)
      {
        DataGridRow row = e.ListItemBar as DataGridRow;

        bool isEvenRow = row.VisibleIndex % 2 == 0;
        if (RowOptions.EvenColor != Color.Empty && isEvenRow)
          e.BackColor = RowOptions.EvenColor;
        else if (RowOptions.OddColor != Color.Empty && !isEvenRow)
          e.BackColor = RowOptions.OddColor;
      }
    }

    protected internal override void HandleFormatParamsNeededEvent(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
      var eh = Events[EventKeyDataCellFormatParamsNeeded] as EventHandler<DataGridDataCellFormatParamsNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellFormatParamsNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected override DataAxisDynamicColumnsCreatingEventArgs GetDataAxisCreatingDynamicColumnsForDataPropertyEventArgs(
      DeepPropertyDescriptor propDescriptor, bool presentInStaticList)
    {
      return new DataGridDynamicColumnsCreatingEventArgs(this, propDescriptor, presentInStaticList);
    }

    protected override void ProcessCreateDynamicPropBarsForDataPropertyEvent(DataAxisDynamicColumnsCreatingEventArgs e)
    {
      var eh = Events[EventKeyDynamicColumnsCreating] as EventHandler<DataGridDynamicColumnsCreatingEventArgs>;
      if (eh != null)
      {
        eh(this, (DataGridDynamicColumnsCreatingEventArgs)e);
      }
    }

    protected internal override void OnCreateDynamicPropBarsForDataProperty(DataAxisDynamicColumnsCreatingEventArgs e)
    {
      if (e.PresentInStaticList)
      {
        e.PropertyBars = null;
      }
      else
      {
        e.PropertyBars = new DataGridColumn[1];
        e.PropertyBars[0] = CreatePropBarForDataProperty(e.PropertyDescriptor);
      }
    }

    protected internal override void OnDataCellContextMenuStripNeeded(DataAxisGridDataCellContextMenuStripNeededEventArgs age)
    {
      DataGridManager.DefaultManager.BuildDataCellContextMenu(this, age);
    }

    //protected internal virtual void OnTitleCellContextMenuStripNeeded(DataGridTitleCellContextMenuStripNeededEventArgs age)
    //{
    //  DataGridManager.DefaultManager.BuildTitleCellContextMenu(this, age);
    //}

    protected internal override void DeleteCurrentListItem()
    {
      //if (CurrentRow == null) return;
      //int curDataRowIndex = CurrentRow.Index;
      int curDataRowIndex = CurrentRowIndex;
      CurrencyManager.RemoveAt(CurrencyManager.Position);
      if (VisibleRows.Count > 0)
      {
        if (curDataRowIndex >= VisibleRows.Count)
          CurrentRowIndex = VisibleRows.Count - 1;
        else
          CurrentRowIndex = curDataRowIndex;
      }
    }

    protected internal virtual void ColumnMergeDuplicatesChanged(DataGridColumn dataGridColumn, bool value)
    {
      Invalidate();
    }

    protected internal virtual void HandlePullValueEvent(DataGridDataCellPullValueEventArgs e)
    {
      var eh = Events[EventKeyDataCellPullValue] as EventHandler<DataGridDataCellPullValueEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    protected internal virtual void HandlePushValueEvent(DataGridDataCellPushValueEventArgs e)
    {
      var eh = Events[EventKeyDataCellPushValue] as EventHandler<DataGridDataCellPushValueEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    protected internal virtual void HandleDataCellManagerNeededEvent(DataGridDataCellManagerNeededEventArgs e)
    {
      var eh = Events[EventKeyDataCellManagerNeeded] as EventHandler<DataGridDataCellManagerNeededEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    protected override BaseGridCellFreeAreaPaintEventArgs CreateCellFreeAreaPaintEventArgs(
      GraphicsContext gc, int colIndex, int rowIndex, Rectangle rect, BaseGridCellManager cellManager)
    {
      return new DataGridCellFreeAreaPaintEventArgs(this, null, gc, colIndex, rowIndex, rect);
    }

    protected override void HandleCellFreeAreaPaintEvent(BaseGridCellFreeAreaPaintEventArgs e)
    {
      var eh = Events[EventKeyCellFreeAreaPaint] as EventHandler<DataGridCellFreeAreaPaintEventArgs>;
      if (eh != null)
      {
        eh(this, (DataGridCellFreeAreaPaintEventArgs)e);
      }
    }

    protected internal override bool IsShowDataCellsNonfitTooltips()
    {
      return ColumnOptions.NonfitTooltips;
    }

    protected internal override void InteractiveSetDataValue(PropertyAxisBar propBar, object dataValue)
    {
      DataGridRow curRow = CurrentRow;
      DataGridColumn curCol = VisibleColumns[CurrentColumnIndex];

      SetDataValue(propBar, dataValue);
      if (Selection.SelectionType == GridSelectionType.CellsBox &&
          Selection.SelectedBox.Left == Selection.SelectedBox.Right
         )
      {
        GridRect selBox = Selection.SelectedBox;
        for (int i = selBox.Top; i <= selBox.Bottom; i++)
        {
          DataGridRow aRow = VisibleRows[i];
          if (aRow != curRow)
          {
            curCol.SetRowValue(aRow, dataValue);
          }
        }
      }
    }
    #endregion nopublic methods

  }

  /// <summary>
  /// Base class for all classes that should have reference to <see cref="DataGridEh"/> control
  /// </summary>
  public class DataGridObject : object
  {
    private readonly DataGridEh grid;

    public DataGridObject(DataGridEh grid)
    {
      this.grid = grid;
    }

    /// <summary>
    ///  Gets the DataGridEh control associated with this object.
    /// </summary>
    [Browsable(false)]
    public DataGridEh Grid
    {
      get { return grid; }
    }

  }

  /// <summary>
  /// Base component for all components that should have reference to <see cref="DataGridEh"/> control
  /// </summary>
  [ToolboxItem(false)]
  public class DataGridBaseComponent : Component
  {
    private readonly DataGridEh grid;

    public DataGridBaseComponent(DataGridEh grid)
    {
      this.grid = grid;
    }

    /// <summary>
    ///  Gets the DataGridEh control associated with this Component.
    /// </summary>
    [Browsable(false)]
    public DataGridEh Grid
    {
      get { return grid; }
    }

  }

  /// <summary>
  /// Defines properties for automatic calculation of columns where a fixed width is not specified.
  /// </summary>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridAutoSizeColumnOptions : DataGridObject
  {
    #region >privates
    bool fitToClient;
    int maxAutoWidth;
    bool maxAutoWidthStored;
    #endregion <privates

    public DataGridAutoSizeColumnOptions(DataGridEh grid) : base(grid)
    {
      ConsiderTitle = true;
      ConsiderRowCount = 100;
      MaxAutoWidth = 0;
      ConsiderRowsMode = DataGridColumnAutoSizeConsiderRowsMode.ConsiderRowCount;
    }

    /// <summary>
    /// Consider header text when calculating column widths.
    /// </summary>
    [DefaultValue(true)]
    public bool ConsiderTitle { get; set; }

    [DefaultValue(DataGridColumnAutoSizeConsiderRowsMode.ConsiderRowCount)]
    public DataGridColumnAutoSizeConsiderRowsMode ConsiderRowsMode { get; set; }

    [DefaultValue(100)]
    public int ConsiderRowCount { get; set; }

    [DefaultValue(0)]
    public int MaxAutoWidth
    {
      get
      {
        if (maxAutoWidthStored)
          return maxAutoWidth;
        else
          return DefaultMaxAutoWidth();
      }

      set
      {
        if (value != maxAutoWidth)
        {
          maxAutoWidth = value;
          maxAutoWidthStored = true;
        }
      }
    }

    [DefaultValue(false)]
    public bool FitToClient
    {
      get
      {
        return fitToClient;
      }
      set
      {
        if (value != fitToClient)
        {
          fitToClient = value;
          if (fitToClient)
          {
            Grid.InitColumnsFillWeight();
            Grid.UpdateFitColWidthsToClient();
          }
        }
      }
    }

    //MaxAutoWidth
    private int DefaultMaxAutoWidth()
    {
      return DataGridManager.DefaultManager.AutoSizeColumnOptionsMaxAutoWidth();
    }

  }

  public class DataGridSortItem : object
  {
    public DataGridColumn Column { get; set; }
    public ListSortDirection SortDirection { get; set; }
  }

  public class DataGridSortCollection : object, IEnumerable<DataGridSortItem>
  {
    #region >privates
    private readonly List<DataGridSortItem> sortCollection;
    private readonly DataGridTitleSortMarking sortMarking;
    private bool sortMarkersChanged;
    #endregion <privates

    public DataGridSortCollection(DataGridTitleSortMarking sortMarking)
    {
      sortCollection = new List<DataGridSortItem>();
      this.sortMarking = sortMarking;
    }

    #region >properties
    public int Count { get { return sortCollection.Count; } }

    public DataGridSortItem this[int index] { get { return sortCollection[index]; } }

    public IEnumerator<DataGridSortItem> GetEnumerator()
    {
      return (sortCollection as IEnumerable<DataGridSortItem>).GetEnumerator();
    }

    public DataGridEh Grid { get { return sortMarking.Title.Grid; } }
    #endregion <properties

    #region public methods
    public void SetSortState(DataGridColumn column, ListSortDirection sortDirection)
    {
      Clear();
      AddSortItem(column, sortDirection);
    }

    public void SetSortState(List<DataGridSortItem> sortList)
    {
      Clear();

      foreach (DataGridSortItem si in sortList)
      {
        AddSortItem(si.Column, si.SortDirection);
      }
    }
    #endregion

    #region internal methods
    IEnumerator IEnumerable.GetEnumerator()
    {
      return (sortCollection as IEnumerable).GetEnumerator();
    }

    protected internal void AddSortItem(DataGridColumn column, ListSortDirection sortDirection)
    {
      if (IndexOf(column) >= 0)
        throw new InvalidOperationException("column is not unique in DataGridSortCollection");
      DataGridSortItem sortItem = new DataGridSortItem() { Column = column, SortDirection = sortDirection };
      sortCollection.Add(sortItem);
      sortMarkersChanged = true;
    }

    protected internal void Clear()
    {
      sortCollection.Clear();
      sortMarkersChanged = true;
    }

    protected internal bool Remove(DataGridColumn column)
    {
      for (int i = 0; i < Count; i++)
      {
        DataGridSortItem si = this[i];
        if (si.Column == column)
        {
          sortCollection.RemoveAt(i);
          sortMarkersChanged = true;
        }
      }
      return false;
    }

    protected internal void SetSortStateInternal(DataGridColumn column, ListSortDirection sortDirection)
    {
      Clear();
      AddSortItem(column, sortDirection);
      sortMarkersChanged = true;
    }

    public void UpdateDataFromListSortDescription(IList listDescCollection)
    {
      DataGridSortItem sortItem;
      DataGridColumn column;
      ListSortDescription sortDesc;

      Clear();
      foreach (object lsd in listDescCollection)
      {
        sortDesc = (lsd as ListSortDescription);
        Debug.Assert(sortDesc != null, "sortDesc != null");
        column = Grid.Columns.FindColumnByPropertyName(sortDesc.PropertyDescriptor.Name);
        if (column != null)
        {
          sortItem = new DataGridSortItem();
          sortItem.SortDirection = sortDesc.SortDirection;
          sortItem.Column = column;
          sortCollection.Add(sortItem);
        }
      }
      sortMarkersChanged = false;
    }

    public int IndexOf(DataGridColumn column)
    {
      int index = 0;
      foreach (DataGridSortItem si in sortCollection)
      {
        if (si.Column == column)
          return index;
        index = index + 1;
      }
      return -1;
    }

    public void ChangeStateAsTitleClick(DataGridColumn column, bool isMultiSortMarking)
    {
      DataGridSortItem si;
      int siIndex;

      siIndex = IndexOf(column);
      if (isMultiSortMarking)
      {
        if (siIndex >= 0)
        {
          si = this[siIndex];
          if (si.SortDirection == ListSortDirection.Ascending)
            si.SortDirection = ListSortDirection.Descending;
          else
            Remove(column);
        }
        else
        {
          AddSortItem(column, ListSortDirection.Ascending);
        }
      }
      else
      {
        if (siIndex >= 0)
        {
          si = this[siIndex];
          if (si.SortDirection == ListSortDirection.Ascending)
            SetSortStateInternal(column, ListSortDirection.Descending);
          else
            SetSortStateInternal(column, ListSortDirection.Ascending);
        }
        else
        {
          ListSortDirection sd = column.Title.SortMarking.FirstSortDirection;
          SetSortStateInternal(column, sd);
          //SetSortStateInternal(column, ListSortDirection.Ascending);
        }
      }
      sortMarkersChanged = true;
    }

    public void CommitChanges()
    {
      if (sortMarkersChanged)
      {
        Grid.OnSortmarkingChangeCommitted();
        sortMarkersChanged = false;
      }
    }

    public void SetChangedStatus(bool isChanged)
    {
      sortMarkersChanged = isChanged;
    }
    #endregion
  }

  /// <summary>
  ///  Contains properties that set the list of items in the drop-down menu in 
  ///  the search bar.
  /// </summary>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridSearchBoxOptionsMenuItems
  {
    public DataGridSearchBoxOptionsMenuItems()
    {
      SearchScopes = true;
      CaseSensitive = true;
      WholeWords = true;
      BeginsWith = true;
    }

    /// <summary>
    /// Show menu item "Search scope"
    /// </summary>
    [DefaultValue(true)]
    public bool SearchScopes { get; set; }

    /// <summary>
    /// Show menu item "Case sensitive"
    /// </summary>
    [DefaultValue(true)]
    public bool CaseSensitive { get; set; }

    /// <summary>
    /// Show menu item "Whole words"
    /// </summary>
    [DefaultValue(true)]
    public bool WholeWords { get; set; }

    /// <summary>
    /// Show menu item "Begins with"
    /// </summary>
    [DefaultValue(true)]
    public bool BeginsWith { get; set; }

    public virtual bool HasVisibleItem()
    {
      return SearchScopes || CaseSensitive || WholeWords || BeginsWith;
    }
  }

  /// <summary>
  ///  Contains properties that define a list of buttons at the search box 
  /// </summary>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridSearchBoxVisibleButtons
  {

    #region >privates
    private readonly DataGridSearchBox searchBox;
    private bool applyFilterClear;
    private bool optionsPopupMenu;
    private bool findPrior;
    private bool findNext;
    #endregion <privates

    public DataGridSearchBoxVisibleButtons(DataGridSearchBox searchBox)
    {
      this.searchBox = searchBox;
      applyFilterClear = true;
      findNext = true;
      findPrior = true;
      optionsPopupMenu = true;
    }

    /// <summary>
    /// Show button "Apply filter"/"Clear filter"
    /// </summary>
    [DefaultValue(true)]
    public bool ApplyFilterClear
    {
      get
      {
        return applyFilterClear;
      }
      set
      {
        if (value != applyFilterClear)
        {
          applyFilterClear = value;
          searchBox.VisibleButtonsChanged();
        }
      }
    }

    /// <summary>
    /// Show button "Find next"
    /// </summary>
    [DefaultValue(true)]
    public bool FindNext
    {
      get
      {
        return findNext;
      }
      set
      {
        if (value != findNext)
        {
          findNext = value;
          searchBox.VisibleButtonsChanged();
        }
      }
    }

    /// <summary>
    /// Show button "Find prior"
    /// </summary>
    [DefaultValue(true)]
    public bool FindPrior
    {
      get
      {
        return findPrior;
      }
      set
      {
        if (value != findPrior)
        {
          findPrior = value;
          searchBox.VisibleButtonsChanged();
        }
      }
    }

    /// <summary>
    /// Show button "Options" with drop-down menu
    /// </summary>
    [DefaultValue(true)]
    public bool OptionsPopupMenu
    {
      get
      {
        return optionsPopupMenu;
      }
      set
      {
        if (value != optionsPopupMenu)
        {
          optionsPopupMenu = value;
          searchBox.VisibleButtonsChanged();
        }
      }
    }
  }

  /// <summary>
  /// Contains properties and events for customizing the search box in the grid.
  /// </summary>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  [ToolboxItem(false)]
  [DesignTimeVisible(false)]
  public class DataGridSearchBox : Component
  //public class SearchBoxParams : Object, IComponent
  {

    #region private consts
    private static readonly object EventKeyDataGridSearchBoxCheckRowHitSearch = new object();
    private static readonly object EventKeyDataGridSearchBoxCheckCellHitSearch = new object();
    private static readonly object EventKeyDataGridSearchGetHighlightedRanges = new object();
    #endregion private consts

    #region privates
    private readonly DataGridEh grid;
    private bool enabled;
    private bool visible;
    private bool caseSensitive;
    private DataGridSearchBoxScope searchScope = DataGridSearchBoxScope.EntireGrid;
    private bool cellBeginsWithMode;
    private bool wholeWords;
    private readonly DataGridSearchBoxOptionsMenuItems optionsPopupMenuItems;
    private readonly DataGridSearchBoxVisibleButtons visibleButtons;
    private bool persistentShowing = true;

    private string filterText = "";
    private bool highlightSearchingText;
    #endregion privates

    public DataGridSearchBox(DataGridEh grid)
    {
      this.grid = grid;
      enabled = false;
      visible = false;
      optionsPopupMenuItems = new DataGridSearchBoxOptionsMenuItems();
      visibleButtons = new DataGridSearchBoxVisibleButtons(this);
      Shortcut = Shortcut.CtrlF;
      FilterEnabled = true;
      FilterOnTyping = false;
    }

    #region design-time properties

    /// <summary>
    /// Indicates that the search pane is available for use at runtime. 
    /// By default, when Enabled = true, the search box immediately becomes visible at the top of the grid.
    /// </summary>
    [DefaultValue(false)]
    public virtual bool Enabled
    {
      get
      {
        return enabled;
      }
      set
      {
        if (enabled != value)
        {
          enabled = value;
          UpdateVisibleState();
        }
      }
    }

    /// <summary>
    /// Specifies that process of searching data is case-sensitive.
    /// </summary>
    [DefaultValue(false)]
    public bool CaseSensitive
    {
      get
      {
        return caseSensitive;
      }
      set
      {
        if (caseSensitive != value)
        {
          caseSensitive = value;
          Grid.Invalidate();
        }
      }
    }

    /// <summary>
    /// Specifies the scope of searching data: current column or th whole grid.
    /// </summary>
    [DefaultValue(DataGridSearchBoxScope.EntireGrid)]
    public DataGridSearchBoxScope SearchScope
    {
      get
      {
        return searchScope;
      }
      set
      {
        if (searchScope != value)
        {
          searchScope = value;
          Grid.Invalidate();
        }
      }
    }

    /// <summary>
    /// Specifies that the match in the search must be from the beginning of the contents of the cell. 
    /// False value means that the search string match can be from any position of the cell value.
    /// </summary>
    [DefaultValue(false)]
    public bool CellBeginsWithMode
    {
      get
      {
        return cellBeginsWithMode;
      }
      set
      {
        if (cellBeginsWithMode != value)
        {
          cellBeginsWithMode = value;
          Grid.Invalidate();
        }
      }
    }

    /// <summary>
    /// The searching string must fully match the value of the cell.
    /// </summary>
    [DefaultValue(false)]
    public bool WholeWords
    {
      get
      {
        return wholeWords;
      }
      set
      {
        if (wholeWords != value)
        {
          wholeWords = value;
          Grid.Invalidate();
        }
      }
    }

    /// <summary>
    /// The key combination to put focus in the search box.
    /// </summary>
    [DefaultValue(Shortcut.CtrlF)]
    public Shortcut Shortcut { get; set; }

    /// <summary>
    ///  Filtering is available. 
    ///  true value means that filtering is also available when searching.
    ///  To activate the filter of the values found, the user usually must press Enter key.
    /// </summary>
    [DefaultValue(true)]
    public bool FilterEnabled { get; set; }

    /// <summary>
    /// Filtering is available and applied as user type text in the search bar text editor.
    /// </summary>
    [DefaultValue(false)]
    public bool FilterOnTyping { get; set; }

    /// <summary>
    /// Defines a list of menu items in drop-down menu for button "Options".
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridSearchBoxOptionsMenuItems OptionsPopupMenuItems
    {
      get { return optionsPopupMenuItems; }
    }

    /// <summary>
    /// Defines a list of buttons in search box.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridSearchBoxVisibleButtons VisibleButtons
    {
      get { return visibleButtons; }
    }

    /// <summary>
    /// Specifies that search box is always visible. This property works when Enabled = true.
    /// </summary>
    [DefaultValue(true)]
    public bool PersistentShowing
    {
      get
      {
        return persistentShowing;
      }
      set
      {
        if (persistentShowing != value)
        {
          persistentShowing = value;
          UpdateVisibleState();
          Grid.Invalidate();
        }
      }
    }

    #endregion design-time properties

    #region run-time properties
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataGridEh Grid
    {
      get { return grid; }
    }

    [Browsable(false)]
    [DefaultValue(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public virtual bool Visible
    {
      get
      {
        return visible;
      }
      set
      {
        if (visible != value)
        {
          visible = value;
          Grid.UpdateBoundaries();
        }
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int InGridHeight
    {
      get
      {
        if (Visible)
          return Grid.SearchBoxControl.CalcAutoHeight();
        else
          return 0;
      }
    }

    [Browsable(false)]
    [DefaultValue(false)]
    public virtual bool Active
    {
      get
      {
        return Grid.SearchBoxControl.ContainsFocus;
      }

      set
      {
        if (value == true)
        {
          if (Grid.ContainsFocus)
            Grid.SearchBoxControl.FindEditor.Focus();
        }
        else
        {
          Grid.Focus();
        }
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public string SearchingText
    {
      get { return Grid.SearchBoxControl.FindEditor.Text; }
      set { Grid.SearchBoxControl.FindEditor.Text = value; }
    }

    [Browsable(false)]
    public bool FilterActive
    {
      get { return /*Enabled &&*/ !string.IsNullOrEmpty(FilterText); }
    }

    [Browsable(false)]
    public string FilterText
    {
      get { return filterText; }
    }

    [DefaultValue(false)]
    [Browsable(false)]
    public bool HighlightSearchingText
    {
      get
      {
        return highlightSearchingText;
      }
      set
      {
        if (highlightSearchingText != value)
        {
          highlightSearchingText = value;
          Grid.Invalidate();
        }
      }
    }

    #endregion run-time properties

    #region events
    //public event KeyEventHandler KeyDown
    //{
    //  add { }
    //  remove { }
    //}

    //public event KeyPressEventHandler KeyPress
    //{
    //  add { }
    //  remove { }
    //}

    //public event KeyEventHandler KeyUp
    //{
    //  add { }
    //  remove { }
    //}

    public event EventHandler<DataGridSearchBoxCheckRowHitSearchEventArgs> CheckRowHitSearch
    {
      add
      {
        Events.AddHandler(EventKeyDataGridSearchBoxCheckRowHitSearch, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataGridSearchBoxCheckRowHitSearch, value);
      }
    }

    public event EventHandler<DataGridSearchBoxCheckCellHitSearchEventArgs> CheckCellHitSearch
    {
      add
      {
        Events.AddHandler(EventKeyDataGridSearchBoxCheckCellHitSearch, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataGridSearchBoxCheckCellHitSearch, value);
      }
    }

    public event EventHandler<DataGridSearchGetHighlightedRangesEventArgs> GetHighlightedRanges
    {
      add
      {
        Events.AddHandler(EventKeyDataGridSearchBoxCheckRowHitSearch, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataGridSearchBoxCheckRowHitSearch, value);
      }
    }

    #endregion events

    #region methods
    public void FindNext()
    {
      DataGridLocateTextArgs locateTextArgs = new DataGridLocateTextArgs()
      {
        CaseSensitive = this.CaseSensitive,
        AllFields = (this.SearchScope == DataGridSearchBoxScope.EntireGrid),
        MatchFormat = true,
        IgnoreCurrentPos = true,
        StopOnEscape = true,
        StopOnAnyKey = true,
        AroundCircle = true,
        Direction = LocateTextDirection.Down,
        Timeout = 0
      };
      if (WholeWords)
        locateTextArgs.Matching = LocateTextMatching.Whole;
      else if (CellBeginsWithMode)
        locateTextArgs.Matching = LocateTextMatching.StartOf;
      else
        locateTextArgs.Matching = LocateTextMatching.AnyPartOf;

      Grid.LocateText(SearchingText, locateTextArgs);
    }

    public void FindPrev()
    {
      DataGridLocateTextArgs locateTextArgs = new DataGridLocateTextArgs()
      {
        CaseSensitive = this.CaseSensitive,
        AllFields = (this.SearchScope == DataGridSearchBoxScope.EntireGrid),
        MatchFormat = true,
        IgnoreCurrentPos = true,
        StopOnEscape = true,
        StopOnAnyKey = true,
        AroundCircle = true,
        Direction = LocateTextDirection.Up,
        Matching = LocateTextMatching.AnyPartOf,
        Timeout = 0
      };
      if (WholeWords)
        locateTextArgs.Matching = LocateTextMatching.Whole;
      else if (CellBeginsWithMode)
        locateTextArgs.Matching = LocateTextMatching.StartOf;
      else
        locateTextArgs.Matching = LocateTextMatching.AnyPartOf;

      Grid.LocateText(SearchingText, locateTextArgs);
    }

    public void RestartFind()
    {
      DataGridLocateTextArgs locateTextArgs = new DataGridLocateTextArgs()
      {
        CaseSensitive = this.CaseSensitive,
        AllFields = (this.SearchScope == DataGridSearchBoxScope.EntireGrid),
        MatchFormat = true,
        IgnoreCurrentPos = false,
        StopOnEscape = true,
        StopOnAnyKey = true,
        AroundCircle = false,
        Direction = LocateTextDirection.All,
        Timeout = 0
      };
      if (WholeWords)
        locateTextArgs.Matching = LocateTextMatching.Whole;
      else if (CellBeginsWithMode)
        locateTextArgs.Matching = LocateTextMatching.StartOf;
      else
        locateTextArgs.Matching = LocateTextMatching.AnyPartOf;

      Grid.LocateText(SearchingText, locateTextArgs);
    }

    public void ApplyFilter(string text)
    {
      ApplyFilter(text, false, false);
    }

    public void ApplyFilter(string text, bool stopOnEscape, bool stopOnAnyKey)
    {
      filterText = text;
      Grid.RebuildVisibleRows(stopOnEscape, stopOnAnyKey, true);
      if ((Grid.InternalCurrentRowIndex == -1) &&
          (Grid.VisibleRows.Count > 0))
      {
        Grid.CurrentRowIndex = 0;
      }
      Grid.SearchBoxControl.RealignControls();
    }

    public void CancelFilter()
    {
      filterText = "";
      DataGridRow currentRow = Grid.CurrentRow;
      Grid.RebuildVisibleRows(false, false, false);
      Grid.LocateRow(currentRow);
      Grid.SearchBoxControl.FindEditor.Text = "";
      Grid.SearchBoxControl.RealignControls();
    }

    public bool CheckTextHit(DataGridColumn column, string srcText, string searchText)
    {
      int stri;
      StringComparison comparisonType;

      if (srcText == null) return false;

      if ((SearchScope == DataGridSearchBoxScope.CurrentColumn) &&
          (column.VisibleIndex != Grid.CurrentColumnIndex))
        return false;

      if (CaseSensitive)
        comparisonType = StringComparison.Ordinal;
      else
        comparisonType = StringComparison.OrdinalIgnoreCase;

      if (WholeWords == true)
      {
        if (string.Equals(srcText, searchText, comparisonType) == true)
          stri = 0;
        else
          stri = -1;
      }
      else if (CellBeginsWithMode == true)
      {
        stri = srcText.IndexOf(searchText, comparisonType);
        if (stri > 0)
          stri = -1;
      }
      else
        stri = srcText.IndexOf(searchText, comparisonType);

      if (stri >= 0)
        return true;
      else
        return false;
    }

    public CharacterRange[] GetHitRanges(DataGridColumn column, DataGridRow row, string text)
    {
      CharacterRange[] charRanges = null;
      StringComparison comparisonType;

      if (CaseSensitive)
        comparisonType = StringComparison.Ordinal;
      else
        comparisonType = StringComparison.OrdinalIgnoreCase;

      if (WholeWords == true)
      {
        if (string.Equals(text, SearchingText, comparisonType) == true)
          charRanges = new[] { new CharacterRange(0, text.Length) };
      }
      else if (CellBeginsWithMode == true)
      {
        int stri = text.IndexOf(SearchingText, comparisonType);
        if (stri == 0)
          charRanges = new[] { new CharacterRange(0, SearchingText.Length) };
      }
      else
      {
        int[] strPList = EhLibUtils.StringAllIndexsOf(text, SearchingText, comparisonType, true);

        charRanges = new CharacterRange[strPList.Length];

        for (int i = 0; i < strPList.Length; i++)
        {
          charRanges[i].First = strPList[i];
          charRanges[i].Length = SearchingText.Length;
        }
      }

      ProcessGetHighlightedRangesEvent(column, row, text, charRanges);

      return charRanges;
    }

    public void UpdateVisibleState()
    {
      if ((persistentShowing || Active) &&
          (Enabled == true))
      {
        Visible = true;
      }
      else
      {
        Active = false;
        Visible = false;
      }
      //else if ((persistentShowing == false) && (Active == false))
      //{
      //  Visible = false;
      //}
    }

    protected internal virtual bool CheckRowVisible(DataGridRow row)
    {
      if (!FilterActive) return true;

      bool result = false;

      foreach (DataGridColumn col in Grid.VisibleColumns)
      {
        string s;
        bool hitTest;

        s = col.GetRowDisplayText(row);
        hitTest = CheckTextHit(col, s, FilterText);

        ProcessCheckCellHitSearchEvent(col, row, FilterText, ref hitTest);

        if (hitTest == true)
        {
          result = true;
          break;
        }
      }

      ProcessCheckRowHitSearchEvent(row, FilterText, ref result);

      return result;
    }

    private void ProcessCheckRowHitSearchEvent(DataGridRow row, string hitSearchText, ref bool isHitSearch)
    {
      var eh = Events[EventKeyDataGridSearchBoxCheckRowHitSearch] as EventHandler<DataGridSearchBoxCheckRowHitSearchEventArgs>;
      if (eh != null && !Grid.IsDisposed)
      {
        var e = new DataGridSearchBoxCheckRowHitSearchEventArgs(hitSearchText, row);
        e.RowIsHitSearch = isHitSearch;
        eh(this, e);
        isHitSearch = e.RowIsHitSearch;
      }
    }

    private void ProcessCheckCellHitSearchEvent(DataGridColumn column, DataGridRow row, string hitSearchText, ref bool isHitSearch)
    {
      var eh = Events[EventKeyDataGridSearchBoxCheckCellHitSearch] as EventHandler<DataGridSearchBoxCheckCellHitSearchEventArgs>;
      if (eh != null && !Grid.IsDisposed)
      {
        var e = new DataGridSearchBoxCheckCellHitSearchEventArgs(hitSearchText, row, column);
        e.CellIsHitSearch = isHitSearch;
        eh(this, e);
      }
    }

    private void ProcessGetHighlightedRangesEvent(DataGridColumn column, DataGridRow row, string hitSearchText, CharacterRange[] ranges)
    {
      var eh = Events[EventKeyDataGridSearchGetHighlightedRanges] as EventHandler<DataGridSearchGetHighlightedRangesEventArgs>;
      if (eh != null && !Grid.IsDisposed)
      {
        var e = new DataGridSearchGetHighlightedRangesEventArgs(hitSearchText, row, column, ranges);
        eh(this, e);
      }
    }

    internal void VisibleButtonsChanged()
    {
      Grid.SearchBoxControl.RealignControls();
    }

    #endregion methods
  }

  public class DataGridLocateTextArgs
  {
    public DataGridLocateTextArgs()
    {
      CaseSensitive = false;
      AllFields = true;
      MatchFormat = true;
      IgnoreCurrentPos = true;
      StopOnEscape = true;
      StopOnAnyKey = true;
      AroundCircle = false;
      Direction = LocateTextDirection.Down;
      Matching = LocateTextMatching.Whole;
      Timeout = 0;
    }

    public bool CaseSensitive { get; set; }
    public bool AllFields { get; set; }
    public bool MatchFormat { get; set; }
    public bool IgnoreCurrentPos { get; set; }
    public bool StopOnEscape { get; set; }
    public bool StopOnAnyKey { get; set; }
    public bool AroundCircle { get; set; }
    public LocateTextDirection Direction { get; set; }
    public LocateTextMatching Matching { get; set; }
    public int Timeout { get; set; }
  }

  public class DataGridLocateTextService
  {
    private readonly DataGridEh grid;
    int nextColIndex, nextRowIndex;

    public DataGridLocateTextService(DataGridEh grid)
    {
      this.grid = grid;
    }

    [Browsable(false)]
    public DataGridEh Grid { get { return grid; } }
    public string SearchText { get; set; }
    public DataGridLocateTextArgs SearchParams { get; set; }

    public bool SearchNext()
    {

      int ticks = Environment.TickCount;
      bool waitCursorSet = false;
      bool result = false;
      int oldNextRowIndex = Grid.CurrentColumnIndex;

      if (grid.VisibleRows.Count == 0) return false;
      if (grid.VisibleColumns.Count == 0) return false;

      nextColIndex = Grid.CurrentColumnIndex;
      nextRowIndex = Grid.CurrentRowIndex;

      if (SearchParams.Direction == LocateTextDirection.All)
        RestartCell();
      if (SearchParams.IgnoreCurrentPos == true)
      {
        SetNextCell();
        if ((nextColIndex == Grid.CurrentColumnIndex) &&
            (nextRowIndex == Grid.CurrentRowIndex))
          return false;
      }

      while (true)
      {
        Debug.Assert(grid.VisibleColumns.Count != 0);

        if (CheckMatch() == true)
        {
          Grid.CurrentColumnIndex = nextColIndex;
          Grid.CurrentRowIndex = nextRowIndex;
          result = true;
          break;
        }
        else if (CheckEndOfData() == true)
          break;
        else
          SetNextCell();

        if (oldNextRowIndex != nextRowIndex)
        {
          if ((SearchParams.StopOnEscape == true) && IsEscapePressed())
            break;

          if ((SearchParams.StopOnAnyKey == true) && IsAnyKeyPressed())
            break;

          if ((Environment.TickCount - ticks > 1000) &&
              (Application.UseWaitCursor == false) &&
              (waitCursorSet == false))
          {
            Cursor.Show();
            Cursor.Current = Cursors.WaitCursor;
            waitCursorSet = true;
          }
          oldNextRowIndex = nextRowIndex;
        }
      }

      if (waitCursorSet)
        Cursor.Current = Cursors.Default;
      return result;
    }

    public bool CheckMatch()
    {
      int stri;
      StringComparison comparisonType;
      if (grid.VisibleRows.Count == 0) return false;

      string cellStr = grid.VisibleColumns[nextColIndex].GetRowDisplayText(grid.VisibleRows[nextRowIndex]);
      if (cellStr == null) cellStr = "";

      if (SearchParams.CaseSensitive)
        comparisonType = StringComparison.Ordinal;
      else
        comparisonType = StringComparison.OrdinalIgnoreCase;

      if (SearchParams.Matching == LocateTextMatching.Whole)
      {
        if (string.Equals(cellStr, SearchText, comparisonType) == true)
          stri = 0;
        else
          stri = -1;
      }
      else if (SearchParams.Matching == LocateTextMatching.StartOf)
      {
        bool strartWith = cellStr.StartsWith(SearchText, comparisonType);
        if (strartWith)
          stri = 0;
        else
          stri = -1;
      }
      else
        stri = cellStr.IndexOf(SearchText, comparisonType);

      if (stri >= 0)
        return true;
      else
        return false;
    }

    public void SetNextCell()
    {
      int minColIndex;
      int maxColIndex;

      if (SearchParams.AllFields)
      {
        minColIndex = 0;
        maxColIndex = Grid.VisibleColumns.Count - 1;
        if (maxColIndex < 0) maxColIndex = 0;
      }
      else
      {
        minColIndex = Grid.CurrentColumnIndex;
        maxColIndex = Grid.CurrentColumnIndex;
      }

      if ((SearchParams.Direction == LocateTextDirection.Down) ||
         (SearchParams.Direction == LocateTextDirection.All))
      {
        if (nextColIndex < maxColIndex)
        {
          nextColIndex = nextColIndex + 1;
        }
        else if (nextRowIndex < Grid.VisibleRows.Count - 1)
        {
          nextRowIndex = nextRowIndex + 1;
          nextColIndex = minColIndex;
        }
        else if (SearchParams.AroundCircle == true)
        {
          nextRowIndex = 0;
          nextColIndex = minColIndex;
        }
      }
      else
      {
        if (nextColIndex > minColIndex)
        {
          nextColIndex -= 1;
        }
        else if (nextRowIndex > 0)
        {
          nextRowIndex -= 1;
          nextColIndex = maxColIndex;
        }
        else if (SearchParams.AroundCircle == true)
        {
          nextRowIndex = Grid.VisibleRows.Count - 1;
          nextColIndex = maxColIndex;
        }
      }
    }

    public void RestartCell()
    {
      nextRowIndex = 0;
      if (SearchParams.AllFields)
        nextColIndex = 0;
    }

    public bool CheckEndOfData()
    {
      bool result;
      int minColIndex;
      int maxColIndex;

      if (SearchParams.AllFields)
      {
        minColIndex = 0;
        maxColIndex = Grid.VisibleColumns.Count - 1;
      }
      else
      {
        minColIndex = Grid.CurrentColumnIndex;
        maxColIndex = Grid.CurrentColumnIndex;
      }

      if (SearchParams.AroundCircle == true)
        result =
            (nextColIndex == Grid.CurrentColumnIndex) &&
            (nextRowIndex == Grid.CurrentRowIndex);
      else if (SearchParams.Direction == LocateTextDirection.Up)
        result = (nextColIndex == minColIndex) && (nextRowIndex == 0);
      else
        result = (nextColIndex == maxColIndex) &&
                 (nextRowIndex == Grid.VisibleRows.Count - 1);
      return result;
    }

    private bool IsAnyKeyPressed()
    {
      return EhLibUtils.InteractiveIsAnyKeyPressed(null);
    }

    private bool IsEscapePressed()
    {
      return EhLibUtils.CheckKeyPressed(null, Keys.Escape, true);
    }

    //internal void OldLocateText(string s, DataGridLocateTextArgs args)
    //{
    //  string cellText;

    //  for (int ir = 0; ir < Grid.VisibleRows.Count; ir++)
    //  {
    //    for (int ic = 0; ic < Grid.VisibleColumns.Count; ic++)
    //    {
    //      DataGridColumn col = Grid.VisibleColumns[ic];

    //      cellText = col.GetRowDisplayText(Grid.VisibleRows[ir]);

    //    }
    //  }
    //}

  }

  /// <summary>
  /// Contains properties for customizing dividing lines between grid cells.
  /// </summary>
  /// <remarks>
  /// You can retrieve an instance of this class through the <see cref="DataGridEh.LineOptions"/> property.
  /// </remarks>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridLineOptions : GridLineColors
  {
    #region privates
    private bool horzLines = true;
    private bool vertLines = true;
    private bool dataBoundaryColorStored;
    private Color dataBoundaryColor = Color.Empty;
    private bool gridBoundaries;
    private DataGridHorzCellFreeAreaFillStyle horzCellFreeAreaFillStyle = DataGridHorzCellFreeAreaFillStyle.TitleExtend;
    private DataGridVertCellFreeAreaFillStyle vertCellFreeAreaFillStyle = DataGridVertCellFreeAreaFillStyle.ColumnGradient;
    #endregion privates

    public DataGridLineOptions(BaseGridControl grid) : base(grid)
    {
    }

    #region design-time properties
    public new Color DarkColor
    {
      get { return base.DarkColor; }
      set { base.DarkColor = value; }
    }

    public new Color BrightColor
    {
      get { return base.BrightColor; }
      set { base.BrightColor = value; }
    }

    /// <summary>
    /// Indicates whether to draw horizontal lines between grid cells.
    /// </summary>
    [DefaultValue(true)]
    public bool HorzLines
    {
      get { return horzLines; }
      set
      {
        if (horzLines != value)
        {
          horzLines = value;
          HorzLinesChanged();
        }
      }
    }

    /// <summary>
    /// Indicates whether to draw vertical lines between grid cells.
    /// </summary>
    [DefaultValue(true)]
    public bool VertLines
    {
      get { return vertLines; }
      set
      {
        if (vertLines != value)
        {
          vertLines = value;
          VertLinesChanged();
        }
      }
    }

    /// <summary>
    /// Gets or sets the color of lines of a grid data boundary area.
    /// </summary>
    public Color DataBoundaryColor
    {
      get
      {
        if (dataBoundaryColorStored)
          return dataBoundaryColor;
        else
          return DefaultDataBoundaryColor();
      }
      set
      {
        if ((dataBoundaryColorStored == false) || (dataBoundaryColor != value))
        {
          dataBoundaryColorStored = true;
          dataBoundaryColor = value;
          DataBoundaryColorChanged();
        }
      }
    }

    /// <summary>
    /// Indicates whether to draw a grid data boundary area lines with DataBoundaryColor color.
    /// </summary>
    [DefaultValue(false)]
    public bool GridBoundaries
    {
      get { return gridBoundaries; }
      set
      {
        if (GridBoundaries != value)
        {
          gridBoundaries = value;
          GridBoundariesChanged();
        }
      }
    }

    /// <summary>
    /// The way to fill the area in the left part of the grid where there are no cells.
    /// </summary>
    [DefaultValue(DataGridHorzCellFreeAreaFillStyle.TitleExtend)]
    public DataGridHorzCellFreeAreaFillStyle HorzCellFreeAreaFillStyle
    {
      get { return horzCellFreeAreaFillStyle; }
      set
      {
        if (horzCellFreeAreaFillStyle != value)
        {
          horzCellFreeAreaFillStyle = value;
          HorzEmptySpaceStyleChanged();
        }
      }
    }

    /// <summary>
    /// The way to fill the area in the bottom part of the grid where there are no cells.
    /// </summary>
    [DefaultValue(DataGridVertCellFreeAreaFillStyle.ColumnGradient)]
    public DataGridVertCellFreeAreaFillStyle VertCellFreeAreaFillStyle
    {
      get { return vertCellFreeAreaFillStyle; }
      set
      {
        if (vertCellFreeAreaFillStyle != value)
        {
          vertCellFreeAreaFillStyle = value;
          VertEmptySpaceStyleChanged();
        }
      }
    }
    #endregion

    #region run-time properties
    [Browsable(false)]
    protected new DataGridEh Grid
    {
      get { return (DataGridEh)base.Grid; }
    }

    [Browsable(false)]
    public int VertLineSpace
    {
      get
      {
        if (VertLines)
          return Grid.GridLineWidth;
        else
          return 0;
      }
    }

    [Browsable(false)]
    public int HorzLineSpace
    {
      get
      {
        if (HorzLines)
          return Grid.GridLineWidth;
        else
          return 0;
      }
    }
    #endregion

    #region methods
    protected virtual void VertEmptySpaceStyleChanged()
    {
      Grid.InvalidateGrid();
    }

    protected virtual void HorzEmptySpaceStyleChanged()
    {
      Grid.InvalidateGrid();
    }

    protected virtual void GridBoundariesChanged()
    {
      Grid.InvalidateGrid();
    }

    protected virtual void HorzLinesChanged()
    {
      if (HorzLines)
        Grid.Options = Grid.Options | GridOptions.HorzLines;
      else
        Grid.Options = Grid.Options & ~GridOptions.HorzLines;

      Grid.UpdateBaseRowHeights();
    }

    protected virtual void VertLinesChanged()
    {
      Grid.UpdateColumnsView();
    }

    public virtual void DataBoundaryColorChanged()
    {
      Grid.InvalidateGrid();
    }

    protected virtual Color DefaultDataBoundaryColor()
    {
      return DarkColor;
    }

    protected virtual bool ShouldSerializeDataBoundaryColor()
    {
      return dataBoundaryColorStored == true;
    }

    public virtual void ResetDataBoundaryColor()
    {
      dataBoundaryColorStored = false;
      DataBoundaryColorChanged();
    }
    #endregion methods

  }

  /// <summary>
  /// Contains properties for customizing the display of all grid columns.
  /// </summary>
  /// <remarks>
  /// You can retrieve an instance of this class through the <see cref="DataGridEh.ColumnOptions"/> property.
  /// </remarks>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridColumnOptions : DataGridObject, IGridLineHost
  {

    #region privates
    private bool allowResizeColumns = true;
    private bool allowMoveColumns = true;
    private bool allowShowEditor = true;
    private bool fitsizeOnSizingDoubleClick = true;
    private bool foreColorStored;
    private Color foreColor = Color.Empty;
    private Padding sidePadding = new Padding(2, 2, 2, 2);
    private bool sidePaddingStored;
    private Font font;
    private CellTextWrapMode wrapMode = CellTextWrapMode.Auto;
    private VerticalAlignment vertAlign = VerticalAlignment.Top;
    private readonly DataGridEditItemOptions editItemOptions;
    private readonly GridLine vertLine;
    private bool nonfitTooltips = true;
    private bool cacheDisplayValues = false;
    #endregion privates

    public DataGridColumnOptions(DataGridEh grid) : base(grid)
    {
      editItemOptions = new DataGridEditItemOptions(this);
      vertLine = new GridLine(this);
    }

    #region properties

    /// <summary>
    /// Gets or sets a value indicating whether users can resize columns.
    /// </summary>
    [DefaultValue(true)]
    public bool AllowResizeColumns
    {
      get
      {
        return allowResizeColumns;
      }
      set
      {
        if (allowResizeColumns != value)
        {
          allowResizeColumns = value;
          if (allowResizeColumns || Grid.DesignMode)
          {
            Grid.Options = Grid.Options | GridOptions.ColSizing;
          }
          else
          {
            Grid.Options = Grid.Options & ~GridOptions.ColSizing;
          }
        }
      }
    }

    /// <summary>
    /// Gets or sets a value indicating whether users can move columns.
    /// </summary>
    [DefaultValue(true)]
    public bool AllowMoveColumns
    {
      get
      {
        return allowMoveColumns;
      }
      set
      {
        if (allowMoveColumns != value)
        {
          allowMoveColumns = value;
        }
      }
    }

    /// <summary>
    /// Gets or sets a value indicating whether the grid can show cell when user press F2 or click on the current cell.
    /// </summary>
    [DefaultValue(true)]
    public bool AllowShowEditor
    {
      get
      {
        return allowShowEditor;
      }
      set
      {
        if (allowShowEditor != value)
        {
          allowShowEditor = value;
        }
      }
    }

    /// <summary>
    /// Gets or sets a value indicating whether the grid will resize column to optimal value for fitting column content when use double click in sizing line.
    /// </summary>
    [DefaultValue(true)]
    public bool FitSizeOnSizingDoubleClick
    {
      get
      {
        return fitsizeOnSizingDoubleClick;
      }
      set
      {
        if (fitsizeOnSizingDoubleClick != value)
        {
          fitsizeOnSizingDoubleClick = value;
        }
      }
    }

    /// <summary>
    /// Gets or sets the color of the grid data cell text.
    /// </summary>
    public Color ForeColor
    {
      get
      {
        if (foreColorStored)
          return foreColor;
        else
          return DefaultForeColor();
      }
      set
      {
        if ((foreColorStored == false) || (foreColor != value))
        {
          foreColorStored = true;
          foreColor = value;
          ForeColorChanged();
        }
      }
    }

    /// <summary>
    /// Gets or sets the font  of the grid data cell text.
    /// </summary>
    public Font Font
    {
      get
      {
        if (font != null)
          return font;
        else
          return DefaultFont();
      }
      set
      {
        font = value;
        FontChanged();
      }
    }

    /// <summary>
    /// Gets or sets the default padding inside data cells. 
    /// </summary>
    /// <remarks>
    /// For left alignmented cells the Right value of SidePadding is not used. Cells use zero value.
    /// For right alignmented cells the Left value of SidePadding is not used. Cells use zero value.
    /// </remarks>
    public Padding SidePadding
    {
      get
      {
        if (sidePaddingStored)
          return sidePadding;
        else
          return DefaultSidePadding();
      }
      set
      {
        if ((sidePaddingStored == false) || (sidePadding != value))
        {
          sidePaddingStored = true;
          sidePadding = value;
          SidePaddingChanged();
        }
      }
    }

    [DefaultValue(CellTextWrapMode.Auto)]
    public CellTextWrapMode WrapMode
    {
      get
      {
        return wrapMode;
      }
      set
      {
        if (wrapMode != value)
        {
          wrapMode = value;
          WrapModeChanged();
        }
      }
    }

    [DefaultValue(VerticalAlignment.Top)]
    public VerticalAlignment VertAlign
    {
      get
      {
        return vertAlign;
      }
      set
      {
        if (vertAlign != value)
        {
          vertAlign = value;
          VertAlignChanged();
        }
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridEditItemOptions EditItemOptions
    {
      get { return editItemOptions; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridLine VertLine
    {
      get
      {
        return vertLine;
      }
    }

    [DefaultValue(null)]
    public virtual ContextMenuStrip ContextMenuStrip { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether grid should should full version of the title text in the tooltip window 
    /// when the text is not fitted in the cell bounds.
    /// </summary>
    [DefaultValue(true)]
    public bool NonfitTooltips
    {
      get
      {
        return nonfitTooltips;
      }
      set
      {
        if (nonfitTooltips != value)
        {
          nonfitTooltips = value;
          UnfitTooltipsChanged();
        }
      }
    }

    [Browsable(false)]
    [DefaultValue(true)]
    public bool CacheDisplayValues
    {
      get
      {
        return cacheDisplayValues;
      }
      set
      {
        if (cacheDisplayValues != value)
        {
          cacheDisplayValues = value;
          CacheDisplayValuesChanged();
        }
      }
    }
    #endregion properties

    #region methods

    //Font
    protected virtual Font DefaultFont()
    {
      return Grid.Font;
    }

    protected virtual bool ShouldSerializeFont()
    {
      return font != null;
    }

    public virtual void ResetFont()
    {
      font = null;
      FontChanged();
    }

    protected virtual void FontChanged()
    {
      Grid.UpdateRowHeights();
    }

    //IGridLineHost
    void IGridLineHost.GridLineChanged(GridLine gl)
    {
      GridLineChanged(gl);
    }

    protected virtual void GridLineChanged(GridLine gl)
    {
      Grid.Invalidate();
    }

    public virtual bool GridLineDefaultVisible(GridLine gl)
    {
      return Grid.LineOptions.VertLines;
    }

    public virtual Color GridLineDefaultColor(GridLine gl)
    {
      return Grid.LineOptions.BrightColor;
    }

    public virtual DashStyle GridLineDefaultStyle(GridLine gl)
    {
      return DashStyle.Solid;
    }

    //Others

    private void CacheDisplayValuesChanged()
    {
      foreach (var col in Grid.Columns)
        col.CacheDisplayValuesChanged();
    }

    protected virtual void VertAlignChanged()
    {
      Grid.Invalidate();
    }

    private void WrapModeChanged()
    {
      Grid.UpdateRowHeights();
    }

    protected virtual void ForeColorChanged()
    {
      Grid.InvalidateGrid();
    }

    public virtual Color DefaultForeColor()
    {
      return Grid.ForeColor;
    }

    protected virtual bool ShouldSerializeForeColor()
    {
      return foreColorStored == true;
    }

    public virtual void ResetForeColor()
    {
      foreColorStored = false;
      ForeColorChanged();
    }

    protected virtual void SidePaddingChanged()
    {
      Grid.SidePaddingChanged();
    }

    private Padding DefaultSidePadding()
    {
      return Grid.DrawStyle.GetColumnOptionsSidePadding();
    }

    protected virtual bool ShouldSerializeSidePadding()
    {
      return sidePaddingStored == true;
    }

    public virtual void ResetSidePadding()
    {
      sidePaddingStored = false;
      SidePaddingChanged();
    }

    protected virtual void HeightTextLinesChanged()
    {
      Grid.UpdateRowHeights();
    }

    public virtual bool CanShowEditor()
    {
      if (AllowShowEditor && Grid.Options.HasFlag(GridOptions.Editing))
        return true;
      else
        return false;
    }

    internal void EditItemOptionsChanged()
    {
      Grid.Invalidate();
    }

    protected virtual void UnfitTooltipsChanged()
    {
      Grid.InvalidateGrid();
    }

    #endregion methods

  }

  /// <summary>
  /// Contains properties for customizing the display of grid rows.
  /// </summary>
  /// <remarks>
  /// You can retrieve an instance of this class through the <see cref="DataGridEh.RowOptions"/> property.
  /// </remarks>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridRowOptions : DataGridObject, IGridLineHost, IGridRowHeightOptionsOwner
  {
    #region privates
    private Color oddColor;
    private Color evenColor;
    private bool allowResize;

    private readonly GridLine horzLine;
    private readonly GridRowHeightOptions heightOptions;
    #endregion

    #region constructor
    public DataGridRowOptions(DataGridEh grid)
      : base(grid)
    {
      horzLine = new GridLine(this);
      heightOptions = new GridRowHeightOptions(this);
    }
    #endregion

    #region design-time properties
    public Color OddColor
    {
      get
      {
        return oddColor;
      }

      set
      {
        if (value != oddColor)
        {
          oddColor = value;
          Grid.Invalidate();
        }
      }
    }

    public Color EvenColor
    {
      get
      {
        return evenColor;
      }

      set
      {
        if (value != evenColor)
        {
          evenColor = value;
          Grid.Invalidate();
        }
      }
    }

    [DefaultValue(false)]
    public bool AllowResize
    {
      get
      {
        return allowResize;
      }

      set
      {
        if (allowResize != value)
        {
          allowResize = value;
          Grid.AllowRowResizeChanged();
        }
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridRowHeightOptions HeightOptions
    {
      get
      {
        return heightOptions;
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridLine HorzLine
    {
      get
      {
        return horzLine;
      }
    }
    #endregion

    #region methods
    // OddColor
    protected void OddColorChanged()
    {
      Grid.InvalidateGrid();
    }

    public Color DefaultOddColor()
    {
      return Color.Empty;
    }

    protected bool ShouldSerializeOddColor()
    {
      return oddColor != Color.Empty;
    }

    public void ResetOddColor()
    {
      oddColor = Color.Empty;
      OddColorChanged();
    }

    // EvenColor
    protected void EvenColorChanged()
    {
      Grid.InvalidateGrid();
    }

    public Color DefaultEvenColor()
    {
      return Color.Empty;
    }

    protected bool ShouldSerializeEvenColor()
    {
      return evenColor != Color.Empty;
    }

    public void ResetEvenColor()
    {
      evenColor = Color.Empty;
      EvenColorChanged();
    }

    //IGridLineHost
    void IGridLineHost.GridLineChanged(GridLine gl)
    {
      Grid.Invalidate();
    }

    bool IGridLineHost.GridLineDefaultVisible(GridLine gl)
    {
      return Grid.LineOptions.HorzLines;
    }

    Color IGridLineHost.GridLineDefaultColor(GridLine gl)
    {
      return Grid.LineOptions.BrightColor;
    }

    DashStyle IGridLineHost.GridLineDefaultStyle(GridLine gl)
    {
      return DashStyle.Solid;
    }

    //IGridRowHeightOptionsOwner
    void IGridRowHeightOptionsOwner.HeightOptionsChanged(GridRowHeightOptions heightOptions)
    {
      if (Grid != null)
        Grid.RowHeightAutoExpandChanged();
    }

    bool IGridRowHeightOptionsOwner.HeightOptionsDefaultAutoExpand(GridRowHeightOptions heightOptions)
    {
      return false;
    }

    int IGridRowHeightOptionsOwner.HeightOptionsDefaultContentHeight(GridRowHeightOptions heightOptions)
    {
      return 1;
    }

    int IGridRowHeightOptionsOwner.HeightOptionsDefaultMaxContentHeight(GridRowHeightOptions heightOptions)
    {
      return 0;
    }

    GridRowHeightUnit IGridRowHeightOptionsOwner.HeightOptionsDefaultUnit(GridRowHeightOptions heightOptions)
    {
      return GridRowHeightUnit.TextLine;
    }

    //Other
    public int MaxHeight()
    {
      int maxHeight;

      if (HeightOptions.Unit == GridRowHeightUnit.Pixel)
      {
        maxHeight = HeightOptions.MaxContentHeight;

      }
      else
      {
        maxHeight = EhLibUtils.GetFontHeight(Grid.ColumnOptions.Font) * HeightOptions.MaxContentHeight;
      }

      if (maxHeight > 0)
        maxHeight = maxHeight + Grid.ColumnOptions.SidePadding.Top + Grid.ColumnOptions.SidePadding.Bottom;

      return maxHeight;
    }
    #endregion
  }

  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridEditItemOptions
  {
    #region privates
    private readonly DataGridColumnOptions columnOptions;
    private DataGridCellItemPaintTime paintBackgroundTime = DataGridCellItemPaintTime.WhenAreaHotOrActive;
    private DataGridCellItemPaintTime paintTime = DataGridCellItemPaintTime.Always;
    private DataGridActiveArea activeArea = DataGridActiveArea.Row;
    #endregion

    public DataGridEditItemOptions(DataGridColumnOptions columnOptions)
    {
      this.columnOptions = columnOptions;
    }

    #region properties
    [DefaultValue(DataGridCellItemPaintTime.WhenAreaHotOrActive)]
    public DataGridCellItemPaintTime PaintBackgroundTime
    {
      get
      {
        return paintBackgroundTime;
      }

      set
      {
        if (paintBackgroundTime != value)
        {
          paintBackgroundTime = value;
          columnOptions.EditItemOptionsChanged();
        }
      }
    }

    [DefaultValue(DataGridCellItemPaintTime.Always)]
    public DataGridCellItemPaintTime PaintTime
    {
      get
      {
        return paintTime;
      }

      set
      {
        if (paintTime != value)
        {
          paintTime = value;
          columnOptions.EditItemOptionsChanged();
        }
      }
    }

    [DefaultValue(DataGridActiveArea.Row)]
    public DataGridActiveArea ActiveArea
    {
      get
      {
        return activeArea;
      }
      set
      {
        if (activeArea != value)
        {
          activeArea = value;
          columnOptions.EditItemOptionsChanged();
        }
      }
    }
    #endregion
  }

  /// <summary>
  /// Contains properties for customizing clipboard operations.
  /// </summary>
  /// <remarks>
  /// You can retrieve an instance of this class through the <see cref="DataGridEh.EditActions"/> property.
  /// </remarks>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridEditActions : DataGridObject
  {

    #region privates
    private bool copyEnabled = true;
    private bool pasteEnabled = true;
    private bool cutEnabled = true;
    private bool deleteEnabled = true;
    private bool confirmDelete = true;
    private bool selectAllEnabled = true;
    #endregion privates

    public DataGridEditActions(DataGridEh grid) : base(grid)
    {
    }

    #region design-time properties    
    /// <summary>
    /// Gets or sets a value indicating whether the edit opertaion "copy to clipboard" is enabled.
    /// </summary>
    [DefaultValue(true)]
    public bool CopyEnabled
    {
      get
      {
        return copyEnabled;
      }
      set
      {
        copyEnabled = value;
      }
    }

    /// <summary>
    /// Gets or sets a value indicating whether the edit opertaion "paster from clipboard" is enabled.
    /// </summary>
    [DefaultValue(true)]
    public bool PasteEnabled
    {
      get
      {
        return pasteEnabled;
      }
      set
      {
        pasteEnabled = value;
      }
    }

    /// <summary>
    /// Gets or sets a value indicating whether the edit opertaion "cut to clipboard" is enabled.
    /// </summary>
    [DefaultValue(true)]
    public bool CutEnabled
    {
      get
      {
        return cutEnabled;
      }
      set
      {
        cutEnabled = value;
      }
    }

    /// <summary>
    /// Gets or sets a value indicating whether the edit opertaion "delete record or selected area" is enabled.
    /// </summary>
    [DefaultValue(true)]
    public bool DeleteEnabled
    {
      get
      {
        return deleteEnabled;
      }
      set
      {
        deleteEnabled = value;
      }
    }

    /// <summary>
    /// Gets or sets a value indicating whether the grid shows confirmation dialog before delete the data.
    /// </summary>
    [DefaultValue(true)]
    public bool ConfirmDelete
    {
      get
      {
        return confirmDelete;
      }
      set
      {
        confirmDelete = value;
      }
    }

    /// <summary>
    /// Gets or sets a value indicating whether the edit opertaion "select all" is enabled.
    /// </summary>
    [DefaultValue(true)]
    public bool SelectAllEnabled
    {
      get
      {
        return selectAllEnabled;
      }
      set
      {
        selectAllEnabled = value;
      }
    }
    #endregion  design-time properties

    #region run-time properties
    #endregion  run-time properties

    #region internal methods
    #endregion internal methods

    #region public methods    
    /// <summary>
    /// Copies the selected cells or value of the current cell into the Clipboard.
    /// </summary>
    public void Copy()
    {
      Grid.CopyContentToClipboard(DataGridExportArea.SelectedArea);
    }

    /// <summary>
    /// Determines whether the user perofrm "Copy" operation in the Grid.
    /// </summary>
    public bool CanCopy()
    {
      return CopyEnabled;
    }

    /// <summary>
    /// Pastes the content of the clipboard into the grid.
    /// </summary>
    public void Paste()
    {
      Grid.PastContentFromClipboard();
    }

    public bool CanPaste()
    {
      return PasteEnabled && Clipboard.ContainsText() && Grid.AllowedOperations.AllowEdit;
    }

    /// <summary>
    /// Cuts the selected cells or value of the current cell into the Clipboard.
    /// </summary>
    public void Cut()
    {
      if ((Grid.Selection.SelectionType != GridSelectionType.None) && (ConfirmDelete == true))
      {
        if (!ShowConfirmDeleteDialog()) return;
      }

      DataObject dataObject = Grid.GetContentAsDataObject(DataGridExportArea.SelectedArea);
      if (dataObject != null)
      {
        Grid.Selection.DeleteSelectedArea();
        Clipboard.SetDataObject(dataObject, true);
      }
    }

    public bool CanCut()
    {
      if (Grid.Selection.SelectionType == GridSelectionType.Rows)
        return CutEnabled && Grid.AllowedOperations.AllowRemove;
      else
        return CutEnabled && Grid.AllowedOperations.AllowEdit;
    }

    /// <summary>
    /// Shows the confirm delete dialog.
    /// </summary>
    /// <returns>true if user press "Yes" in dialog</returns>
    public bool ShowConfirmDeleteDialog()
    {
      string text = "";

      switch (Grid.Selection.SelectionType)
      {
        case GridSelectionType.All:
          {
            text = Properties.Resources.DeleteAllRecordsQuestion;
            break;
          }

        case GridSelectionType.CellsBox:
          {
            text = Properties.Resources.ClearSelectedCellsQuestion;
            break;
          }

        case GridSelectionType.Columns:
          {
            text = Properties.Resources.ClearSelectedCellsQuestion;
            break;
          }

        case GridSelectionType.Rows:
          {
            text = Properties.Resources.DeleteAllSelectedRowsQuestion;
            break;
          }
        case GridSelectionType.None:
          {
            text = Properties.Resources.DeleteRowQuestion;
            break;
          }
      }

      DialogResult result = MessageBox.Show(text, Properties.Resources.DeleteData, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);

      if (result == DialogResult.Yes)
        return true;
      else
        return false;
    }

    /// <summary>
    /// Deletes the selected cells of current record.
    /// </summary>
    public void Delete()
    {
      Grid.Selection.DeleteSelectedArea();
    }

    public bool CanDelete()
    {
      if (Grid.Selection.SelectionType == GridSelectionType.Rows)
        return DeleteEnabled && Grid.AllowedOperations.AllowRemove;
      else
        return DeleteEnabled && Grid.AllowedOperations.AllowEdit;
    }

    /// <summary>
    /// Selects the whole grid.
    /// </summary>
    public void SelectAll()
    {
      Grid.Selection.SelectAll();
    }

    public bool CanSelectAll()
    {
      return SelectAllEnabled;
    }

    public void MoveCurrentTo(int newCol, int newRow)
    {
      GridCoord newCurrent;
      newCurrent = new GridCoord(newCol, newRow);
      Grid.Restrict(ref newCurrent,
        Grid.FixedColCount - Grid.FrozenColCount, Grid.FixedRowCount - Grid.FrozenRowCount,
        Grid.ColCount - 1, Grid.RowCount - 1);
      if ((newCurrent.X != Grid.Col) || (newCurrent.Y != Grid.Row))
        Grid.InteractiveFocusCell(newCurrent.X, newCurrent.Y, InteractiveActionSource.Keyboard);
    }

    public void MoveCurrentToNextRow()
    {
      MoveCurrentTo(Grid.Col, Grid.Row + 1);
    }

    public bool CanMoveCurrentToNextRow()
    {
      if (Grid.Row < Grid.RowCount - 1)
        return true;
      else
        return false;
    }

    public void MoveCurrentToPriorRow()
    {
      MoveCurrentTo(Grid.Col, Grid.Row - 1);
    }

    public bool CanMoveCurrentToPriorRow()
    {
      if (Grid.Row > Grid.FixedRowCount)
        return true;
      else
        return false;
    }

    public void MoveCurrentToFirstRow()
    {
      MoveCurrentTo(Grid.Col, Grid.FixedRowCount);
    }

    public bool CanMoveCurrentToFirstRow()
    {
      if (Grid.Row != Grid.FixedRowCount)
        return true;
      else
        return false;
    }

    public void MoveCurrentToLastRow()
    {
      MoveCurrentTo(Grid.Col, Grid.FixedRowCount + Grid.VisibleRows.Count - 1);
    }

    public bool CanMoveCurrentToLastRow()
    {
      if (Grid.Row < Grid.FixedRowCount + Grid.VisibleRows.Count - 1)
        return true;
      else
        return false;
    }

    public void MoveCurrentToNewRow()
    {
      if (Grid.VisibleRows.Count == 0)
        Grid.DataLink.AddNew();
      else
        MoveCurrentTo(Grid.Col, Grid.NewRowIndex);
      //Grid.InteractiveFocusCell(Grid.Col, Grid.NewRowIndex, InteractiveActionSource.Other);
    }

    public bool CanMoveCurrentToNewRow()
    {
      if (Grid.AllowedOperations.AllowAdd &&
          Grid.VisibleRows.Count == 0 &&
          Grid.DataLink.Active)
        return true;
      else if ((Grid.Row == Grid.NewRowIndex) ||
          (Grid.AllowedOperations.AllowAdd == false))
        return false;
      else
        return true;
    }

    public void DeleteCurrentRow()
    {
      Grid.DataLink.DeleteCurrent();
    }

    public bool CanDeleteCurrentRow()
    {
      if ((Grid.VisibleRows.Count > 0) &&
          (Grid.AllowedOperations.AllowRemove == true)
      )
        return true;
      else
        return false;
    }

    #endregion public methods

  }

  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridHorzScrollBarExtraBarVisibleItems
  {
    private readonly DataGridHorzScrollBarExtraBar extraBar;
    private bool recordsInfo = true;
    private bool navigator = true;
    private bool selectAggregationInfo = true;

    public DataGridHorzScrollBarExtraBarVisibleItems(DataGridHorzScrollBarExtraBar extraBar)
    {
      this.extraBar = extraBar;
    }

    [DefaultValue(true)]
    public bool RecordsInfo
    {
      get
      {
        return recordsInfo;
      }
      set
      {
        if (recordsInfo != value)
        {
          recordsInfo = value;
          extraBar.VisibleItemsChanged();
        }
      }
    }

    [DefaultValue(true)]
    public bool Navigator
    {
      get
      {
        return navigator;
      }
      set
      {
        if (navigator != value)
        {
          navigator = value;
          extraBar.VisibleItemsChanged();
        }
      }
    }

    [DefaultValue(true)]
    public bool SelectAggregationInfo
    {
      get
      {
        return selectAggregationInfo;
      }
      set
      {
        if (selectAggregationInfo != value)
        {
          selectAggregationInfo = value;
          extraBar.VisibleItemsChanged();
        }
      }
    }

  }

  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridHorzScrollBarExtraBar
  {
    private readonly DataGridHorzScrollBar scrollBar;
    private readonly DataGridHorzScrollBarExtraBarVisibleItems visibleItems;
    private bool visible;

    public DataGridHorzScrollBarExtraBar(DataGridHorzScrollBar scrollBar)
    {
      this.scrollBar = scrollBar;
      visibleItems = new DataGridHorzScrollBarExtraBarVisibleItems(this);
    }

    #region design-time properties
    [DefaultValue(false)]
    public bool Visible
    {
      get
      {
        return visible;
      }
      set
      {
        if (visible != value)
        {
          visible = value;
          VisibleItemsChanged();
        }
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridHorzScrollBarExtraBarVisibleItems VisibleItems
    {
      get { return visibleItems; }
    }
    #endregion design-time properties

    [Browsable(false)]
    public DataGridHorzScrollBar ScrollBar
    {
      get { return scrollBar; }
    }

    internal void VisibleItemsChanged()
    {
      scrollBar.Grid.UpdateBoundaries();
    }
  }

  /// <summary>
  /// Contains properties for customizing horizontal scroll bar.
  /// </summary>
  [ToolboxItem(false)]
  [DesignTimeVisible(false)]
  public class DataGridHorzScrollBar : BaseGridHorzScrollBar
  {
    private readonly DataGridHorzScrollBarExtraBar extraBar;

    public DataGridHorzScrollBar(BaseGridControl grid, Orientation kind) :
      base(grid, kind)
    {
      extraBar = new DataGridHorzScrollBarExtraBar(this);
    }

    #region Properties
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataGridHorzScrollBarExtraBar ExtraBar
    {
      get { return extraBar; }
    }
    #endregion

    #region Methods
    public override bool CheckScrollBarMustBeShown()
    {
      if (ExtraBar.Visible)
        return true;
      else
        return base.CheckScrollBarMustBeShown();
    }
    #endregion

    #region events
    public new event EventHandler<EventArgs> ScrollPosChanged
    {
      add
      {
        base.ScrollPosChanged += value;
      }

      remove
      {
        base.ScrollPosChanged -= value;
      }
    }

    public new event EventHandler<EventArgs> RollParamsChanged
    {
      add
      {
        base.RollParamsChanged += value;
      }

      remove
      {
        base.RollParamsChanged -= value;
      }
    }
    #endregion

  }

  /// <summary>
  /// Contains properties for customizing vertical scroll bar.
  /// </summary>
  [ToolboxItem(false)]
  [DesignTimeVisible(false)]
  public class DataGridVertScrollBar : BaseGridVertScrollBar
  {

    public DataGridVertScrollBar(BaseGridControl grid, Orientation kind) :
      base(grid, kind)
    {
    }

    #region events
    public new event EventHandler<EventArgs> ScrollPosChanged
    {
      add
      {
        base.ScrollPosChanged += value;
      }

      remove
      {
        base.ScrollPosChanged -= value;
      }
    }

    public new event EventHandler<EventArgs> RollParamsChanged
    {
      add
      {
        base.RollParamsChanged += value;
      }

      remove
      {
        base.RollParamsChanged -= value;
      }
    }
    #endregion
  }

  /// <summary>
  /// Contains properties for allowing / disallowing editing operations in the grid, such as adding, changing or deleting records.
  /// </summary>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridAllowedOperations : DataGridObject
  {

    #region privates
    private bool addRecord = true;
    private bool changeRecord = true;
    private bool deleteRecord = true;
    #endregion privates

    public DataGridAllowedOperations(DataGridEh grid) : base(grid)
    {
    }

    #region design-time properties
    [DefaultValue(true)]
    public bool AddRecord
    {
      get
      {
        return addRecord;
      }
      set
      {
        if (addRecord != value)
        {
          addRecord = value;
          AllowedOperationsChanged();
        }
      }
    }

    [DefaultValue(true)]
    public bool ChangeRecord
    {
      get
      {
        return changeRecord;
      }
      set
      {
        if (changeRecord != value)
        {
          changeRecord = value;
          AllowedOperationsChanged();
        }
      }
    }

    [DefaultValue(true)]
    public bool DeleteRecord
    {
      get
      {
        return deleteRecord;
      }
      set
      {
        if (deleteRecord != value)
        {
          deleteRecord = value;
          AllowedOperationsChanged();
        }
      }
    }
    #endregion  design-time properties

    #region run-time properties
    [Browsable(false)]
    public bool AllowAdd
    {
      get { return AddRecord && Grid.DataLink.AllowAdd && !Grid.ReadOnly; }
    }

    [Browsable(false)]
    public bool AllowEdit
    {
      get { return ChangeRecord && Grid.DataLink.AllowEdit && !Grid.ReadOnly; }
    }

    [Browsable(false)]
    public bool AllowRemove
    {
      get { return DeleteRecord && Grid.DataLink.AllowRemove && !Grid.ReadOnly; }
    }
    #endregion  run-time properties

    #region internal methods
    private void AllowedOperationsChanged()
    {
      Grid.OnAllowedOperationsChanged(EventArgs.Empty);
    }
    #endregion internal methods

    #region public methods
    #endregion public methods

  }

  /// <summary>
  /// Contains properties for customizing respond on pressing some keys.
  /// </summary>
  /// <remarks>
  /// You can retrieve an instance of this class through the <see cref="DataGridEh.KeyboardOptions"/> property.
  /// </remarks>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridKeyboardOptions : GridKeyboardOptions
  {

    public DataGridKeyboardOptions(/*DataAxisGrid grid*/) : base(/*grid*/)
    {
      base.TabKeyAction = GridKeyboardAction.NextColCell;
    }

    [DefaultValue(GridKeyboardAction.NextColCell)]
    public override GridKeyboardAction TabKeyAction
    {
      get { return base.TabKeyAction; }
      set { base.TabKeyAction = value; }
    }
  }

  /// <summary>
  /// Collection of extra data cell managers that can be used in DataCellManagerNeeded event handler.
  /// </summary>
  [ListBindable(false)]
  public class DataGridServiceCellManagerList : Collection<BaseGridCellManager>
  {
    private readonly DataGridEh grid;

    public DataGridServiceCellManagerList(DataGridEh grid)
    {
      this.grid = grid;
    }

    public new void Add(BaseGridCellManager item)
    {
      base.Add(item);
      item.BoundGrid = grid;
    }
  }

  public class DataGridStorableElements
  {
    public DataGridStorableElements()
    {
      ColumnElements = new DataGridColumnStorableElements();
    }

    public DataGridColumnStorableElements ColumnElements { get; internal set; }
  }

  public class DataGridColumnStorableElements
  {
    public DataGridColumnStorableElements()
    {
      Width = true;
      DisplayOrder = true;
      Visibility = true;
      //TitleSortMarker = true;
    }

    public bool Width { get; set; }
    public bool DisplayOrder { get; set; }
    public bool Visibility { get; set; }
    public bool TitleSortMarker { get; set; }
    public bool TitleFilter { get; set; }
  }

}
