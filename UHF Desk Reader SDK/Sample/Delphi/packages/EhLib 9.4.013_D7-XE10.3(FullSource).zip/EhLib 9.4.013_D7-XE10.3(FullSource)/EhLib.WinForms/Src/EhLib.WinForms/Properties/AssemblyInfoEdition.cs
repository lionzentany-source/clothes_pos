﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyConfiguration("Source Code Included")]
[assembly: AssemblyProduct("EhLib Controls Library. Source Code Included")]
