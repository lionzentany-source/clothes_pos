﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace EhLib.WinForms.Design
{
  public partial class FormSelectDataSource : Form
  {

    private TypeConverter.StandardValuesCollection dataSourceList;

    public FormSelectDataSource()
    {
      InitializeComponent();
    }

    public static object ShowSelectDataSourceDialog(Component component)
    {
      var form = new FormSelectDataSource();
      form.Component = component;
      DialogResult result = form.ShowDialog();
      if (result == DialogResult.OK)
        return form.SelectedDataSource;
      else
        return null;
    }

    public object SelectedDataSource
    {
      get
      {
        return dataSourceList[bindingSource1.Position];
      }
    }

    Component Component { get; set; }

    //IServiceProvider ServiceProvider { get; set; }

    //protected object GetDesignService(Type serviceType)
    //{
    //  return ServiceProvider.GetService(serviceType);
    //}

    public object GetInstance(string strFullyQualifiedName)
    {
      Type type = Type.GetType(strFullyQualifiedName);
      if (type != null)
        return Activator.CreateInstance(type);
      foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
      {
        type = asm.GetType(strFullyQualifiedName);
        if (type != null)
          return Activator.CreateInstance(type);
      }
      return null;
    }

    private void FormSelectDataSource_Shown(object sender, EventArgs e)
    {
      DialogWindowsFormsEditorService internalSrv = new DialogWindowsFormsEditorService(Component, null);
      //var tdc = (ITypeDescriptorContext)GetDesignService(typeof(ITypeDescriptorContext));
      ReferenceConverter dsConverter = (ReferenceConverter)GetInstance("System.Windows.Forms.Design.DataSourceConverter");
      dataSourceList = dsConverter.GetStandardValues(internalSrv);

      List<string> textList = new List<string>();

      foreach (var obj in dataSourceList)
      {
        string propertyTextValue = GetPropertyTextValue(obj, internalSrv, dsConverter);
        textList.Add(propertyTextValue);
      }

      bindingSource1.DataSource = textList;
    }

    public virtual string GetPropertyTextValue(object value, ITypeDescriptorContext typeDescContext, TypeConverter typeConverter)
    {
      string str = (string)null;
      try
      {
        str = typeConverter.ConvertToString(typeDescContext, value);
      }
      catch (Exception)
      {
      }
      if (str == null)
        str = string.Empty;
      return str;
    }
  }
}
