﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel.Design;
using System.Collections.ObjectModel;
using System.ComponentModel.Design.Serialization;
using System.Drawing.Design;

namespace EhLib.WinForms.Design
{
  internal partial class SimpleRichEditDialog : Form
  {

    public SimpleRichEditDialog()
    {
      InitializeComponent();
    }

    public static bool EditRichText(RichTextBox richTextBox)
    {
      SimpleRichEditDialog f = new SimpleRichEditDialog();
      f.richTextBox1.Rtf = richTextBox.Rtf;

      if (f.ShowDialog() == DialogResult.OK)
      {
        richTextBox.Rtf = f.richTextBox1.Rtf;
        return true;
      }
      else
      {
        return false;
      }
    }

    public static bool EditRichText(ref string rtf, HorizontalAlignment align)
    {
      SimpleRichEditDialog f = new SimpleRichEditDialog();
      f.richTextBox1.Rtf = rtf;

      f.richTextBox1.SelectAll();
      f.richTextBox1.SelectionAlignment = align;
      f.richTextBox1.DeselectAll();

      if (f.ShowDialog() == DialogResult.OK)
      {
        rtf = f.richTextBox1.Rtf;
        return true;
      }
      else
      {
        return false;
      }
    }

    private void button1_Click(object sender, EventArgs e)
    {
      if (ActiveControl is RichTextBox)
      {
        RichTextBox re = ActiveControl as RichTextBox;

        fontDialog1.Font = re.SelectionFont;
        fontDialog1.Color = re.SelectionColor;

        if (fontDialog1.ShowDialog() != DialogResult.Cancel)
        {
          re.SelectionFont = fontDialog1.Font;
          re.SelectionColor = fontDialog1.Color;
        }
      }
    }
  }


  public class SimpleRichEditor : UITypeEditor
  {

    public override UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context)
    {
      return UITypeEditorEditStyle.Modal;
    }

    public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value)
    {
      HorizontalAlignment align = HorizontalAlignment.Left;

      string result = (string)value;
      if (context.PropertyDescriptor.Name == "CenterText")
        align = HorizontalAlignment.Center;

      if (SimpleRichEditDialog.EditRichText(ref result, align))
        return result;
      else
        return value;
    }
  }

}
