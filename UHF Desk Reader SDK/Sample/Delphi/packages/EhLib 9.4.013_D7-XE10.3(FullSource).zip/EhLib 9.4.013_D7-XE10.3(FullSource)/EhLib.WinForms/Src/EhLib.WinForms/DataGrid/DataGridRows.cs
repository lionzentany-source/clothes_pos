﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2019 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;

namespace EhLib.WinForms
{

  /// <summary>
  /// Represents a row in a <see cref="DataGridEh"/> control.
  /// </summary>
  public class DataGridRow : DataAxisGridListItemBar
  {
    #region Privates
    private int index = -1;
    private int visibleIndex = -1;
    private DataGridRows rows;
    private bool visible = true;
    //private object srcRow;

    internal int HeightInternal;
    internal bool SelectedInternal;
    #endregion Privates

    public DataGridRow()
    {
    }

    #region Properties
    //internal List<DataGridBaseCell> Cells { get; set; }

    public DataGridEh Grid { get { return rows.Grid; } }

    public DataGridRows Rows
    {
      get
      {
        return rows;
      }

      internal set
      {
        rows = value;
      }
    }

    [DefaultValue(false)]
    [Browsable(false)]
    public bool Selected
    {
      get
      {
        return SelectedInternal;
      }

      set
      {
        if (value != SelectedInternal)
        {
          if (Grid == null)
            SelectedInternal = value;
          else
            Grid.Selection.AddSelectedRow(this, value);
        }
      }
    }

    [Browsable(false)]
    public int Index
    {
      get
      {
        Rows.EnsureIndexesActual();
        return index;
      }

      internal set
      {
        index = value;
      }
    }

    [Browsable(false)]
    public int VisibleIndex
    {
      get
      {
        Rows.Grid.VisibleRows.EnsureIndexesActual();
        return visibleIndex;
      }

      internal set
      {
        visibleIndex = value;
      }
    }

    [Browsable(false)]
    public bool Visible
    {
      get
      {
        return visible;
      }

      internal set
      {
        if (visible != value)
        {
          visible = value;
          Grid.VisibleRows.IndexesIsDirty = true;
        }
      }
    }

    [Browsable(false)]
    public int Height
    {
      get
      {
        return HeightInternal;
      }

      set
      {
        if (value != Height)
          Grid.RowHeights[Grid.FixedRowCount + VisibleIndex] = value;
      }
    }

    //[Browsable(false)]
    //public object SourceItem
    //{
    //  get { return srcRow; }
    //  internal set { srcRow = value; }
    //}

    [Browsable(false)]
    public RowEditState EditState
    {
      get
      {
        if (Grid.CurrentRow == this)
          return Grid.DataLink.CurrentListItemState;
        else
          return RowEditState.Browse;
      }
    }

    #endregion Properties

    #region Methods
    internal void UpdateRowHeight()
    {
      HeightInternal = Grid.CalcRowHeight(this);
    }
    #endregion Methods
  }

  /// <summary>
  /// Collection of rows in the DataGridEh.
  /// The class is used to declare 
  /// <see cref="DataGridEh.Rows"/>
  /// property
  /// </summary>
  public class DataGridRows : DataGridObject, IList<DataGridRow>
  {
    #region >privates
    private bool indexesIsDirty;
    private readonly List<DataGridRow> list;
    #endregion <privates

    public DataGridRows(DataGridEh grid) : base(grid)
    {
      list = new List<DataGridRow>();
    }

    #region >properties
    public int Count
    {
      get
      {
        //CheckMakeIndexesActual();
        return list.Count;
      }
    }

    public DataGridRow this[int index]
    {
      get
      {
        //CheckMakeIndexesActual();
        return list[index];
      }
      set
      {
        list[index] = value;
      }
    }

    public bool IsReadOnly
    {
      get { return false; }
    }

    #endregion <properties

    #region >methods
    public void Insert(int index, DataGridRow item)
    {
      item.Rows = this;
      list.Insert(index, item);
      indexesIsDirty = true;
      //Grid.SortedRows.IndexesIsDirty = true;
    }

    void ICollection<DataGridRow>.Add(DataGridRow item)
    {
      list.Add(item);
      indexesIsDirty = true;
      Grid.VisibleRows.IndexesIsDirty = true;
    }

    public bool Remove(DataGridRow item)
    {
      if (list.Remove(item))
      {
        indexesIsDirty = true;
        //Grid.SortedRows.IndexesIsDirty = true;
        return true;
      }
      else
        return false;
    }

    public int RemoveAll(Predicate<DataGridRow> match)
    {
      indexesIsDirty = true;
      //Grid.SortedRows.IndexesIsDirty = true;
      return list.RemoveAll(match);
    }

    public void RemoveAt(int index)
    {
      indexesIsDirty = true;
      //Grid.SortedRows.IndexesIsDirty = true;
      list.RemoveAt(index);
    }

    public void RemoveRange(int index, int count)
    {
      indexesIsDirty = true;
      //Grid.SortedRows.IndexesIsDirty = true;
      list.RemoveRange(index, count);
    }

    public void Reverse()
    {
      indexesIsDirty = true;
      //Grid.SortedRows.IndexesIsDirty = true;
      list.Reverse();
    }

    public void Reverse(int index, int count)
    {
      indexesIsDirty = true;
      //Grid.SortedRows.IndexesIsDirty = true;
      list.Reverse(index, count);
    }

    public void Clear()
    {
      indexesIsDirty = true;
      //Grid.SortedRows.IndexesIsDirty = true;
      list.Clear();
    }

    public IEnumerator<DataGridRow> GetEnumerator()
    {
      return list.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
      return list.GetEnumerator();
    }

    public int IndexOf(DataGridRow item)
    {
      return list.IndexOf(item);
    }

    public int IndexOfSourceItem(object sourceItem)
    {
      foreach (DataGridRow row in this)
      {
        if (row.SourceItem == sourceItem)
          return row.Index;
      }
      return -1;
    }

    public bool Contains(DataGridRow item)
    {
      return list.Contains(item);
    }

    public void CopyTo(DataGridRow[] array, int arrayIndex)
    {
      list.CopyTo(array, arrayIndex);
    }

    public void EnsureIndexesActual()
    {
      if (indexesIsDirty)
        MakeIndexesActual();
    }

    protected internal virtual void MakeIndexesActual()
    {
      for (int i = 0; i < list.Count; i++)
      {
        list[i].Index = i;
      }
      indexesIsDirty = false;
    }
    #endregion <methods
  }

  public class DataGridBaseRowsList : IList<DataGridRow>
  {
    #region >privates
    internal virtual bool IndexesIsDirty { get; set; }
    internal readonly List<DataGridRow> InternalItems = new List<DataGridRow>();
    #endregion <privates

    public DataGridBaseRowsList(DataGridEh grid)
    {
      Grid = grid;
    }

    #region >properties

    public DataGridEh Grid
    {
      get;
      internal set;
    }

    public int Count
    {
      get
      {
        EnsureIndexesActual();
        return InternalItems.Count;
      }
    }

    public bool IsReadOnly
    {
      get
      {
        return true;
      }
    }

    public DataGridRow this[int index]
    {
      get
      {
        EnsureIndexesActual();
        return InternalItems[index];
      }
      set
      {
        InternalItems[index] = value;
      }
    }
    #endregion <properties

    #region >methods
    internal void EnsureIndexesActual()
    {
      if (IndexesIsDirty)
        MakeIndexesActual();
    }

    protected internal virtual void MakeIndexesActual()
    {
      throw new NotImplementedException();
    }

    public int IndexOf(DataGridRow item)
    {
      return InternalItems.IndexOf(item);
    }

    public int IndexOfSourceItem(object sourceItem)
    {
      for (int i = 0; i < Count; i++)
      {
        if (this[i].SourceItem == sourceItem)
          return i;
      }
      return -1;
    }

    public bool Contains(DataGridRow item)
    {
      return InternalItems.Contains(item);
    }

    public void CopyTo(DataGridRow[] array, int arrayIndex)
    {
      InternalItems.CopyTo(array, arrayIndex);
    }

    // Internals
    internal void ClearInternal()
    {
      InternalItems.Clear();
    }

    internal void AddInternal(DataGridRow item)
    {
      InternalItems.Add(item);
    }

    // IEnumerator
    public IEnumerator GetEnumerator()
    {
      EnsureIndexesActual();
      return InternalItems.GetEnumerator();
    }

    IEnumerator<DataGridRow> IEnumerable<DataGridRow>.GetEnumerator()
    {
      EnsureIndexesActual();
      return InternalItems.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
      EnsureIndexesActual();
      return GetEnumerator();
    }

    // IList
    void IList<DataGridRow>.Insert(int index, DataGridRow item)
    {
      throw new InvalidOperationException("Collection is ReadOnly");
    }

    void IList<DataGridRow>.RemoveAt(int index)
    {
      throw new InvalidOperationException("Collection is ReadOnly");
    }

    void ICollection<DataGridRow>.Add(DataGridRow item)
    {
      throw new InvalidOperationException("Collection is ReadOnly");
    }

    void ICollection<DataGridRow>.Clear()
    {
      throw new InvalidOperationException("Collection is ReadOnly");
    }

    bool ICollection<DataGridRow>.Remove(DataGridRow item)
    {
      throw new InvalidOperationException("Collection is ReadOnly");
    }
    #endregion <methods
  }

  /// <summary>
  /// Collection of visible rows in the DataGridEh.
  /// The class is used to declare 
  /// <see cref="DataGridEh.VisibleRows"/>
  /// property
  /// </summary>
  public class DataGridVisibleRows : DataGridBaseRowsList
  {
    public DataGridVisibleRows(DataGridEh grid) : base(grid)
    {
    }
    #region >methods
    protected internal override void MakeIndexesActual()
    {
      int vi = 0;

      ClearInternal();

      foreach (DataGridRow row in Grid.SortedRows)
      {
        if (row.Visible)
        {
          row.VisibleIndex = vi;
          AddInternal(row);
          vi = vi + 1;
        }
        else
        {
          row.VisibleIndex = -1;
        }
      }
      IndexesIsDirty = false;

      FireChangeEvent(new ListChangedEventArgs(ListChangedType.Reset, -1));

    }

    private void FireChangeEvent(ListChangedEventArgs e)
    {
      Grid.OnVisibleRowListChanged(EventArgs.Empty);
      Grid.DataView.FireEvent(e);
      foreach(var col in Grid.Columns)
        col.OnVisibleRowListChanged(EventArgs.Empty);
    }
    #endregion <methods
  }

  /// <summary>
  /// Collection of sorted rows in the DataGridEh.
  /// The class is used to declare 
  /// <see cref="DataGridEh.SortedRows"/>
  /// property
  /// </summary>
  public class DataGridSortedRows : DataGridBaseRowsList
  {
    private readonly List<DataGridSortItem> sortItems;

    public DataGridSortedRows(DataGridEh grid) : base(grid)
    {
      sortItems = new List<DataGridSortItem>();
    }

    internal override bool IndexesIsDirty
    {
      get
      {
        return base.IndexesIsDirty;
      }
      set
      {
        base.IndexesIsDirty = value;
        if (value == true)
        {
          Grid.VisibleRows.IndexesIsDirty = value;
        }
      }
    }

    public bool SortingActive
    { 
      get { return sortItems.Count > 0; }
    }

    #region >methods

    protected internal void RebuildList()
    {
      IndexesIsDirty = true;
      EnsureIndexesActual();
    }

    protected internal override void MakeIndexesActual()
    {
      FillInitList();

      ResortList();
      //FireChangeEvent(new ListChangedEventArgs(ListChangedType.Reset, -1));

      IndexesIsDirty = false;
    }

    private void FillInitList()
    {
      int vi = 0;

      ClearInternal();

      foreach (DataGridRow row in Grid.Rows)
      {
        AddInternal(row);
        vi = vi + 1;
      }
    }

    internal void ApplySorting(IEnumerable<DataGridSortItem> sortList)
    {
      sortItems.Clear();
      sortItems.AddRange(sortList);

      if (sortItems != null && sortItems.Count > 0)
        ResortList();
      else
        FillInitList();
      Grid.SortedRowListChanged();
    }

    private void ResortList()
    {
      if (Grid.DataLink.CurrentListItemState == RowEditState.Browse)
      {
        if (sortItems != null && sortItems.Count > 0)
        {
          InternalItems.Sort(SortComparison);
          Grid.VisibleRows.IndexesIsDirty = true;
        }
      }
    }

    public int SortComparison(DataGridRow x, DataGridRow y)
    {
      int result = 0;

      //if (x.EditState == RowEditState.New)
      //  return -1;
      //else if (y.EditState == RowEditState.New)
      //  return 1;

      foreach (DataGridSortItem si in sortItems)
      {
        object vx = si.Column.GetSortingRowValue(x);
        object vy = si.Column.GetSortingRowValue(y);

        result = EhLibUtils.DBCompareValues(vx, vy);
        if (si.SortDirection == ListSortDirection.Descending)
          result = result * -1;
        if (result != 0) return result;
      }

      if (result == 0)
        result = x.Index - y.Index;

      return result;
    }

    public void RowsEvent(int itemIndex, DataGridSourceListChangedType listChangedType, DataGridRow row)
    {
      if (SortingActive)
        ActiveRowsEvent(itemIndex, listChangedType, row);
      else
        InactiveRowsEvent(itemIndex, listChangedType, row);
    }

    private void ActiveRowsEvent(int itemIndex, DataGridSourceListChangedType listChangedType, DataGridRow row)
    {
      switch (listChangedType)
      {
        case DataGridSourceListChangedType.ListChanged:
          RebuildList();
          break;

        case DataGridSourceListChangedType.ItemAdded:
          InternalItems.Insert(itemIndex, row);
          Grid.VisibleRows.IndexesIsDirty = true;
          break;

        case DataGridSourceListChangedType.ItemChanged:
          ResortList();
          //sortItems.Insert(itemIndex, row);
          break;

        case DataGridSourceListChangedType.ItemDeleted:
          InternalItems.Remove(row);
          Grid.VisibleRows.IndexesIsDirty = true;
          break;
      }
    }

    private void InactiveRowsEvent(int itemIndex, DataGridSourceListChangedType listChangedType, DataGridRow row)
    {
      switch (listChangedType)
      {
        case DataGridSourceListChangedType.ListChanged:
          FillInitList();
          Grid.VisibleRows.IndexesIsDirty = true;
          break;

        case DataGridSourceListChangedType.ItemAdded:
          InternalItems.Insert(itemIndex, row);
          Grid.VisibleRows.IndexesIsDirty = true;
          break;

        case DataGridSourceListChangedType.ItemChanged:
          //sortItems.Insert(itemIndex, row);
          break;

        case DataGridSourceListChangedType.ItemDeleted:
          InternalItems.RemoveAt(itemIndex);
          Grid.VisibleRows.IndexesIsDirty = true;
          break;
      }
    }

    #endregion <methods
  }

  public enum DataGridSourceListChangedType
  {
    ListChanged,
    ItemAdded,
    ItemDeleted,
    ItemChanged,
  }

  public class RowListsManager : DataGridObject
  {

    public RowListsManager(DataGridEh grid) : base(grid)
    {
    }

    public DataGridRows Rows
    {
      get { return Grid.Rows; }
    }

    public DataGridSortedRows SortedRows
    {
      get { return Grid.SortedRows; }
    }

    public DataGridVisibleRows VisibleRows
    {
      get { return Grid.VisibleRows; }
    }

    public void DataLinkEvent(int itemIndex, DataGridSourceListChangedType listChangedType, RowEditState editState)
    {
      switch (listChangedType)
      {
        case DataGridSourceListChangedType.ListChanged:
          RebuildRows();
          if (Grid.CurrencyManager != null)
            Grid.UpdateCurrentDataRowPosition();
          break;

        case DataGridSourceListChangedType.ItemAdded:
          AddDataRow(itemIndex);
          Grid.CheckRecalcFooters();
          if (Grid.InternalCurrentRowIndex == -1)
            Grid.UpdateCurrentDataRowPosition();
          break;

        case DataGridSourceListChangedType.ItemChanged:
          UpdateDataRow(itemIndex);
          Grid.UpdateDataRow(itemIndex);
          Grid.CheckRecalcFooters();
          break;

        case DataGridSourceListChangedType.ItemDeleted:
          DeleteItem(itemIndex);
          break;
      }
    }

    public void InternalClear()
    {
      Rows.Clear();
      SortedRows.ClearInternal();
      VisibleRows.ClearInternal();
    }

    public void RebuildRows()
    {
      InternalRebuildRows();
      SortedRows.RebuildList();
      Grid.UpdateDataRows();
    }

    internal void InternalRebuildRows()
    {
      InternalClear();
      if (Grid.CurrencyManager != null)
      {
        for (int i = 0; i < Grid.CurrencyManager.Count; i++)
        {
          InternalAddDataRow(i);
        }
      }
    }

    public void AddDataRow(int index)
    {
      DataGridRow row = InternalAddDataRow(index);
      SortedRows.RowsEvent(index, DataGridSourceListChangedType.ItemAdded, row);
      row.UpdateRowHeight();
      Grid.UpdateBaseGridColumns();
      Grid.UpdateBaseRowCount();
    }

    private DataGridRow InternalAddDataRow(int index)
    {
      DataGridRow row = CreateGridRow(index);
      InitDataRow(row, index);
      Rows.Insert(index, row);
      return row;
    }

    protected virtual DataGridRow CreateGridRow(int index)
    {
      DataGridRow row;
      row = new DataGridRow();

      return row;
    }

    private void InitDataRow(DataGridRow row, int index)
    {
      object listItem = Grid.CurrencyManager.List[index];
      row.SourceItem = listItem;
    }

    private void DeleteItem(int index)
    {
      int visibleIndex;
      DataGridRow row;

      if (index >= 0 && index < Rows.Count)
      {
        row = Rows[index];
        visibleIndex = row.VisibleIndex;
        Rows.RemoveAt(index);
        SortedRows.RowsEvent(index, DataGridSourceListChangedType.ItemDeleted, row);
        Grid.GridDeleteRow(visibleIndex + Grid.FixedRowCount);
        Grid.UpdateBaseGridColumns();
        Grid.UpdateBaseRowCount();
      }
    }

    private void UpdateDataRow(int rowIndex)
    {
      DataGridRow row = Rows[rowIndex];
      SortedRows.RowsEvent(rowIndex, DataGridSourceListChangedType.ItemChanged, row);
      row.UpdateRowHeight();

      if (Grid.VisibleRows.IndexesIsDirty)
      {
        Grid.VisibleRows.EnsureIndexesActual();
        Grid.UpdateBaseRowHeights();
      }
    }
  }
}