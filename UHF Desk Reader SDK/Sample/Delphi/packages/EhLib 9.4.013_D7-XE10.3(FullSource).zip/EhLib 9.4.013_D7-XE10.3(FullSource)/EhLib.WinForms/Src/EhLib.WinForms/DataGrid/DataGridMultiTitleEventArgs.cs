﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2018 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  public class SuperTitlePaintEventArgs : HandledEventArgs
  {
    private GraphicsContext gc;
    DataGridSuperTitle superTitle;
    private Rectangle cellRect;
    private Rectangle cellClientRect;
    private Point inCellMousePos;

    private CellFillStyle fillStyle;
    private CellInnerBorderStyle innerBorder;
    private Color fillColor;
    private Color secondFillColor;
    private String text;
    private Font font;
    private Color foreColor;

    public SuperTitlePaintEventArgs(DataGridSuperTitle superTitle, GraphicsContext gc, Rectangle cellRect, Point inCellMousePos)
    {
      this.gc = gc;
      this.cellRect = cellRect;
      this.cellClientRect = cellRect;
      this.inCellMousePos = inCellMousePos;
      this.superTitle = superTitle;
      IsPaintBackground = true;
      IsPaintForeground = true;
    }

    public void Reset(DataGridSuperTitle superTitle, GraphicsContext gc, Rectangle cellRect, Point inCellMousePos)
    {
      this.gc = gc;
      this.cellRect = cellRect;
      this.cellClientRect = cellRect;
      this.inCellMousePos = inCellMousePos;
      this.superTitle = superTitle;
    }


    public GraphicsContext GraphicsContext
    {
      get { return this.gc; }
    }

    public Graphics Graphics
    {
      get { return this.gc.Graphics; }
    }

    public Rectangle CellRect
    {
      get { return this.cellRect; }
      set { cellRect = value; }
    }

    public Rectangle CellClientRect
    {
      get { return this.cellClientRect; }
      set { this.cellClientRect = value; }
    }

    public Point InCellMousePos
    {
      get { return this.inCellMousePos; }
    }

    public DataGridSuperTitle SuperTitle
    {
      get { return this.superTitle; }
    }

    public CellFillStyle FillStyle
    {
      get { return fillStyle; }
      set { fillStyle = value; }
    }

    public CellInnerBorderStyle InnerBorder
    {
      get { return innerBorder; }
      set { innerBorder = value; }
    }

    public Color FillColor
    {
      get { return fillColor; }
      set { fillColor = value; }
    }

    public Color SecondFillColor
    {
      get { return secondFillColor; }
      set { secondFillColor = value; }
    }

    public String Text
    {
      get { return text; }
      set { text = value; }
    }

    public Color ForeColor
    {
      get { return foreColor; }
      set { foreColor = value; }
    }

    public Font Font
    {
      get { return font; }
      set { font = value; }
    }

    public bool IsPaintBackground { get; set; }

    public bool IsPaintForeground { get; set; }

    public virtual void Paint(SuperTitlePaintEventArgs e)
    {
      SuperTitle.OnPaint(e);
    }

    public virtual void PaintBackground(SuperTitlePaintEventArgs e)
    {
      SuperTitle.OnPaintBackground(e);
    }

    public virtual void PaintForeground(SuperTitlePaintEventArgs e)
    {
      SuperTitle.OnPaintForeground(e);
    }
  }

  public class DataGridSuperTitleCellMouseEventArgs : HandledEventArgs
  {
    private readonly DataGridSuperTitle superTitle;
    private readonly BaseGridCellMouseEventArgs baseEventArgs;
    private readonly int inCellX;
    private readonly int inCellY;
    private readonly Rectangle cellRect;

    public DataGridSuperTitleCellMouseEventArgs(BaseGridCellMouseEventArgs baseArgs, 
      DataGridSuperTitle superTitle, int inCellX, int inCellY,
      Rectangle cellRect)
    {
      this.baseEventArgs = baseArgs;
      this.superTitle = superTitle;
      this.inCellX = inCellX;
      this.inCellY = inCellY;
      this.cellRect = cellRect;
    }

    public DataGridSuperTitle SuperTitle
    {
      get { return this.superTitle; }
    }

    public BaseGridCellMouseEventArgs BaseEventArgs
    {
      get { return baseEventArgs; }
    }

    public int InCellX
    {
      get { return inCellX; }
    }

    public int InCellY
    {
      get { return inCellY; }
    }

    public Rectangle CellRect
    {
      get { return cellRect; }
    }
  }

  public class DataGridSuperTitleCellEventArgs : HandledEventArgs
  {
    private readonly DataGridSuperTitle superTitle;
    private readonly BaseGridCellEventArgs baseEventArgs;

    public DataGridSuperTitleCellEventArgs(BaseGridCellEventArgs baseEventArgs, DataGridSuperTitle superTitle)
    {
      this.baseEventArgs = baseEventArgs;
      this.superTitle = superTitle;
    }

    public DataGridSuperTitle SuperTitle
    {
      get { return this.superTitle; }
    }

    public BaseGridCellEventArgs BaseEventArgs
    {
      get { return baseEventArgs; }
    }
  }

  //public class DataGridSuperTitleCellCustomAreaNeededEventArgs : EventArgs
  //{
  //  private readonly CellCustomAreaMeasures areaMeasures;
  //  private readonly DataGridSuperTitle superTitle;

  //  public DataGridSuperTitleCellCustomAreaNeededEventArgs(
  //    CellCustomAreaMeasures areaMeasures, DataGridSuperTitle superTitle)
  //  {
  //    this.areaMeasures = areaMeasures;
  //    this.superTitle = superTitle;
  //  }

  //  public CellCustomAreaMeasures AreaMeasures
  //  {
  //    get { return areaMeasures; }
  //  }

  //  public DataGridSuperTitle SuperTitle
  //  {
  //    get { return this.superTitle; }
  //  }
  //}

  public class DataGridSuperTitleCellClientAreaNeededEventArgs : EventArgs          
  {
    private readonly Rectangle cellRect;
    private readonly DataGridSuperTitle superTitle;
    private Rectangle cellClientRect;

    public DataGridSuperTitleCellClientAreaNeededEventArgs(
      DataGridSuperTitle superTitle, Rectangle cellRect)
    {
      this.cellRect = cellRect;
      this.cellClientRect = cellRect;
      this.superTitle = superTitle;
    }

    public DataGridSuperTitle SuperTitle
    {
      get { return this.superTitle; }
    }

    public Rectangle CellRect
    {
      get { return cellRect; }
    }

    public Rectangle CellClientRect
    {
      get { return cellClientRect; }
      set { cellClientRect = value; }
    }
  }

  public class DataGridSuperTitleCellHeightNeededEventArgs : EventArgs
  {
    private readonly DataGridSuperTitle superTitle;
    int cellHeight;

    public DataGridSuperTitleCellHeightNeededEventArgs(
      DataGridSuperTitle superTitle, int cellHeight)
    {
      this.cellHeight = cellHeight;
      this.superTitle = superTitle;
    }

    public DataGridSuperTitle SuperTitle
    {
      get { return this.superTitle; }
    }

    public int CellHeight
    {
      get { return cellHeight; }
      set { cellHeight = value; }
    }
  }

  public class DataGridSuperTitleCellContextMenuStripNeededEventArgs : HandledEventArgs
  {
    private readonly Rectangle cellRect;

    private readonly int inCellX;
    private readonly int inCellY;
    private readonly int mousePosX;
    private readonly int mousePosY;

    private ContextMenuStrip contextMenuStrip;

    private DataGridSuperTitle superTitle;

    public DataGridSuperTitleCellContextMenuStripNeededEventArgs(
      int inCellX, int inCellY, Rectangle cellRect, int mousePosX, int mousePosY,
      DataGridSuperTitle superTitle)
    {
      this.cellRect = cellRect;
      this.inCellX = inCellX;
      this.inCellY = inCellY;
      this.mousePosX = mousePosX;
      this.mousePosY = mousePosY;
      this.superTitle = superTitle;
    }

    public DataGridSuperTitle SuperTitle
    {
      get { return this.superTitle; }
    }
    public int InCellX
    {
      get { return inCellX; }
    }

    public int InCellY
    {
      get { return inCellY; }
    }

    public Rectangle CellRect
    {
      get { return cellRect; }
    }

    public int MousePosX
    {
      get { return mousePosX; }
    }

    public int MousePosY
    {
      get { return mousePosY; }
    }

    public ContextMenuStrip ContextMenuStrip
    {
      get { return this.contextMenuStrip; }
      set { this.contextMenuStrip = value; }
    }

    public virtual void SetContextMenuStrip(DataGridSuperTitleCellContextMenuStripNeededEventArgs e)
    {
      e.ContextMenuStrip = e.SuperTitle.GetMouseContextMenuStrip(e);
    }
  }

}
