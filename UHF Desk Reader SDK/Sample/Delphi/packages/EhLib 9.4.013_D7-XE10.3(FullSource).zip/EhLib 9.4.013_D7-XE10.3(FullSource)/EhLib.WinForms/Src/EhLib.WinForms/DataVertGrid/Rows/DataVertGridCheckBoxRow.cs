﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  public class DataVertGridCheckBoxRowQueryCheckStateEventArgs : HandledEventArgs
  {
    private object listItem;
    private CheckState checkState;

    public DataVertGridCheckBoxRowQueryCheckStateEventArgs(object listItem)
    {
      this.listItem = listItem;
    }

    public object ListItem
    {
      get { return this.listItem; }
      internal set { this.listItem = value; }
    }

    public CheckState CheckState
    {
      get { return this.checkState; }
      set { this.checkState = value; }
    }

  }

  /// <summary>
  /// Defines a type of row in a DataVertGridEh control that displays a check box user interface (UI).
  /// </summary>
  [DataVertGridRowDesignTimeVisible(true)]
  public class DataVertGridCheckBoxRow : DataVertGridRow, ICheckBoxDataCellHolder
  {

    #region private consts
    private static readonly object EventKeyQueryCheckboxState = new object();
    #endregion

    #region privates
    #endregion

    public DataVertGridCheckBoxRow()
    {

    }

    #region run-rime properties
    [Browsable(false)]
    public new CheckBoxDataCellManager DataCell
    {
      get { return (CheckBoxDataCellManager)base.InternalCellManager; }
    }
    #endregion

    #region properties
    [DefaultValue(false)]
    public bool ThreeState
    {
      get { return DataCell.ThreeState; }
      set { DataCell.ThreeState = value; }
    }

    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object TrueValue
    {
      get
      {
        return DataCell.TrueValue;
      }

      set
      {
        DataCell.TrueValue = value;
      }
    }

    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object FalseValue
    {
      get
      {
        return DataCell.FalseValue;
      }

      set
      {
        DataCell.FalseValue = value;
      }
    }

    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object IndeterminateValue
    {
      get
      {
        return DataCell.IndeterminateValue;
      }

      set
      {
        DataCell.IndeterminateValue = value;
      }
    }

    [DefaultValue(FlatStyle.Standard)]
    public FlatStyle FlatStyle
    {
      get
      {
        return DataCell.FlatStyle;
      }

      set
      {
        DataCell.FlatStyle = value;
      }
    }

    #endregion

    #region events
    public event EventHandler<DataGridCheckBoxColumnQueryCheckStateEventArgs> QueryCheckState
    {
      add
      {
        this.Events.AddHandler(EventKeyQueryCheckboxState, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyQueryCheckboxState, value);
      }
    }
    #endregion

    #region methods
    protected override BaseDataCellManager CreateTemplateCell()
    {
      //return new InternalCheckBoxDataCellManager();
      return new CheckBoxDataCellManager();
    }

    protected internal virtual CheckState OnGetCheckState(DataVertGridRow column, object listItem, out bool handled)
    {
      DataVertGridCheckBoxRowQueryCheckStateEventArgs e = null;
      var eh = this.Events[EventKeyQueryCheckboxState] as EventHandler<DataVertGridCheckBoxRowQueryCheckStateEventArgs>;
      if (eh != null /*&& !this.IsDisposed*/)
      {
        e = new DataVertGridCheckBoxRowQueryCheckStateEventArgs(listItem);
        eh(this, e);
      }
      if ((e != null) && e.Handled)
      {
        handled = true;
        return e.CheckState;
      }
      else
      {
        handled = false;
        return CheckState.Indeterminate;
      }
    }

    CheckState ICheckBoxDataCellHolder.OnGetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, out bool handled)
    {
      return OnGetCheckState((DataVertGridRow)propAxisBar, listItemBar, out handled);
    }
    #endregion

  }

  //[DataVertGridDataCellDesignTimeVisible(true)]
  //public class DataVertGridCheckBoxDataCellManager : DataVertGridBaseDataCellManager
  //{

  //  #region private consts
  //  private static readonly object EventKeyQueryCheckboxState = new object();
  //  #endregion private consts

  //  #region privates
  //  private CheckBoxDataCellWorker cellWorker;
  //  #endregion privates

  //  public DataVertGridCheckBoxDataCellManager()
  //  {
  //    cellWorker = new CheckBoxDataCellWorker(this);
  //  }

  //  #region properties
  //  [DefaultValue(false)]
  //  public bool ThreeState
  //  {
  //    get
  //    {
  //      return cellWorker.ThreeState;
  //    }
  //    set
  //    {
  //      cellWorker.ThreeState = value;
  //    }
  //  }

  //  [DefaultValue(null)]
  //  [TypeConverter(typeof(StringConverter))]
  //  public object TrueValue
  //  {
  //    get
  //    {
  //      return cellWorker.TrueValue;
  //    }
  //    set
  //    {
  //      cellWorker.TrueValue = value;
  //    }
  //  }

  //  [DefaultValue(null)]
  //  [TypeConverter(typeof(StringConverter))]
  //  public object FalseValue
  //  {
  //    get
  //    {
  //      return cellWorker.FalseValue;
  //    }
  //    set
  //    {
  //      cellWorker.FalseValue = value;
  //    }
  //  }

  //  [DefaultValue(null)]
  //  [TypeConverter(typeof(StringConverter))]
  //  public object IndeterminateValue
  //  {
  //    get
  //    {
  //      return cellWorker.IndeterminateValue;
  //    }
  //    set
  //    {
  //      cellWorker.IndeterminateValue = value;
  //    }
  //  }

  //  [DefaultValue(FlatStyle.Standard)]
  //  public FlatStyle FlatStyle
  //  {
  //    get
  //    {
  //      return cellWorker.FlatStyle;
  //    }
  //    set
  //    {
  //      cellWorker.FlatStyle = value;
  //    }
  //  }
  //  #endregion 

  //  #region events
  //  public event EventHandler<DataGridCheckBoxColumnQueryCheckStateEventArgs> QueryCheckState
  //  {
  //    add
  //    {
  //      this.Events.AddHandler(EventKeyQueryCheckboxState, value);
  //    }
  //    remove
  //    {
  //      this.Events.RemoveHandler(EventKeyQueryCheckboxState, value);
  //    }
  //  }
  //  #endregion events

  //  #region Methods
  //  public CheckBoxState GetCheckBoxState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    DataAxisGridCheckBoxQueryDataCellCheckStateEventArgs e = null;
  //    var eh = this.Events[EventKeyQueryCheckboxState] as EventHandler<DataAxisGridCheckBoxQueryDataCellCheckStateEventArgs>;
  //    if (eh != null /*&& !this.IsDisposed*/)
  //    {
  //      e = new DataAxisGridCheckBoxQueryDataCellCheckStateEventArgs(listItemBar);
  //      eh(this, e);
  //    }

  //    CheckState checkState;

  //    if ((e != null) && e.Handled)
  //      checkState = e.CheckState;
  //    else
  //      checkState = cellWorker.OnGetCheckState(propAxisBar, listItemBar);

  //    return cellWorker.GetCheckBoxStateByCheckState(checkState);
  //  }

  //  public CheckState GetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    return cellWorker.OnGetCheckState(propAxisBar, listItemBar);
  //  }

  //  public CheckState GetCheckStateFromValue(object value)
  //  {
  //    return cellWorker.GetCheckStateFromValue(value);
  //  }

  //  public void SetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, CheckState checkState)
  //  {
  //    cellWorker.SetCheckState(propAxisBar, listItemBar, checkState);
  //  }

  //  public object GetDataValueFromCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, CheckState checkState)
  //  {
  //    return cellWorker.GetDataValueFromCheckState(propAxisBar, listItemBar, checkState);
  //  }

  //  public CheckState NextCheckState(CheckState cs)
  //  {
  //    return cellWorker.NextCheckState(cs);
  //  }

  //  public virtual void Toggle(int dataColIndex, int dataRowIndex)
  //  {
  //    cellWorker.Toggle(dataColIndex, dataRowIndex);
  //  }

  //  protected override void PaintContent(DataAxisGridDataCellContentPaintEventArgs e)
  //  {
  //    cellWorker.PaintContent(e);
  //  }

  //  protected internal override void OnKeyDown(KeyEventArgs e)
  //  {
  //    cellWorker.OnKeyDown(e);
  //  }

  //  protected internal override void OnKeyUp(KeyEventArgs e)
  //  {
  //    cellWorker.OnKeyUp(e);
  //  }

  //  protected internal override void OnMouseDown(DataAxisGridDataCellMouseEventArgs e)
  //  {
  //    base.OnMouseDown(e);
  //    cellWorker.OnMouseDown(e);
  //  }

  //  protected internal override void OnMouseMove(DataAxisGridDataCellMouseEventArgs e)
  //  {
  //    base.OnMouseMove(e);
  //    //cellWorker.OnMouseMove(e);
  //  }

  //  protected internal override void OnMouseUp(DataAxisGridDataCellMouseEventArgs e)
  //  {
  //    cellWorker.OnMouseUp(e);
  //    base.OnMouseUp(e);
  //  }

  //  protected internal override void OnMouseEnter(DataAxisGridDataCellEnterEventArgs e)
  //  {
  //    Grid.InvalidateCell(e.ColIndex, e.RowIndex);
  //    base.OnMouseEnter(e);
  //  }

  //  protected internal override void OnMouseLeave(DataAxisGridDataCellLeaveEventArgs e)
  //  {
  //    Grid.InvalidateCell(e.ColIndex, e.RowIndex);
  //    base.OnMouseLeave(e);
  //    cellWorker.OnMouseLeave(e);
  //  }


  //  #endregion Methods
  //}

}
