﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Windows.Forms.Design;
using System.Drawing;
using System.Collections;
using System.Diagnostics;
using System.Windows.Forms;
using System.Windows.Forms.Design.Behavior;
using System.Collections.Generic;

namespace EhLib.WinForms.Design
{
  [System.Security.Permissions.PermissionSet(System.Security.Permissions.SecurityAction.Demand, Name = "FullTrust")]
  public class DataAxisGridDesigner : ControlDesigner
  {

    internal IComponentChangeService ChangeService;
    internal ISelectionService SelService;
    internal bool disposed = false;

    #region constructor
    public DataAxisGridDesigner()
    {
    }

    public override void Initialize(IComponent component)
    {
      base.Initialize(component);

      SelService = (ISelectionService)GetService(typeof(ISelectionService));
      if (SelService != null)
      {
        SelService.SelectionChanged += SelService_SelectionChanged;
        SelService.SelectionChanging += SelService_SelectionChanging;
      }

      ChangeService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
      if (ChangeService != null)
      {
        ChangeService.ComponentAdded += ChangeService_ComponentAdded;
        ChangeService.ComponentAdding += ChangeService_ComponentAdding;
        ChangeService.ComponentRemoved += ChangeService_ComponentRemoved;
        ChangeService.ComponentRemoving += ChangeService_ComponentRemoving;
        ChangeService.ComponentChanged += ChangeService_ComponentChanged;
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        if (SelService != null)
        {
          SelService.SelectionChanged -= SelService_SelectionChanged;
          SelService.SelectionChanging -= SelService_SelectionChanging;
          SelService = null;
        }

        if (ChangeService != null)
        {
          ChangeService.ComponentAdded -= ChangeService_ComponentAdded;
          ChangeService.ComponentAdding -= ChangeService_ComponentAdding;
          ChangeService.ComponentRemoved -= ChangeService_ComponentRemoved;
          ChangeService.ComponentRemoving -= ChangeService_ComponentRemoving;
          ChangeService.ComponentChanged -= ChangeService_ComponentChanged;

          ChangeService = null;
        }
      }

      base.Dispose(disposing);
      disposed = true;
    }
    #endregion

    #region >properties
    internal DataAxisGrid Grid
    {
      get { return this.Component as DataAxisGrid; }
    }

    public virtual string PropAxisBarName
    {
      get { return "PropAxisBar"; }
    }

    public virtual string PropAxisBarsName
    {
      get { return "PropAxisBars"; }
    }

    public virtual Type StaticPropBarCollectionType
    {
      get { return null; }
      //typeof(DataGridStaticColumnCollection)
    }

    public virtual Type PropAxisBarType
    {
      get { return null; }
    }

    public virtual DataAxisGridPropertyBarsEditor CreatePropertyBarsEditor()
    {
      return null;
    }

    public object GetSelectionIfOne
    {
      get
      {
        ICollection sel = SelService.GetSelectedComponents();

        if (sel.Count != 1)
          return null;

        foreach (object o in sel)
        {
          return o;
        }

        return null;
      }
    }
    #endregion <properties

    #region >methods
    protected override bool GetHitTest(Point point)
    {
      if (Grid == null) return base.GetHitTest(point);

      Point tpPoint = this.Control.PointToClient(point);

      Control childControl = Grid.GetChildAtPoint(tpPoint, GetChildAtPointSkip.None);

      if (childControl is BaseGridScrollBarPanelControl)
        return true;
      else
        return false;
    }

    protected virtual void SelService_SelectionChanged(object sender, EventArgs e)
    {
    }

    protected virtual void SelService_SelectionChanging(object sender, EventArgs e)
    {
    }

    protected virtual void ChangeService_ComponentAdding(object sender, ComponentEventArgs e)
    {
    }

    protected virtual void ChangeService_ComponentAdded(object sender, ComponentEventArgs e)
    {
      if (Grid == null || Grid.Disposing) return;


      PropertyAxisBar propBar = e.Component as PropertyAxisBar;
      if (propBar != null && 
          !Grid.InInitialization &&
          PropAxisBarType.IsAssignableFrom(propBar.GetType()))
      {
        object sel1 = GetSelectionIfOne;
        PropertyAxisBar propBarSeled = sel1 as PropertyAxisBar;
        if (propBarSeled != null && propBarSeled.Grid == Grid)
          Grid.StaticPropBars.Add(propBar);
        else if (sel1 == Component)
          Grid.StaticPropBars.Add(propBar);
        //        EhLibUtils.DoNothing();
      }

    }

    protected virtual void ChangeService_ComponentRemoving(object sender, ComponentEventArgs e)
    {
    }

    protected virtual void ChangeService_ComponentRemoved(object sender, ComponentEventArgs e)
    {
      if (Grid == null || Grid.Disposing) return;

      //???
      //DataGridColumn col = e.Component as DataGridColumn;
      //if (col != null && Grid.StaticColumns.IndexOf(col) >= 0)
      //  Grid.StaticColumns.Remove(col);
    }

    protected virtual void ChangeService_ComponentChanged(object sender, ComponentChangedEventArgs e)
    {
    }
    #endregion <methods

  }

  [ComplexBindingProperties("DataSource", "DataMember")]
  public class DataAxisGridChooseDataSourceActionList : DesignerActionList
  {
    readonly DataAxisGridDesigner owner;

    public DataAxisGridChooseDataSourceActionList(DataAxisGridDesigner owner) : base(owner.Component)
    {
      this.owner = owner;
    }

    public override DesignerActionItemCollection GetSortedActionItems()
    {
      DesignerActionItemCollection items = new DesignerActionItemCollection();
      DesignerActionPropertyItem item = new DesignerActionPropertyItem("DataSource", "Choose Data Source");
      item.RelatedComponent = this.owner.Component;
      items.Add(item);
      return items;
    }

    [AttributeProvider(typeof(IListSource))]
    public object DataSource
    {
      get
      {
        return this.owner.Grid.DataSource;
      }
      set
      {
        DataAxisGrid grid = this.owner.Grid;
        IDesignerHost host = grid.Site.GetService(typeof(IDesignerHost)) as IDesignerHost;
        PropertyDescriptor member = TypeDescriptor.GetProperties(grid)["DataSource"];
        IComponentChangeService service = grid.Site.GetService(typeof(IComponentChangeService)) as IComponentChangeService;
        DesignerTransaction transaction = host.CreateTransaction("Choose DataSource");
        try
        {
          service.OnComponentChanging(grid, member);
          this.owner.Grid.DataSource = value;
          service.OnComponentChanged(grid, member, null, null);
          transaction.Commit();
          transaction = null;
        }
        finally
        {
          if (transaction != null)
          {
            transaction.Cancel();
          }
        }
      }
    }
  }

  public class DataAxisGridActionList : DesignerActionList
  {
    readonly DataAxisGridDesigner owner;

    public DataAxisGridActionList(DataAxisGridDesigner owner) : base(owner.Component)
    {
      this.owner = owner;
    }

    public override DesignerActionItemCollection GetSortedActionItems()
    {
      DesignerActionItemCollection items = new DesignerActionItemCollection();
      items.Add(new DesignerActionMethodItem(this, "EditAxisBands", "Edit " + owner.PropAxisBarsName + " ...", true));
      //items.Add(new DesignerActionMethodItem(this, "EditAxisBand", "Add " + owner.PropAxisBarName + " ...", true));  // promoteToDesignerVerb 
      items.Add(new DesignerActionMethodItem(this, "AddAxisBands", "Add " + owner.PropAxisBarsName + " from DataSource ...", true)); // promoteToDesignerVerb 
      return items;
    }

    public void EditAxisBands()
    {
      DataAxisGridPropertyBarsEditor ce = owner.CreatePropertyBarsEditor();

      PropertyDescriptor propDesc = TypeDescriptor.GetProperties(owner.Grid)["StaticPropBars"];
      DialogWindowsFormsEditorService internalSrv = new DialogWindowsFormsEditorService(owner.Grid, propDesc);

      ce.EditValue(internalSrv, internalSrv, owner.Grid.StaticPropBars);
    }

    public void EditAxisBand()
    {
      //     Show Collection Dialog for grid.Collumns Collection
    }

    public void AddAxisBands()
    {
      DataAxisGridAddBoundBandsDialog.AddBoundAxisBars(owner.Grid);
    }

  }

  public class DataAxisGridPropertiesActionList : DesignerActionList
  {
    readonly DataAxisGridDesigner owner;

    public DataAxisGridPropertiesActionList(DataAxisGridDesigner owner) : base(owner.Component)
    {
      this.owner = owner;
    }

    public override DesignerActionItemCollection GetSortedActionItems()
    {
      DesignerActionItemCollection items = new DesignerActionItemCollection();
      items.Add(new DesignerActionPropertyItem("Dock", "Dock"));
      items.Add(new DesignerActionPropertyItem("Anchor", "Anchor"));
      return items;
    }

    public DockStyle Dock
    {
      get { return this.owner.Grid.Dock; }
      set { GetPropertyByName("Dock").SetValue(owner.Grid, value); }
    }

    public AnchorStyles Anchor
    {
      get { return this.owner.Grid.Anchor; }
      set { GetPropertyByName("Anchor").SetValue(owner.Grid, value); }
    }

    private PropertyDescriptor GetPropertyByName(String propName)
    {
      PropertyDescriptor prop = TypeDescriptor.GetProperties(owner.Grid)[propName];
      if (prop == null)
      {
        throw new ArgumentException("Propery {0} does not exist", propName);
      }
      return prop;
    }
  }

  public class DialogWindowsFormsEditorService : IServiceProvider, IWindowsFormsEditorService, ITypeDescriptorContext
  {
    readonly IServiceProvider baseServiceProvider;

    readonly PropertyDescriptor propDesc;
    readonly Component component;

    public DialogWindowsFormsEditorService(Component component, PropertyDescriptor propDesc)
    {
      this.baseServiceProvider = component.Site;
      this.component = component;
      this.propDesc = propDesc;
    }

    //IServiceProvider
    public object GetService(Type serviceType)
    {
      if (serviceType == typeof(IWindowsFormsEditorService))
        return this;
      else if (baseServiceProvider != null)
        return baseServiceProvider.GetService(serviceType);
      else
        return null;
    }

    //IWindowsFormsEditorService
    public void CloseDropDown()
    {
      //throw new NotImplementedException();
    }

    public void DropDownControl(Control control)
    {
      //throw new NotImplementedException();
    }

    public DialogResult ShowDialog(Form dialog)
    {
      return dialog.ShowDialog();
    }

    //ITypeDescriptorContext
    public IContainer Container
    {
      get { return component.Site.Container; }
    }

    public object Instance
    {
      get { return component; }
    }

    public PropertyDescriptor PropertyDescriptor
    {
      get { return propDesc; }
    }

    public bool OnComponentChanging()
    {
      return true;
    }

    public void OnComponentChanged()
    {
      var changeService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
      if (changeService != null)
        changeService.OnComponentChanged(component, null, null, null);
    }
  }

}
