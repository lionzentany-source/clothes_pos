﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of row in a DataVertGridEh control that displays a text.
  /// </summary>
  [DataVertGridRowDesignTimeVisible(true)]
  public class DataVertGridTextRow : DataVertGridRow
  {
    public DataVertGridTextRow()
    {

    }

    #region> Properties
    [Browsable(false)]
    //public new DataVertGridTextDataCellManager DataCell
    //{
    //  get { return (DataVertGridTextDataCellManager)base.DefaultDataCellManager; }
    //}
    public new TextDataCellManager DataCell
    {
      get { return (TextDataCellManager)base.InternalCellManager; }
    }

    [DefaultValue(CellTextWrapMode.Auto)]
    public CellTextWrapMode WrapMode
    {
      get { return DataCell.WrapMode; }
      set { DataCell.WrapMode = value; }
    }

    [DefaultValue(false)]
    public bool CellDataIsLink
    {
      get { return DataCell.CellDataIsLink; }
      set { DataCell.CellDataIsLink = value; }
    }

    public new bool AllowShowEditor
    {
      get { return base.AllowShowEditor; }
      set { base.AllowShowEditor = value; }
    }

    [DefaultValue("")]
    public string FormatString
    {
      get { return DataCell.FormatString; }
      set { DataCell.FormatString = value; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public TextAutoCompleting AutoCompleting
    {
      get
      {
        return DataCell.AutoCompleting;
      }
    }
    #endregion< Properties

    #region> methods
    protected override BaseDataCellManager CreateTemplateCell()
    {
      return new TextDataCellManager();
      //return new InternalTextDataCellManager();
    }
    #endregion< methods
  }

}
