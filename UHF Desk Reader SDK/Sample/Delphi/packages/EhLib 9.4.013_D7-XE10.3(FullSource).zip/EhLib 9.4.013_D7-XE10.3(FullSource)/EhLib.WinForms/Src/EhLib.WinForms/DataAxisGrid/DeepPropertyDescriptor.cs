﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  /// <summary>
  /// PropertyDescriptor keeper - class that support descriptos for nested properties 
  /// in complex classes.
  /// DataPropertyName should Nested properties should be described by the name of 
  /// properties and sub-properties separated by a dot.
  /// Like: "PropertyName.SubpropertyName. ... .SubpropertyName"
  /// </summary>
  public class DeepPropertyDescriptor : Object
  {

    internal List<PropertyDescriptor> propDescList;

    public DeepPropertyDescriptor(PropertyDescriptor pr)
    {
      propDescList = new List<PropertyDescriptor>();
      propDescList.Add(pr);

    }

    public DeepPropertyDescriptor(List<PropertyDescriptor> propStackList)
    {
      propDescList = new List<PropertyDescriptor>(propStackList);
    }

    public override bool Equals(object obj)
    {
      if ((obj == null) || !this.GetType().Equals(obj.GetType()))
      {
        return false;
      }
      else
      {
        var pd2 = obj as DeepPropertyDescriptor;

        if (propDescList.Count != pd2.propDescList.Count)
          return false;
        else
        {
          for (int i = 0; i < propDescList.Count; i++)
          {
            PropertyDescriptor pdi1 = propDescList[i];
            PropertyDescriptor pdi2 = pd2.propDescList[i];
            if (pdi1 != pdi2)
              return false;
          }

          return true;
          //return Object.Equals(this.ButtomPropDescr, pd2.ButtomPropDescr);
        }
      }
    }

    public override int GetHashCode()
    {
      return base.GetHashCode();
    }

    #region properties
    public PropertyDescriptor ButtomPropDescr
    {
      get
      {
        if (propDescList != null && propDescList.Count > 0)
          return propDescList[propDescList.Count - 1];
        else
          return null;
      }
    }

    public bool IsNested
    {
      get
      {
        if (propDescList != null && propDescList.Count > 1)
          return true;
        else
          return false;
      }
    }

    public bool IsReadOnly
    {
      get { return ButtomPropDescr.IsReadOnly; }
    }

    public Type PropertyType
    {
      get { return ButtomPropDescr.PropertyType; }
    }

    public string Path
    {
      get
      {
        return GetPath();
      }
    }
    #endregion

    #region methods
    public object GetValue(object component)
    {
      //object result = null;
      object nestedComponent = component;

      foreach (PropertyDescriptor p in propDescList)
      {
        nestedComponent = p.GetValue(nestedComponent);
      }

      return nestedComponent;
    }

    public void SetValue(object component, object value)
    {
      object nestedComponent = component;

      for (int i = 0; i < propDescList.Count-1; i++)
      {
        PropertyDescriptor p = propDescList[i];
        nestedComponent = p.GetValue(nestedComponent);
      }

      ButtomPropDescr.SetValue(nestedComponent, value);
    }

    private string GetPath()
    {
      string result = "";

      foreach (PropertyDescriptor pd in propDescList)
      {
        if (result == "")
          result = pd.Name;
        else
          result = result + "." + pd.Name;
      }

      return result;
    }
    #endregion

    #region static methods
    public static DeepPropertyDescriptorCollection GetItemProperties(BindingManagerBase bindingManager, int depthLevel)
    {
      List<DeepPropertyDescriptor> list = new List<DeepPropertyDescriptor>();

      //PropertyDescriptorCollection flatProperties = bindingManager.GetItemProperties();
      PropertyDescriptorCollection flatProperties = DataGridManager.DefaultManager.GetDataSourceItemProperties(bindingManager);

      foreach (PropertyDescriptor pd in flatProperties)
      {
        if (DataGridManager.DefaultManager.IsDeepPropertyType(pd.PropertyType) && depthLevel > 1)
        {
          List<PropertyDescriptor> propStackList = new List<PropertyDescriptor>();
          propStackList.Add(pd);
          AddDeepSubproperies(list, propStackList, pd, depthLevel - 1);
        }
        else
        {
          list.Add(new DeepPropertyDescriptor(pd));
        }
      }

      return new DeepPropertyDescriptorCollection(list);
    }

    public static DeepPropertyDescriptorCollection GetItemProperties(Type listItemType, int depthLevel)
    {
      List<DeepPropertyDescriptor> list = new List<DeepPropertyDescriptor>();

      PropertyDescriptorCollection flatProperties = TypeDescriptor.GetProperties(listItemType);

      foreach (PropertyDescriptor pd in flatProperties)
      {
        if ((pd.PropertyType != typeof(string)) &&
            (pd.PropertyType != typeof(DateTime)) &&
            (pd.PropertyType != typeof(Array)) &&
            (pd.PropertyType != typeof(TimeSpan)) &&
            (pd.PropertyType.IsArray == false) &&
            (pd.PropertyType.IsClass || IsStruct(pd.PropertyType)) &&
            depthLevel > 1)
        {
          List<PropertyDescriptor> propStackList = new List<PropertyDescriptor>();
          propStackList.Add(pd);
          AddDeepSubproperies(list, propStackList, pd, depthLevel - 1);
        }
        else
        {
          list.Add(new DeepPropertyDescriptor(pd));
        }
      }

      return new DeepPropertyDescriptorCollection(list);
    }

    public static DeepPropertyDescriptor GetDeepPropertyDescriptorFromPath(BindingManagerBase bindingManager, string propertyPath)
    {
      if (bindingManager == null) return null;

      List<string> propList = new List<string>(propertyPath.Split(new string[] { "." }, StringSplitOptions.None));
      int level = 1;
      List<PropertyDescriptor> propStackList = new List<PropertyDescriptor>();
      PropertyDescriptor prop = null;

      foreach (string propItem in propList)
      {
        if (level == 1)
        {

          //PropertyDescriptorCollection dataItemProps = bindingManager.GetItemProperties();
          PropertyDescriptorCollection dataItemProps = DataGridManager.DefaultManager.GetDataSourceItemProperties(bindingManager);
          prop = dataItemProps.Find(propItem, true);
          if (prop == null) return null;
          propStackList.Add(prop);
        }
        else
        {
          //PropertyDescriptorCollection pdc = TypeDescriptor.GetProperties(prop.PropertyType);
          PropertyDescriptorCollection pdc = DataGridManager.DefaultManager.GetDataSourceItemProperties(prop.PropertyType);
          prop = pdc.Find(propItem, true);
          if (prop == null) return null;
          propStackList.Add(prop);
        }
        level++;
      }

      return new DeepPropertyDescriptor(propStackList);
      //ReadOnlyCollection<DeepPropertyDescriptor> dpList = GetItemProperties(bindingManager, int.MaxValue);
    }

    internal static void AddDeepSubproperies(List<DeepPropertyDescriptor> propList, 
      List<PropertyDescriptor> propStackList, PropertyDescriptor pr, int depthLevel)
    {
      //PropertyDescriptorCollection pdc = TypeDescriptor.GetProperties(pr.PropertyType);
      PropertyDescriptorCollection pdc = DataGridManager.DefaultManager.GetDataSourceItemProperties(pr.PropertyType);

      if (pdc == null || pdc.Count == 0)
      {
        propList.Add(new DeepPropertyDescriptor(propStackList));
      }
      else
      {
        foreach (PropertyDescriptor subPr in pdc)
        {
          if (DataGridManager.DefaultManager.IsDeepPropertyType(subPr.PropertyType) && depthLevel > 1)
          {
            propStackList.Add(subPr);
            AddDeepSubproperies(propList, propStackList, subPr, depthLevel - 1);
          }
          else
          {
            propStackList.Add(subPr);
            propList.Add(new DeepPropertyDescriptor(propStackList));
            propStackList.RemoveAt(propStackList.Count-1);
          }
        }
      }

      //throw new NotImplementedException();
    }

    internal static bool IsStruct(Type source)
    {
      return source.IsValueType && !source.IsPrimitive && !source.IsEnum;
    }
    #endregion

  }

  public class DeepPropertyDescriptorCollection : ReadOnlyCollection<DeepPropertyDescriptor>
  {
    public DeepPropertyDescriptorCollection(IList<DeepPropertyDescriptor> list) : base(list)
    {
    }

    public int IndexOfButtomPropDescr(PropertyDescriptor propDescr)
    {
      for (int i = 0; i < Items.Count; i++)
      {
        if (Items[i].ButtomPropDescr == propDescr)
          return i;
      }
      return -1;
    }

    public int IndexOfPropertyDescriptor(DeepPropertyDescriptor propDescr)
    {
      for (int i = 0; i < Items.Count; i++)
      {
        if (Items[i].Equals(propDescr))
          return i;
      }
      return -1;
    }

  }
}
