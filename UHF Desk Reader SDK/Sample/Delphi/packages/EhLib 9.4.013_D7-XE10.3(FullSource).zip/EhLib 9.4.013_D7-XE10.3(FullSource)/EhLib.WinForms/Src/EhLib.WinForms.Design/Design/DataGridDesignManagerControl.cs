﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EhLib.WinForms;
using System.Drawing.Design;
using System.ComponentModel.Design;
using System.Collections;

namespace EhLib.WinForms.Design
{

  [ToolboxItem(false)]
  public partial class DataGridDesignManagerControl : UserControl
  {
    private readonly TreeListGeneric<SimpleTreeViewNode> baseTreeList = new TreeListGeneric<SimpleTreeViewNode>();
    private readonly List<SimpleTreeViewNode> flatList = new List<SimpleTreeViewNode>();
    private DataGridEh targetDataGridEh;
    private Point downGlPos;
    private Point downTopRightPos;
    private int downGlWidth;
    private int downGlLeft;
    private int preferredWidth;

    private ButtonEh btnHideManager;
    private ButtonEh btnShowManager;
    private bool flatListRebuilding;
    //private Color designFrameColor = Color.FromArgb(255, 140, 0);
    //private Color designFillColor = Color.FromArgb(255, 248, 239);
    //private Color designFrameColor = Color.FromArgb(200, 110, 0);  //HST 33 255 200
    //private Color designFillColor = Color.FromArgb(252, 245, 236); //Sat 16, Val 250
    private Color designFrameColor = Color.FromArgb(245, 155, 0);  //HST 38 
    private Color designFillColor = Color.FromArgb(250, 245, 234); //Sat 39, 16, 250
    

    public DataGridDesignManagerControl()
    {
      InitializeComponent();

      btnHideManager = new ButtonEh();
      btnHideManager.Parent = managerGrid;
      btnHideManager.Text = ">";
      btnHideManager.TextAlign = ContentAlignment.MiddleCenter;
      btnHideManager.Focusable = false;
      btnHideManager.Click += BtnHideShowManager_Click;

      btnShowManager = new ButtonEh();
      //btnHideManager.Parent = dataGridEh1;
      btnShowManager.Text = "<";
      btnShowManager.TextAlign = ContentAlignment.MiddleCenter;
      btnShowManager.Focusable = false;
      btnShowManager.Click += BtnHideShowManager_Click;

      UpdateButtons();

      managerGrid.TreeViewArea.NodeStateRenderer = new FlatTriangleTreeNodeStateRenderer();

      ReloadData();
      bindingSource1.DataSource = flatList;
      managerGrid.CurrentRowIndex = -1;

      framePanel.CustomBorderColor = designFrameColor;
      managerGrid.Border.Color = designFrameColor;
      managerGrid.BackColor = designFillColor;
    }

    public Rectangle DesignManagerBounds
    {
      get
      {
        if (Visible)
          return Bounds;
        else if (btnShowManager.Visible)
          return btnShowManager.Bounds;
        else
          return Rectangle.Empty;
      }
    }

    public object GetSelectionIfOne
    {
      get
      {
        var selService = (ISelectionService)GetService(typeof(ISelectionService));
        ICollection sel = selService.GetSelectedComponents();

        if (sel.Count != 1)
          return null;

        foreach (object o in sel)
        {
          return o;
        }

        return null;
      }
    }

    private new object GetService(Type serviceType)
    {
      if (targetDataGridEh == null) return null;
      if (targetDataGridEh.Site == null) return null;
      return targetDataGridEh.Site.GetService(serviceType);
    }

    private void UpdateToolBar()
    {

      tbAdd.Enabled = false;
      tbDelete.Enabled = false;
      tbMoveUp.Enabled = false;
      tbMoveDown.Enabled = false;
      tbShowEditor.Enabled = (bindingSource1.Current is SimpleTreeViewNode) &&  
                             (((SimpleTreeViewNode)bindingSource1.Current).ShowDialogEditor != null);

      tbAdd.Visible = false;
      tbDelete.Visible = false;
      tbMoveUp.Visible = false;
      tbMoveDown.Visible = false;
      toolStripSeparator1.Visible = false;
      toolStripSeparator2.Visible = false;
    }

    private void BtnHideShowManager_Click(object sender, EventArgs e)
    {
      if (Visible)
      {
        Visible = false;
        btnShowManager.Parent = targetDataGridEh;
        btnShowManager.Visible = true;
        UpdateButtons();
      }
      else
      {
        btnShowManager.Parent = null;
        btnShowManager.Visible = false;
        Visible = true;
        UpdateButtons();
      }
    }

    private void UpdateButtons()
    {
      if (!IsHandleCreated) return;

      GridAxisData gridHorzAxis;
      GridAxisData gridVertAxis;

      btnHideManager.Size = new Size(24, 24);
      gridHorzAxis = ((IBaseGridControlInternal)managerGrid).HorzAxis;
      btnHideManager.Location = new Point(gridHorzAxis.ContraStart - btnHideManager.Width - 5, 5);

      if (targetDataGridEh != null)
      {
        btnShowManager.Size = new Size(24, 24);
        gridHorzAxis = ((IBaseGridControlInternal)targetDataGridEh).HorzAxis;
        gridVertAxis = ((IBaseGridControlInternal)targetDataGridEh).VertAxis;
        btnShowManager.Location = 
          new Point(gridHorzAxis.ContraStart - btnShowManager.Width - 5, 
                    gridVertAxis.FixedBoundary + 5);
      }
    }

    public void SetTargetDataGridEh(DataGridEh targetDataGridEh)
    {
      if (this.targetDataGridEh != targetDataGridEh)
      {
        if (this.targetDataGridEh != null)
        {
          this.targetDataGridEh.SizeChanged -= TargetDataGridEh_SizeChanged;
          Parent = null;
          btnShowManager.Parent = null;
        }

        this.targetDataGridEh = targetDataGridEh;

        if (this.targetDataGridEh != null)
        {
          this.targetDataGridEh.SizeChanged += TargetDataGridEh_SizeChanged;
          Width = 320;
          preferredWidth = 320;
          Parent = this.targetDataGridEh;
          UpdateSizeAndPos();
        }

        ReloadData();
      }
    }

    private void TargetDataGridEh_SizeChanged(object sender, EventArgs e)
    {
      UpdateSizeAndPos();
    }

    private void UpdateSizeAndPos()
    {
      Rectangle bounds = Rectangle.Empty;

      if (Width < targetDataGridEh.Width - 24 - 24)
        bounds.Width = preferredWidth;
      else
        bounds.Width = targetDataGridEh.Width - 24 - 24;

      GridAxisData gridVertAxis = ((IBaseGridControlInternal)targetDataGridEh).VertAxis;

      bounds.X = targetDataGridEh.Width - bounds.Width - 24;
      //bounds.Height = targetDataGridEh.Height - 24 - 24;
      bounds.Y = gridVertAxis.FixedBoundary + targetDataGridEh.RowHeights[targetDataGridEh.FixedRowCount] + 8;
      bounds.Height = gridVertAxis.GridClientStop - 24 - bounds.Y;
      SetBounds(bounds.X, bounds.Y, bounds.Width, bounds.Height);

      UpdateButtons();
    }

    public void ReloadData()
    {

      List<SimpleTreeViewNode> oldTreeItems = new List<SimpleTreeViewNode>();
      baseTreeList.ForEach(n => oldTreeItems.Add(n));

      baseTreeList.Clear();

      if (targetDataGridEh == null)
      {
        RebuildFlatList();
        return;
      }

      SimpleTreeViewNode gridNode = new SimpleTreeViewNode()
      {
        Name = targetDataGridEh.Name,
        PropertyName = targetDataGridEh.Name,
        RefObject = targetDataGridEh,
        ShowTypeName = true,
        Expanded = true
      };

      baseTreeList.AddNode(gridNode, null, TreeListNodeAttachMode.AddChild, false);

      SimpleTreeViewNode exmNode = AddChild(
        targetDataGridEh.ExtraCellManagers, "ExtraCellManagers ...", "ExtraCellManagers", gridNode, false, ShowPropertyEditor);

      foreach (var cm in targetDataGridEh.ExtraCellManagers)
      {
        SimpleTreeViewNode colCellManNode = AddChild(cm, cm.Site.Name, cm.Site.Name, exmNode, false);
        colCellManNode.ShowTypeName = true;
      }

      AddChild(targetDataGridEh.Footer, "Footer", "Footer", gridNode, false);
      AddChild(targetDataGridEh.HorzScrollBar, "HorzScrollBar", "HorzScrollBar", gridNode, false);
      AddChild(targetDataGridEh.IndicatorColumn, "IndicatorColumn", "IndicatorColumn", gridNode, false);
      AddChild(targetDataGridEh.IndicatorTitle, "IndicatorTitle", "IndicatorTitle", gridNode, false);

      AddChild(targetDataGridEh.SearchBox, "SearchBox", "SearchBox", gridNode, false);
      SimpleTreeViewNode colsNode = AddChild(targetDataGridEh.StaticColumns, "StaticColumns ...", "StaticColumns", gridNode, false);
      colsNode.ShowDialogEditor = ShowPropertyEditor;

      foreach (var col in targetDataGridEh.StaticColumns)
      {
        SimpleTreeViewNode colNode = AddChild(col, col.Name, col.Name, colsNode, false);
        colNode.ShowTypeName = true;

        AddChild(col.EditButton, "EditButton", "EditButton", colNode, false);

        SimpleTreeViewNode colExmNode = AddChild(
          col.ExtraCellManagers, "ExtraCellManagers ...", "ExtraCellManagers", colNode, false, ShowPropertyEditor);

        foreach (var cm in col.ExtraCellManagers)
        {
          SimpleTreeViewNode colCellManNode = AddChild(cm, cm.Site.Name, cm.Site.Name, colExmNode, false);
          colCellManNode.ShowTypeName = true;
        }

        SimpleTreeViewNode inEditControlsNode = AddChild(col.InEditControls, "InEditControls ...", "InEditControls", colNode, false);
        inEditControlsNode.ShowDialogEditor = ShowPropertyEditor;
        foreach (var ine in col.InEditControls)
        {
          string ineName = "";
          if (ine.Site != null)
            ineName = ine.Site.Name;
          else
            ineName = ine.GetType().Name;
          SimpleTreeViewNode inEditCtrl = AddChild(ine, ineName, ineName, inEditControlsNode, false);
          inEditCtrl.ShowTypeName = true;
        }

        AddChild(col.Title, "Title", "Title", colNode, false);
      }

      AddChild(targetDataGridEh.Title, "Title", "Title", gridNode, false);
      AddChild(targetDataGridEh.TreeViewArea, "TreeViewArea", "TreeViewArea", gridNode, false);

      //AddChild(targetDataGridEh.ExtraCells, "ExtraCells", gridNode);
      AddChild(targetDataGridEh.VertScrollBar, "VertScrollBar", "VertScrollBar", gridNode, false);

      //DataSource
      if (targetDataGridEh.DataSource != null && 
          targetDataGridEh.DataSource is Component)
      {
        Component cmpDataSource = targetDataGridEh.DataSource as Component;
        ISite cmpDataSourceSite = cmpDataSource.Site;

        if (cmpDataSourceSite != null)
        {
          SimpleTreeViewNode dsNode = new SimpleTreeViewNode()
          {
            Name = cmpDataSourceSite.Name,
            PropertyName = cmpDataSourceSite.Name,
            RefObject = targetDataGridEh.DataSource,
            ShowTypeName = true,
            Expanded = true
          };

          baseTreeList.AddNode(dsNode, null, TreeListNodeAttachMode.AddChild, false);
        }
      }

      bool treeLisHaveChangedObject = false;

      baseTreeList.ForEach( 
        n => 
        {
          foreach (SimpleTreeViewNode on in oldTreeItems)
          {
            if (on.RefObject == n.RefObject)
            {
              treeLisHaveChangedObject = true;
              break;
            }
          }
        }
      );

      if (treeLisHaveChangedObject == true)
      {
        baseTreeList.ForEach(
          n =>
          {
            foreach (SimpleTreeViewNode on in oldTreeItems)
            {
              if (on.RefObject == n.RefObject)
              {
                n.Expanded = on.Expanded;
              }
            }
          }
        );
      }

      RebuildFlatList();
      SelServiceSelectionChanged(null, null);
    }

    private void ShowPropertyEditor(SimpleTreeViewNode node)
    {
      SimpleTreeViewNode parent = node.Parent as SimpleTreeViewNode;
      PropertyDescriptor propDesc = TypeDescriptor.GetProperties(parent.RefObject)[node.PropertyName];
      object editor = propDesc.GetEditor(typeof(UITypeEditor));
      UITypeEditor uiEditor = editor as UITypeEditor;
      if (uiEditor != null)
      {
        var internalSrv = new EhLib.WinForms.Design.DialogWindowsFormsEditorService(targetDataGridEh, propDesc);
        uiEditor.EditValue(internalSrv, internalSrv, node.RefObject);
      }

      //var ce = new EhLib. Design.DataGridColumnsEditor(typeof(DataGridStaticColumnCollection));
      //PropertyDescriptor propDesc = TypeDescriptor.GetProperties(targetDataGridEh)["StaticColumns"];
      //ce.EditValue(internalSrv, internalSrv, targetDataGridEh.StaticPropBars);
    }

    private SimpleTreeViewNode AddChild(object childObject, string displayName, string propertyName,
      SimpleTreeViewNode parentNode, bool expanded, ShowDialogEditor showDialogEditorProc = null)
    {
      SimpleTreeViewNode childNode = new SimpleTreeViewNode()
      {
        Name = displayName,
        PropertyName = propertyName,
        RefObject = childObject,
        Expanded = expanded,
        ShowDialogEditor = showDialogEditorProc
      };

      baseTreeList.AddNode(childNode, parentNode, TreeListNodeAttachMode.AddChild, false);

      return childNode;
    }

    private void RebuildFlatList()
    {
      flatListRebuilding = true;
      long savedScrollPos = managerGrid.VertScrollBar.ScrollPos;
      SimpleTreeViewNode curNode;
      if (managerGrid.CurrentRow == null)
        curNode = null;
      else
        curNode = managerGrid.CurrentRow.SourceItem as SimpleTreeViewNode;
      flatList.Clear();
      flatList.AddRange(baseTreeList.GetAsFlatList(true, true));
      bindingSource1.ResetBindings(false);

      if (curNode == null)
      {
        managerGrid.CurrentRowIndex = -1;
      }
      else
      {
        for (int i = 0; i < bindingSource1.List.Count; i++)
        {
          object item = bindingSource1.List[i];
          if (item == curNode)
          {
            bindingSource1.Position = i;
            break;
          }
        }
      }
      managerGrid.VertScrollBar.ScrollPos = savedScrollPos;
      flatListRebuilding = false;
    }

    protected override void OnHandleCreated(EventArgs e)
    {
      base.OnHandleCreated(e);
      UpdateSizeAndPos();
      //UpdateButtons();
    }

    protected override void OnLayout(LayoutEventArgs levent)
    {
      base.OnLayout(levent);
      UpdateButtons();
    }

    public delegate void ShowDialogEditor(SimpleTreeViewNode node);

    public class SimpleTreeViewNode : BaseTreeNode
    {

      public SimpleTreeViewNode()
      {
      }

      public string Name { get; set; }

      public string PropertyName { get; set; }

      public object RefObject { get; set; }

      public bool ShowTypeName { get; set; }

      public ShowDialogEditor ShowDialogEditor;

    }

    private void dataGridEh1_TreeViewArea_NodeStateNeeded(object sender, DataGridTreeViewNodeStateNeededEventArgs e)
    {
      if (e.Row == null) return;
      SimpleTreeViewNode node = (SimpleTreeViewNode)e.Row.SourceItem;
      e.NodeLevel = node.Level;
      e.HasChildren = node.HasChildren;
      e.Expanded = node.Expanded;
      e.ParentItem = node.Parent;
    }

    private void dataGridEh1_TreeViewArea_ExpandedStateSet(object sender, DataGridTreeViewNodeExpandedStateSetEventArgs e)
    {
      if (e.Row == null) return;
      SimpleTreeViewNode node = (SimpleTreeViewNode)e.Row.SourceItem;
      node.Expanded = e.Expanded;
      RebuildFlatList();
    }

    private void dataGridEh1_SelectionChanged(object sender, DataGridSelectionChangeOperationEventArgs e)
    {

    }

    private void bindingSource1_CurrentChanged(object sender, EventArgs e)
    {
      UpdateToolBar();
      if (flatListRebuilding) return;
      var node = bindingSource1.Current as SimpleTreeViewNode;
      if (node != null)
      {
        object selObject = node.RefObject;
        var SelService = (ISelectionService)GetService(typeof(ISelectionService));
        if (SelService == null) return;
        SelService.SetSelectedComponents(new object[] { selObject });

        //Form_PorpertiesGrid.ShowPropertiesGridFormFor(node.RefObject);
      }
    }

    private void panel1_MouseDown(object sender, MouseEventArgs e)
    {
      downGlPos = panel1.PointToScreen(e.Location);
      downGlWidth = Width;
      downGlLeft = Left;

      downTopRightPos = panel1.PointToScreen(e.Location);
      downTopRightPos.X += Width;
    }

    private void panel1_MouseMove(object sender, MouseEventArgs e)
    {
      if (panel1.Capture)
      {
        Point glPos = panel1.PointToScreen(e.Location);
        int newWidth = downGlWidth + downGlPos.X - glPos.X;
        int newLeft = downGlLeft - downGlPos.X + glPos.X;

        if (newWidth < targetDataGridEh.Width - 24 - 24 && 
            newWidth > 24 + 5 + 5 + 10)
        {
          preferredWidth = newWidth;
          SetBounds(newLeft, Top, newWidth, Height);
        }
      }
    }

    private void panel1_MouseUp(object sender, MouseEventArgs e)
    {

    }

    private void panel1_Paint(object sender, PaintEventArgs e)
    {
      e.Graphics.FillRectangle(SystemBrushes.ButtonFace, panel1.ClientRectangle);

      Rectangle frameRect = panel1.ClientRectangle;
      frameRect.Height -= 1;
      e.Graphics.DrawRectangle(new Pen(designFrameColor), frameRect);
    }

    private void dataGridEh1_SizeChanged(object sender, EventArgs e)
    {
      UpdateButtons();
    }

    private void tbShowEditor_Click(object sender, EventArgs e)
    {
      SimpleTreeViewNode node = bindingSource1.Current as SimpleTreeViewNode;
      if (node != null)
        node.ShowDialogEditor(node);
    }

    private void dataGridTextColumn1_DataCellPaint(object sender, DataGridDataCellPaintEventArgs e)
    {
      //return;

      object os = e.Column.GetRowDisplayText(e.Row);
      string s = null;
      SimpleTreeViewNode sourceRow = e.Row.SourceItem as SimpleTreeViewNode;

      e.PaintBackground(e);
      e.PaintForegroundServiceArea(e);
      e.Handled = true;

      if (os != null)
        s = os.ToString();


      ////e.Pa
      //e.PaintForeground Background(e);
      Rectangle textRect = EhLibUtils.TrimPadding(e.CellArgs.ClientRect, e.CellArgs.Padding);

      int text1Len = EhLibUtils.MeasureText(e.CellArgs.Graphics, s, e.CellArgs.Font).Width;
      EhLibUtils.DrawText(e.CellArgs.Graphics, s, e.CellArgs.Font, 
        textRect, e.CellArgs.ForePaintColor, e.CellArgs.HorzAlign, e.CellArgs.VertAlign, 0);
      textRect.X += text1Len;
      textRect.Width -= text1Len;

      if (!sourceRow.ShowTypeName) return;

      int text2Len = EhLibUtils.MeasureText(e.CellArgs.Graphics, ": ", e.CellArgs.Font).Width;
      EhLibUtils.DrawText(e.CellArgs.Graphics, ": ", e.CellArgs.Font, textRect, 
        e.CellArgs.ForePaintColor, e.CellArgs.HorzAlign, e.CellArgs.VertAlign, 0);
      textRect.X += text2Len;
      textRect.Width -= text2Len;

      string text3;
      Color foreColor;

      if (sourceRow.RefObject != null)
        text3 = sourceRow.RefObject.GetType().Name;
      else
        text3 = "";

      if (e.CellArgs.ForeColor != e.CellArgs.ForePaintColor)
        foreColor = e.CellArgs.ForePaintColor;
      else
        foreColor = SystemColors.GrayText;
        //foreColor = SystemColors.WindowText;

      EhLibUtils.DrawText(e.CellArgs.Graphics, text3, e.CellArgs.Font, 
        textRect, foreColor, e.CellArgs.HorzAlign, e.CellArgs.VertAlign, 0);
      textRect.X += text1Len;
      textRect.Width -= text1Len;

    }

    private void DataGridTextColumn1_DataCellContentPaint(object sender, DataGridDataCellContentPaintEventArgs e)
    {
      object os = e.Column.GetRowDisplayText(e.Row);
      string s = null;
      SimpleTreeViewNode sourceRow = e.Row.SourceItem as SimpleTreeViewNode;
      e.Handled = true;

      if (os != null)
        s = os.ToString();

      Rectangle textRect = EhLibUtils.TrimPadding(e.CellArgs.CellContentRect, e.CellArgs.Padding);

      int text1Len = EhLibUtils.MeasureText(e.CellArgs.Graphics, s, e.CellArgs.Font).Width;
      EhLibUtils.DrawText(e.CellArgs.Graphics, s, e.CellArgs.Font,
        textRect, e.CellArgs.ForePaintColor, e.CellArgs.HorzAlign, e.CellArgs.VertAlign, 0);
      textRect.X += text1Len;
      textRect.Width -= text1Len;

      if (!sourceRow.ShowTypeName) return;

      int text2Len = EhLibUtils.MeasureText(e.CellArgs.Graphics, ": ", e.CellArgs.Font).Width;
      EhLibUtils.DrawText(e.CellArgs.Graphics, ": ", e.CellArgs.Font, textRect,
        e.CellArgs.ForePaintColor, e.CellArgs.HorzAlign, e.CellArgs.VertAlign, 0);
      textRect.X += text2Len;
      textRect.Width -= text2Len;

      string text3;
      Color foreColor;

      if (sourceRow.RefObject != null)
        text3 = sourceRow.RefObject.GetType().Name;
      else
        text3 = "";

      if (e.CellArgs.ForeColor != e.CellArgs.ForePaintColor)
        foreColor = e.CellArgs.ForePaintColor;
      else
        foreColor = SystemColors.GrayText;
      //foreColor = SystemColors.WindowText;

      EhLibUtils.DrawText(e.CellArgs.Graphics, text3, e.CellArgs.Font,
        textRect, foreColor, e.CellArgs.HorzAlign, e.CellArgs.VertAlign, 0);
      textRect.X += text1Len;
      textRect.Width -= text1Len;
    }

    protected internal virtual void ComponentAdded(ComponentEventArgs e)
    {
      //if (IsComponentInList(e.Component))
      //  ReloadData();
    }

    protected internal virtual void ComponentRemoved(ComponentEventArgs e)
    {
      if (IsComponentInList(e.Component))
        ReloadData();
    }

    protected internal virtual void ComponentChanged(ComponentChangedEventArgs e)
    {
      if (IsComponentInList(e.Component))
        ReloadData();
    }

    protected internal virtual void GridEndInitialization()
    {
      ReloadData();
      UpdateSizeAndPos();
    }

    internal void SelServiceSelectionChanged(object sender, EventArgs e)
    {
      object o = GetSelectionIfOne;
      foreach(var oi in bindingSource1.List)
      {
        SimpleTreeViewNode node = oi as SimpleTreeViewNode;
        if (node.RefObject == o)
        {
          //bindingSource1.Position = bindingSource1.IndexOf(oi);
          managerGrid.CurrentRowIndex = bindingSource1.IndexOf(oi);
          return;
        }
      }
      managerGrid.CurrentRowIndex = -1;
    }

    private bool IsComponentInList(object component)
    {
      return baseTreeList.Exists(n => n.RefObject == component);
    }

    private void DataGridTextColumn1_DataCellDisplayValueNeeded(object sender, DataGridDataCellDisplayValueNeededEventArgs e)
    {
      if (e.Row == null) return;
      e.DisplayValue = e.GetDisplayValue(e);
      SimpleTreeViewNode srcRow = e.Row.SourceItem as SimpleTreeViewNode;
      IList srcAsList = srcRow.RefObject as IList;
      if (srcAsList != null && srcAsList.Count > 0)
      {
        e.DisplayValue = e.DisplayValue + " (" + srcAsList.Count.ToString() + ")";
      }
      e.Handled = true;
    }

  }

  [ToolboxItem(false)]
  public class DataGridDesignManagerGrid : DataGridEh
  {

    #region privates
    #endregion privates

    #region constructor
    public DataGridDesignManagerGrid()
    {
    }
    #endregion

    #region properties
    public override bool Focused
    {
      get { return true; }
    }
    #endregion properties

    #region methods
    protected override void FocusGrid()
    {
      //Nothing to-do
    }

    protected override bool IsActiveControl()
    {
      return true;
    }

    protected override void PaintCell(GraphicsContext gc, int colIndex, int rowIndex, Rectangle rect, Rectangle cellAreaRect, BasePaintCellStates state)
    {
      //if (SelectedIndex == -1)
      //  state = state &
      //         (~BasePaintCellStates.Selected) &
      //         (~BasePaintCellStates.Current) &
      //         (~BasePaintCellStates.Focused) &
      //         (~BasePaintCellStates.CurrentRow) &
      //         (~BasePaintCellStates.RowSelected);

      base.PaintCell(gc, colIndex, rowIndex, rect, cellAreaRect, state);
    }
    #endregion
  }

}
