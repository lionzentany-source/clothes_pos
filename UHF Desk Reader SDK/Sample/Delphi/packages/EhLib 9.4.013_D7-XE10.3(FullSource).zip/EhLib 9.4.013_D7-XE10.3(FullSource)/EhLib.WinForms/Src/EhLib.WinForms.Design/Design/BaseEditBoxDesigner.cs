﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2019 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Windows.Forms.Design;

namespace EhLib.WinForms.Design
{
  public class BaseEditBoxDesigner : ControlDesigner
  {

    //private DesignerActionListCollection actionLists;

    public BaseEditBoxDesigner()
    {
    }

    public override void Initialize(IComponent component)
    {
      base.Initialize(component);
      SelService = (ISelectionService) GetService(typeof(ISelectionService));
    }

    internal BaseEditBoxEh EditBox
    {
      get { return Component as BaseEditBoxEh; }
    }

    public override ICollection AssociatedComponents
    {
      get
      {
        ArrayList items = new ArrayList();

        //if (EditBox.EditItem != null)
        //  items.Add(EditBox.EditItem);

        foreach (EditItem ei in EditBox.InEditControls)
          items.Add(ei);

        if (EditBox.BoundLabel != null)
          items.Add(EditBox.BoundLabel);

        return items;
      }
    }

    public override DesignerActionListCollection ActionLists
    {
      get
      {
        DesignerActionListCollection actionLists;
        //if (actionLists == null)
        {
          actionLists = new DesignerActionListCollection();
          actionLists.Add(new BaseEditBoxActionList(this));
          actionLists.Add(new BaseEditBoxSelectInEditControlActionList(this));
        }
        return actionLists;
      }
    }

    public ISelectionService SelService
    {
      get;
      internal set;
    }

    public override DesignerVerbCollection Verbs
    {
      get
      {
        DesignerVerbCollection dvc = new DesignerVerbCollection();
        //dvc.Add(EmptyFooterItemDesignerVerb);

        foreach (EditItem ei in EditBox.InEditControls)
        {
          dvc.Add(new SelectInEditControlDesignerVerb("Select " + ei.Site.Name, SelectInEditControl, ei));
        }

        dvc.Add(new DesignerVerb("About EhLib.WinForms", ShowAboutDialog));
        //dvc.Add(new DesignerVerb("About EhLib.WinForms 1", ShowAboutDialog));

        //// Adds an array of DesignerVerb objects to the collection.
        //DesignerVerb[] verbs = { new DesignerVerb("Example designer verb 1", ShowAboutDialog) };
        //dvc.AddRange(verbs);

        //// Adds a collection of DesignerVerb objects to the collection.
        //var verbsCollection = new DesignerVerbCollection();
        //verbsCollection.Add(new DesignerVerb("Example designer verb 2", ShowAboutDialog));
        //verbsCollection.Add(new DesignerVerb("Example designer verb 3", ShowAboutDialog));
        //verbsCollection.Add(new DesignerVerb("Example designer verb 4", ShowAboutDialog));
        //verbsCollection.Add(new DesignerVerb("Example designer verb 5", ShowAboutDialog));
        //verbsCollection.Add(new DesignerVerb("Example designer verb 6", ShowAboutDialog));
        //dvc.AddRange(verbsCollection);

        //dvc.Add(new DesignerVerb("About EhLib.WinForms", ShowAboutDialog));
        //dvc.Add(new DesignerVerb("About EhLib.WinForms 1", SelectInEditControl));
        //dvc.Add(new DesignerVerb("About EhLib.WinForms 2", ShowAboutDialog));
        //dvc.Add(new DesignerVerb("About EhLib.WinForms 3", SelectInEditControl));

        return dvc;
      }
    }

    private void ShowAboutDialog(object sender, EventArgs e)
    {
      FormAbout fa = new FormAbout();
      fa.ShowDialog();
    }

    public void SelectInEditControl(object sender, EventArgs e)
    {
      var verb = sender as SelectInEditControlDesignerVerb;
      if (verb == null) return;
      SelService.SetSelectedComponents(new object[] { verb.EditItem });
    }

    public CollectionEditor CreateInEditControlsEditor()
    {
      return new InEditControlsCollectionEditor(typeof(Collection<EditItem>));
    }

  }

  public class BaseEditBoxActionList : DesignerActionList
  {
    public BaseEditBoxActionList(BaseEditBoxDesigner owner) : base(owner.Component)
    {
      Owner = owner;
    }

    public BaseEditBoxDesigner Owner
    {
      get;
      internal set;
    }

    public override DesignerActionItemCollection GetSortedActionItems()
    {
      DesignerActionItemCollection items = new DesignerActionItemCollection();
      items.Add(new DesignerActionMethodItem(this, "EditInEditControls", "Edit InEditControls ...", true));
      return items;
    }

    public void EditInEditControls()
    {
      CollectionEditor ce = Owner.CreateInEditControlsEditor();

      PropertyDescriptor propDesc = TypeDescriptor.GetProperties(Owner.EditBox)["InEditControls"];
      DialogWindowsFormsEditorService internalSrv = new DialogWindowsFormsEditorService(Owner.EditBox, propDesc);

      ce.EditValue(internalSrv, internalSrv, Owner.EditBox.InEditControls);
    }

  }

  public class BaseEditBoxSelectInEditControlActionList : DesignerActionList
  {
    public BaseEditBoxSelectInEditControlActionList(BaseEditBoxDesigner owner) : base(owner.Component)
    {
      Owner = owner;
    }

    public BaseEditBoxDesigner Owner
    {
      get;
      internal set;
    }

    public override DesignerActionItemCollection GetSortedActionItems()
    {
      if (Owner.EditBox == null)
      {
        return base.GetSortedActionItems();
      }
      else
      {
        DesignerActionItemCollection items = new DesignerActionItemCollection();

        foreach (EditItem ei in Owner.EditBox.InEditControls)
        {
          items.Add(new SelectInEditControlDesignerActionMethodItem(this, "", "Select " + ei.Site.Name, ei));
        }

        return items;
      }
    }

  }

  public class SelectInEditControlDesignerActionMethodItem : DesignerActionMethodItem
  {
    private readonly BaseEditBoxSelectInEditControlActionList actionList;

    public SelectInEditControlDesignerActionMethodItem(BaseEditBoxSelectInEditControlActionList actionList, string memberName, string displayName, EditItem editItem) : 
      base(actionList, memberName, displayName)
    {
      EditItem = editItem;
      this.actionList = actionList;
    }

    public EditItem EditItem
    {
      get;
      internal set;
    }

    public override void Invoke()
    {
      ISelectionService selSrv = actionList.Owner.SelService;
      selSrv.SetSelectedComponents(new object[] { EditItem });
    }

  }

  public class SelectInEditControlDesignerVerb : DesignerVerb
  {
    public SelectInEditControlDesignerVerb(string text, EventHandler handler, EditItem editItem) : 
      base(text, handler)
    {
      EditItem = editItem;
    }

    public SelectInEditControlDesignerVerb(string text, EventHandler handler, CommandID startCommandID, EditItem editItem) : 
      base(text, handler, startCommandID)
    {
      EditItem = editItem;
    }

    public EditItem EditItem
    {
      get;
      internal set;
    }

  }
}
