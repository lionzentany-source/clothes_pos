﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  /// <summary>
  /// Base class for lists that are used to display data in drop-down lists such as a combo box for ComboBoxEh
  /// </summary>
  [ToolboxItem(false)]
  public class PopupDataGrid : DataGridEh
  {
    #region privates
    private readonly PopupDataGridForm gridForm;
    private string displayMember;
    private string valueMember;
    private int selectedIndex;
    private Point mouseMovePos;
    #endregion privates

    #region constructor
    public PopupDataGrid(PopupDataGridForm gridForm)
    {
      this.gridForm = gridForm;
      SetStyle(ControlStyles.Selectable, false);
      IndicatorColumn.Visible = false;
      Selection.RowSelect = true;
      Title.Visible = false;
      AutoSizeColumnOptions.FitToClient = true;
      SizeGripAlwaysShow = true;
      LineOptions.HorzLines = false;
      LineOptions.VertLines = false;
      Selection.AllowedSelection.SetAllowedSelections(true, false, false, false);
      ReadOnly = true;
      EmptyDataInfo.Active = true;
      EmptyDataInfo.Text = "The list is empty";
      Selection.AllowedSelection.All = false;
      Selection.AllowedSelection.Cells = false;
      Selection.AllowedSelection.Columns = false;
      Selection.AllowedSelection.Rows = false;
    }
    #endregion

    #region >properties
    //public object DataSource

    public string DisplayMember
    {
      get
      {
        return displayMember;
      }

      set
      {
        if (value != displayMember)
        {
          displayMember = value;
          UpdateColumnsList();
        }
      }
    }

    public string ValueMember
    {
      get
      {
        return valueMember;
      }

      set
      {
        valueMember = value;
        //if (value != valueMember)
        //{
        //  valueMember = value;
        //}
      }
    }

    public int SelectedIndex
    {
      get
      {
        return selectedIndex;
      }
      set
      {
        if (value != selectedIndex)
        {
          if (value >= 0 && VisibleRows.Count > 0)
          {
            int inVisibleRowsIndex = Rows[value].VisibleIndex;
            if (inVisibleRowsIndex >= 0)
              CurrentRowIndex = inVisibleRowsIndex;
          }
          else
          {
            if (VisibleRows.Count > 0)
              CurrentRowIndex = 0;
          }
          selectedIndex = value;
          Invalidate();
        }
      }
    }

    public object SelectedValue
    {
      get
      {
        if (CurrentRow != null)
        {
          PropertyDescriptorCollection pc = CurrencyManager.GetItemProperties();

          string valuePropName;
          if (LookupMode)
            valuePropName = ValueMember;
          else
            valuePropName = DisplayMember;

          PropertyDescriptor prop = pc.Find(valuePropName, true);
          object val = prop.GetValue(CurrentRow.SourceItem);
          return val;
        }
        else
        {
          return null;
        }
      }
      set
      {
        if (CurrencyManager != null)
        {
          PropertyDescriptorCollection props = CurrencyManager.GetItemProperties();

          string findPropName;
          if (LookupMode)
            findPropName = ValueMember;
          else
            findPropName = DisplayMember;

          PropertyDescriptor property = props.Find(findPropName, true);
          SelectedIndex = ItemIndexByPropValue(property, value);
        }
        else
        {
          SelectedIndex = -1;
        }
      }
    }

    public object SelectedItem
    {
      get
      {
        if (CurrentRow != null)
          return CurrentRow.SourceItem;
        else
          return null;
      }
    }

    /// <summary>
    ///    Returns true when ValueMember is assigned and DataSource is active
    /// </summary>
    [Browsable(false)]
    public bool LookupMode
    {
      get
      {
        return !string.IsNullOrEmpty(ValueMember);
      }
    }

    public new int DefaultRowHeight
    {
      get
      {
        return CalcDefaultRowHeight();
      }
    }

    protected override CreateParams CreateParams
    {
      get
      {
        CreateParams cp = base.CreateParams;
        //cp.Style |= WS_BORDER;
        //cp.ExStyle |= WS_EX_CLIENTEDGE;
        return cp;
      }
    }

    public override bool Focused
    {
      get { return true; }
    }

    public new SizeGripPosition SizeGripPosition
    {
      get { return base.SizeGripPosition; }
      set { base.SizeGripPosition = value; }
    }

    public PopupDataGridForm GridForm
    {
      get
      {
        return gridForm;
      }
    }

    public bool Sizable
    {
      get
      {
        return SizeGripAlwaysShow;
      }
      set
      {
        SizeGripAlwaysShow = value;
      }
    }
    #endregion <properties

    #region >methods
    protected override PropertyAxisBar[] CreateDynamicColumnsForDataProperty(DeepPropertyDescriptor prop)
    {
      if (OnCheckIfCreateDynaColumnForDataProperty(prop))
        return base.CreateDynamicColumnsForDataProperty(prop);
      else
        return null;
    }

    protected override PropertyAxisBar CreatePropBarForDataProperty(DeepPropertyDescriptor prop)
    {
      //if (DataSource != null && prop.Name == DisplayMember)
      if (DataSource != null && prop.Path == DisplayMember)
      {
        return CreatePropBarForListItemType(prop.PropertyType);
      }
      else
      {
        return base.CreatePropBarForDataProperty(prop);
      }
    }

    protected override bool ColumnValueSourceIsListItem(Type listItemType)
    {
      if (GridForm.ListSourceOrigin == ListSourceOrigin.Items)
        return true;
      else
        return base.ColumnValueSourceIsListItem(listItemType);
    }

    protected internal override void FocusGrid()
    {
      //Nothing to-do
    }

    protected internal override bool IsActiveControl()
    {
      return true;
    }

    protected override GripActiveStatus CornerSizeGripActiveStatus(SizeGripControl sizeGrip)
    {
      return GripActiveStatus.Always;
    }

    protected override void OnCellMouseClick(BaseGridCellManager cell, BaseGridCellMouseEventArgs e)
    {
      base.OnCellMouseClick(cell, e);
      CellAreaType areaType = GetCellAreaTypeByColRow(e.ColIndex, e.RowIndex);
      if (areaType.HorzType == DataGridCellAreaHorzType.Data &&
          areaType.VertType == DataGridCellAreaVertType.Data)
      {
        var ex = e as DataAxisGridDataCellMouseEventArgs;
        if (ex != null)
        {
          bool canSelect = ListItemIsSelectable(ex.ListItemBar.SourceItem);
          if (canSelect)
            OnCloseUpNeeded(new PopupListCloseUpNeededEventArgs(true));
        }
      }
    }

    protected override void OnCellMouseMove(BaseGridCellManager cell, BaseGridCellMouseEventArgs e)
    {
      base.OnCellMouseMove(cell, e);
      
      CellAreaType areaType = GetCellAreaTypeByColRow(e.ColIndex, e.RowIndex);
      if (VisibleRows.Count > 0 &&
          areaType.HorzType == DataGridCellAreaHorzType.Data &&
          areaType.VertType == DataGridCellAreaVertType.Data &&
          mouseMovePos != e.GridMouseArgs.Location
          )
      {
        DataGridRow row = VisibleRows[e.RowIndex];
        object listItem = row.SourceItem;
        if (ListItemIsSelectable(listItem))
          SelectedIndex = row.Index;
        mouseMovePos = e.GridMouseArgs.Location;
      }
    }

    protected override void OnMouseEnter(EventArgs e)
    {
      base.OnMouseEnter(e);
      mouseMovePos = new Point(-1, -1);
    }

    protected override void OnCellMouseEnter(BaseGridCellManager cell, BaseGridCellEnterEventArgs e)
    {
      base.OnCellMouseEnter(cell, e);
    }

    protected override void OnHandleCreated(EventArgs e)
    {
      base.OnHandleCreated(e);
      gridForm.UpdateHeight(false);
    }

    protected override void PaintCell(GraphicsContext gc, int colIndex, int rowIndex, Rectangle rect, Rectangle cellAreaRect, BasePaintCellStates state)
    {
      if (SelectedIndex == -1)
        state = state &
               (~BasePaintCellStates.Selected) &
               (~BasePaintCellStates.Current) &
               (~BasePaintCellStates.Focused) &
               (~BasePaintCellStates.CurrentRow) &
               (~BasePaintCellStates.RowSelected);

      base.PaintCell(gc, colIndex, rowIndex, rect, cellAreaRect, state);
    }

    protected override void OnCurrentCellPosChanged(BaseGridCurrentCellPosChangedEventArgs e)
    {
      base.OnCurrentCellPosChanged(e);
      if (CurrentRowIndex < VisibleRows.Count)
        selectedIndex = VisibleRows[CurrentRowIndex].Index;
      else
        selectedIndex = -1;
    }

    protected internal override void CurrencyManagerListChanged(object sender, ListChangedEventArgs e)
    {
      base.CurrencyManagerListChanged(sender, e);
      if (!IsDisposed)
        SelectedIndex = -1;
    }

    //New 
    private int ItemIndexByPropValue(PropertyDescriptor property, object key)
    {
      for (int i = 0; i < CurrencyManager.List.Count; i++)
      {
        Debug.Assert(property != null, @"property != null");
        object obj2 = property.GetValue(CurrencyManager.List[i]);
        if (ValueEqual(key, obj2))
        {
          return i;
        }
      }
      return -1;
    }

    protected virtual bool ValueEqual(object x, object y)
    {
      if (x == null && y == null)
        return true;
      else if (x == null)
        return false;
      else if (y == null)
        return false;
      else if (x.GetType() != y.GetType())
        return false;
      else
      {
        IComparable cmp = x as IComparable;
        if (cmp != null)
          return cmp.CompareTo(y) == 0;
        else
          return x.Equals(y);
      }
    }

    protected bool OnCheckIfCreateDynaColumnForDataProperty(DeepPropertyDescriptor prop)
    {
      bool result = true;
      if (DataSource != null)
      {
        if (result)
        {
          //if (prop.Name == DisplayMember)
          if (prop.Path == DisplayMember)
            // ReSharper disable once RedundantAssignment
            result = true;
          else
            result = false;
        }
      }
      return result;
    }

    internal void ProcessKeyDown(KeyEventArgs e)
    {
      if (e.Alt) return;

      switch (e.KeyCode)
      {
        case Keys.Up:
          if (SelectedIndex == -1 && VisibleRows.Count > 0)
            SelectedIndex = VisibleRows[0].Index;
          else
          {
            int oldCurRowIndex = CurrentRowIndex;
            for (int i = CurrentRowIndex - 1; i >= 0; i--)
            {
              object sourceItem = VisibleRows[i].SourceItem;
              if (ListItemIsSelectable(sourceItem))
              {
                CurrentRowIndex = i;
                break;
              }
            }
            if (oldCurRowIndex == CurrentRowIndex)
            {
              TopRow = 0;
            }
          }
          e.Handled = true;
          break;

        case Keys.Down:
          for (int i = CurrentRowIndex + 1; i < VisibleRows.Count; i++)
          {
            object sourceItem = VisibleRows[i].SourceItem;
            if (ListItemIsSelectable(sourceItem))
            {
              CurrentRowIndex = i;
              break;
            }
          }
          e.Handled = true;
          break;
        //case Keys.Home:
        //case Keys.End:

        case Keys.PageDown:
        case Keys.PageUp:
          int nextPageRow, prevPageRow;
          int nextSelRowIndex;

          CalcPageExtents(out nextPageRow, out prevPageRow);

          if (e.KeyCode == Keys.PageDown)
            nextSelRowIndex = nextPageRow;
          else
            nextSelRowIndex = prevPageRow;

          CalcNextSelectableRowIndex(CurrentRowIndex, ref nextSelRowIndex);
          CurrentRowIndex = nextSelRowIndex;

          if (e.KeyCode == Keys.PageUp && prevPageRow == 0)
          {
            TopRow = 0;
          }

          e.Handled = true;
          break;

        case Keys.Enter:
          OnCloseUpNeeded(new PopupListCloseUpNeededEventArgs(true));
          e.Handled = true;
          break;
      }
    }

    private void CalcNextSelectableRowIndex(int currentRowIndex, ref int nextSelRowIndex)
    {
      if (nextSelRowIndex > currentRowIndex)
      {
        for (int i = nextSelRowIndex; i < VisibleRows.Count; i++)
        {
          object sourceItem = VisibleRows[i].SourceItem;
          if (ListItemIsSelectable(sourceItem))
          {
            nextSelRowIndex = i;
            return;
          }
        }

        for (int i = nextSelRowIndex - 1; i >= currentRowIndex; i--)
        {
          object sourceItem = VisibleRows[i].SourceItem;
          if (ListItemIsSelectable(sourceItem))
          {
            nextSelRowIndex = i;
            return;
          }
        }

      }
      else if (nextSelRowIndex < currentRowIndex)
      {
        for (int i = nextSelRowIndex; i >= 0; i--)
        {
          object sourceItem = VisibleRows[i].SourceItem;
          if (ListItemIsSelectable(sourceItem))
          {
            nextSelRowIndex = i;
            return;
          }
        }

        for (int i = nextSelRowIndex + 1; i <= currentRowIndex; i++)
        {
          object sourceItem = VisibleRows[i].SourceItem;
          if (ListItemIsSelectable(sourceItem))
          {
            nextSelRowIndex = i;
            return;
          }
        }
      }
    }

    protected virtual void OnCloseUpNeeded(PopupListCloseUpNeededEventArgs e)
    {
      GridForm.OnCloseUpNeeded(e);
    }

    protected virtual bool ListItemIsSelectable(object sourceItem)
    {
      return true;
    }

    public override void InteractiveFocusCell(int colIndex, int rowIndex, InteractiveActionSource actionSource)
    {
      int dataRowIndex = RawToDataRowIndex(rowIndex);
      DataGridRow row = VisibleRows[dataRowIndex];
      if (ListItemIsSelectable(row.SourceItem))
        base.InteractiveFocusCell(colIndex, rowIndex, actionSource);
    }
    #endregion <methods
  }

  /// <summary>
  /// Base form drop-down list for ComboBoxEh and TextAutoCompleting list.
  /// </summary>
  [ToolboxItem(false)]
  public class PopupDataGridForm : Form
  {
    #region >private consts
    private static readonly object EventKeyCloseUpNeeded = new object();
    #endregion <privates consts
    
    #region >privates
    readonly BindingSource bindingSource;
    public PopupDataGrid Grid;
    private int visibleRowCount;
    private int oldWidth, oldHeight;
    private bool widthChanged, heightChanged;
    private string filterText;
    private bool internalSizeSet;
    private Rectangle screenEditRect;
    #endregion <privates

    #region constructor
    public PopupDataGridForm()
    {
      FormBorderStyle = FormBorderStyle.None;
      StartPosition = FormStartPosition.Manual;
      //BackColor = Color.Black;
      //TransparencyKey = Color.Black;
      ShowInTaskbar = false;

      bindingSource = new BindingSource();

      Grid = CreatePopupDataGrid();
      Grid.Dock = DockStyle.Fill;
      Grid.Parent = this;
      Grid.DataSource = bindingSource;
    }
    #endregion

    #region properties
    public object DataSource
    {
      get
      {
        return bindingSource.DataSource;
      }

      set
      {
        bindingSource.DataSource = value;
      }
    }

    public string DisplayMember
    {
      get
      {
        return Grid.DisplayMember;
      }

      set
      {
        Grid.DisplayMember = value;
      }
    }

    public string ValueMember
    {
      get
      {
        return Grid.ValueMember;
      }

      set
      {
        Grid.ValueMember = value;
      }
    }

    public int SelectedIndex
    {
      get
      {
        return Grid.SelectedIndex;
      }

      set
      {
        Grid.SelectedIndex = value;
      }
    }

    public object SelectedValue
    {
      get
      {
        return Grid.SelectedValue;
      }

      set
      {
        Grid.SelectedValue = value;
      }
    }

    public object SelectedItem
    {
      get
      {
        return Grid.SelectedItem;
      }
    }

    public bool WidthChanged
    {
      get { return widthChanged; }
    }

    public bool HeightChanged
    {
      get { return heightChanged; }
    }

    protected override bool ShowWithoutActivation
    {
      get { return true; }
    }

    protected override CreateParams CreateParams
    {
      //[EnvironmentPermissionAttribute(SecurityAction.LinkDemand, Unrestricted = true)]
      get
      {

        CreateParams baseParams = base.CreateParams;
        baseParams.ExStyle |= (NativeMethods.WS_EX_TOPMOST);
        baseParams.ClassStyle |= NativeMethods.CS_DROPSHADOW;

        return baseParams;
      }
    }

    public int VisibleRowCount
    {
      get
      {
        return visibleRowCount;
      }
      set
      {
        if (value != visibleRowCount)
        {
          visibleRowCount = value;
          UpdateHeight(false);
        }
      }
    }

    public SizeGripPosition SizeGripPosition
    {
      get
      {
        return Grid.SizeGripPosition;
      }
      set
      {
        Grid.SizeGripPosition = value;
      }
    }

    public string FilterText
    {
      get
      {
        return filterText;
      }
      set
      {
        if (value != filterText)
        {
          filterText = value;
          if (FilterType == ComboBoxFilterType.StartOfText)
          {
            Grid.SearchBox.CellBeginsWithMode = true;
            Grid.SearchBox.HighlightSearchingText = false;
          }
          else
          {
            Grid.SearchBox.CellBeginsWithMode = false;
            Grid.SearchBox.HighlightSearchingText = true;
          }
          Grid.SearchBox.SearchingText = filterText;
          Grid.SearchBox.ApplyFilter(filterText);
          internalSizeSet = true;
          try
          {
            UpdateHeight(false);
          }
          finally
          {
            internalSizeSet = false;
          }
        }
      }
    }

    public ComboBoxFilterType FilterType { get; set; }

    public ListSourceOrigin ListSourceOrigin { get; set; }
    #endregion

    #region >events
    public event EventHandler<PopupListCloseUpNeededEventArgs> CloseUpNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyCloseUpNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyCloseUpNeeded, value);
      }
    }
    #endregion <events

    #region >methods
    public void CreateAllHandles()
    {
      if (Handle == null || Grid.Handle == null)
        throw new NotSupportedException("PopupDataGridForm.CreateFormHandle(). Handle should be not null.");
    }

    public void AlignWindow(Rectangle screenEditRect, int visibleRowCount, int width)
    {
      CreateAllHandles();
      VisibleRowCount = visibleRowCount;
      Width = width;
      this.screenEditRect = screenEditRect;
      UpdateHeight(true);
      VerticalDropLayout layout = EhLibUtils.AlignDropDownWindowRect(screenEditRect, this, DropDownAlign.Left);

      if (layout == VerticalDropLayout.AboveControl)
        SizeGripPosition = SizeGripPosition.TopRight;
      else
        SizeGripPosition = SizeGripPosition.BottomRight;
    }

    protected virtual PopupDataGrid CreatePopupDataGrid()
    {
      return new PopupDataGrid(this);
    }

    public void ResetOldSizeInfo()
    {
      oldWidth = Width;
      widthChanged = false;
      oldHeight = Height;
      heightChanged = false;
    }

    protected override void DefWndProc(ref Message m)
    {
      switch (m.Msg)
      {
        case NativeMethods.WM_MOUSEACTIVATE:
          m.Result = (IntPtr)NativeMethods.MA_NOACTIVATE;
          return;
      }
      base.DefWndProc(ref m);
    }

    protected internal virtual void ProcessKeyDown(KeyEventArgs e)
    {
      Grid.ProcessKeyDown(e);
    }

    protected override void SetBoundsCore(int x, int y, int width, int height, BoundsSpecified specified)
    {
      height = CalcAutoHeightForOfferedHeight(height);
      width = Math.Max(SystemInformation.VerticalScrollBarWidth * 2, width);
      base.SetBoundsCore(x, y, width, height, specified);
    }

    protected override void OnHandleCreated(EventArgs e)
    {
      base.OnHandleCreated(e);
      UpdateHeight(false);
    }

    protected override void OnSizeChanged(EventArgs e)
    {
      base.OnSizeChanged(e);
      if (internalSizeSet) return;
      if (oldWidth != Width)
      {
        widthChanged = true;
        oldWidth = Width;
      }
      if (oldHeight != Height)
      {
        heightChanged = true;
        int defRowHeight = Grid.DefaultRowHeight;
        int gridBordersHeight = Grid.Height - Grid.ClientBounds.Height;
        visibleRowCount = (Height - gridBordersHeight) / defRowHeight;
        oldHeight = Height;
      }
    }

    internal void UpdateHeight(bool forceHandle)
    {
      //if (Grid == null || !Grid.IsHandleCreated) return;
      if (Grid == null) return;
      if (!forceHandle && !Grid.IsHandleCreated) return;

      Grid.CreateControl();
      int defRowHeight = Grid.DefaultRowHeight;
      int gridBordersHeight = Grid.Height - Grid.ClientBounds.Height;
      int newHeight = CalcAutoHeightForOfferedHeight(VisibleRowCount * defRowHeight + gridBordersHeight);
      int newTop;
      if (SizeGripPosition == SizeGripPosition.TopLeft || 
          SizeGripPosition == SizeGripPosition.TopRight)
      {
        newTop = screenEditRect.Top - newHeight;
      }
      else
      {
        newTop = Top;
      }

      SetBounds(Left, newTop, Width, newHeight);
    }

    //internal void UpdateHeightFromVisibleRowCount()
    //{

    //}

    private int CalcAutoHeightForOfferedHeight(int offeredHeight)
    {
      if (!Grid.IsHandleCreated) return offeredHeight;

      int result;

      int gridBordersHeight = Grid.Height - Grid.ClientBounds.Height;
      int gridNewClientHeight = offeredHeight - gridBordersHeight;
      int defRowHeight = Grid.DefaultRowHeight;
      int rows = gridNewClientHeight / defRowHeight;
      if (rows < 1) rows = 1;

      int heightLow = rows * defRowHeight;
      int heightHigh = (rows + 1) * defRowHeight;

      int fixedVisibleRowCount;
      if (Grid.VisibleRows.Count > 0)
        fixedVisibleRowCount = Grid.VisibleRows.Count;
      else
        fixedVisibleRowCount = VisibleRowCount;

      int maxRowsHeight = fixedVisibleRowCount * defRowHeight;

      Rectangle gridScreenRect = Grid.RectangleToScreen(new Rectangle(Point.Empty, Grid.Size));
      Screen myScreen = Screen.FromRectangle(gridScreenRect);
      Rectangle workArea = myScreen.WorkingArea;
      if (gridScreenRect.Top + gridBordersHeight + maxRowsHeight > workArea.Bottom)
      {
        maxRowsHeight = workArea.Bottom - gridScreenRect.Top - gridBordersHeight;
        int newRows = maxRowsHeight / defRowHeight;
        maxRowsHeight = newRows * defRowHeight;
      }

      if (heightLow > maxRowsHeight) heightLow = maxRowsHeight;
      if (heightHigh > maxRowsHeight) heightHigh = maxRowsHeight;

      int deltaToLow = Math.Abs(heightLow - gridNewClientHeight);
      int deltaToHigh = Math.Abs(heightHigh - gridNewClientHeight);

      if (deltaToLow < deltaToHigh)
        result = heightLow + gridBordersHeight;
      else
        result = heightHigh + gridBordersHeight;

      return result;
    }

    protected internal virtual void OnCloseUpNeeded(PopupListCloseUpNeededEventArgs e)
    {
      var eh = this.Events[EventKeyCloseUpNeeded] as EventHandler<PopupListCloseUpNeededEventArgs>;
      if (eh != null)
        eh(this, e);
    }
    #endregion <methods
  }

  [ToolboxItem(false)]
  public class ComboBoxPopupDataGrid : PopupDataGrid
  {
    public ComboBoxPopupDataGrid(PopupDataGridForm gridForm) : base(gridForm)
    {
      ColumnOptions.CacheDisplayValues = true;
    }

    #region >properties
    public new ComboBoxPopupDataGridForm GridForm
    {
      get
      {
        return (ComboBoxPopupDataGridForm)base.GridForm;
      }
    }

    public ComboBoxEh ComboBox
    {
      get
      {
        return GridForm.ComboBox;
      }
    }
    #endregion <properties

    #region >methods
    protected override PropertyAxisBar CreatePropBarForListItemType(Type type)
    {
      Type columnType = ComboBoxManager.DefaultManager.GetMainColumnType();
      DataGridColumn column = (DataGridColumn)Activator.CreateInstance(columnType);
      return column;
    }

    protected internal override void HandleFormatParamsNeededEvent(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
      GridForm.ComboBox.DropDownBox.HandleFormatParamsNeededEvent(e);
    }

    protected internal override void HandleDataCellPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      GridForm.ComboBox.DropDownBox.HandleDataCellPaintEvent(e);
    }

    protected override bool ListItemIsSelectable(object sourceItem)
    {
      return ComboBox.ListItemIsSelectable(sourceItem);
    }
    #endregion <methods
  }

  /// <summary>
  /// Form drop-down list for ComboBoxEh.
  /// </summary>
  [ToolboxItem(false)]
  public class ComboBoxPopupDataGridForm : PopupDataGridForm
  {
    public ComboBoxPopupDataGridForm(ComboBoxEh comboBox) : base()
    {
      this.ComboBox = comboBox;
    }

    #region >properties
    public ComboBoxEh ComboBox { get; internal set; }
    #endregion <properties

    #region >methods
    protected override PopupDataGrid CreatePopupDataGrid()
    {
      return new ComboBoxPopupDataGrid(this);
    }

    protected internal override void OnCloseUpNeeded(PopupListCloseUpNeededEventArgs e)
    {
      base.OnCloseUpNeeded(e);
      ComboBox.CloseUp(e.AcceptValue);
    }
    #endregion <methods
  }

  /// <summary>
  /// Control to hold and paint cutrom area of ComboBoxEh
  /// </summary>
  [ToolboxItem(false)]
  public class ComboBoxCustomAreaControl : Control
  {
    private ComboBoxEh comboBox;

    public ComboBoxCustomAreaControl(ComboBoxEh comboBox)
    {
      this.comboBox = comboBox;
      SetStyle(ControlStyles.Selectable, false);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
      var pe = new ComboBoxCustomAreaPaintEventArgs(e.Graphics, ClientRectangle, comboBox.SelectedItem);
      comboBox.OnCustomAreaPaint(pe);
    }
  }

  [DataGridColumnDesignTimeVisible(false)]
  public class ComboBoxTextColumn : DataGridTextColumn
  {
    public ComboBoxTextColumn()
    {

    }

    #region Properties
    #endregion

    #region methods
    protected override BaseDataCellManager CreateTemplateCell()
    {
      return new PopupDataGridDataCellManager();
    }
    #endregion
  }

  //[DataGridDataCellDesignTimeVisible(false)]
  [DataCellDesignTimeVisible(false)]
  [ToolboxItem(false)]
  public class PopupDataGridDataCellManager : TextDataCellManager
  {

    #region privates
    #endregion

    public PopupDataGridDataCellManager()
    {
    }

    #region properties
    public ComboBoxEh ComboBox
    {
      get
      {
        return ((ComboBoxPopupDataGrid)BoundGrid).ComboBox;
      }
    }
    #endregion

    #region methods
    #endregion
    protected internal override void OnPaintContent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      Rectangle cellContentRect = e.CellContentRect;
      object listItem = null;
      if (e.ListItemBar != null)
      {
        listItem = ComboBox.GetListItemByIndex(((DataGridRow)e.ListItemBar).Index);
        //listItem = ComboBox.GetListItemValue(item);
      }

      if (ComboBox.Compound == ComboBoxCompound.CustomAreaAndTextEditor)
      {
        Rectangle customAreaRect = e.CellContentRect;

        customAreaRect.Width = ComboBox.CustomAreaWidth;
        cellContentRect.Width = cellContentRect.Width - ComboBox.CustomAreaWidth;
        cellContentRect.X = cellContentRect.X + ComboBox.CustomAreaWidth;

        var ce = new ComboBoxCustomAreaPaintEventArgs(e.Graphics, customAreaRect, listItem);
        ComboBox.OnCustomAreaPaint(ce);
      }

      var te = new ComboBoxTextAreaPaintEventArgs(e, this, cellContentRect, listItem);
      ComboBox.OnTextAreaPaint(te);
    }

    protected internal virtual void InternalPaintTextContent(ComboBoxTextAreaPaintEventArgs e)
    {
      var ne = new DataAxisGridDataCellContentPaintEventArgs(e.CellPaintEventArgs.ParentCellPaintArgs, e.AreaRect);
      base.OnPaintContent(ne);
    }

  }

  public class ComboBoxCustomAreaPaintEventArgs : EventArgs
  {
    private Graphics graphics;
    private Rectangle areaRect;
    private object listItem;
    private bool handled;

    public ComboBoxCustomAreaPaintEventArgs(Graphics graphics, Rectangle areaRect, object listItem)
    {
      this.graphics = graphics;
      this.areaRect = areaRect;
      this.listItem = listItem;
    }

    public Graphics Graphics
    {
      get { return this.graphics; }
    }

    public Rectangle AreaRect
    {
      get { return this.areaRect; }
    }

    public object ListItem
    {
      get { return this.listItem; }
    }

    public bool Handled
    {
      get
      {
        return handled;
      }
      set
      {
        handled = value;
      }
    }

  }

  public class ComboBoxTextAreaPaintEventArgs : EventArgs
  {
    private Rectangle areaRect;
    private object comboValue;
    private DataAxisGridDataCellContentPaintEventArgs cellPaintEventArgs;
    private bool handled;
    private BaseGridCellManager cellManager;

    public ComboBoxTextAreaPaintEventArgs(DataAxisGridDataCellContentPaintEventArgs cellPaintEventArgs,
      BaseGridCellManager cellManager, Rectangle areaRect, object comboValue)
    {
      this.cellPaintEventArgs = cellPaintEventArgs;
      this.cellManager = cellManager;
      this.areaRect = areaRect;
      this.comboValue = comboValue;
    }

    public DataAxisGridDataCellContentPaintEventArgs CellPaintEventArgs
    {
      get { return this.cellPaintEventArgs; }
    }

    public Graphics Graphics
    {
      get { return this.cellPaintEventArgs.Graphics; }
    }

    public Rectangle AreaRect
    {
      get { return this.areaRect; }
    }

    public object ComboValue
    {
      get { return this.comboValue; }
    }

    public BaseGridCellManager CellManager
    {
      get { return this.cellManager; }
    }

    public bool Handled
    {
      get
      {
        return handled;
      }
      set
      {
        handled = value;
      }
    }

    public void DrawContent(ComboBoxTextAreaPaintEventArgs e)
    {
      ((PopupDataGridDataCellManager)CellManager).InternalPaintTextContent(e);
    }

  }

  public class ComboBoxListItemStatusNeededEventArgs : EventArgs
  {

    public ComboBoxListItemStatusNeededEventArgs(object listItem)
    {
      ListItem = listItem;
      Selectable = true;
    }

    public object ListItem
    {
      get;
      private set;
    }

    public bool Selectable
    {
      get;
      set;
    }

    //public bool Handled
    //{
    //  get;
    //  set;
    //}
  }

  public class PopupListCloseUpNeededEventArgs : EventArgs
  {

    public PopupListCloseUpNeededEventArgs(bool acceptValue)
    {
      AcceptValue = acceptValue;
    }

    public bool AcceptValue { get; internal set; }
  }

  public class PopupListClosedUpEventArgs : EventArgs
  {

    public PopupListClosedUpEventArgs(bool acceptValue, object selectedItem)
    {
      AcceptValue = acceptValue;
      SelectedItem = selectedItem;
    }

    public bool AcceptValue { get; set; }

    public object SelectedItem { get; internal set; }
  }
}
