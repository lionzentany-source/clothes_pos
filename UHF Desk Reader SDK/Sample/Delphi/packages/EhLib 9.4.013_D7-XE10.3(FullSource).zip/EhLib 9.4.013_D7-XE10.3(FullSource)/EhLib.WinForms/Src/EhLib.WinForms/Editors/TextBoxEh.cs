﻿//------------------------------------------------------------------------------
// <copyright file=”TextBoxEh.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Design;
using System.Reflection;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  /// <summary>
  /// Represents a Windows text box control. Enables the user to enter text, and provide multiline 
  /// editing and password character masking.
  /// </summary>
  [DesignerCategory("Code")]
  [Designer("EhLib.WinForms.Design.TextBoxEhDesigner" + EhLibUtils.EhLibDesignDesignerVersionInfo)]
  [ToolboxItem(true)]
  [ToolboxBitmap(typeof(TextBoxEh), "ToolboxBitmaps.EhLib_TextBox.bmp")]
  [Description("Enables the user to enter text, and provide multiline editing and password character masking")]
  //public class TextBoxEh : ContainerControl
  public class TextBoxEh : BaseTextBoxEh
  {
    #region constructor
    public TextBoxEh()
    {
    }
    #endregion

    #region design-time properties
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public new EditButton EditButton
    {
      get
      {
        return base.EditButton;
      }
      //set
      //{
      //  base.EditButton = value;
      //}
    }

    [DefaultValue(false)]
    public new bool AcceptsReturn
    {
      get { return TextBoxControl.AcceptsReturn; }
      set { TextBoxControl.AcceptsReturn = value; }
    }

    //[Browsable(true)]
    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    //[Editor("System.Windows.Forms.Design.ListControlStringCollectionEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(UITypeEditor))]
    //[EditorBrowsable(EditorBrowsableState.Always)]
    //[Localizable(true)]
    //public new AutoCompleteStringCollection AutoCompleteCustomSource
    //{
    //  get { return TextBoxControl.AutoCompleteCustomSource; }
    //  set { TextBoxControl.AutoCompleteCustomSource = value; }
    //}

    //[Browsable(true)]
    //[DefaultValue(AutoCompleteMode.None)]
    //[EditorBrowsable(EditorBrowsableState.Always)]
    //public new AutoCompleteMode AutoCompleteMode
    //{
    //  get { return TextBoxControl.AutoCompleteMode; }
    //  set { TextBoxControl.AutoCompleteMode = value; }
    //}

    //[Browsable(true)]
    //[DefaultValue(AutoCompleteSource.None)]
    //[EditorBrowsable(EditorBrowsableState.Always)]
    //// TODO: ? [TypeConverter(typeof(TextBoxAutoCompleteSourceConverter))]
    //public new AutoCompleteSource AutoCompleteSource
    //{
    //  get { return TextBoxControl.AutoCompleteSource; }
    //  set { TextBoxControl.AutoCompleteSource = value; }
    //}

    [DefaultValue(CharacterCasing.Normal)]
    public new CharacterCasing CharacterCasing
    {
      get { return TextBoxControl.CharacterCasing; }
      set { TextBoxControl.CharacterCasing = value; }
    }

    //[Description("TextBoxMultilineDescr")]
    [Category("Behavior")]
    [DefaultValue(false)]
    [Localizable(true)]
    [RefreshProperties(RefreshProperties.All)]
    public new bool Multiline
    {
      get { return base.Multiline; }
      set { base.Multiline = value; }
    }

    [DefaultValue('\0')]
    [Localizable(true)]
    [RefreshProperties(RefreshProperties.Repaint)]
    public new char PasswordChar
    {
      get { return TextBoxControl.PasswordChar; }
      set { TextBoxControl.PasswordChar = value; }
    }

    [DefaultValue(ScrollBars.None)]
    [Localizable(true)]
    public ScrollBars ScrollBars
    {
      get { return TextBoxControl.ScrollBars; }
      set { TextBoxControl.ScrollBars = value; }
    }

    [DefaultValue(HorizontalAlignment.Left)]
    [Localizable(true)]
    public new HorizontalAlignment TextAlign
    {
      get { return TextBoxControl.TextAlign; }
      set { TextBoxControl.TextAlign = value; }
    }

    [DefaultValue(false)]
    [RefreshProperties(RefreshProperties.Repaint)]
    public new bool UseSystemPasswordChar
    {
      get { return TextBoxControl.UseSystemPasswordChar; }
      set { TextBoxControl.UseSystemPasswordChar = value; }
    }

    [DefaultValue(false)]
    public new bool AcceptsTab
    {
      get { return base.AcceptsTab; }
      set { base.AcceptsTab = value; }
    }

    //public override Color BackColor
    //{
    //  get { return base.BackColor; }
    //  set { base.BackColor = value; }
    //}

    //public override Color ForeColor
    //{
    //  get { return base.ForeColor; }
    //  set { base.ForeColor = value; }
    //}

    //[Browsable(false)]
    //[EditorBrowsable(EditorBrowsableState.Never)]
    //public override Image BackgroundImage { get; set; }

    //[Browsable(false)]
    //[EditorBrowsable(EditorBrowsableState.Never)]
    //public override ImageLayout BackgroundImageLayout { get; set; }

    [DefaultValue(true)]
    public new bool HideSelection
    {
      get { return base.HideSelection; }
      set { base.HideSelection = value; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Editor("System.Windows.Forms.Design.StringArrayEditor, System.Design, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(UITypeEditor))]
    [Localizable(true)]
    [MergableProperty(false)]
    public new string[] Lines
    {
      get { return base.Lines; }
      set { base.Lines = value; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public new TextAutoCompleting AutoCompleting
    {
      get
      {
        return base.AutoCompleting;
      }
    }

    //[Browsable(false)]
    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    //public new bool Modified
    //{
    //  get { return base.Modified; }
    //  set { base.Modified = value; }
    //}

    //[Browsable(false)]
    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    //[EditorBrowsable(EditorBrowsableState.Never)]
    //public Padding Padding { get; set; }

    [DefaultValue(true)]
    [Localizable(true)]
    public new bool WordWrap
    {
      get { return base.WordWrap; }
      set { base.WordWrap = value; }
    }
    #endregion <design-time properties

    #region >run-time properties
    [Browsable(false)]
    public new TextAutoCompletingManager CompletingManager
    {
      get { return base.CompletingManager; }
    }

    [Browsable(false)]
    [DefaultValue(true)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    [Localizable(true)]
    [RefreshProperties(RefreshProperties.Repaint)]
    public override bool AutoSize
    {
      get { return base.AutoSize; }
      set { base.AutoSize = value; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public new bool CanUndo
    {
      get { return base.CanUndo; }
    }
    #endregion

    #region internal properties
    protected internal new TextBox TextBoxControl
    {
      get
      {
        return (TextBox)EditControl;
      }
    }
    #endregion

    #region public methods
    #endregion

    #region internal methos
    protected override void OnKeyDown(KeyEventArgs e)
    {
      base.OnKeyDown(e);

      //if (!e.Handled)
      //{
      //  switch (e.KeyCode)
      //  {
      //    case Keys.Enter:
      //      e.SuppressKeyPress = !TextBoxControl.AcceptsReturn;
      //      break;
      //  }
      //}
    }

    protected override void OnKeyPress(KeyPressEventArgs e)
    {
      base.OnKeyPress(e);

      if (!e.Handled)
      {
        switch (e.KeyChar)
        {
          case (char)Keys.Enter:
            if (!TextBoxControl.AcceptsReturn)
            {
              SelectAll();
              e.Handled = true;
            }
            break;

          case (char)Keys.Escape:
            if (!TextBoxControl.AcceptsReturn)
            {
              e.Handled = true;
            }
            break;
        }

      }
    }
    #endregion

  }
}
