﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Drawing.Drawing2D;

namespace EhLib.WinForms
{

  /// <summary>
  /// Contains properties for customizing title column in <see cref="DataVertGridEh"/>.
  /// </summary>
  /// <remarks>
  /// You can retrieve an instance of this class through the <see cref="DataVertGridEh.TitleColumn"/> property.
  /// </remarks>
  public class DataVertGridTitleColumn : DataAxisGridTitleBar
  {
    #region privates
    internal bool WidthStored;
    private int width = -1;
    #endregion

    public DataVertGridTitleColumn(DataAxisGrid grid) : base(grid)
    {
      DefaultPadding = new Padding(2, 2, 2, 2);
    }

    #region design-time properties
    public int Width
    {
      get
      {
        if (WidthStored)
          return width;
        else
          return DefaultWidth;
      }
      set
      {
        if ((WidthStored == false) || (width != value))
        {
          WidthStored = true;
          width = value;
          OnWidthChanged();
        }
      }
    }
    #endregion

    #region runtime properties
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public virtual int DefaultWidth
    {
      get
      {
        return Grid.ClientBounds.Width / 2;
      }
    }

    [Browsable(false)]
    public new DataVertGridEh Grid
    {
      get { return (DataVertGridEh)base.Grid; }
    }
    #endregion

    #region Methods
    protected override Color GridLineDefaultColor(GridLine gl)
    {
      if (Grid != null)
        return Grid.GridLineColors.DarkColor;
      else
        return Color.Empty;
    }

    protected override bool GridLineDefaultVisible(GridLine gl)
    {
      return true;
    }

    private void OnWidthChanged()
    {
      Grid.TitleColumnWidthChanged();
    }

    protected override void WrapModeChanged()
    {
      Grid.GridLayoutChanged();
    }

    protected override void FontChanged()
    {
      Grid.UpdateRowHeights();
      Grid.Invalidate();
    }
    #endregion
  }
}