﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  /// <summary>
  /// Represents a Windows rich text box control. 
  /// RichTextBoxEh allows you to edit content at design time and save as design resource.
  /// </summary>
  [System.ComponentModel.DesignerCategory("Code")]
  [Designer("EhLib.WinForms.Design.RichTextBoxEhDesigner" + EhLibUtils.EhLibDesignDesignerVersionInfo)]
  [ToolboxItem(true)]
  //[ToolboxBitmap(typeof(NumericBoxEh), "ToolboxBitmaps.EhLib_NumericBox.bmp")]
  public class RichTextBoxEh : RichTextBox
  {

    public RichTextBoxEh()
    {

    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public override string Text { get; set; }

    [Browsable(true)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
    public new string Rtf
    {
      get { return base.Rtf; }
      set { base.Rtf = value; }
    }

  }
}
