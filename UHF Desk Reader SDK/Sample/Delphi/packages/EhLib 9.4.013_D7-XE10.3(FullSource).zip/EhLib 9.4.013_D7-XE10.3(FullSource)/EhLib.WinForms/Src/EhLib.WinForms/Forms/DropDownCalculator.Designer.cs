﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

namespace EhLib.WinForms
{
  partial class DropDownCalculator
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.calculatorControl1 = new CalculatorControl();
      this.SuspendLayout();
      // 
      // calculatorControl1
      // 
      this.calculatorControl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.calculatorControl1.Location = new System.Drawing.Point(0, 0);
      this.calculatorControl1.Name = "calculatorControl1";
      this.calculatorControl1.ReadOnly = false;
      this.calculatorControl1.Size = new System.Drawing.Size(233, 165);
      this.calculatorControl1.TabIndex = 2;
      this.calculatorControl1.Value = new decimal(new int[] {
            0,
            0,
            0,
            0});
      this.calculatorControl1.OkButtonPressed += new System.EventHandler(this.calculatorControl1_OkButtonPressed);
      // 
      // DropDownCalculator
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.ClientSize = new System.Drawing.Size(284, 262);
      this.Controls.Add(this.calculatorControl1);
      this.KeyPreview = true;
      this.Name = "DropDownCalculator";
      this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DropDownCalculator_KeyDown);
      this.Controls.SetChildIndex(this.calculatorControl1, 0);
      this.ResumeLayout(false);

    }

    #endregion

    private CalculatorControl calculatorControl1;
  }
}
