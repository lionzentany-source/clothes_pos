﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2019 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// DataValueSource
  /// </summary>
  public enum DataValueSource
  {
    /// <summary>
    ///  The initial value is taken from the list item property.
    /// </summary>
    DataProperty,

    /// <summary>
    ///  The initial value is taken from the list item itself. 
    ///  Usually used in the lists consisting of the elementary types.
    /// </summary>
    ListItem
  }

  /// <summary>
  /// State of row in the grid
  /// </summary>
  public enum RowEditState
  {
    Browse, Edit, New
  }

  internal enum NewRowEditState
  {
    Unchanged, Browse, Edit, New
  }

  /// <summary>
  /// Possible reactions when keyboard button is pressed.
  /// </summary>
  public enum GridKeyboardAction
  {
    None, OpenEditor, OpenCloseEditor, NextRowCell, NextColCell,
  }

  /// <summary>
  /// Specifies how to build the context menu. 
  /// The final context menu can be composed of several intermediate context menus.
  /// </summary>
  public enum ContextMenuBuildingMode
  {
    ContextMenuStripPropertyDefined,
    LocalAndGlobalMenuCompound,
    LocalMenuCompound
    //ContextMenuStripPropertyOrCompoundGlobal
  }

  /// <summary>
  /// Interface for accessing internal methods and properties of a <see cref="DataAxisGrid "/> class. 
  /// </summary>
  public interface IDataAxisGridInternal
  {
    bool IsInEndInit();
    void ResetViewOrderedPropBars();
    void SetPropBarsOrderFromViewOrderedBars();
  }

  //public interface IDataCellHolder
  //{
  //  Type GetValueDataType();
  //  Color GetBackColor();
  //  PropertyDescriptor GetPropertyDescriptor();

  //  void OnDataCellContentClick(DataGridDataCellEventArgs e);
  //}

  /// <summary>
  /// Interface that should be supported by DataGrid cell editor to be able be shown in the cell and edit cell value
  /// <seealso cref="DataAxisGridComboBoxEditControl"/>
  /// <seealso cref="DataAxisGridDateTimeBoxEditControl"/>
  /// <seealso cref="DataAxisGridMaskedTextBoxEditControl"/>
  /// <seealso cref="DataAxisGridTextBoxEditControl"/>
  /// </summary>
  public interface IDataAxisGridCellInPlaceEditor
  {
    /// <summary>
    /// Gets or sets the editor grid owner of the editor. The value is set in the grid ShowEditor method.
    /// </summary>
    DataAxisGrid EditorOwnerGrid
    {
      get;
      set;
    }

    /// <summary>
    /// Gets or sets the editor value.
    /// </summary>
    object EditorEditValue
    {
      get;
      set;
    }

    /// <summary>
    /// Gets or sets the index of the table row wher editor is shown. The value is set in the grid ShowEditor method.
    /// </summary>
    int EditorTableRowIndex
    {
      get;
      set;
    }

    /// <summary>
    /// Gets or sets a value indicating that  the editor value was changed. 
    /// The editor code should set the property to true when user makes any changes in the editor.
    /// </summary>
    bool EditorValueChanged
    {
      get;
      set;
    }

    /// <summary>
    /// Gets or sets the cell manager. The value is set in the grid ShowEditor method.
    /// </summary>
    BaseDataCellManager CellManager
    {
      get;
      set;
    }

    /// <summary>
    /// Gets or sets the exitor extra information. The value is set in the grid ShowEditor method.
    /// </summary>
    DataAxisGridDataCellEditorOccupyEventArgs CellPosData
    {
      get;
      set;
    }

    bool EditorWantsInputKey(Keys keyData, bool dataGridWantsInputKey);

    void PrepareEditorForEdit(bool selectAll);
  }

  /// <summary>
  /// Base class for <see cref="DataGridEh"/> and <see cref="DataVertGridEh"/>
  /// </summary>
  /// <remarks>
  /// The class sets the abstractions for such concepts as 
  /// a <see cref="PropertyAxisBar"/> and <see cref="DataAxisGridListItemBar"/> which 
  /// in <see cref="DataGridEh"/> turnes into <see cref="DataGridColumn"/> and <see cref="DataGridRow"/>, respectively; and 
  /// in <see cref="DataVertGridEh"/> into <see cref="DataVertGridRow"/> and <see cref="DataVertGridColumn"/>.
  /// </remarks>
  [DesignerCategory("Code")]
  [ToolboxItem(false)]
  [ComplexBindingProperties("DataSource", "DataMember")]
  public class DataAxisGrid : BaseGridControl, IDataAxisGridInternal
  {
    #region private consts
    private const string ErrorCaptionMessage = "Error";
    private static readonly object EventKeyPaint = new object();
    #endregion

    #region privates
    private readonly DataAxisGridStaticPropBarCollection staticPropBars;

    private readonly DataAxisGridMainPropBarCollection propBars;
    private readonly List<PropertyAxisBar> propBarsList;

    private readonly DataAxisGridReadOnlyPropBarCollection dynamicPropBars;
    private readonly List<PropertyAxisBar> dynamicPropBarsList;

    private readonly DataAxisGridReadOnlyPropBarCollection viewOrderedPropBars;
    private readonly List<PropertyAxisBar> viewOrderedPropBarsList;
    protected List<PropertyAxisBar> OldViewOrderedPropBarsList;

    private readonly DataAxisGridReadOnlyPropBarCollection visiblePropBars;
    private readonly List<PropertyAxisBar> visiblePropBarsList;

    private bool readOnly;
    private int layoutSuspendCount;
    private bool gridLayoutChanged;
    private bool gridLayoutPerforming;
    private bool inBindingContextChanged;
    //private bool handleCreated;

    protected internal bool EditorDataPushing;
    private bool inValidatingCode;

    private DataAxisGridTitleBar titleBar;
    private DataAxisGridDataLink dataLink;

    private bool autoGeneratePropBars;
    private bool autoGeneratePropBarsStored;
    MouseHoverToolTip cellNonfitToolTip;
    MouseHoverToolTip cellHintToolTip;

    private Type cellEditControlType;
    //private bool editorTextWasChanged;
    private bool passNextCharMessageInEditControl;

    private GridKeyboardOptions keyboardOptions;
    #endregion privates

    public DataAxisGrid()
    {
      //staticPropBars = new DataAxisGridStaticPropBarCollection(this);
      staticPropBars = CreateStaticPropBarCollection();

      propBarsList = new List<PropertyAxisBar>();
      propBars = CreatePropBarMainCollection(propBarsList);

      dynamicPropBarsList = new List<PropertyAxisBar>();
      dynamicPropBars = CreatePropBarReadOnlyCollection(dynamicPropBarsList);

      viewOrderedPropBarsList = new List<PropertyAxisBar>();
      viewOrderedPropBars = CreatePropBarReadOnlyCollection(viewOrderedPropBarsList);

      visiblePropBarsList = new List<PropertyAxisBar>();
      visiblePropBars = CreatePropBarReadOnlyCollection(visiblePropBarsList);
    }

    protected override void Dispose(bool disposing)
    {
      Disposing = true;

      DoDispose(disposing);

      base.Dispose(disposing);
      Disposing = false;
    }

    protected virtual void DoDispose(bool disposing)
    {
      if (disposing)
      {
        for (int i = StaticPropBars.Count - 1; i >= 0; i--)
        {
          StaticPropBars[i].Dispose();
        }

        StaticPropBars.Clear();
        if (cellNonfitToolTip != null)
        {
          cellNonfitToolTip.Dispose();
          cellNonfitToolTip = null;
        }
      }
    }
  
    #region properties
    [Browsable(false)]
    public new bool Disposing
    {
      get;
      private set;
    }


    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataAxisGridStaticPropBarCollection StaticPropBars
    {
      get { return staticPropBars; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected internal DataAxisGridReadOnlyPropBarCollection DynamicPropBars
    {
      get { return dynamicPropBars; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected internal DataAxisGridMainPropBarCollection PropBars
    {
      get { return propBars; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected internal DataAxisGridReadOnlyPropBarCollection ViewOrderedPropBars
    {
      get { return viewOrderedPropBars; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected internal DataAxisGridReadOnlyPropBarCollection VisiblePropBars
    {
      get { return visiblePropBars; }
    }

    //DataSource & DataMember
    [TypeConverter("System.Windows.Forms.Design.DataSourceConverter, System.Design")]
    [Category("Data")]
    [DefaultValue(null)]
    public object DataSource
    {
      get { return DataLink.DataSource; }
      set { DataLink.DataSource = value; }
    }

    [Category("Data")]
    [Editor("System.Windows.Forms.Design.DataMemberListEditor, System.Design", "System.Drawing.Design.UITypeEditor, System.Drawing")]
    [DefaultValue(null)]
    public string DataMember
    {
      get { return DataLink.DataMember; }
      set { DataLink.DataMember = value; }
    }

    [Browsable(false)]
    public virtual int CurrentDataColIndex
    {
      get { return Col; }
    }

    [Browsable(false)]
    public virtual int CurrentDataRowIndex
    {
      get { return Row; }
    }
    //Other
    protected internal bool EditorBanned { get; set; }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public new bool DesignMode
    {
      get { return base.DesignMode; }
    }

    [DefaultValue(false)]
    protected bool AutoGeneratePropBars
    {
      get
      {
        if (autoGeneratePropBarsStored)
          return autoGeneratePropBars;
        else
          return DefaultAutoGeneratePropBars();
      }

      set
      {
        if (autoGeneratePropBars != value || !autoGeneratePropBarsStored)
        {
          autoGeneratePropBars = value;
          autoGeneratePropBarsStored = true;
          if (!InInitialization)
            UpdatePropBarsList();
        }
      }
    }

    [DefaultValue(false)]
    public bool ReadOnly
    {
      get
      {
        return readOnly;
      }

      set
      {
        if (readOnly != value)
        {
          readOnly = value;
          OnReadOnlyChanged(EventArgs.Empty);
        }
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    protected internal DataAxisGridTitleBar TitleBar
    {
      get
      {
        if (titleBar == null)
          titleBar = CreateTitleBar();
        return titleBar;
      }
    }

    [Browsable(false)]
    [DefaultValue(false)]
    public CurrencyManager CurrencyManager
    {
      get { return DataLink.CurrencyManager; }
    }

    protected internal DataAxisGridDataLink DataLink
    {
      get
      {
        if (dataLink == null)
          dataLink = CreateDataLink();
        return dataLink;
      }
    }

    protected internal virtual PropertyAxisBar CurrentPropBar
    {
      get { return null; }
    }

    protected internal virtual DataAxisGridListItemBar CurrentListItemBar
    {
      get { return null; }
    }

    /// <summary>
    /// Contains properties for customizing respond on pressing some keys.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    protected GridKeyboardOptions KeyboardOptions
    {
      get
      {
        if (keyboardOptions == null)
          keyboardOptions = CreateKeyboardOptions();

        return keyboardOptions;
      }
    }

    protected Control CellEditControl
    {
      get;
      private set;
    }

    [Browsable(false)]
    public bool GridLayoutSuspend
    {
      get { return layoutSuspendCount > 0; }
    }
    #endregion

    #region events
    /// <summary>
    /// Occurs when the DataAxisGrid is redrawn.
    /// </summary>
    public new event EventHandler<ControlPaintEventArgs> Paint
    {
      add
      {
        Events.AddHandler(EventKeyPaint, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyPaint, value);
      }
    }
    #endregion

    #region methods

    //GridLayout
    public void SuspendGridLayout()
    {
      layoutSuspendCount += 1;
    }

    public void ResumeGridLayout(bool forcePerformLayout)
    {
      Debug.Assert(layoutSuspendCount > 0, "'ResumeGridLayout' happened before 'SuspendGridLayout'.");
      layoutSuspendCount = layoutSuspendCount - 1;

      if (layoutSuspendCount == 0 &&
          (gridLayoutChanged == true || forcePerformLayout == true)
         )
      {
        GridLayoutChanged();
      }
    }

    public void ResumeGridLayout()
    {
      ResumeGridLayout(false);
    }

    public void GridLayoutChanged()
    {
      if (GridLayoutSuspend || InInitialization || /*!IsHandleCreated || */gridLayoutPerforming)
      {
        gridLayoutChanged = true;
        return;
      }

      gridLayoutPerforming = true;
      try
      {
        gridLayoutChanged = false;
        PerformGridLayout();
      }
      finally
      {
        gridLayoutPerforming = false;
      }

      if (gridLayoutChanged)
      {
        gridLayoutPerforming = true;
        try
        {
          gridLayoutChanged = false;
          PerformGridLayout();
        }
        finally
        {
          gridLayoutPerforming = false;
        }
      }
    }

    protected virtual void PerformGridLayout()
    {
      foreach (PropertyAxisBar bar in VisiblePropBars)
      {
        bar.PerformLayout();
      }
      gridLayoutChanged = false;
    }

    //AutoGeneratePropBars
    protected virtual bool DefaultAutoGeneratePropBars()
    {
      return StaticPropBars.Count == 0;
    }

    protected virtual bool ShouldSerializeAutoGeneratePropBars()
    {
      return autoGeneratePropBarsStored;
    }

    protected virtual void ResetAutoGeneratePropBars()
    {
      autoGeneratePropBarsStored = false;
    }

    //Editor
    protected internal virtual void PrepareForShowEditor()
    {

    }

    protected internal override void ShowEditor(bool selectAll)
    {
      Type newCellEditType;
      int localColIndex;
      int localRowIndex;
      DataAxisGridDataCellEditorParamsNeededEventArgs editorParams;
      IDataAxisGridCellInPlaceEditor iInPlaceEditor;

      BaseGridCellManager cellMan = CellManByColRow(Col, Row, out localColIndex, out localRowIndex);
      if (cellMan == null) return;

      BaseDataCellManager dataCellMan = cellMan as BaseDataCellManager;
      Debug.Assert(dataCellMan != null, "dataCellMan != null");

      bool canShowEditor = dataCellMan.CanShowEditor(this, Col, Row, localColIndex, localRowIndex);
      if (!canShowEditor) return;
      if (EditorBanned) return;

      editorParams = dataCellMan.GetCellEditorParams(this, Col, Row, localColIndex, localRowIndex);

      //if (!CanShowEditor()) return;
      if (EditorMode == true) return;
      //if (dataCellMan == null) return;
      //if (!editorParams.CanShowEditor) return;

      ClampInView(new GridCoord(Col, Row), true, true);

      newCellEditType = editorParams.EditorType;
      if (newCellEditType == null) return;

      OnShowEditor();
      if (newCellEditType != cellEditControlType)
      {
        if (CellEditControl != null)
        {
          CellEditControl.Dispose();
          CellEditControl = null;
        }
        CellEditControl = (Control)Activator.CreateInstance(newCellEditType);
        CellEditControl.Visible = false;
        Controls.Add(CellEditControl);
        ((IDataAxisGridCellInPlaceEditor)CellEditControl).EditorOwnerGrid = this;
        cellEditControlType = newCellEditType;
      }

      iInPlaceEditor = (IDataAxisGridCellInPlaceEditor)CellEditControl;
      cellMan.OccupyEditControl(this, CellEditControl, selectAll, editorParams);
      iInPlaceEditor.EditorValueChanged = false;
      iInPlaceEditor.CellManager = dataCellMan;

      UpdateCellEditorBounds();
      CellEditControl.Visible = true;

      EditorMode = true;
      //editorTextWasChanged = false;
      UpdateFocus();
    }

    protected virtual void OnShowEditor()
    {

    }

    protected internal override bool HideEditor(bool acceptValue)
    {
      //base.HideEditor();
      if (EditorMode == false) return true;
      if (CellEditControl == null) return true;
      if (acceptValue)
      {
        if (!PushEditorData())
        {
          UpdateFocus();
          return false;
        }
      }
      EditorMode = false;
      UpdateFocus();
      CellEditControl.Visible = false;
      CurrentCellMan.ReleaseEditControl(CellEditControl);
      DataLink.EditorClosed();
      //CellEditControl = null;
      //editorTextWasChanged = false;
      return true;
    }

    //protected internal virtual bool CanShowEditor()
    //{
    //  return false;
    //}

    protected internal virtual void EditorTextChanged(EventArgs e)
    {
      if (EditorMode)
      {
        //editorTextWasChanged = true;
        ClampInView(new GridCoord(Col, Row), true, true);
        DataLink.EditorValueChanged();
      }
    }

    protected internal virtual bool IsShowDataCellsNonfitTooltips()
    {
      return false;
    }

    internal virtual void InitCellEditControl()
    {

    }

    internal virtual void UpdateCellEditorBounds()
    {
      if (CellEditControl == null) return;

      //var custAreaMeasures = new CellCustomAreaMeasures();
      int areaColIndex;
      int areaRowIndex;
      Rectangle cellRect = CellRect(Col, Row);
      Rectangle cellCustomRect;
      Rectangle editorRect = cellRect;
      BaseGridCellManager cell = CellManByColRow(Col, Row, out areaColIndex, out areaRowIndex);
      BaseDataCellManager dataCell = cell as BaseDataCellManager;

      //cell.SetCellCustomAreaMeasures(Col, Row, areaColIndex, areaRowIndex, custAreaMeasures);
      //Rectangle editorRect = EhLibUtils.ReduceRectCellCustomAreaMeasures(cellRect, custAreaMeasures);

      if (dataCell != null)
      {
        PropertyAxisBar propAxisBar;
        DataAxisGridListItemBar listItemBar;

        dataCell.AxisObjectsByDataColRowIndex(this, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar);
        cellCustomRect = dataCell.GetCellCustomRect(propAxisBar, listItemBar, cellRect);
        editorRect = dataCell.GetCellClientRect(propAxisBar, listItemBar, cellCustomRect);
      }

      CellEditControl.Location = editorRect.Location;
      CellEditControl.Size = editorRect.Size;
    }

    internal virtual bool PushEditorData()
    {
      bool result = true;

      if ((EditorMode == true) &&
          (((IDataAxisGridCellInPlaceEditor)CellEditControl).EditorValueChanged == true))
      {
        EditorDataPushing = true;
        try
        {
          if (CellEditControl.Focused)
          {
            Form form = FindForm();
            if (form != null) form.Validate(true);
            //if (form != null) form.ValidateChildren();
          }
          object editorValue = ((IDataAxisGridCellInPlaceEditor)CellEditControl).EditorEditValue;
          PropertyAxisBar curPropBar = CurrentPropBar;

          result = SafePushValue(curPropBar, editorValue);
        }
        finally
        {
          EditorDataPushing = false;
        }
      }
      return result;
    }

    internal virtual bool SafePushValue(PropertyAxisBar propBar, object value)
    {
      bool result;
      Exception exception;

      result = PushValue(propBar, value, out exception);
      if (!result)
      {
        DataGridSetDataValueErrorEventArgs evArgs = new DataGridSetDataValueErrorEventArgs(exception);
        OnSetDataValueError(evArgs);
      }

      return result;
    }

    internal virtual bool PushValue(PropertyAxisBar propBar, object value, out Exception exception)
    {
      exception = null;
      try
      {
        SetDataValue(propBar, value);
      }
      catch (Exception e)
      {
        if (EhLibUtils.IsCriticalException(e))
        {
          throw;
        }
        exception = e;
        return false;
      }
      return true;
    }

    protected internal void SetDataValue(PropertyAxisBar propBar, object dataValue)
    {
      object parsedValue = propBar.ParseValue(CurrentListItemBar, dataValue);
      DataLink.BeginCurrentEdit();
      propBar.SetValue(CurrentListItemBar, parsedValue);
    }

    protected internal virtual void InteractiveSetDataValue(PropertyAxisBar propBar, object dataValue)
    {
      SetDataValue(propBar, dataValue);
      SetDataValue(propBar, dataValue);
    }

    protected internal virtual bool DefaultAllowShowEditor()
    {
      return false;
    }

    protected internal virtual void OnEditorKeyDown(DataAxisGridEditorKeyEventArgs ke)
    {
    }

    //Focus
    protected internal override void FocusGrid()
    {
      if (EditorMode == true)
        CellEditControl.Focus();
      else
        base.FocusGrid();
    }

    internal virtual void UpdateFocus()
    {
      if (EditorMode == true)
      {
        CellEditControl.Focus();
      }
      else
      {
        if ((CellEditControl != null) &&
           (CellEditControl.Focused == true))
        {
          Focus();
        }
      }
    }

    //Keyboard
    protected override bool ProcessKeyEventArgs(ref Message m)
    {
      if (m.Msg == NativeMethods.WM_SYSKEYDOWN || m.Msg == NativeMethods.WM_KEYDOWN)
      {
        passNextCharMessageInEditControl = false;
        //KeyEventArgs ke = new KeyEventArgs((Keys)(unchecked((int)(long)m.WParam)) | ModifierKeys);
        bool wmChatInQueue;
        Message charMsg;
        wmChatInQueue = EhLibUtils.PeekMessage(this, out charMsg, NativeMethods.WM_CHAR, NativeMethods.WM_CHAR, false);
        if (wmChatInQueue)
        {
          KeyPressEventArgs ke = new KeyPressEventArgs(unchecked((char)(long)charMsg.WParam));
          if (ke.KeyChar == (char)Keys.Escape) return false;

          PrepareForShowEditor();
          BaseGridCellManager currentCell = CurrentCellMan;

          if ((currentCell != null) && currentCell.IsCharToEnterEditMode(ke))
          {
            ClampInView(new GridCoord(Col, Row), true, true);
            ShowEditor(true);
            if (EditorMode)
            {
              if (CellEditControl != null)
              {
                passNextCharMessageInEditControl = true;
                //EhLibUtils.SendMessage(this.cellEditControl, m.Msg, m.WParam, m.LParam);
                return true;
              }
            }
          }
        }
      }
      else if ((m.Msg == NativeMethods.WM_CHAR) &&
                (passNextCharMessageInEditControl == true) &&
                CellEditControl.Focused
                )
      {
        passNextCharMessageInEditControl = false;
        KeyPressEventArgs ke = new KeyPressEventArgs(unchecked((char)(long)m.WParam));
        SendKeys.Send(ke.KeyChar.ToString());
        //EhLibUtils.SendMessage(this.cellEditControl, m.Msg, m.WParam, m.LParam);
        return true;
      }
      return base.ProcessKeyEventArgs(ref m);
    }

    protected override bool ProcessKeyPreview(ref Message m)
    {
      return base.ProcessKeyPreview(ref m);
    }

    protected virtual bool ProcessF2Key(Keys keyData)
    {
      if (EditorMode == false)
      {
        ShowEditor(false);
        return true;
      }
      return false;
    }

    protected virtual bool ProcessEnterKey(Keys keyData)
    {
      if (KeyboardOptions.EnterKeyAction == GridKeyboardAction.OpenCloseEditor)
      {
        if (EditorMode == true)
        {
          bool saveData;
          IDataAxisGridCellInPlaceEditor ipe = CellEditControl as IDataAxisGridCellInPlaceEditor;
          if (ipe != null)
            saveData = ipe.EditorValueChanged;
          else
            saveData = true;
          HideEditor(saveData);
          ClampInView(new GridCoord(Col, Row), true, true);
        }
        else
        {
          ShowEditor(true);
        }
        return true;
      }
      else if (KeyboardOptions.EnterKeyAction == GridKeyboardAction.OpenEditor)
      {
        if (EditorMode == false)
        {
          ShowEditor(true);
          return true;
        }
      }
      else if (KeyboardOptions.EnterKeyAction == GridKeyboardAction.NextColCell)
      {
        GridMoveCellDirection direction;
        if ((keyData & Keys.Shift) == Keys.Shift)
          direction = GridMoveCellDirection.Backward;
        else
          direction = GridMoveCellDirection.Forward;

        bool result = NextCol(direction, true, true, false, true);
        return result;
      }

      return false;
    }

    protected virtual bool ProcessEscapeKey(Keys keyData)
    {
      if (EditorMode == true)
      {
        HideEditor(false);
        ClampInView(new GridCoord(Col, Row), true, true);
        return true;
      }

      if ((DataLink.CurrentListItemState == RowEditState.Edit) ||
          (DataLink.CurrentListItemState == RowEditState.New))
      {
        DataLink.CancelCurrentEdit();
        return true;
      }

      return false;
    }

    //Errors handling
    protected internal virtual void OnSetDataValueError(DataGridSetDataValueErrorEventArgs e)
    {
      string errorText = e.Exception.Message;
      MessageBox.Show(errorText, ErrorCaptionMessage, MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    //IDataAxisGridInternal

    bool IDataAxisGridInternal.IsInEndInit()
    {
      return InEndInit;
    }

    //Other
    protected override void RollPosChanged(long oldRowPosX, long oldRowPosY)
    {
      base.RollPosChanged(oldRowPosX, oldRowPosY);
      UpdateCellEditorBounds();
    }

    protected override void ColWidthsChanged()
    {
      base.ColWidthsChanged();
      UpdateCellEditorBounds();
    }

    protected override void RowHeightsChanged()
    {
      base.RowHeightsChanged();
      UpdateCellEditorBounds();
    }

    protected override void OnFontChanged(EventArgs e)
    {
      base.OnFontChanged(e);
      GridLayoutChanged();
    }

    protected override void OnHandleCreated(EventArgs e)
    {
      base.OnHandleCreated(e);
    }

    protected override void OnCreateControl()
    {
      base.OnCreateControl();
      GridLayoutChanged();
    }

    protected override void OnLayout(LayoutEventArgs levent)
    {
      base.OnLayout(levent);
      GridLayoutChanged();
    }

    protected virtual void OnReadOnlyChanged(EventArgs e)
    {
    }

    protected virtual GridKeyboardOptions CreateKeyboardOptions()
    {
      return new GridKeyboardOptions();
    }

    protected internal virtual bool PrepareChangeCellPos()
    {
      bool result;
      result = PushEditorData();
      if (result && EditorMode)
        HideEditor(false);
      return result;
    }

    protected override void OnBindingContextChanged(EventArgs e)
    {
      if (inBindingContextChanged) return;
      inBindingContextChanged = true;
      DataLink.TryDataBinding();
      base.OnBindingContextChanged(e);
      inBindingContextChanged = false;
    }

    protected internal virtual void PropertyAxisBarVisibleChanged(PropertyAxisBar propAxisBar, bool value)
    {
      if (PropBars.Updating) return;
      UpdatePropBarsView();
    }

    protected internal void CreateAutoGeneratedColumns()
    {
      List<PropertyAxisBar> oldDynaBarsList = new List<PropertyAxisBar>(dynamicPropBarsList);

      dynamicPropBarsList.Clear();

      if (CurrencyManager != null)
      {
        int colIndex = 0;

        Type listItemType = ListBindingHelper.GetListItemType(CurrencyManager.List);

        if (!ColumnValueSourceIsListItem(listItemType))
        {
          //foreach (PropertyDescriptor prop in CurrencyManager.GetItemProperties())
          DeepPropertyDescriptorCollection propCollection = DeepPropertyDescriptor.GetItemProperties(CurrencyManager, 
            DataGridManager.DefaultManager.DefaultPropertyDescriptorDepthLevel);
          foreach (DeepPropertyDescriptor prop in propCollection)
          {
            PropertyAxisBar oldPropBar = oldDynaBarsList.Find((pb) => Equals(pb.PropDescr, prop));
            //oldPropBar = null;
            if (oldPropBar != null)
            {
              dynamicPropBarsList.Add(oldPropBar);
              colIndex += 1;
            }
            else
            {

              PropertyAxisBar[] bars = CreateDynamicColumnsForDataProperty(prop);
              if (bars == null) continue;

              foreach (var bar in bars)
              {
                if (bar == null) continue;
                //bar.DataPropertyName = prop.Name;
                bar.DataPropertyName = prop.Path;
                bar.PropDescr = prop;
                bar.AutoGenerated = true;
                bar.Grid = this;
                InitDynaPropBar(bar, prop);

                dynamicPropBarsList.Add(bar);
                colIndex = colIndex + 1;
              }
            }
          }
        }
        else
        {
          PropertyAxisBar propBar = CreatePropBarForListItemType(listItemType);
          if (propBar != null)
          {
            propBar.DataValueSource = DataValueSource.ListItem;
            propBar.DataPropertyName = "";
            propBar.PropDescr = null;
            propBar.AutoGenerated = true;
            propBar.Grid = this;
            InitDynaPropBar(propBar, null);

            dynamicPropBarsList.Add(propBar);
          }
        }
      }
    }

    //protected virtual bool OnCheckIfCreateDynaColumnForDataProperty(PropertyDescriptor prop)
    //{
    //  PropertyAxisBar statPropBar = StaticPropBars.FindBarByDataProperty(prop.Name);
    //  if (statPropBar != null)
    //    return false;
    //  else
    //    return true;
    //}

    protected virtual PropertyAxisBar[] CreateDynamicColumnsForDataProperty(DeepPropertyDescriptor prop)
    {
      //PropertyAxisBar presentInStaticList = StaticPropBars.FindBarByDataProperty(prop.Name);
      PropertyAxisBar presentInStaticList = StaticPropBars.FindBarByDataProperty(prop.Path);

      DataAxisDynamicColumnsCreatingEventArgs e =
        GetDataAxisCreatingDynamicColumnsForDataPropertyEventArgs(prop, presentInStaticList != null);
      //var e = new DataAxisCreatingDynamicColumnsForDataPropertyEventArgs(this, prop, statPropBar != null);
      ProcessCreateDynamicPropBarsForDataPropertyEvent(e);
      if (!e.Handled)
        OnCreateDynamicPropBarsForDataProperty(e);
      return e.PropertyBars;
    }

    protected virtual DataAxisDynamicColumnsCreatingEventArgs GetDataAxisCreatingDynamicColumnsForDataPropertyEventArgs(
      DeepPropertyDescriptor propDescriptor, bool presentInStaticList)
    {
      return new DataAxisDynamicColumnsCreatingEventArgs(this, propDescriptor, presentInStaticList);
    }

    protected virtual void ProcessCreateDynamicPropBarsForDataPropertyEvent(DataAxisDynamicColumnsCreatingEventArgs e)
    {
    }

    protected internal virtual void OnCreateDynamicPropBarsForDataProperty(DataAxisDynamicColumnsCreatingEventArgs e)
    {
      if (e.PresentInStaticList)
      {
        e.PropertyBars = null;
      }
      else
      {
        e.PropertyBars = new PropertyAxisBar[1];
        e.PropertyBars[0] = CreatePropBarForDataProperty(e.PropertyDescriptor);
      }
    }

    protected virtual PropertyAxisBar CreatePropBarForDataProperty(DeepPropertyDescriptor prop)
    {
      return CreatePropBarFromType(prop.PropertyType);
    }

    protected virtual PropertyAxisBar CreatePropBarForListItemType(Type type)
    {
      return CreatePropBarFromType(type);
    }

    public virtual PropertyAxisBar CreatePropBarFromType(Type type)
    {
      return null;
    }

    public virtual Type GetAxisBarTypeForDataType(Type type)
    {
      return null;
    }

    protected virtual void InitDynaPropBar(PropertyAxisBar bar, DeepPropertyDescriptor prop)
    {
      DataTable dataTable = GetDataTable();

      if ((dataTable != null) && (dataTable.Columns[prop.ButtomPropDescr.Name] != null))
      {
        if (dataTable.Columns[prop.ButtomPropDescr.Name].MaxLength >= 0)
          bar.MaxLength = dataTable.Columns[prop.ButtomPropDescr.Name].MaxLength;
        else
          bar.MaxLength = 0;
      }
    }

    protected internal virtual void UpdatePropBarsList()
    {
      if (IsDisposed || Disposing) return;
      if (InInitialization) return;
      if (PropBars.Updating) return;

      //if (PropBars.Updating)
      //{
      //  PropBars.listGonnaChange = true;
      //  return;
      //}


      bool listChanged = false;

      PropertyAxisBar[] oldList = new PropertyAxisBar[propBarsList.Count];
      propBarsList.CopyTo(oldList);

      propBarsList.Clear();

      PropBars.ViewsUpdating = true;
      //PropBars.BeginUpdate();
      //try
      {
        //StaticColumns.RemoveAutoGeneratedColumns();

        foreach (PropertyAxisBar bar in StaticPropBars)
          propBarsList.Add(bar);

        if (AutoGeneratePropBars && !DesignMode)
        {
          CreateAutoGeneratedColumns();
          foreach (PropertyAxisBar bar in DynamicPropBars)
            propBarsList.Add(bar);
        }

        foreach (PropertyAxisBar bar in PropBars)
        {
          if (!string.IsNullOrEmpty(bar.DataPropertyName))
          {
            DeepPropertyDescriptor prop = null;
            //if (CurrencyManager != null)
            //{
            //  PropertyDescriptorCollection dataItemProps = CurrencyManager.GetItemProperties();
            //  prop = dataItemProps.Find(bar.DataPropertyName, true);
            //}
            prop = DeepPropertyDescriptor.GetDeepPropertyDescriptorFromPath(CurrencyManager, bar.DataPropertyName);
            if (prop != null)
            {
              bar.PropDescr = prop;
            }
            else
            {
              bar.PropDescr = null;
            }
          }
          bar.UpdatedInList();
        }

        if (propBarsList.Count != oldList.Length)
        {
          listChanged = true;
        }
        else
        {
          for (int i = 0; i < oldList.Length; i++)
          {
            if (oldList[i] != propBarsList[i])
            {
              listChanged = true;
              break;
            }
          }
        }

      }
      //finally
      //{
      //  PropBars.EndUpdate();
      //}

      if (listChanged)
        PropBarsListChanged();
      else
        UpdatePropBarsView();

      PropBars.ViewsUpdating = false;
    }

    protected internal void CheckPropBarsPropDescr()
    {
      //PropertyDescriptorCollection dataItemProps;
      DeepPropertyDescriptorCollection dataItemProps;

      if (CurrencyManager == null)
        dataItemProps = null;
      else
        //dataItemProps = CurrencyManager.GetItemProperties();
        dataItemProps = DeepPropertyDescriptor.GetItemProperties(CurrencyManager, 
          DataGridManager.DefaultManager.DefaultPropertyDescriptorDepthLevel);

      foreach (PropertyAxisBar bar in PropBars)
      {
        if (bar.PropDescr != null)
        {
          if (dataItemProps == null)
            //Debug.Fail("column.propDescr reference is inconsistent.");
            bar.PropDescr = null;
          //else if (dataItemProps.IndexOfButtomPropDescr(bar.PropDescr.ButtomPropDescr) < 0)
          else if (dataItemProps.IndexOfPropertyDescriptor(bar.PropDescr) < 0)
            Debug.Fail(Name + ". Column.PropDescr reference is inconsistent.");
        }
      }
    }

    protected virtual void PropBarsListChanged()
    {
      for (int i = 0; i < propBarsList.Count; i++)
        propBarsList[i].Index = i;

      OnPropBarsListChanged(EventArgs.Empty);

      UpdatePropBarsView();
    }

    protected virtual void OnPropBarsListChanged(EventArgs e)
    {
    }

    protected internal virtual void UpdatePropBarsView()
    {
      UpdateColumnsDisplayIndex();
    }

    protected void SetPropBarsDisplayOrder(Collection<PropertyAxisBar> newDisplayOrderedPropBars)
    {
      bool orderChagned = false;

      if (newDisplayOrderedPropBars.Count != ViewOrderedPropBars.Count)
        throw new InvalidOperationException("List of bars must be complete and not redundant.");

      IEnumerator<PropertyAxisBar> enmrt = newDisplayOrderedPropBars.GetEnumerator();
      for (int i = 0; enmrt.MoveNext(); i++)
      {
        PropertyAxisBar ordCol = enmrt.Current;
        if (!ViewOrderedPropBars.Contains(ordCol))
          throw new InvalidOperationException(string.Format("PropBar {0} not in the list", ordCol));
        if (ordCol != ViewOrderedPropBars[i])
        {
          orderChagned = true;
          break;
        }
      }
      enmrt.Dispose();

      if (orderChagned == false) return;

      for (int i = 0; i < newDisplayOrderedPropBars.Count; i++)
        newDisplayOrderedPropBars[i].DisplayIndexInternal = i;

      PropBarsDisplayIndexChanged();
    }

    protected internal void PropBarsDisplayIndexChanged()
    {
      if (InInitialization || PropBars.Updating) return;
      UpdatePropBarsView();
    }

    protected void UpdateColumnsDisplayIndex()
    {
      List<PropertyAxisBar> oldColList;
      var voColList = viewOrderedPropBarsList;

      if (OldViewOrderedPropBarsList != null)
        oldColList = OldViewOrderedPropBarsList;
      else
        oldColList = new List<PropertyAxisBar>(viewOrderedPropBarsList);

      voColList.Clear();

      FillPropBarsViewOrderedList(voColList);

      for (int i = 0; i < voColList.Count; i++)
      {
        PropertyAxisBar column = voColList[i];
        column.DisplayIndexInternal = i;
        column.NewColumn = false;
        //column.DisplayIndexQuery = false;
        //column.DisplayIndexQueryIndex = -1;
      }

      bool listChanged = false;

      if (voColList.Count != oldColList.Count)
        listChanged = true;
      else
      {
        for (int i = 0; i < voColList.Count; i++)
        {
          if (voColList[i] != oldColList[i])
          {
            listChanged = true;
            break;
          }
        }

      }

      if (listChanged)
        OnOrderedColumnsListChanged(new EventArgs());

      OldViewOrderedPropBarsList = null;
      UpdateVisibleColumns();
    }

    protected virtual void FillPropBarsViewOrderedList(List<PropertyAxisBar> voColList)
    {
      foreach (PropertyAxisBar propBar in PropBars)
      {
        voColList.Add(propBar);
        if (propBar.DisplayIndex < 0)
          propBar.DisplayIndexInternal = PropBars.Count + 1;
      }
      voColList.Sort(CompareDisplayOrderColumns);

      // New columns have higher priority
      var newCols = new List<PropertyAxisBar>();
      for (int i = 0; i < voColList.Count; i++)
      {
        PropertyAxisBar propBar = voColList[i];
        if (propBar.NewColumn && propBar.DisplayIndex >= 0)
        {
          newCols.Add(propBar);
          voColList[i] = null;
        }
      }

      if (newCols.Count > 0)
      {
        voColList.RemoveAll(propBar => propBar == null);
        newCols.Sort(CompareDisplayOrderColumns);

        foreach (PropertyAxisBar propBar in newCols)
        {
          if (propBar.DisplayIndex < voColList.Count)
            voColList.Insert(propBar.DisplayIndex, propBar);
          else
            voColList.Add(propBar);
        }
      }
    }

    protected virtual int CompareDisplayOrderColumns(PropertyAxisBar x, PropertyAxisBar y)
    {
      if (x.DisplayIndex < y.DisplayIndex)
      {
        return -1;
      }
      else if (x.DisplayIndex > y.DisplayIndex)
      {
        return 1;
      }
      else
      {
        if (x.Index < y.Index)
          return -1;
        else if (x.Index < y.Index)
          return 1;
        else
          return 0;
      }
    }

    protected virtual void OnOrderedColumnsListChanged(EventArgs e)
    {
    }

    protected virtual void VisibleColumnsListChanged()
    {

    }

    protected internal void UpdateVisibleColumns()
    {
      int i;
      bool listChanged = false;
      List<PropertyAxisBar> oldVisiblePropBarsList = new List<PropertyAxisBar>(visiblePropBarsList);

      visiblePropBarsList.Clear();

      i = 0;
      foreach (PropertyAxisBar bar in ViewOrderedPropBars)
      {
        if (bar.IsVisible)
        {
          visiblePropBarsList.Add(bar);
          bar.VisibleIndex = i;
          i++;
        }
        else
        {
          bar.VisibleIndex = -1;
        }
      }

      if (oldVisiblePropBarsList.Count != visiblePropBarsList.Count)
      {
        listChanged = true;
      }
      else
      {
        for (i = 0; i < visiblePropBarsList.Count; i++)
        {
          if (oldVisiblePropBarsList[i] != visiblePropBarsList[i])
          {
            listChanged = true;
            break;
          }
        }
      }

      if (listChanged)
        VisibleColumnsListChanged();
    }

    protected DataTable GetDataTable()
    {
      BindingSource bindingSource = DataSource as BindingSource;
      if ((bindingSource != null) && string.IsNullOrEmpty(DataMember))
      {
        DataSet dataSet = bindingSource.DataSource as DataSet;
        if ((dataSet != null) && (bindingSource.DataMember != null))
        {
          DataTable dataTable = dataSet.Tables[bindingSource.DataMember];
          return dataTable;
        }
      }
      return null;
    }

    protected internal virtual void CurrencyManagerMetaDataChanged(object sender, EventArgs e)
    {
    }

    protected internal virtual void CurrencyManagerListChanged(object sender, ListChangedEventArgs e)
    {
    }

    protected internal virtual void CurrencyManagerPositionChanged(object sender, EventArgs e)
    {
    }

    protected internal virtual void OnCurrentListItemStateChanged()
    {
    }

    protected internal virtual void OnCurrentListItemModifiedStateChanged()
    {
    }

    protected internal virtual void OnEditorHasValueToPushChanged()
    {
    }

    protected internal virtual void SetPropBarDisplayIndex(PropertyAxisBar propertyAxisBar, int newDisplayIndex)
    {
      if (InInitialization) return;
      if (PropBars.Updating)
      {
        propertyAxisBar.DisplayIndexInternal = newDisplayIndex;
      }
      else
      {
        if (viewOrderedPropBarsList[propertyAxisBar.DisplayIndex] != propertyAxisBar)
          throw new InvalidOperationException("propertyAxisBar.DisplayIndex is incorrect");

        OldViewOrderedPropBarsList = new List<PropertyAxisBar>(viewOrderedPropBarsList);
        viewOrderedPropBarsList.RemoveAt(propertyAxisBar.DisplayIndex);
        viewOrderedPropBarsList.Insert(newDisplayIndex, propertyAxisBar);
        for (int i = 0; i < viewOrderedPropBarsList.Count; i++)
        {
          viewOrderedPropBarsList[i].DisplayIndexInternal = i;
        }
      }
    }

    protected internal virtual void AxisObjectsByDataColRowIndex(int dataColIndex, int dataRowIndex, 
      out PropertyAxisBar propAxisBar, out DataAxisGridListItemBar listItemBar, out DataAxisGridListAxisItemViewState listAxisItemViewState)
    {
      propAxisBar = null;
      listItemBar = null;
      listAxisItemViewState = DataAxisGridListAxisItemViewState.VirtualEmpty;
    }

    void IDataAxisGridInternal.ResetViewOrderedPropBars()
    {
      ResetViewOrderedPropBars();
    }

    void IDataAxisGridInternal.SetPropBarsOrderFromViewOrderedBars()
    {
      SetPropBarsOrderFromViewOrderedBars();
    }

    protected internal virtual void ResetViewOrderedPropBars()
    {
      foreach (var axisBar in ViewOrderedPropBars)
        axisBar.DisplayIndexInternal = -1;
      PropBarsDisplayIndexChanged();
    }

    protected internal virtual void SetPropBarsOrderFromViewOrderedBars()
    {
    }

    protected internal virtual void OnSuperTitleNameChanged(DataGridSuperTitle superTitle)
    {
    }

    protected internal virtual void OnPropBarNameChanged(PropertyAxisBar propertyAxisBar)
    {
      //OnColumnNameChanged
    }

    protected internal virtual void UpdateBaseFixedBands()
    {
      //UpdateBaseFixedBands
    }

    protected virtual DataAxisGridReadOnlyPropBarCollection CreatePropBarReadOnlyCollection(IList<PropertyAxisBar> list)
    {
      return new DataAxisGridReadOnlyPropBarCollection(this, list);
    }

    protected virtual DataAxisGridMainPropBarCollection CreatePropBarMainCollection(IList<PropertyAxisBar> list)
    {
      return new DataAxisGridMainPropBarCollection(this, list);
    }

    protected virtual DataAxisGridStaticPropBarCollection CreateStaticPropBarCollection()
    {
      return new DataAxisGridStaticPropBarCollection(this);
    }

    protected internal virtual DataAxisGridDataLink CreateDataLink()
    {
      return new DataAxisGridDataLink(this);
    }

    protected internal virtual DataAxisGridTitleBar CreateTitleBar()
    {
      return null;
    }

    protected internal virtual void OnPropBarAdded(PropertyAxisBar propBar)
    {
      //OnColumnAdded
    }

    protected internal virtual void OnPropBarRemoved(PropertyAxisBar propBar)
    {
      //OnColumnRemoved
    }

    protected internal virtual void PropBarsUpdateCommitted()
    {
      UpdatePropBarsList();
      //UpdatePropBarsView();
      //ColumnsUpdateCommited()
    }

    protected internal virtual bool PropBarCanBeVisible(PropertyAxisBar bar)
    {
      return true;
    }

    protected virtual bool ColumnValueSourceIsListItem(Type listItemType)
    {
      if (listItemType.IsPrimitive ||
          listItemType == typeof(string) ||
          listItemType == typeof(DateTime) ||
          listItemType == typeof(decimal) ||
          listItemType == typeof(System.DBNull)
          )
        return true;
      else
        return false;
    }

    protected internal virtual void UpdatePaddingsForSidePadding()
    {
    }

    protected internal virtual void SidePaddingChanged()
    {
      UpdatePaddingsForSidePadding();
    }

    public virtual Padding GetDefaultPaddingForAlign(HorizontalAlignment horzAlign, VerticalAlignment vertAlign)
    {
      return Padding.Empty;
    } 
    
    protected internal virtual Padding GetDataCellSidePadding()
    {
      return Padding.Empty;
    }

    protected internal virtual HorizontalAlignment DefaultHorzAlignForType(Type dataType)
    {
      return EhLibManager.DefaultEhLibManager.GetHorzAlignForType(dataType);
    }

    protected internal virtual VerticalAlignment DefaultVertAlign()
    {
      return VerticalAlignment.Top;
    }

    public virtual void ShowCellNonFitToolTip(string toolTipText, BaseGridCellManager cellManager, BaseGridCellEventArgs e)
    {
      Point hintShowPos;

      if (cellNonfitToolTip == null)
      {
        cellNonfitToolTip = new MouseHoverToolTip
        {
          ShowAlways = true,
          InitialDelay = 0,
          UseFading = true,
          UseAnimation = false,
          AutoPopDelay = 0,
          OwnerDraw = false
        };
      }

      BaseDataCellManager dataCellManager = cellManager as BaseDataCellManager;
      if (dataCellManager != null)
      {
        PropertyAxisBar propAxisBar;
        DataAxisGridListItemBar listItemBar;
        dataCellManager.AxisObjectsByDataColRowIndex(this, e.AreaColIndex, e.AreaRowIndex, out propAxisBar, out listItemBar);

        Rectangle clientRect = dataCellManager.GetCellClientRect(propAxisBar, listItemBar, e.CellRect);
        Rectangle contentRect = dataCellManager.CalcContentRect(clientRect);
        Rectangle textRect = EhLibUtils.TrimPadding(contentRect, Padding);
        hintShowPos = new Point(textRect.X, e.CellRect.Y + e.CellRect.Height);
      }
      else
      {
        hintShowPos = new Point(e.CellRect.X, e.CellRect.Y + e.CellRect.Height);
      }

      cellNonfitToolTip.OwnerDraw = false;
      cellNonfitToolTip.Active = true;
      cellNonfitToolTip.Show(toolTipText, this, hintShowPos, -1, 3000);
    }

    public virtual void ShowCellNonFitToolTip(PopupEventHandler popupProc, DrawToolTipEventHandler drawProc, BaseGridCellEventArgs e)
    {
      Point hintShowPos;

      if (cellNonfitToolTip == null)
      {
        cellNonfitToolTip = new MouseHoverToolTip
        {
          ShowAlways = true,
          InitialDelay = 0,
          UseFading = true,
          UseAnimation = false,
          AutoPopDelay = 0,
          OwnerDraw = false
        };
      }

      hintShowPos = new Point(e.CellRect.X, e.CellRect.Y + e.CellRect.Height);
      //cellNonfitToolTip.Popup += popupProc;
      //cellNonfitToolTip.Draw += drawProc;
      cellNonfitToolTip.OwnerDraw = true;
      cellNonfitToolTip.Active = true;
      cellNonfitToolTip.Show(popupProc, drawProc, this, hintShowPos, -1, 3000);
    }

    public virtual void HideCellNonFitToolTip()
    {
      if (cellNonfitToolTip == null) return;
      cellNonfitToolTip.Hide();
    }

    public virtual void ShowCellHintTooltip(string toolTipText, int delay)
    {
      if (cellHintToolTip == null)
      {
        cellHintToolTip = new MouseHoverToolTip();
      }
      cellHintToolTip.Show(toolTipText, this, delay, 3000);
    }

    public virtual void HideCellHintToolTip()
    {
      if (cellHintToolTip == null) return;
      cellHintToolTip.Hide();
    }

    protected override void OnCellMouseLeave(BaseGridCellManager cell, BaseGridCellLeaveEventArgs e)
    {
      base.OnCellMouseLeave(cell, e);
      HideCellNonFitToolTip();
    }

    protected override void OnValidating(CancelEventArgs e)
    {
      if (inValidatingCode || EditorDataPushing) return;
      inValidatingCode = true;
      try
      {
        if (EditorMode)
        {
          bool editorClosed = HideEditor(true);
          if (!editorClosed)
            e.Cancel = true;
        }

        //base.OnValidating(e);
        HideEditor(true);
        if (DataLink.CurrentListItemState != RowEditState.Browse)
        {
          if (DataLink.CurrentRowModified)
            DataLink.EndCurrentEdit();
          else
            DataLink.CancelCurrentEdit();
        }
        base.OnValidating(e);

      }
      finally
      {
        inValidatingCode = false;
      }
    }

    protected internal virtual void HandleDataCellMouseDownEvent(DataAxisGridDataCellMouseEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellMouseMoveEvent(DataAxisGridDataCellMouseEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellMouseUpEvent(DataAxisGridDataCellMouseEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellMouseClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellMouseDoubleClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellMouseEnter(DataAxisGridDataCellEnterEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellMouseLeave(DataAxisGridDataCellLeaveEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellMouseHoverEvent(DataAxisGridDataCellMouseEventArgs e)
    {
    }

    protected internal virtual void HandleEditValueNeededEvent(DataAxisGridDataCellEditValueNeededEventArgs e)
    {
    }

    protected internal virtual void OnDataCellContentClick(DataAxisGridDataCellEventArgs e)
    {
    }

    protected internal virtual void RowHeightAffectPropertyChanged()
    {
    }

    protected internal virtual string GetHighlightSearchingData(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar,
      string cellText, out CharacterRange[] charRanges)
    {
      charRanges = null;
      return null;
    }

    protected internal virtual void OnDataCellClick(DataAxisGridDataCellEventArgs e)
    {
    }

    protected internal virtual void SpecifyFormatParams(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
    }

    protected internal virtual void HandleFormatParamsNeededEvent(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
    }

    protected internal virtual void HandleEditorParamsNeededEvent(DataAxisGridDataCellEditorParamsNeededEventArgs e)
    {
    }

    protected internal virtual void HandleCanShowEditorStateNeededEvent(DataAxisGridDataCellCanShowEditorStateNeededEventArgs e)
    {
    }

    protected override void HandlePaintEvent(ControlPaintEventArgs e)
    {
      var eh = Events[EventKeyPaint] as EventHandler<ControlPaintEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    protected internal virtual void HandleDataCellPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellContentPaintEvent(DataAxisGridDataCellContentPaintEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellCustomAreaPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
    }

    protected internal virtual void OnDataCellContextMenuStripNeeded(DataAxisGridDataCellContextMenuStripNeededEventArgs age)
    {
      throw new NotImplementedException();
    }

    protected internal virtual void HandleDisplayValueNeededEvent(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellContextMenuStripNeededEvent(DataAxisGridDataCellContextMenuStripNeededEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellClientAreaNeededEvent(DataAxisGridDataCellClientAreaNeededEventArgs e)
    {
    }

    protected internal virtual void HandleCanModifyStateNeededEvent(DataAxisGridDataCellCanModifyStateNeededEventArgs e)
    {
    }

    protected internal virtual void HandleEditorOccupyEvent(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
    }

    protected internal virtual void HandleEditorReleaseEvent(DataAxisGridDataCellEditorReleaseEventArgs e)
    {
    }

    protected internal virtual void HandleParseValueEvent(DataAxisGridDataCellParseValueEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellToolTipInfoNeeded(DataAxisGridDataCellToolTipInfoEventArgs e)
    {
    }

    protected internal virtual void DeleteCurrentListItem()
    {
      CurrencyManager.RemoveAt(CurrencyManager.Position);
    }

    #endregion

  }

  /// <summary>
  /// Contains properties for customizing respond on pressing some keys.
  /// </summary>
  /// <remarks>
  /// You can retrieve an instance of this class through the <see cref="DataAxisGrid.KeyboardOptions"/> property.
  /// </remarks>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class GridKeyboardOptions
  {
    #region privates
    //private readonly DataAxisGrid grid;

    private GridKeyboardAction tabKeyAction = GridKeyboardAction.None;
    private GridKeyboardAction enterKeyAction = GridKeyboardAction.OpenCloseEditor;
    private GridKeyboardAction f2KeyAction = GridKeyboardAction.OpenEditor;
    #endregion privates

    public GridKeyboardOptions(/*DataAxisGrid grid*/)
    {
      //this.grid = grid;
    }

    #region design-time properties
    //[DefaultValue(GridKeyboardAction.NextColCell)]
    public virtual GridKeyboardAction TabKeyAction
    {
      get { return tabKeyAction; }
      set { tabKeyAction = value; }
    }

    [DefaultValue(GridKeyboardAction.OpenCloseEditor)]
    public virtual GridKeyboardAction EnterKeyAction
    {
      get { return enterKeyAction; }
      set { enterKeyAction = value; }
    }

    [DefaultValue(GridKeyboardAction.OpenEditor)]
    public virtual GridKeyboardAction F2KeyAction
    {
      get { return f2KeyAction; }
      set { f2KeyAction = value; }
    }
    #endregion  design-time properties

  }

}
