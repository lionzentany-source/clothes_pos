﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  public partial class TextEditForm : DropDownForm
  {
    private bool readOnly;

    public TextEditForm()
    {
      InitializeComponent();
    }

    public TextBox TextBox
    {
      get { return textBox1; }
    }

    public new string Text
    {
      get { return textBox1.Text; }
      set { textBox1.Text = value; }
    }

    public bool ReadOnly
    {   
      get
      {
        return readOnly;
      }
      set
      {
        if (readOnly != value)
        {
          readOnly = value;
          textBox1.ReadOnly = value;
          bOk.Enabled = !value;
        }
      }
    }

    private void BOk_Click(object sender, EventArgs e)
    {
      DialogResult = DialogResult.OK;
      Close();
    }

    private void BCancel_Click(object sender, EventArgs e)
    {
      DialogResult = DialogResult.Cancel;
      Close();
    }
  }

  public class TextEditDropDownFormPassEventArgs : EventArgs
  {

    public TextEditDropDownFormPassEventArgs(string text, bool readOnly, Control textControl)
    {
      this.Text = text;
      this.ReadOnly = readOnly;
      this.TextControl = textControl;
    }

    public string Text
    { get; set; }

    public bool ReadOnly
    { get; set; }

    public Control TextControl
    { get; set; }

  }

}
