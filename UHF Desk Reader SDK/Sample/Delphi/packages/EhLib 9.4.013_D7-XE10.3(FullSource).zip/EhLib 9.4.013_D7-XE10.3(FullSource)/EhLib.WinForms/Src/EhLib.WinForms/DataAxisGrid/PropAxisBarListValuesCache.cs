﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace EhLib.WinForms
{

  public enum ValueDisplayValuePairListChangedType
  {
    Reset = 0,
    AddItem = 1,
    DeleteItem = 2,
    MoveItem = 3,
    ChangeItem = 4,
  }

  public class ValueDisplayValuePair
  {
    public object Value { get; set; }
    public object DisplayValue { get; set; }
  }

  public class PropAxisBarListValuesCache : ReadOnlyCollection<ValueDisplayValuePair>
  {
    public PropAxisBarListValuesCache(IList<ValueDisplayValuePair> list) : base(list)
    {
    }
  }
}
