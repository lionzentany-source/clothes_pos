﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace EhLib.WinForms
{
  public class AutoUpdatableOnAccessList<T> 
  {
    private readonly List<T> internalList = new List<T>();
    private bool isListObsolete;

    public AutoUpdatableOnAccessList()
    {
    }

    public T this[int index]
    {
      get
      {
        CheckUpateList();
        return internalList[index];
      }
    }

    public int Count
    {
      get
      {
        CheckUpateList();
        return internalList.Count;
      }
    }

    protected bool IsListObsolete { get { return isListObsolete; } }

    protected IList<T> Items { get { return internalList; } }

    public bool Contains(T value)
    {
      CheckUpateList();
      return internalList.Contains(value);
    }

    public void CopyTo(T[] array, int index)
    {
      CheckUpateList();
      internalList.CopyTo(array, index);
    }

    public IEnumerator<T> GetEnumerator()
    {
      CheckUpateList();
      return internalList.GetEnumerator();
    }

    public int IndexOf(T value)
    {
      CheckUpateList();
      return internalList.IndexOf(value);
    }

    private void CheckUpateList()
    {
      if (isListObsolete)
      {
        UpdateList();
        isListObsolete = false;
      }
    }

    public void ListIsObsolete()
    {
      isListObsolete = true;
    }

    protected virtual void UpdateList()
    {
      throw new NotImplementedException();
    }
  }
}
