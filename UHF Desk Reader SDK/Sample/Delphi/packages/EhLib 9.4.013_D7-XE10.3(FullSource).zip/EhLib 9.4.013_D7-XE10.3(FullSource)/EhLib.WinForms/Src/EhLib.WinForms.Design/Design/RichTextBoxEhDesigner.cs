﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Windows.Forms.Design;

namespace EhLib.WinForms.Design
{
  public class RichTextBoxEhDesigner : ControlDesigner
  {
    private DesignerActionListCollection _actionLists;

    public override void InitializeNewComponent(IDictionary defaultValues)
    {
      base.InitializeNewComponent(defaultValues);
    }

    internal RichTextBoxEh EditBox
    {
      get { return this.Component as RichTextBoxEh; }
    }

    public override DesignerActionListCollection ActionLists
    {
      get
      {
        if (this._actionLists == null)
        {
          this._actionLists = new DesignerActionListCollection();
          this._actionLists.Add(new RichTextBoxEhActionList(this));
        }
        return this._actionLists;
      }
    }
  }

  public class RichTextBoxEhActionList : DesignerActionList
  {
    readonly RichTextBoxEhDesigner owner;

    public RichTextBoxEhActionList(RichTextBoxEhDesigner owner) : base(owner.Component)
    {
      this.owner = owner;
    }

    public override DesignerActionItemCollection GetSortedActionItems()
    {
      DesignerActionItemCollection items = new DesignerActionItemCollection();
      items.Add(new DesignerActionMethodItem(this, "EditLines", "Edit Lines ...", true));
      return items;
    }

    public void EditLines()
    {
      if (SimpleRichEditDialog.EditRichText(owner.EditBox))
      {
        IComponentChangeService chService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
        chService.OnComponentChanged(this, null, null, null);
      }
    }

  }

}
