﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System.Drawing;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  class NumericBoxEhManager
  {
    #region static fields
    private static NumericBoxEhManager _defaultManager;
    #endregion static fields

    public NumericBoxEhManager()
    {
    }

    public static NumericBoxEhManager DefaultManager
    {
      get
      {
        if (_defaultManager == null)
          _defaultManager = new NumericBoxEhManager();
        return _defaultManager;
      }
      set
      {
        _defaultManager = value;
      }
    }

    #region methods
    public virtual void InEditButtonDownDefaultAction(NumericBoxEh numericBox, EditItem inEditControl, DownEventArgs e)
    {
      if (inEditControl is InEditUpDownButton)
      {
        var upe = e as UpDownButtonDownEventArgs;
        if (upe == null) return;
        if (upe.UpDownButtonId == UpDownButtonId.Down)
          numericBox.IncrementValue(-numericBox.Increment);
        else
          numericBox.IncrementValue(numericBox.Increment);
        e.AutoRepeat = true;
      }
      else
      {
        DropDownCalculator ddForm = new DropDownCalculator();

        if (numericBox.Value.HasValue)
          ddForm.Value = numericBox.Value.Value;
        else
          ddForm.Value = 0;
        ddForm.ReadOnly = numericBox.ReadOnly;

        ddForm.ExecuteNomodal(
          numericBox.RectangleToScreen(new Rectangle(new Point(0, 0), numericBox.Size)),
          DropDownAlign.Left,
          InEditButtonDownDropDownFormCloseHandler,
          numericBox
        );
      }
    }

    protected virtual void InEditButtonDownDropDownFormCloseHandler(object sender, DropDownFormCloseEventArgs e)
    {
      if (e.CloseResult == DialogResult.OK)
      {
        ((NumericBoxEh) ((DropDownCalculator) sender).MasterControl).Value = ((DropDownCalculator) sender).Value;
      }
    }

    #endregion methods
  }

}
