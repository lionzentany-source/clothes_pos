﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  public class DataGridCheckBoxColumnQueryCheckStateEventArgs : HandledEventArgs
  {
    private DataGridRow dataRow;
    private CheckState checkState;

    public DataGridCheckBoxColumnQueryCheckStateEventArgs(DataGridRow dataRow)
    {
      this.dataRow = dataRow;
    }

    public DataGridRow DataRow
    {
      get { return this.dataRow; }
      internal set { this.dataRow = value; }
    }

    public CheckState CheckState
    {
      get { return this.checkState; }
      set { this.checkState = value; }
    }

  }

  /// <summary>
  /// Defines a type of column in a DataGridEh control that displays a check box user interface (UI).
  /// </summary>
  [DataGridColumnDesignTimeVisible(true)]
  public class DataGridCheckBoxColumn : DataGridColumn, ICheckBoxDataCellHolder
  {

    #region private consts
    private static readonly object EventKeyQueryCheckboxState = new object();
    #endregion

    #region privates
    #endregion

    public DataGridCheckBoxColumn()
    {

    }

    #region run-rime properties
    [Browsable(false)]
    public new CheckBoxDataCellManager DataCell
    {
      get { return (CheckBoxDataCellManager)base.InternalCellManager; }
    }
    #endregion

    #region properties
    [DefaultValue(false)]
    public bool ThreeState
    {
      get { return DataCell.ThreeState; }
      set { DataCell.ThreeState = value; }
    }

    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object TrueValue
    {
      get
      {
        return DataCell.TrueValue;
      }

      set
      {
        DataCell.TrueValue = value;
      }
    }

    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object FalseValue
    {
      get
      {
        return DataCell.FalseValue;
      }

      set
      {
        DataCell.FalseValue = value;
      }
    }

    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object IndeterminateValue
    {
      get
      {
        return DataCell.IndeterminateValue;
      }

      set
      {
        DataCell.IndeterminateValue = value;
      }
    }

    [DefaultValue(FlatStyle.Standard)]
    public FlatStyle FlatStyle
    {
      get
      {
        return DataCell.FlatStyle;
      }

      set
      {
        DataCell.FlatStyle = value;
      }
    }

    #endregion

    #region events
    public event EventHandler<DataGridCheckBoxColumnQueryCheckStateEventArgs> QueryCheckState
    {
      add
      {
        this.Events.AddHandler(EventKeyQueryCheckboxState, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyQueryCheckboxState, value);
      }
    }
    #endregion

    #region methods
    protected override BaseDataCellManager CreateTemplateCell()
    {
      //return new InternalCheckBoxDataCellManager();
      return new CheckBoxDataCellManager();
    }

    protected internal virtual CheckState OnGetCheckState(DataGridColumn column, DataGridRow row, out bool handled)
    {
      DataGridCheckBoxColumnQueryCheckStateEventArgs e = null;
      var eh = this.Events[EventKeyQueryCheckboxState] as EventHandler<DataGridCheckBoxColumnQueryCheckStateEventArgs>;
      if (eh != null /*&& !this.IsDisposed*/)
      {
        e = new DataGridCheckBoxColumnQueryCheckStateEventArgs(row);
        eh(this, e);
      }
      if ((e != null) && e.Handled)
      {
        handled = true;
        return e.CheckState;
      }
      else
      {
        handled = false;
        return CheckState.Indeterminate;
      }
    }

    CheckState ICheckBoxDataCellHolder.OnGetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, out bool handled)
    {
      return OnGetCheckState((DataGridColumn)propAxisBar, (DataGridRow)listItemBar, out handled);
    }
    #endregion

  }
      
}
