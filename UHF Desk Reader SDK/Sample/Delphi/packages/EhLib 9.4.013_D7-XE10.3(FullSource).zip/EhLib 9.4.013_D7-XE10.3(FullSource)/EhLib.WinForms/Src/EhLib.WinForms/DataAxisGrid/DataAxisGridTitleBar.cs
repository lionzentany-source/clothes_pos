﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{
  /// <summary>
  /// Base class for <see cref="DataGridTitle"/> and <see cref="DataVertGridTitleColumn"/> classes
  /// </summary>
  [DesignerCategory("Code")]
  [ToolboxItem(false)]
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public abstract class DataAxisGridTitleBar : Component, IGridLineHost, ICellBackFillerOwner
  {

    #region private consts
    #endregion private consts

    #region privates
    private bool disposed;
    private bool visible = true;
    private Font font;
    private bool foreColorStored;
    private Color foreColor = Color.Empty;
    private Padding padding = new Padding(0);
    private bool paddingStored;

    private bool endEllipsis;
    private bool nonfitTooltips = true;

    private readonly DataAxisGrid grid;
    private readonly GridLine vertLine;
    private readonly GridLine horzLine;
    private readonly CellBackFiller backFiller;

    private HorizontalAlignment horzAlign = HorizontalAlignment.Left;
    private VerticalAlignment vertAlign = VerticalAlignment.Center;

    protected Padding DefaultPadding = new Padding(3, 2, 3, 4);
    private CellTextWrapMode wrapMode = CellTextWrapMode.Auto;
    #endregion privates

    protected DataAxisGridTitleBar(DataAxisGrid grid)
    {
      this.grid = grid;
      vertLine = new GridLine(this);
      horzLine = new GridLine(this);
      backFiller = new CellBackFiller(this);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposed) return;

      if (disposing)
      {
      }

      disposed = true;

      base.Dispose(disposing);
    }

    #region design-time properties    
    /// <summary>
    /// Gets or sets a value indicating whether the grid title is visible.
    /// </summary>
    [DefaultValue(true)]
    public bool Visible
    {
      get { return visible; }
      set
      {
        if (value != visible)
        {
          visible = value;
          Grid.UpdateBaseFixedBands();
        }
      }
    }

    /// <summary>
    /// Gets or sets the horizontal alignment of the text in the title cells.
    /// </summary>
    [DefaultValue(HorizontalAlignment.Left)]
    public HorizontalAlignment HorzAlign
    {
      get
      {
        return horzAlign;
      }
      set
      {
        if (value != horzAlign)
        {
          horzAlign = value;
          Grid.InvalidateGrid();
        }
      }
    }

    /// <summary>
    /// Gets or sets the vertical alignment of the text in the title cells.
    /// </summary>
    [DefaultValue(VerticalAlignment.Center)]
    public VerticalAlignment VertAlign
    {
      get
      {
        return vertAlign;
      }
      set
      {
        if (value != vertAlign)
        {
          vertAlign = value;
          Grid.InvalidateGrid();
        }
      }
    }

    /// <summary>
    /// Gets or sets the font that is used to display text in the title cells.
    /// </summary>
    public Font Font
    {
      get
      {
        if (font != null)
          return font;
        else
          return DefaultFont();
      }
      set
      {
        font = value;
        FontChanged();
      }
    }

    /// <summary>
    /// Gets the back filler that is used to fill title cells background.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public CellBackFiller BackFiller
    {
      get
      {
        return backFiller;
      }
    }

    /// <summary>
    /// Gets or sets the color of the foreground content in the title cells.
    /// </summary>
    public Color ForeColor
    {
      get
      {
        if (foreColorStored)
          return foreColor;
        else
          return DefaultForeColor();
      }
      set
      {
        if ((foreColorStored == false) || (foreColor != value))
        {
          foreColorStored = true;
          foreColor = value;
          ForeColorChanged();
        }
      }
    }

    /// <summary>
    /// Gets or sets the space between the edges of cell and its contents.
    /// </summary>
    public Padding Padding
    {
      get
      {
        if (paddingStored)
          return padding;
        else
          return GetDefaultPadding();
      }
      set
      {
        padding = value;
        paddingStored = true;
        PaddingChanged();
      }
    }

    /// <summary>
    /// Gets or sets a value ends with ellipsis if it does not fit in the grid cell.
    /// </summary>
    [DefaultValue(false)]
    public bool EndEllipsis
    {
      get
      {
        return endEllipsis;
      }
      set
      {
        if (endEllipsis != value)
        {
          endEllipsis = value;
          EndEllipsisChanged();
        }
      }
    }

    /// <summary>
    /// Defines properties for setting the parameters of the vertical lines separating the grid cells.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridLine VertLine
    {
      get
      {
        return vertLine;
      }
    }

    /// <summary>
    /// Defines properties for setting the parameters of the horizontal lines separating the grid cells.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridLine HorzLine
    {
      get
      {
        return horzLine;
      }
    }

    /// <summary>
    /// Gets or sets the shortcut menu associated title cells.
    /// </summary>
    [DefaultValue(null)]
    public virtual ContextMenuStrip ContextMenuStrip { get; set; }

    /// <summary>
    /// Gets or sets a value indicating whether grid should should full version of the title text in the tooltip window 
    /// when the text is not fitted in the cell bounds.
    /// </summary>
    [DefaultValue(true)]
    public bool NonfitTooltips
    {
      get
      {
        return nonfitTooltips;
      }
      set
      {
        if (nonfitTooltips != value)
        {
          nonfitTooltips = value;
          UnfitTooltipsChanged();
        }
      }
    }

    /// <summary>
    /// Gets or sets the mode of wrapping the text when text is not fitted in the cell width.
    /// </summary>
    [DefaultValue(CellTextWrapMode.Auto)]
    public CellTextWrapMode WrapMode
    {
      get
      {
        return wrapMode;
      }
      set
      {
        if (wrapMode != value)
        {
          wrapMode = value;
          WrapModeChanged();
        }
      }
    }
    #endregion

    #region run-time properties
    [Browsable(false)]
    public int HorzLineSpace
    {
      get
      {
        if (HorzLine.Visible)
          return Grid.GridLineWidth;
        else
          return 0;
      }
    }

    [Browsable(false)]
    public DataAxisGrid Grid
    {
      get { return grid; }
    }
    #endregion

    #region events
    #endregion

    #region methods
    //ICellBackFillerOwner
    void ICellBackFillerOwner.BackFillerChanged(CellBackFiller backFiller)
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    Color ICellBackFillerOwner.BackFillerDefaultColor(CellBackFiller backFiller)
    {
      return Grid.FixedBackFiller.Color;
    }

    Color ICellBackFillerOwner.BackFillerDefaultSecondColor(CellBackFiller backFiller)
    {
      return Grid.FixedBackFiller.SecondColor;
    }

    CellFillStyle ICellBackFillerOwner.BackFillerDefaultFillStyle(CellBackFiller backFiller)
    {
      return Grid.FixedBackFiller.FillStyle;
    }

    CellInnerBorderStyle ICellBackFillerOwner.BackFillerDefaultInnerBorder(CellBackFiller backFiller)
    {
      return Grid.FixedBackFiller.InnerBorder;
    }

    //IGridLineHost
    void IGridLineHost.GridLineChanged(GridLine gl)
    {
      GridLineChanged(gl);
    }

    protected virtual void GridLineChanged(GridLine gl)
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    bool IGridLineHost.GridLineDefaultVisible(GridLine gl)
    {
      return GridLineDefaultVisible(gl);
    }

    protected abstract bool GridLineDefaultVisible(GridLine gl);

    Color IGridLineHost.GridLineDefaultColor(GridLine gl)
    {
      return GridLineDefaultColor(gl);
    }

    protected abstract Color GridLineDefaultColor(GridLine gl);

    DashStyle IGridLineHost.GridLineDefaultStyle(GridLine gl)
    {
      return GridLineDefaultStyle(gl);
    }

    protected virtual DashStyle GridLineDefaultStyle(GridLine gl)
    {
      return DashStyle.Solid;
    }

    //Other
    protected virtual void WrapModeChanged()
    {
    }

    protected virtual void UnfitTooltipsChanged()
    {
      Grid.InvalidateGrid();
    }

    protected virtual void EndEllipsisChanged()
    {
      Grid.InvalidateGrid();
    }

    protected virtual void PaddingChanged()
    {
      //MessageBox.Show("DataGridTitle.PaddingChanged");
      Grid.UpdateBaseFixedBands();
    }

    protected virtual Padding GetDefaultPadding()
    {
      return DefaultPadding;
    }

    protected virtual bool ShouldSerializePadding()
    {
      return (paddingStored == true);
    }

    public virtual void ResetPadding()
    {
      paddingStored = false;
      PaddingChanged();
    }

    protected virtual void ForeColorChanged()
    {
      Grid.InvalidateGrid();
    }

    public virtual Color DefaultForeColor()
    {
      return Grid.ForeColor;
    }

    protected virtual bool ShouldSerializeForeColor()
    {
      return (foreColorStored == true);
    }

    public virtual void ResetForeColor()
    {
      foreColorStored = false;
      ForeColorChanged();
    }

    protected virtual Font DefaultFont()
    {
      return Grid.Font;
    }

    protected virtual bool ShouldSerializeFont()
    {
      return (font != null);
    }

    public virtual void ResetFont()
    {
      font = null;
      FontChanged();
    }

    protected virtual void FontChanged()
    {
      Grid.UpdateBaseFixedBands();
      Grid.Invalidate();
    }

    //protected internal virtual void HandleMouseDownEvent(DataGridTitleCellMouseEventArgs e)
    //{
    //}

    protected internal virtual void OnCellMouseClick(DataGridTitleCellMouseEventArgs e)
    {
    }
    #endregion
  }
}
