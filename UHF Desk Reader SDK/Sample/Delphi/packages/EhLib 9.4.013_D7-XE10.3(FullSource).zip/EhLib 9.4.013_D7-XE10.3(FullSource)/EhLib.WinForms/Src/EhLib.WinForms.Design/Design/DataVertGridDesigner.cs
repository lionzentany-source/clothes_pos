﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms.Design
{
  public class DataVertGridDesigner : DataAxisGridDesigner, IDataVertGridDesigner
  {
    private DesignerActionListCollection actionLists;

    internal Point GridMouseDownPos = Point.Empty;

    #region constructor
    public DataVertGridDesigner()
    {

    }

    public override void Initialize(IComponent component)
    {
      base.Initialize(component);

      Grid.GridDesigner = this;
      //Grid.OrderedColumnsListChanged += Grid_OrderedColumnsListChanged;

    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        Grid.GridDesigner = null;
        //Grid.OrderedColumnsListChanged -= Grid_OrderedColumnsListChanged;
      }

      base.Dispose(disposing);
    }
    #endregion

    internal new DataVertGridEh Grid
    {
      get { return this.Component as DataVertGridEh; }
    }

    public override string PropAxisBarName
    {
      get { return "Row"; }
    }

    public override string PropAxisBarsName
    {
      get { return "Rows"; }
    }

    public override Type StaticPropBarCollectionType
    {
      get { return typeof(DataVertGridStaticRowsCollection); }
    }

    public override Type PropAxisBarType
    {
      get { return typeof(DataVertGridRow); }
    }

    public override DesignerActionListCollection ActionLists
    {
      get
      {
        if (actionLists == null)
        {
          actionLists = new DesignerActionListCollection();
          actionLists.Add(new DataAxisGridChooseDataSourceActionList(this));
          actionLists.Add(new DataAxisGridActionList(this));
          actionLists.Add(new DataAxisGridPropertiesActionList(this));
          actionLists.AddRange(base.ActionLists);
        }
        return actionLists;
      }
    }

    public override ICollection AssociatedComponents
    {
      get
      {
        ArrayList acItems = new ArrayList();

        foreach (DataVertGridRow r in Grid.StaticRows)
        {
          acItems.Add(r);
        }

        return acItems;
      }
    }

    public override DataAxisGridPropertyBarsEditor CreatePropertyBarsEditor()
    {
      return new DataVertGridRowsEditor(StaticPropBarCollectionType);
    }

    protected override void SelService_SelectionChanged(object sender, EventArgs e)
    {
      base.SelService_SelectionChanged(sender, e);
      Control.Invalidate();
    }

    protected override void SelService_SelectionChanging(object sender, EventArgs e)
    {
      base.SelService_SelectionChanging(sender, e);
    }

    protected override bool GetHitTest(Point point)
    {
      Point tpPoint = this.Control.PointToClient(point);

      GridCoord cellCoord = Grid.CalcCellCoordFromPoint(tpPoint.X, tpPoint.Y);
      Component hitTestComponent = GetHitTestComponent(tpPoint);
      if ( (hitTestComponent != null) 
          ||
           ((cellCoord.X == Grid.TitleColumnBaseColIndex) && 
            (cellCoord.Y >= Grid.StartDataRowBaseRowIndex) &&
            (Grid.StartDataRowBaseRowIndex >= 0)))
      {
        //        MessageBox.Show(cellCoord.X.ToString() +":"+ cellCoord.Y.ToString());
        return true;
      }

      return base.GetHitTest(point);
    }

    protected virtual Component GetHitTestComponent(Point point)
    {
      BaseGridState state = Grid.CheckSizingState(point.X, point.Y);
      if (state == BaseGridState.ColSizing)
        return null;

      GridCoord cellHit = Grid.CalcCellCoordFromPoint(point.X, point.Y);
      int dataRowHit = cellHit.Y - Grid.StartDataRowBaseRowIndex;
      if (cellHit.Y >= Grid.StartDataRowBaseRowIndex &&
          dataRowHit < Grid.VisibleRows.Count)
      {
        DataVertGridRow row = Grid.VisibleRows[dataRowHit];

        if (cellHit.X == Grid.TitleColumnBaseColIndex)
        {
          ISelectionService selSrv = SelService;
          if ((selSrv != null) && (row != null))
          {
            return row;
          }
        }
      }
      return null;
    }

    public virtual void GridMouseDown(MouseEventArgs e)
    {
      GridMouseDownPos = e.Location;

      Component hitTestComponent = GetHitTestComponent(e.Location);

      if (hitTestComponent != null)
      {
        if (e.Button == MouseButtons.Left)
        {
          ISelectionService selSrv = SelService;
          selSrv.SetSelectedComponents(new object[] { hitTestComponent });
        }
      }
    }

    public virtual void GridMouseUp(MouseEventArgs e)
    {
    }

    public virtual void GridMouseMove(MouseEventArgs e)
    {
    }

    public virtual void PaintCellDesignData(DataVertGridEh grid, Graphics graphics, int colIndex, int rowIndex,
      Rectangle rect, BasePaintCellStates state)
    {
      if (colIndex == Grid.TitleColumnBaseColIndex && 
          rowIndex >= Grid.StartDataRowBaseRowIndex &&
          Grid.StartDataRowBaseRowIndex >= 0)
      {
        int dataRowIndex = rowIndex - Grid.StartDataRowBaseRowIndex;
        if (dataRowIndex < 0) return;
        DataVertGridRow row = grid.VisibleRows[dataRowIndex];
        if ((SelService != null) && (row != null))
        {
          if (SelService.GetComponentSelected(row))
          {
            Rectangle paintRect = rect;
            paintRect.Inflate(-2, -2);
            using (Pen pen = new Pen(Color.Black, 1))
            {
              pen.DashStyle = DashStyle.Dot;
              graphics.DrawRectangle(pen, paintRect);
            }
          }
        }
      }
    }
  }
}
