﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  public interface IDataVertGridDesigner
  {
    void GridMouseDown(MouseEventArgs e);
    void GridMouseMove(MouseEventArgs e);
    void GridMouseUp(MouseEventArgs e);
    void PaintCellDesignData(DataVertGridEh grid, Graphics graphics, int colIndex, int rowIndex, Rectangle rect, BasePaintCellStates state);
  }

  /// <summary>
  /// Displays data in a customizable grid in vertical orientation. 
  /// Data properties of DataSource in <see cref = "DataVertGridEh" /> represents as rows.
  /// </summary>
  [DesignerCategory("Code")]
  [Designer("EhLib.WinForms.Design.DataVertGridDesigner, EhLib.WinForms.Design")]
  [ToolboxItem(true)]
  [ToolboxBitmap(typeof(DataVertGridEh), "ToolboxBitmaps.EhLib_DataVertGrid.bmp")]
  [ComplexBindingProperties("DataSource", "DataMember")]
  [Description("Displays rows and columns of data in a grid you can customize where properties of a list is shown as rows and list items as columns")]
  public class DataVertGridEh : DataAxisGrid
  {
    #region private consts
    private static readonly object EventKeyDataCellDisplayValueNeeded = new object();
    private static readonly object EventKeyDataCellPaint = new object();
    private static readonly object EventKeyDataCellContentPaint = new object();
    private static readonly object EventKeyDataCellCustomAreaPaint = new object();
    private static readonly object EventKeyDataCellClientAreaNeeded = new object();
    private static readonly object EventKeyDataCellFormatParamsNeeded = new object();

    private static readonly object EventKeyDataCellMouseDown = new object();
    private static readonly object EventKeyDataCellMouseMove = new object();
    private static readonly object EventKeyDataCellMouseUp = new object();
    private static readonly object EventKeyDataCellMouseClick = new object();
    private static readonly object EventKeyDataCellMouseDoubleClick = new object();
    private static readonly object EventKeyDataCellMouseEnter = new object();
    private static readonly object EventKeyDataCellMouseLeave = new object();
    private static readonly object EventKeyDataCellMouseHover = new object();
    private static readonly object EventKeyDataCellContentClick = new object();

    private static readonly object EventKeyDataCellCanModifyStateNeeded = new object();
    private static readonly object EventKeyDataCellCanShowEditorStateNeeded = new object();
    private static readonly object EventKeyDataCellEditorParamsNeeded = new object();
    private static readonly object EventKeyDataCellEditValueNeeded = new object();
    private static readonly object EventKeyDataCellParseValue = new object();
    private static readonly object EventKeyDataCellEditorOccupy = new object();
    private static readonly object EventKeyDataCellEditorRelease = new object();

    private static readonly object EventKeyDataCellToolTipInfo = new object();
    private static readonly object EventKeyDataCellContextMenuStripNeeded = new object();

    private static readonly object EventKeyDataCellManagerNeeded = new object();
    #endregion private consts

    #region privates
    private readonly BaseDataCellManager emptyDataCell;
    internal readonly DataVertGridTitleColumnCellMan titleCell;
    private bool gridIsEmpty;
    private int internalCurrentColumnIndex;

    private readonly DataVertGridIndicatorDataCellMan indicatorRowCell;
    private readonly DataVertGridIndicatorRow indicatorRow;
    private readonly DataVertGridIndicatorTitle indicatorTitle;
    private readonly DataVertGridIndicatorTitleCellMan titleIndicatorCell;

    protected internal List<DataVertGridColumn> ListItems;
    private readonly ReadOnlyCollection<DataVertGridColumn> visibleColumns;

    private Padding leftAlignDefaultPadding;
    private Padding centerAlignDefaultPadding;
    private Padding rightAlignDefaultPadding;

    private readonly DataVertGridColumnOptions columnOptions;
    private readonly DataVertGridRowOptions rowOptions;
    private readonly DataVertGridServiceCellManagerList extraCellManagers;

    private DataVertGridManager manager;
    public IDataVertGridDesigner GridDesigner;
    #endregion

    public DataVertGridEh()
    {
      Options = GridOptions.DrawFocusSelected | GridOptions.Editing |
                GridOptions.ColSizing |
                //GridOptions.RowSizing | GridOptions.ColSizing |
                //GridOption.RowMoving | //GridOption.ColMoving | 
                GridOptions.Tabs |
                GridOptions.ContraHorzBoundaryLine | GridOptions.ContraVertBoundaryLine;

      this.ColCount = 2;
      this.FixedRowCount = 0;
      this.RowCount = 1;

      emptyDataCell = new DataVertGridEmptyCellManager();
      emptyDataCell.BoundGrid = this;

      titleCell = new DataVertGridTitleColumnCellMan();
      titleCell.BoundGrid = this;

      titleIndicatorCell = new DataVertGridIndicatorTitleCellMan();
      titleIndicatorCell.BoundGrid = this;
      indicatorRowCell = new DataVertGridIndicatorDataCellMan();
      indicatorRowCell.BoundGrid = this;

      indicatorTitle = CreateIndicatorTitle();
      indicatorRow = CreateIndicatorRow();

      ListItems = new List<DataVertGridColumn>();
      visibleColumns = new ReadOnlyCollection<DataVertGridColumn>(ListItems);
      extraCellManagers = new DataVertGridServiceCellManagerList(this);

      rowOptions = new DataVertGridRowOptions(this);
      columnOptions = new DataVertGridColumnOptions(this);
      UpdatePaddingsForSidePadding();

      InitData();

      UpdateBaseFixedBands();
      InternalUpdateRowsList();
    }

    internal void InitData()
    {
      UpdateGridState();
    }

    #region design-time properties
    public bool AutoGenerateRows
    {
      get { return base.AutoGeneratePropBars; }
      set { base.AutoGeneratePropBars = value; }
    }

    /// <summary>
    /// Contains properties for customizing title column in DataVertGridEh
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataVertGridTitleColumn TitleColumn
    {
      get { return (DataVertGridTitleColumn)base.TitleBar; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataVertGridLineOptions LineOptions
    {
      get { return (DataVertGridLineOptions)GridLineColors; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataVertGridRowOptions RowOptions
    {
      get { return rowOptions; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataVertGridColumnOptions ColumnOptions
    {
      get { return columnOptions; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    [Editor("EhLib.WinForms.Design.DataVertGridRowsEditor" + EhLibUtils.EhLibDesignDesignerVersionInfo, "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    public DataVertGridStaticRowsCollection StaticRows
    {
      get { return (DataVertGridStaticRowsCollection)base.StaticPropBars; }
    }

    /// <summary>
    /// Access to keyboard options.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public new DataVertGridKeyboardOptions KeyboardOptions
    {
      get
      {
        return (DataVertGridKeyboardOptions)base.KeyboardOptions;
      }
    }

    /// <summary>
    /// Access properties to customize the top-left indicator title cell.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataVertGridIndicatorTitle IndicatorTitle
    {
      get { return indicatorTitle; }
    }

    /// <summary>
    /// Access properties to customize the top indicator row.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public DataVertGridIndicatorRow IndicatorRow
    {
      get { return indicatorRow; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    [Editor("EhLib.WinForms.Design.DataVertGridDynaColumnCellsEditor" + EhLibUtils.EhLibDesignDesignerVersionInfo, "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    public DataVertGridServiceCellManagerList ExtraCellManagers
    {
      get { return extraCellManagers; }
    }
    #endregion 

    #region run-time properties
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public ReadOnlyCollection<DataVertGridColumn> VisibleColumns
    {
      get { return visibleColumns; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool GridIsEmpty
    {
      get { return gridIsEmpty; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public BaseDataCellManager EmptyDataCell
    {
      get { return emptyDataCell; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataVertGridTitleColumnCellMan TitleCell
    {
      get { return titleCell; }
    }

    [Browsable(false)]
    public override int CurrentDataColIndex
    {
      get { return Col - FixedColCount; }
    }

    [Browsable(false)]
    public override int CurrentDataRowIndex
    {
      get { return Row - FixedRowCount; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected internal int InternalCurrentColumnIndex
    {
      get
      {
        return internalCurrentColumnIndex;
      }

      set
      {
        if (internalCurrentColumnIndex != value)
        {
          internalCurrentColumnIndex = value;
          if (internalCurrentColumnIndex != -1)
            Col = internalCurrentColumnIndex + FixedColCount;
          InvalidateCol(Col);
        }
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataVertGridReadOnlyRowCollection DynamicRows
    {
      get { return (DataVertGridReadOnlyRowCollection)base.DynamicPropBars; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataVertGridMainRowCollection Rows
    {
      get { return (DataVertGridMainRowCollection)base.PropBars; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataVertGridReadOnlyRowCollection ViewOrderedRows
    {
      get { return (DataVertGridReadOnlyRowCollection)base.ViewOrderedPropBars; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataVertGridReadOnlyRowCollection VisibleRows
    {
      get { return (DataVertGridReadOnlyRowCollection)base.VisiblePropBars; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int CurrentRowIndex
    {
      get { return Row - FixedRowCount; }
      set { Row = value + FixedRowCount; }
    }

    protected internal override PropertyAxisBar CurrentPropBar
    {
      get
      {
        if (CurrentRowIndex < VisibleRows.Count)
          return VisibleRows[CurrentRowIndex];
        else
          return null;
      }
    }

    protected internal override DataAxisGridListItemBar CurrentListItemBar
    {
      get
      {
        if (VisibleColumns.Count > 0)
          return VisibleColumns[CurrentDataColIndex];
        else
          return null;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected virtual DataVertGridManager DefaultManager
    {
      get
      {
        return DataVertGridManager.DefaultManager;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public DataVertGridManager Manager
    {
      get
      {
        if (manager != null)
          return manager;
        else
          return DefaultManager;
      }
      set
      {
        manager = value;
      }
    }

    [Browsable(false)]
    public int StartDataColIndex
    {
      get
      {
        if (TitleColumn.Visible)
          return 1;
        else
          return 0;
      }
    }

    [Browsable(false)]
    public int StartDataRowIndex
    {
      get
      {
        if (IndicatorRow.Visible)
          return 1;
        else
          return 0;
      }
    }

    [Browsable(false)]
    public int TitleColumnBaseColIndex
    { get; internal set; }

    [Browsable(false)]
    public int StartDataColumnBaseColIndex
    { get; internal set; }

    [Browsable(false)]
    public int StartDataRowBaseRowIndex
    { get; internal set; }

    [Browsable(false)]
    public int EmptyDataColumnBaseColIndex
    { get; internal set; }

    [Browsable(false)]
    public int DataColumnWidth
    {
      get
      {
        int result = ColWidths[TitleColumnBaseColIndex + 1];
        if (LineOptions.VertLines)
          result = result - 1;
        return result; 
      }
    }
    #endregion 

    #region events
    /// <summary>
    /// Occurs when the grid request the display value for the date cell position specified by Column and Row
    /// </summary>
    public event EventHandler<DataVertGridDataCellDisplayValueNeededEventArgs> DataCellDisplayValueNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellDisplayValueNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellDisplayValueNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a "data" cell paint params like BackColor, Font, etc should be specified.
    /// </summary>
    /// <remarks>
    /// By default these params are assigned by column properties
    /// </remarks>    
    public event EventHandler<DataVertGridDataCellFormatParamsNeededEventArgs> DataCellFormatParamsNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellFormatParamsNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellFormatParamsNeeded, value);
      }
    }

    public event EventHandler<DataVertGridDataCellPaintEventArgs> DataCellPaint
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellPaint, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellPaint, value);
      }
    }

    /// <summary>
    /// Occurs when a cell content in the grid data cell needs to be drawn.
    /// </summary>
    public event EventHandler<DataGridDataCellContentPaintEventArgs> DataCellContentPaint
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellContentPaint, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellContentPaint, value);
      }
    }

    public event EventHandler<DataVertGridDataCellPaintEventArgs> DataCellCustomAreaPaint
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellCustomAreaPaint, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellCustomAreaPaint, value);
      }
    }

    public event EventHandler<DataVertGridDataCellClientAreaNeededEventArgs> DataCellClientAreaNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellClientAreaNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellClientAreaNeeded, value);
      }
    }

    /// <summary>
    /// Occurs every time when certain actions like MouseDown, MouseClick, ProcessPaint, ShowEditor etc
    /// should be processed in a specific cell position in the data area.
    /// </summary>
    /// <remarks>
    /// After the grid has received a cell manager, it calls the appropriate method in the manager 
    /// object so that the action is processed by the cell manager. The event handler must return 
    /// the correct cell manager for the specified column and row. By default, the grid uses 
    /// the manager specified in the Column.CellManager property.
    /// </remarks>    
    public event EventHandler<DataVertGridDataCellManagerNeededEventArgs> DataCellManagerNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellManagerNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellManagerNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when the cell editor requests and sets its readonly state.
    /// </summary>
    public event EventHandler<DataVertGridDataCellCanModifyStateNeededEventArgs> DataCellCanModifyStateNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellCanModifyStateNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellCanModifyStateNeeded, value);
      }
    }

    //Mouse
    /// <summary>
    /// Occurs when the user presses a mouse button while the mouse pointer is 
    /// within the boundaries of a "data" cell.
    /// </summary>
    public event EventHandler<DataVertGridDataCellMouseEventArgs> DataCellMouseDown
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseDown, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseDown, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer moves over the boundaries of a "data" cell.
    /// </summary>
    public event EventHandler<DataVertGridDataCellMouseEventArgs> DataCellMouseMove
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseMove, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseMove, value);
      }
    }

    /// <summary>
    /// Occurs when the user releases a mouse button while over a "data" cell.
    /// </summary>
    public event EventHandler<DataVertGridDataCellMouseEventArgs> DataCellMouseUp
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseUp, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseUp, value);
      }
    }

    /// <summary>
    /// Occurs whenever the user clicks anywhere on a "data" cell with the mouse.
    /// </summary>
    public event EventHandler<DataVertGridDataCellMouseEventArgs> DataCellMouseClick
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseClick, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseClick, value);
      }
    }

    /// <summary>
    /// Occurs when a "data" cell within the DataVertGridEh is double-clicked.
    /// </summary>
    public event EventHandler<DataVertGridDataCellMouseEventArgs> DataCellMouseDoubleClick
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseDoubleClick, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseDoubleClick, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer enters a "data" cell.
    /// </summary>
    public event EventHandler<DataVertGridDataCellEnterEventArgs> DataCellMouseEnter
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseEnter, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseEnter, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer leaves a "data" cell.
    /// </summary>
    public event EventHandler<DataVertGridDataCellLeaveEventArgs> DataCellMouseLeave
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseLeave, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseLeave, value);
      }
    }

    /// <summary>
    /// Occurs when the mouse pointer rests on the "data" cell.
    /// </summary>
    public event EventHandler<DataVertGridDataCellMouseEventArgs> DataCellMouseHover
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellMouseHover, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellMouseHover, value);
      }
    }

    /// <summary>
    /// Occurs when the user clicks on the content part of the data cell with the mouse or keyboard.
    /// </summary>
    /// <remarks>
    ///   This event can be used to catch the click event on the text when DataVertGridTextRow.CellDataIsLink or
    ///   click on the DataVertGridButtonRow
    /// </remarks>
    public event EventHandler<DataVertGridDataCellEventArgs> DataCellContentClick
    {
      add { this.Events.AddHandler(EventKeyDataCellContentClick, value); }
      remove { this.Events.RemoveHandler(EventKeyDataCellContentClick, value); }
    }

    public event EventHandler<DataVertGridDataCellCanShowEditorStateNeededEventArgs> DataCellCanShowEditorStateNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellCanShowEditorStateNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellCanShowEditorStateNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a data cell editor params such as BackColor, Font, etc should be specified.
    /// </summary>
    public event EventHandler<DataVertGridDataCellEditorParamsEventArgs> DataCellEditorParamsNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellEditorParamsNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellEditorParamsNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager converts datasource cell value to the value for the editor.
    /// </summary>
    public event EventHandler<DataVertGridDataCellEditValueNeededEventArgs> DataCellEditValueNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellEditValueNeeded, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellEditValueNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager converts a value from the editor to the value for datasource.
    /// </summary>
    public event EventHandler<DataVertGridDataCellParseValueEventArgs> DataCellParseValue
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellParseValue, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellParseValue, value);
      }
    }

    public event EventHandler<DataVertGridDataCellEditorOccupyEventArgs> DataCellEditorOccupy
    {
      add
      {
        Events.AddHandler(EventKeyDataCellEditorOccupy, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellEditorOccupy, value);
      }
    }

    public event EventHandler<DataVertGridDataCellEditorReleaseEventArgs> DataCellEditorRelease
    {
      add
      {
        Events.AddHandler(EventKeyDataCellEditorRelease, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellEditorRelease, value);
      }
    }

    /// <summary>
    /// Occurs when a cell manager requests info to show in tooltip window.
    /// </summary>
    /// <remarks>
    /// For text data, assign the text to e.ToolTipText property by the text you want to be shown in tooltip window.
    /// </remarks>
    public event EventHandler<DataVertGridDataCellToolTipInfoEventArgs> DataCellToolTipInfoNeeded
    {
      add
      {
        this.Events.AddHandler(EventKeyDataCellToolTipInfo, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyDataCellToolTipInfo, value);
      }
    }

    public event EventHandler<DataVertGridDataCellContextMenuStripNeededEventArgs> DataCellContextMenuStripNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellContextMenuStripNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellContextMenuStripNeeded, value);
      }
    }
    #endregion events

    #region public methods
    public virtual DataVertGridDrawStyle GetDrawStyle()
    {
      return EhLibRenderManager.DefaultEhLibRenderManager.DataVertGridDrawStyle;
    }

    public void GetColumnRowByDataColRowIndex(int areaColIndex, int areaRowIndex,
      out DataVertGridRow row, out object listItem)
    {
      if (areaRowIndex < VisibleRows.Count)
        row = VisibleRows[areaRowIndex];
      else
        row = null;

      if (areaColIndex < VisibleColumns.Count)
        listItem = VisibleColumns[areaColIndex];
      else
        listItem = null;
    }
    #endregion 

    #region nopublic methods

    //AutoGenerateRows
    protected virtual bool DefaultAutoGenerateRows()
    {
      return DefaultAutoGeneratePropBars();
    }

    protected virtual bool ShouldSerializeAutoGenerateRows()
    {
      return ShouldSerializeAutoGeneratePropBars();
    }

    public virtual void ResetAutoGenerateRows()
    {
      ResetAutoGeneratePropBars();
    }

    //Keyboard handling
    protected override void OnKeyDown(KeyEventArgs e)
    {
      base.OnKeyDown(e);
      if (e.Handled) return;

      switch (e.KeyData & Keys.KeyCode)
      {
        case Keys.F2:
          {
            e.Handled = ProcessF2Key(e.KeyData);
            return;
          }
      }
    }

    protected override bool ProcessDialogKey(Keys keyData)
    {

      if (EditorMode &&
          ((IDataAxisGridCellInPlaceEditor)CellEditControl).EditorWantsInputKey(keyData, true))
      {
        return base.ProcessDialogKey(keyData);
      }

      Keys key = (keyData & Keys.KeyCode);

      switch (key)
      {
        case Keys.Enter:
          {
            if (ProcessEnterKey(keyData))
              return true;
            else
              break;
          }

        case Keys.Escape:
          {
            if (ProcessEscapeKey(keyData))
              return true;
            else
              break;
          }
      }

      return base.ProcessDialogKey(keyData);
    }

    protected override bool IsInputKey(Keys keyData)
    {
      switch (keyData & Keys.KeyCode)
      {
        case Keys.Tab:
          {
            Keys altData = (keyData & (Keys.Control | Keys.Shift | Keys.Alt));
            if ((altData == 0 || altData == Keys.Shift) && ((GridOptions.Tabs & Options) != 0))
              return (KeyboardOptions.TabKeyAction != GridKeyboardAction.None);
            else
              break;
          }
      }
      return base.IsInputKey(keyData);
    }

    //Other
    protected internal override void HandleFormatParamsNeededEvent(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
      var eh = Events[EventKeyDataCellFormatParamsNeeded] as EventHandler<DataVertGridDataCellFormatParamsNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellFormatParamsNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseDownEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseDown] as EventHandler<DataVertGridDataCellMouseEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataVertGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseMoveEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseMove] as EventHandler<DataVertGridDataCellMouseEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataVertGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseUpEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseUp] as EventHandler<DataVertGridDataCellMouseEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataVertGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseClick] as EventHandler<DataVertGridDataCellMouseEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataVertGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseDoubleClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseDoubleClick] as EventHandler<DataVertGridDataCellMouseEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataVertGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseEnter(DataAxisGridDataCellEnterEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseEnter] as EventHandler<DataVertGridDataCellEnterEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataVertGridDataCellEnterEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseLeave(DataAxisGridDataCellLeaveEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseLeave] as EventHandler<DataVertGridDataCellLeaveEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataVertGridDataCellLeaveEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellMouseHoverEvent(DataAxisGridDataCellMouseEventArgs e)
    {
      var eh = Events[EventKeyDataCellMouseHover] as EventHandler<DataVertGridDataCellMouseEventArgs>;
      if (eh != null && !IsDisposed)
      {
        var ge = new DataVertGridDataCellMouseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void AxisObjectsByDataColRowIndex(int dataColIndex, int dataRowIndex,
      out PropertyAxisBar propAxisBar, out DataAxisGridListItemBar listItemBar, out DataAxisGridListAxisItemViewState listAxisItemViewState)
    {

      if (dataRowIndex < VisibleRows.Count)
        propAxisBar = VisibleRows[dataRowIndex];
      else
        propAxisBar = null;

      if (dataColIndex < VisibleColumns.Count)
      {
        listItemBar = VisibleColumns[dataColIndex];

        RowEditState rowState = DataLink.CurrentListItemState;

        if (dataColIndex == CurrentDataColIndex)
        {
          if (rowState == RowEditState.Edit)
            listAxisItemViewState = DataAxisGridListAxisItemViewState.DataEdit;
          else if (rowState == RowEditState.New)
            listAxisItemViewState = DataAxisGridListAxisItemViewState.DataNew;
          else
            listAxisItemViewState = DataAxisGridListAxisItemViewState.DataBrowse;
        }
        else
        {
          listAxisItemViewState = DataAxisGridListAxisItemViewState.DataBrowse;
        }
      }
      else
      {
        listItemBar = null;

        if (dataColIndex == VisibleColumns.Count)
          listAxisItemViewState = DataAxisGridListAxisItemViewState.VirtualNew;
        else
          listAxisItemViewState = DataAxisGridListAxisItemViewState.VirtualEmpty;
      }
    }

    protected override GridKeyboardOptions CreateKeyboardOptions()
    {
      return new DataVertGridKeyboardOptions();
    }

    public override void InteractiveFocusCell(int colIndex, int rowIndex, InteractiveActionSource actionSource)
    {
      if ((colIndex == Col) && (rowIndex == Row)) return;
      if (!PrepareChangeCellPos()) return;
      //if ((ModifierKeys & Keys.Shift) != 0) return;
      if (!DataLink.Active) return;

      if ((colIndex - FixedColCount) == visibleColumns.Count)
        DataLink.AddNew();
      else
        DataLink.Position = colIndex - FixedColCount;

      FocusCell(Col, rowIndex, false);
    }

    protected override void OnResize(EventArgs e)
    {
      base.OnResize(e);
    }

    protected override GridLineColors CreateGridLineColors()
    {
      return new DataVertGridLineOptions(this);
    }

    protected internal override void CurrencyManagerListChanged(object sender, ListChangedEventArgs e)
    {
      switch (e.ListChangedType)
      {
        case ListChangedType.Reset:
          InternalUpdateRowsList();
          CheckPropBarsPropDescr();
          ColumnsListChanged();
          //GridLayoutChanged();
          //UpdateRowHeights();
          if (CurrencyManager != null)
            CurrencyManagerPositionChanged(null, null);
          break;

        case ListChangedType.ItemMoved:
          //ColumnsListChanged();
          GridLayoutChanged();
          break;

        case ListChangedType.ItemAdded:
          //object row = CurrencyManager.List[e.NewIndex];
          //if ((e.NewIndex < Rows.Count) && (addedSrcRow == row))
          //  EhLibUtils.DoNothing();//Do nothing. It is second time
          //else
          //{
          //  AddDataRow(e.NewIndex);
          //  addedSrcRow = row;
          //}
          ColumnsListChanged();
          //UpdateRowHeights();
          //GridLayoutChanged();
          break;

        case ListChangedType.ItemChanged:
          //UpdateDataRow(e.NewIndex);
          ColumnsListChanged();
          //UpdateRowHeights();
          //GridLayoutChanged();
          break;

        case ListChangedType.ItemDeleted:
          //DeleteItem(e.NewIndex);
          ColumnsListChanged();
          //UpdateRowHeights();
          break;

        default:
          InternalUpdateRowsList();
          ColumnsListChanged();
          break;
      }
    }

    protected internal override void CurrencyManagerPositionChanged(object sender, EventArgs e)
    {
      UpdateGridColumnIndexFromCurrencyManagerPosition();

      //TODO: return this code for DataPropertyGrid
      //UpdateDataColumns();
      //UpdateRowHeights();
    }

    internal void UpdateGridColumnIndexFromCurrencyManagerPosition()
    {
      if (CurrencyManager.Position >= 0 && CurrencyManager.Position < VisibleColumns.Count)
      {
        InternalCurrentColumnIndex = CurrencyManager.Position;
      }
    }

    protected internal virtual void UpdateRowsView()
    {
      UpdatePropBarsView();
    }

    protected internal override void UpdatePropBarsView()
    {
      base.UpdatePropBarsView();
      GridLayoutChanged();
      //TODO ?
      //UpdateFitColWidthsToClient();
    }

    protected override void PropBarsListChanged()
    {
      base.PropBarsListChanged();
      GridLayoutChanged();
      //UpdateRowHeights();
    }

    protected internal void InternalUpdateRowsList()
    {
      UpdatePropBarsList();
    }

    public void RowsListChanged()
    {
      if (InInitialization || Rows.Updating) return;

      InternalUpdateRowsList();
      GridLayoutChanged();
    }

    protected internal virtual void ColumnsListChanged()
    {
      if (InInitialization || Rows.Updating) return;

      InternalUpdateColumnsList();
      GridLayoutChanged();

      //UpdateBaseGridRows();
      ////UpdateDataColumnWidths();

      //UpdateBaseColCount();
      //UpdateBaseColWidths();
      //InvalidateGrid();
    }

    protected internal virtual void InternalUpdateColumnsList()
    {
      ListItems.Clear();
      if (CurrencyManager != null && CurrencyManager.Count > 0)
      {
        //listItems.Add(CurrencyManager.Current);
        for (int i = 0; i < CurrencyManager.Count; i++)
        {
          var itemCol = new DataVertGridColumn();
          itemCol.SourceItem = CurrencyManager.List[i];
          ListItems.Add(itemCol);
        }
      }
    }

    public override PropertyAxisBar CreatePropBarFromType(Type type)
    {
      return Manager.GetDataVertGridRowFromType(type);
    }

    public override Type GetAxisBarTypeForDataType(Type type)
    {
      return Manager.GetDataVertGridRowTypeForDataType(type);
    }

    internal virtual void UpdateGridState()
    {
      gridIsEmpty = (Rows.Count == 0) && (CurrencyManager == null);
    }

    protected override DataAxisGridReadOnlyPropBarCollection CreatePropBarReadOnlyCollection(IList<PropertyAxisBar> list)
    {
      return new DataVertGridReadOnlyRowCollection(this, list);
    }

    protected override DataAxisGridMainPropBarCollection CreatePropBarMainCollection(IList<PropertyAxisBar> list)
    {
      return new DataVertGridMainRowCollection(this, list);
    }

    protected override DataAxisGridStaticPropBarCollection CreateStaticPropBarCollection()
    {
      return new DataVertGridStaticRowsCollection(this);
    }

    protected internal virtual bool RowCanBeVisible(DataVertGridRow dataVertGridRow)
    {
      return true;
    }

    protected internal override DataAxisGridTitleBar CreateTitleBar()
    {
      return new DataVertGridTitleColumn(this);
    }

    protected override void PerformGridLayout()
    {
      base.PerformGridLayout();

      UpdateBaseColCount();
      UpdateBaseColWidths();

      UpdateRowHeights();
      UpdateBaseGridRows();

      UpdateBoundaries();

      UpdateGridState();
      InvalidateGrid();
    }

    internal void UpdateRowHeights()
    {
      if (InInitialization) return;

      foreach (DataVertGridRow row in Rows)
      {
        row.Height = row.CalcHeight();
      }

      //UpdateBaseGridRows();
    }

    protected internal override void UpdateBaseFixedBands()
    {
      UpdateBaseGridRows();
      UpdateBaseColCount();
    }

    internal void UpdateBaseGridRows()
    {
      if ((InInitialization) || Rows.Updating) return;

      int newFixedRowCount = 0;
      int newRowCount;
      bool vertLayoutChanged = false;

      if (IndicatorRow.Visible)
        newFixedRowCount = 1;

      if (FixedRowCount != newFixedRowCount)
      {
        FixedRowCount = newFixedRowCount;
        vertLayoutChanged = true;
      }

      if (VisibleRows.Count == 0)
        StartDataRowBaseRowIndex = -1;
      else
        StartDataRowBaseRowIndex = FixedRowCount;

      newRowCount = FixedRowCount + VisibleRows.Count;
      if (VisibleRows.Count == 0)
        newRowCount = FixedRowCount + 1;

      if (RowCount != newRowCount)
      {
        RowCount = newRowCount;
        vertLayoutChanged = true;
      }

      for (int i = 0; i < VisibleRows.Count; i++)
      {
        DataVertGridRow row = VisibleRows[i];

        int newRowHeight = row.Height + LineOptions.VertLineSpace;
        if (newRowHeight != this.RowHeights[i + FixedRowCount])
        {
          this.RowHeights[i + FixedRowCount] = newRowHeight;
          vertLayoutChanged = true;
        }
      }

      if (vertLayoutChanged)
        UpdateBaseColWidths();
      Invalidate();
    }

    internal void HandleDataCellManagerNeededEvent(DataVertGridDataCellManagerNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellManagerNeeded] as EventHandler<DataVertGridDataCellManagerNeededEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    internal void UpdateBaseColCount()
    {
      int newColCount;
      int newFixedColCount;

      if (TitleColumn.Visible)
        newFixedColCount = 1;
      else
        newFixedColCount = 0;

      if (VisibleColumns.Count == 0)
        newColCount = newFixedColCount + 1;
      else
        newColCount = newFixedColCount + VisibleColumns.Count;

      TitleColumnBaseColIndex = newFixedColCount - 1;
      if (VisibleColumns.Count == 0)
      {
        StartDataColumnBaseColIndex = -1;
        EmptyDataColumnBaseColIndex = 1;
      }
      else
      {
        StartDataColumnBaseColIndex = 1;
        EmptyDataColumnBaseColIndex = -1;
      }

      if (newFixedColCount > FixedColCount)
      {
        ColCount = newColCount;
        FixedColCount = newFixedColCount;
      }
      else
      {
        FixedColCount = newFixedColCount;
        ColCount = newColCount;
      }
    }

    protected internal virtual void UpdateBaseColWidths()
    {
      int titleColWidth = TitleColumn.Width;

      ColWidths[0] = titleColWidth;
      if (VisibleColumns.Count == 0)
      {
        ColWidths[1] = ColumnOptions.Width;
      }
      else
      {
        for (int i = 0; i < VisibleColumns.Count; i++)
        {
          ColWidths[i + StartDataColumnBaseColIndex] = ColumnOptions.Width;
        }
      }
    }

    protected override void OnEndInitialization()
    {
      if (VisibleColumns == null) return;

      SuspendGridLayout();
      InternalUpdateRowsList();
      InternalUpdateColumnsList();
      ResumeGridLayout(true);
      //GridLayoutChanged();

      //UpdateBaseFixedBands();
      //InternalUpdateRowsList();
      //ColumnsListChanged();
      //UpdateRowHeights();
      //UpdateGridState();
    }

    protected internal override void UpdatePaddingsForSidePadding()
    {
      leftAlignDefaultPadding = new Padding(2);
      leftAlignDefaultPadding.Right = 0;

      centerAlignDefaultPadding = new Padding(2);
      centerAlignDefaultPadding.Right = 0;
      centerAlignDefaultPadding.Left = 0;

      rightAlignDefaultPadding = new Padding(2);
      rightAlignDefaultPadding.Left = 0;
    }

    protected internal override Padding GetDataCellSidePadding()
    {
      return RowOptions.SidePadding;
    }

    protected internal override void SidePaddingChanged()
    {
      UpdatePaddingsForSidePadding();
      UpdateRowHeights();
    }

    public override Padding GetDefaultPaddingForAlign(HorizontalAlignment horzAlign, VerticalAlignment vertAlign)
    {
      switch (horzAlign)
      {
        case HorizontalAlignment.Left:
          return leftAlignDefaultPadding;

        case HorizontalAlignment.Center:
          return centerAlignDefaultPadding;

        case HorizontalAlignment.Right:
          return rightAlignDefaultPadding;

        default:
          return Padding.Empty;
      }
    }

    protected internal override VerticalAlignment DefaultVertAlign()
    {
      return VerticalAlignment.Top;
    }

    internal void RowHeightAutoExpandChanged()
    {
      if (!InInitialization)
        UpdateRowHeights();
    }

    public override BaseGridCellManager CellManByColRow(int colIndex, int rowIndex, out int localColIndex, out int localRowIndex)
    {
      int areaColOffset = 0;
      int areaRowOffset = 0;
      BaseGridCellManager result;

      if (rowIndex >= 0 && rowIndex < FixedRowCount)
      {
        if (colIndex < FixedRowCount)
          result = titleIndicatorCell;
        else
        {
          result = indicatorRowCell;
          areaColOffset = StartDataColIndex;
        }
      }
      else if (colIndex >= 0 && colIndex < FixedColCount)
      {
        areaRowOffset = StartDataRowIndex;

        if (gridIsEmpty)
          result = emptyDataCell;
        else if (VisibleRows.Count > 0)
          result = titleCell;
        else
          result = emptyDataCell;
      }
      else
      {
        areaColOffset = StartDataColIndex;
        areaRowOffset = StartDataRowIndex;

        if (gridIsEmpty || colIndex == -1)
          result = emptyDataCell;
        else if (VisibleRows.Count == 0)
          result = emptyDataCell;
        else
        {
          if (VisibleRows.Count > 0)
          {
            DataVertGridRow dataRowIndex = VisibleRows[rowIndex - FixedRowCount];
            if (colIndex - FixedColCount < VisibleColumns.Count)
              result = dataRowIndex.InternalGetColumnCellManager(VisibleColumns[colIndex - FixedColCount]);
            else
              result = dataRowIndex.NewVirtualRowCell;
          }
          else
            result = emptyDataCell;
        }
      }

      localColIndex = colIndex - areaColOffset;
      localRowIndex = rowIndex - areaRowOffset;
      return result;
    }

    protected internal override bool FixedColsSizingAllowed()
    {
      return true;
    }

    protected override bool CanResizeCol(int colIndex, int rowIndex, int xPos, int yPos, int inCellXPos, int inCellYPos)
    {
      bool result = base.CanResizeCol(colIndex, rowIndex, xPos, yPos, inCellXPos, inCellYPos);
      if (colIndex != FixedColCount - 1)
        return false;
      else
        return result;
    }

    protected override void InteractiveSetColWidths(int colIndex, int newSize)
    {
      if (colIndex == FixedColCount - 1)
        TitleColumn.Width = newSize;
      else
        base.InteractiveSetColWidths(colIndex, newSize);
    }

    internal void TitleColumnWidthChanged()
    {
      if ((InInitialization) || Rows.Updating) return;
      GridLayoutChanged();
      //UpdateBaseColWidths();
      //UpdateRowHeights();
    }

    protected internal override HorizontalAlignment DefaultHorzAlignForType(Type dataType)
    {
      return HorizontalAlignment.Left;
    }

    protected internal override void RowHeightAffectPropertyChanged()
    {
      if (!InInitialization)
        UpdateRowHeights();
    }

    protected override void OnHandleCreated(EventArgs e)
    {
      base.OnHandleCreated(e);
    }

    protected override void OnCreateControl()
    {
      base.OnCreateControl();
      //UpdateBaseColWidths();
    }

    protected internal override bool DefaultAllowShowEditor()
    {
      return RowOptions.AllowShowEditor;
    }

    //protected internal override bool CanShowEditor()
    //{
    //  return !EditorBanned && RowOptions.CanShowEditor();
    //}

    protected internal override void OnDataCellContextMenuStripNeeded(DataAxisGridDataCellContextMenuStripNeededEventArgs age)
    {
      if (RowOptions.ContextMenuStrip != null)
        age.ContextMenuStrip = RowOptions.ContextMenuStrip;
      else
        age.ContextMenuStrip = ContextMenuStrip;
    }

    protected virtual DataVertGridIndicatorTitle CreateIndicatorTitle()
    {
      return new DataVertGridIndicatorTitle(this);
    }

    protected virtual DataVertGridIndicatorRow CreateIndicatorRow()
    {
      return new DataVertGridIndicatorRow(this);
    }

    protected override void PaintCell(GraphicsContext gc, int colIndex, int rowIndex, Rectangle rect, Rectangle cellAreaRect, BasePaintCellStates state)
    {
      base.PaintCell(gc, colIndex, rowIndex, rect, cellAreaRect, state);

      if (DesignMode)
      {
        IDesignerHost idh = (IDesignerHost)GetService(typeof(IDesignerHost));
        if (idh == null) return;
        var grd = idh.GetDesigner(this) as IDataVertGridDesigner;
        if (grd != null)
          grd.PaintCellDesignData(this, gc.Graphics, colIndex, rowIndex, rect, state);
      }
    }

    protected internal override void HandleDisplayValueNeededEvent(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellDisplayValueNeeded] as EventHandler<DataVertGridDataCellDisplayValueNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellDisplayValueNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellPaint] as EventHandler<DataVertGridDataCellPaintEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellPaintEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellContentPaintEvent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellContentPaint] as EventHandler<DataVertGridDataCellContentPaintEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellContentPaintEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellCustomAreaPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellCustomAreaPaint] as EventHandler<DataVertGridDataCellPaintEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellPaintEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellClientAreaNeededEvent(DataAxisGridDataCellClientAreaNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellClientAreaNeeded] as EventHandler<DataVertGridDataCellClientAreaNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellClientAreaNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleCanModifyStateNeededEvent(DataAxisGridDataCellCanModifyStateNeededEventArgs e)
    {
      var eh = Events[EventKeyDataCellCanModifyStateNeeded] as EventHandler<DataVertGridDataCellCanModifyStateNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellCanModifyStateNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleCanShowEditorStateNeededEvent(DataAxisGridDataCellCanShowEditorStateNeededEventArgs e)
    {
      var eh = Events[EventKeyDataCellCanShowEditorStateNeeded] as EventHandler<DataVertGridDataCellCanShowEditorStateNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellCanShowEditorStateNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditorParamsNeededEvent(DataAxisGridDataCellEditorParamsNeededEventArgs e)
    {
      var eh = Events[EventKeyDataCellEditorParamsNeeded] as EventHandler<DataVertGridDataCellEditorParamsEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellEditorParamsEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditValueNeededEvent(DataAxisGridDataCellEditValueNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellEditValueNeeded] as EventHandler<DataVertGridDataCellEditValueNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellEditValueNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleParseValueEvent(DataAxisGridDataCellParseValueEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellParseValue] as EventHandler<DataVertGridDataCellParseValueEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellParseValueEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditorOccupyEvent(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
      var eh = Events[EventKeyDataCellEditorOccupy] as EventHandler<DataVertGridDataCellEditorOccupyEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellEditorOccupyEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleEditorReleaseEvent(DataAxisGridDataCellEditorReleaseEventArgs e)
    {
      var eh = Events[EventKeyDataCellEditorRelease] as EventHandler<DataVertGridDataCellEditorReleaseEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellEditorReleaseEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellToolTipInfoNeeded(DataAxisGridDataCellToolTipInfoEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellToolTipInfo] as EventHandler<DataVertGridDataCellToolTipInfoEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellToolTipInfoEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal override void HandleDataCellContextMenuStripNeededEvent(DataAxisGridDataCellContextMenuStripNeededEventArgs e)
    {
      var eh = Events[EventKeyDataCellContextMenuStripNeeded] as EventHandler<DataVertGridDataCellContextMenuStripNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataVertGridDataCellContextMenuStripNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
      if (DesignMode && GridDesigner != null)
      {
        GridDesigner.GridMouseDown(e);
      }
      else
      {
        base.OnMouseDown(e);
      }
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
      if (DesignMode &&
          GridDesigner != null &&
          GridState == BaseGridState.Normal)
      {
        GridDesigner.GridMouseMove(e);
      }
      else
      {
        base.OnMouseMove(e);
      }
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
      if (DesignMode &&
          GridDesigner != null &&
          GridState == BaseGridState.Normal)
      {
        GridDesigner.GridMouseUp(e);
      }
      else
      {
        base.OnMouseUp(e);
      }
    }
    #endregion
  }

  public class DataVertGridBaseCellManager : BaseGridCellManager
  {

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public new DataVertGridEh BoundGrid
    {
      get { return (DataVertGridEh)base.BoundGrid; }
      set { base.BoundGrid = value; }
    }

    protected internal override void OnGetCellBorderParams(BaseGridCellBorderEventArgs e)
    {
      e.Style = DashStyle.Solid;

      if ((e.BorderType == GridCellBorderSide.Left) || (e.BorderType == GridCellBorderSide.Right))
      {
        if ((e.ColIndex < BoundGrid.FixedColCount) || (e.RowIndex < BoundGrid.FixedRowCount))
          e.Visible = BoundGrid.LineOptions.VertLines;
        else
          e.Visible = BoundGrid.LineOptions.VertLines;
        e.IsExtent = true;
      }
      else
      {
        if ((e.ColIndex < BoundGrid.FixedColCount) || (e.RowIndex < BoundGrid.FixedRowCount))
          e.Visible = BoundGrid.LineOptions.HorzLines;
        else
          e.Visible = BoundGrid.RowOptions.HorzLine.Visible;
        e.IsExtent = true;
      }

      if ((e.BorderType == GridCellBorderSide.Top || e.BorderType == GridCellBorderSide.Left) &&
          ((e.ColIndex == BoundGrid.ColCount) || (e.RowIndex == BoundGrid.RowCount))
      )
        e.Color = BoundGrid.GridLineColors.DarkColor;
      else if ((e.ColIndex < BoundGrid.FixedColCount - BoundGrid.FrozenColCount) || (e.RowIndex < BoundGrid.FixedRowCount - BoundGrid.FrozenRowCount))
        e.Color = BoundGrid.LineOptions.DarkColor;
      else if ((e.ColIndex == BoundGrid.FixedColCount - 1) && (e.BorderType == GridCellBorderSide.Right))
        e.Color = BoundGrid.LineOptions.DarkColor;
      else if ((e.RowIndex == BoundGrid.FixedRowCount - 1) && (e.BorderType == GridCellBorderSide.Bottom))
        e.Color = BoundGrid.LineOptions.DarkColor;
      else
        e.Color = BoundGrid.LineOptions.BrightColor;
    }
  }

  //[DataVertGridDataCellDesignTimeVisible(false)]
  [DataCellDesignTimeVisibleAttribute(false)]
  public class DataVertGridEmptyCellManager : BaseDataCellManager
  {
    public override string GetDisplayText(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      return null;
    }

    protected internal override void OnPaintBackground(BaseGridCellPaintEventArgs e)
    {
      using (
        SolidBrush fillBrush = new SolidBrush(BoundGrid.BackColor))
      {
        if ((BasePaintCellStates.Selected & e.State) != 0)
        {
          if (BoundGrid.IsActiveControl())
            fillBrush.Color = SystemColors.Highlight;
          else
            fillBrush.Color = SystemColors.ButtonShadow;
        }

        BoundGrid.PaintingFillRectangle(e.Graphics, fillBrush, e.ClientRect);
      }
    }
  }

  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataVertGridLineOptions : GridLineColors
  {
    #region privates
    private bool horzLines = true;
    private bool vertLines = true;
    #endregion privates

    public DataVertGridLineOptions(BaseGridControl grid) : base(grid)
    {
    }

    #region design-time properties
    public new Color DarkColor
    {
      get { return base.DarkColor; }
      set { base.DarkColor = value; }
    }

    public new Color BrightColor
    {
      get { return base.BrightColor; }
      set { base.BrightColor = value; }
    }

    [DefaultValue(true)]
    public bool HorzLines
    {
      get { return horzLines; }
      set
      {
        if (horzLines != value)
        {
          horzLines = value;
          HorzLinesChanged();
        }
      }
    }

    [DefaultValue(true)]
    public bool VertLines
    {
      get { return vertLines; }
      set
      {
        if (vertLines != value)
        {
          vertLines = value;
          VertLinesChanged();
        }
      }
    }
    #endregion

    #region run-time properties
    [Browsable(false)]
    protected new DataVertGridEh Grid
    {
      get { return (DataVertGridEh)base.Grid; }
    }

    [Browsable(false)]
    public int VertLineSpace
    {
      get
      {
        if (VertLines)
          return Grid.GridLineWidth;
        else
          return 0;
      }
    }

    [Browsable(false)]
    public int HorzLineSpace
    {
      get
      {
        if (HorzLines)
          return Grid.GridLineWidth;
        else
          return 0;
      }
    }
    #endregion

    #region methods
    protected virtual void VertEmptySpaceStyleChanged()
    {
      Grid.InvalidateGrid();
    }

    protected virtual void HorzEmptySpaceStyleChanged()
    {
      Grid.InvalidateGrid();
    }

    protected virtual void GridBoundariesChanged()
    {
      Grid.InvalidateGrid();
    }

    protected virtual void HorzLinesChanged()
    {
      if (HorzLines)
        Grid.Options = Grid.Options | GridOptions.HorzLines;
      else
        Grid.Options = Grid.Options & ~GridOptions.HorzLines;

      Grid.UpdateRowsView();
    }

    protected virtual void VertLinesChanged()
    {
      Grid.UpdateBaseColWidths();
    }
    #endregion methods

  }

  public class DataVertGridObject : object
  {
    private readonly DataVertGridEh grid;

    public DataVertGridObject(DataVertGridEh grid)
    {
      this.grid = grid;
    }

    [Browsable(false)]
    public DataVertGridEh Grid
    {
      get { return grid; }
    }

  }

  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataVertGridRowOptions : DataVertGridObject, IGridLineHost, IGridRowHeightOptionsOwner
  {

    #region privates
    private bool allowShowEditor = true;
    private bool foreColorStored;
    private Color foreColor = Color.Empty;
    private Padding sidePadding = new Padding(2, 2, 2, 2);
    private bool sidePaddingStored;
    private Font font;
    private CellTextWrapMode wrapMode = CellTextWrapMode.Auto;
    private VerticalAlignment vertAlign = VerticalAlignment.Top;
    private readonly GridLine horzLine;
    private readonly GridRowHeightOptions heightOptions;
    #endregion privates

    public DataVertGridRowOptions(DataVertGridEh grid) : base(grid)
    {
      this.horzLine = new GridLine(this);
      this.heightOptions = new GridRowHeightOptions(this);
    }

    #region properties
    [DefaultValue(true)]
    public bool AllowShowEditor
    {
      get
      {
        return allowShowEditor;
      }
      set
      {
        if ((allowShowEditor != value))
        {
          allowShowEditor = value;
        }
      }
    }

    public Color ForeColor
    {
      get
      {
        if (foreColorStored)
          return foreColor;
        else
          return DefaultForeColor();
      }
      set
      {
        if ((foreColorStored == false) || (foreColor != value))
        {
          foreColorStored = true;
          foreColor = value;
          ForeColorChanged();
        }
      }
    }

    public Font Font
    {
      get
      {
        if (font != null)
          return font;
        else
          return DefaultFont();
      }
      set
      {
        font = value;
        FontChanged();
      }
    }

    public Padding SidePadding
    {
      get
      {
        if (sidePaddingStored)
          return sidePadding;
        else
          return DefaultSidePadding();
      }
      set
      {
        if ((sidePaddingStored == false) || (sidePadding != value))
        {
          sidePaddingStored = true;
          sidePadding = value;
          SidePaddingChanged();
        }
      }
    }

    [DefaultValue(CellTextWrapMode.Auto)]
    public CellTextWrapMode WrapMode
    {
      get
      {
        return wrapMode;
      }
      set
      {
        if (wrapMode != value)
        {
          wrapMode = value;
          WrapModeChanged();
        }
      }
    }

    [DefaultValue(VerticalAlignment.Top)]
    public VerticalAlignment VertAlign
    {
      get
      {
        return vertAlign;
      }
      set
      {
        if (vertAlign != value)
        {
          vertAlign = value;
          VertAlignChanged();
        }
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridLine HorzLine
    {
      get
      {
        return horzLine;
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridRowHeightOptions HeightOptions
    {
      get
      {
        return heightOptions;
      }
    }

    [DefaultValue(null)]
    public virtual ContextMenuStrip ContextMenuStrip { get; set; }
    #endregion properties

    #region methods

    //Font
    protected virtual Font DefaultFont()
    {
      return Grid.Font;
    }

    protected virtual bool ShouldSerializeFont()
    {
      return (font != null);
    }

    public virtual void ResetFont()
    {
      font = null;
      FontChanged();
    }

    protected virtual void FontChanged()
    {
      Grid.UpdateRowHeights();
    }

    //IGridLineHost
    void IGridLineHost.GridLineChanged(GridLine gl)
    {
      GridLineChanged(gl);
    }

    protected virtual void GridLineChanged(GridLine gl)
    {
      Grid.Invalidate();
    }

    public virtual bool GridLineDefaultVisible(GridLine gl)
    {
      return Grid.LineOptions.VertLines;
    }

    public virtual Color GridLineDefaultColor(GridLine gl)
    {
      return Grid.LineOptions.BrightColor;
    }

    public virtual DashStyle GridLineDefaultStyle(GridLine gl)
    {
      return DashStyle.Solid;
    }

    //IGridRowHeightOptionsOwner
    public void HeightOptionsChanged(GridRowHeightOptions heightOptions)
    {
      if (Grid != null)
        Grid.RowHeightAutoExpandChanged();
    }

    public bool HeightOptionsDefaultAutoExpand(GridRowHeightOptions heightOptions)
    {
      return false;
    }

    public int HeightOptionsDefaultContentHeight(GridRowHeightOptions heightOptions)
    {
      return 1;
    }

    public int HeightOptionsDefaultMaxContentHeight(GridRowHeightOptions heightOptions)
    {
      return 0;
    }

    public GridRowHeightUnit HeightOptionsDefaultUnit(GridRowHeightOptions heightOptions)
    {
      return GridRowHeightUnit.TextLine;
    }

    //Others
    protected virtual void VertAlignChanged()
    {
      Grid.Invalidate();
    }

    private void WrapModeChanged()
    {
      Grid.UpdateRowHeights();
    }

    protected virtual void ForeColorChanged()
    {
      Grid.InvalidateGrid();
    }

    public virtual Color DefaultForeColor()
    {
      return Grid.ForeColor;
    }

    protected virtual bool ShouldSerializeForeColor()
    {
      return (foreColorStored == true);
    }

    public virtual void ResetForeColor()
    {
      foreColorStored = false;
      ForeColorChanged();
    }

    protected virtual void SidePaddingChanged()
    {
      Grid.SidePaddingChanged();
    }

    private Padding DefaultSidePadding()
    {
      return Grid.GetDrawStyle().GetColumnOptionsSidePadding();
    }

    protected virtual bool ShouldSerializeSidePadding()
    {
      return (sidePaddingStored == true);
    }

    public virtual void ResetSidePadding()
    {
      sidePaddingStored = false;
      SidePaddingChanged();
    }

    protected virtual void HeightTextLinesChanged()
    {
      Grid.UpdateRowHeights();
    }

    public virtual bool CanShowEditor()
    {
      if (AllowShowEditor && Grid.Options.HasFlag(GridOptions.Editing))
        return true;
      else
        return false;
    }

    internal void EditItemOptionsChanged()
    {
      Grid.Invalidate();
    }
    #endregion methods

  }

  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataVertGridColumnOptions : DataVertGridObject
  {
    #region privates
    private bool fitWidthToWinClient;
    private int width = 200;
    #endregion

    public DataVertGridColumnOptions(DataVertGridEh grid) : base(grid)
    {
    }

    #region properties
    [DefaultValue(false)]
    public bool FitWidthToWinClient
    {
      get
      {
        return fitWidthToWinClient;
      }
      set
      {
        if (fitWidthToWinClient != value)
        {
          fitWidthToWinClient = value;
        }
      }
    }

    [DefaultValue(200)]
    public int Width
    {
      get
      {
        return width;
      }
      set
      {
        if (width != value)
        {
          width = value;
        }
      }
    }
    #endregion

    #region methods

    //Others
    #endregion

  }

  /// <summary>
  /// Contains properties for customizing respond on pressing some keys in <see cref="DataVertGridEh"/>.
  /// </summary>
  /// <remarks>
  /// You can retrieve an instance of this class through the <see cref="DataVertGridEh.KeyboardOptions"/> property.
  /// </remarks>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataVertGridKeyboardOptions : GridKeyboardOptions
  {

    public DataVertGridKeyboardOptions(/*DataAxisGrid grid*/) : base(/*grid*/)
    {
      base.TabKeyAction = GridKeyboardAction.NextRowCell;
    }

    [DefaultValue(GridKeyboardAction.NextRowCell)]
    public override GridKeyboardAction TabKeyAction
    {
      get { return base.TabKeyAction; }
      set { base.TabKeyAction = value; }
    }
  }

  /// <summary>
  /// Represents a column in a DataVertGridEh control.
  /// </summary>
  public class DataVertGridColumn : DataAxisGridListItemBar
  {
    #region >privates
    #endregion <privates

    public DataVertGridColumn()
    {
    }

    #region >properties
    #endregion <properties

    #region >methods
    #endregion <methods
  }

}
