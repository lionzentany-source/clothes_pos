﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of data cell manager in a grid that displays a button user interface (UI).
  /// </summary>
  //[DataCellDesignTimeVisible(true)]
  //[ToolboxItem(true)]
  [DataCellDesignTimeVisible(true)]
  public class ButtonDataCellManager : ButtonBaseDataCellManager
  {

    #region internal
    protected internal int HotButtonDataRow = -1;

    private FlatStyle flatStyle = FlatStyle.Standard;
    private string text = "";
    private bool useColumnTextForButtonValue;
    private bool buttonPaddingStored;
    private Padding buttonPadding = new Padding(0);
    private Padding defaultButtonPadding = new Padding(2, 3, 2, 3);
    //protected bool downState = false;
    #endregion

    #region properties
    [DefaultValue(FlatStyle.Standard)]
    public FlatStyle FlatStyle
    {
      get
      {
        return flatStyle;
      }
      set
      {
        if (flatStyle != value)
        {
          flatStyle = value;
          if (BoundGrid != null)
            BoundGrid.InvalidateGrid();
        }
      }
    }

    [DefaultValue("")]
    public string Text
    {
      get
      {
        return text;
      }
      set
      {
        if (value != text)
        {
          text = value;
          if (BoundGrid != null)
            BoundGrid.InvalidateGrid();
        }
      }
    }

    [DefaultValue(false)]
    public bool UseColumnTextForButtonValue
    {
      get
      {
        return useColumnTextForButtonValue;
      }
      set
      {
        if (useColumnTextForButtonValue != value)
        {
          useColumnTextForButtonValue = value;
          if (BoundGrid != null)
            BoundGrid.InvalidateGrid();
        }
      }
    }
    #endregion

    #region runtime properties
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public new bool DownState
    {
      get
      {
        return base.DownState;
      }
      set
      {
        if (value != base.DownState)
        {
          base.DownState = value;
          if (BoundGrid != null)
            BoundGrid.InvalidateGrid();
        }
      }
    }

    public Padding ButtonPadding
    {
      get
      {
        if (buttonPaddingStored)
          return buttonPadding;
        else
          return DefaultButtonPadding();
      }
      set
      {
        buttonPadding = value;
        buttonPaddingStored = true;
        ButtonPaddingChanged();
      }
    }

    #endregion

    #region methods
    //ButtonPadding
    public virtual void ButtonPaddingChanged()
    {
      if (BoundGrid != null)
        BoundGrid.UpdateBaseFixedBands();
    }

    public virtual Padding DefaultButtonPadding()
    {
      //if (BoundGrid != null)
      //  return defaultButtonPadding;
      //else
      //  return Padding.Empty;
      return defaultButtonPadding;
    }

    public virtual bool ShouldSerializeButtonPadding()
    {
      return (buttonPaddingStored == true);
    }

    public virtual void ResetButtonPadding()
    {
      buttonPaddingStored = false;
      ButtonPaddingChanged();
    }

    //Other
    public override Padding DefaultPadding()
    {
      if (BoundGrid != null)
        return GetPaddingForSidePadding(BoundGrid.GetDataCellSidePadding());
      else
        return Padding.Empty;
    }

    public override Padding GetDefaultPadding(PropertyAxisBar propAxisBar)
    {
      if (propAxisBar != null && propAxisBar.Grid != null)
        return GetPaddingForSidePadding(propAxisBar.Grid.GetDataCellSidePadding());
      else
        return Padding.Empty;
    }

    protected Padding GetPaddingForSidePadding(Padding sidePadding)
    {
      // ReSharper disable once UseObjectOrCollectionInitializer
      var result = new Padding();

      result.Left = Math.Max(sidePadding.Left, sidePadding.Right);
      result.Right = result.Left;
      result.Top = sidePadding.Top;
      result.Bottom = sidePadding.Bottom;

      return result;
    }

    protected internal virtual void SetHotButtonDataRow(DataAxisGrid grid, bool isHot, int colIndex, int rowIndex, int dataColIndex, int dataRowIndex)
    {
      if (dataRowIndex == -1 && isHot == false && HotButtonDataRow != -1)
      {
        HotButtonDataRow = -1;
        grid.InvalidateCell(colIndex, rowIndex);
      }
      else if (HotButtonDataRow != dataRowIndex && isHot)
      {
        HotButtonDataRow = dataRowIndex;
        grid.InvalidateCell(colIndex, rowIndex);
      }
      else if (HotButtonDataRow == dataRowIndex && !isHot)
      {
        HotButtonDataRow = -1;
        grid.InvalidateCell(colIndex, rowIndex);
      }
    }

    public override string GetDisplayText(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      if (UseColumnTextForButtonValue)
        return Text;
      else
        return base.GetDisplayText(propAxisBar, listItemBar);
    }

    protected internal override void OnPaintContent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      Rectangle buttonPaintRect = e.CellContentRect;
      PushButtonState buttonState;

      if (DownState && (e.Grid.CurrentDataRowIndex == e.ParentCellPaintArgs.AreaRowIndex))
        buttonState = PushButtonState.Pressed;
      else if (HotButtonDataRow == e.ParentCellPaintArgs.AreaRowIndex)
        buttonState = PushButtonState.Hot;
      else if (e.Grid.Col == e.ColIndex &&
               e.Grid.Row == e.RowIndex &&
               e.Grid.Focused)
        buttonState = PushButtonState.Default;
      else
        buttonState = PushButtonState.Normal;

      Padding padding = e.ParentCellPaintArgs.Padding;
      buttonPaintRect.X = buttonPaintRect.X + padding.Left;
      buttonPaintRect.Y = buttonPaintRect.Y + padding.Top;
      buttonPaintRect.Width = buttonPaintRect.Width - padding.Left - padding.Right;
      buttonPaintRect.Height = buttonPaintRect.Height - padding.Top - padding.Bottom;
      if (buttonPaintRect.Width < 0) buttonPaintRect.Width = 0;
      if (buttonPaintRect.Height < 0) buttonPaintRect.Height = 0;

      if (buttonPaintRect.Width > 0 && buttonPaintRect.Height > 0)
      {
        //ButtonRenderer.DrawButton(e.Graphics, buttonPaintRect, buttonState);
        EhLibPushButtonRenderer cbRenderer = EhLibRenderManager.DefaultEhLibRenderManager.PushButtonRenderer;
        cbRenderer.DrawButton(e.GraphicsContext, buttonPaintRect, buttonState);
      }

      DrawButtonForeground(e.ParentCellPaintArgs, buttonPaintRect);
    }

    protected virtual void DrawButtonForeground(DataAxisGridDataCellPaintEventArgs e, Rectangle buttonDrawRect)
    {
      Color fForeColor = e.Grid.ForeColor;
      bool clipped = false;
      Region clientClip = null;

      if (DownState && (e.Grid.CurrentDataRowIndex == e.DataRowIndex))
      {
        clientClip = e.Graphics.Clip;
        e.Graphics.SetClip(buttonDrawRect, CombineMode.Intersect);
        clipped = true;
        buttonDrawRect.Offset(new Point(1, 1));
      }

      //TextFormatFlags fmtFlags = TextFormatFlags.Left |
      //                            TextFormatFlags.VerticalCenter |
      //                            TextFormatFlags.PreserveGraphicsClipping |
      //                            TextFormatFlags.HorizontalCenter;

      string text = GetDisplayText(e.PropAxisBar, e.ListItemBar);
      if (text != null)
        e.GraphicsContext.DrawText(text, Font, buttonDrawRect, fForeColor, 
          HorizontalAlignment.Center, VerticalAlignment.Center, 0);

      if (clipped)
      {
        e.Graphics.Clip = clientClip;
        buttonDrawRect.Offset(new Point(-1, -1));
      }
    }

    protected internal override void OnMouseDown(DataAxisGridDataCellMouseEventArgs e)
    {
      base.OnMouseDown(e);

      Rectangle cellBounds = e.CellRect;
      Rectangle clientBounds = e.ClientRect;
      clientBounds.X = clientBounds.Left - cellBounds.Left;
      clientBounds.Y = clientBounds.Top - cellBounds.Top;

      Rectangle buttonRect = EhLibUtils.TrimPadding(clientBounds, GetPadding(e.PropAxisBar));

      if (buttonRect.Contains(e.InCellX, e.InCellY))
        DownState = true;
    }

    protected internal override void OnMouseMove(DataAxisGridDataCellMouseEventArgs e)
    {
      base.OnMouseMove(e);

      Rectangle cellBounds = e.CellRect;
      cellBounds.Location = Point.Empty;

      Rectangle buttonRect = EhLibUtils.TrimPadding(cellBounds, GetPadding(e.PropAxisBar));
      DataAxisGrid axisGrid = e.Grid as DataAxisGrid;

      if (buttonRect.Contains(e.InCellX, e.InCellY))
        SetHotButtonDataRow(axisGrid, true, e.ColIndex, e.RowIndex, e.AreaColIndex, e.AreaRowIndex);
      else
        SetHotButtonDataRow(axisGrid, false, e.ColIndex, e.RowIndex, e.AreaColIndex, e.AreaRowIndex);
    }

    protected internal override void OnMouseUp(BaseGridCellMouseEventArgs e)
    {
      //int dataColIndex;
      //int dataRowIndex;

      //GridCellPosToAreaCellPos(e.ColIndex, e.RowIndex, out dataColIndex, out dataRowIndex);
      if (DownState &&
          (e.InCellX >= 0) &&
          (e.InCellY >= 0) &&
          (e.InCellX < e.CellRect.Width) &&
          (e.InCellY < e.CellRect.Height))
      {

        PropertyAxisBar propAxisBar;
        DataAxisGridListItemBar listItemBar;
        DataAxisGrid axisGrid = e.Grid as DataAxisGrid;

        AxisObjectsByDataColRowIndex(axisGrid, e.AreaColIndex, e.AreaRowIndex, out propAxisBar, out listItemBar);

        DataAxisGridDataCellEventArgs de = CreateDataCellEventArgs(
          axisGrid, e.ColIndex, e.RowIndex, e.AreaColIndex, e.AreaRowIndex, e.CellRect, propAxisBar, listItemBar, this);
        axisGrid.OnDataCellClick(de);
      }
      base.OnMouseUp(e);
      DownState = false;
    }

    protected internal override void OnMouseEnter(DataAxisGridDataCellEnterEventArgs e)
    {
      e.Grid.InvalidateCell(e.ColIndex, e.RowIndex);
      base.OnMouseEnter(e);
    }

    protected internal override void OnMouseLeave(BaseGridCellLeaveEventArgs e)
    {
      e.Grid.InvalidateCell(e.ColIndex, e.RowIndex);
      base.OnMouseLeave(e);
      SetHotButtonDataRow(e.Grid as DataAxisGrid, false, e.ColIndex, e.RowIndex, e.AreaColIndex, e.AreaRowIndex);
    }

    protected internal override int CalcDefaultRowHeight(PropertyAxisBar propAxisBar)
    {
      int th;

      Padding padding = GetPadding(propAxisBar);
      Font font = GetFont(propAxisBar);
      th = EhLibUtils.GetFontHeight(font);
      th = th + padding.Top + padding.Bottom + ButtonPadding.Top + ButtonPadding.Bottom;
      return th;
    }

    protected internal override int CalcCellHeight(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, int cellWidth)
    {
      int th;
      Padding padding = GetPadding(propAxisBar);

      if (HeightOptions.Unit == GridRowHeightUnit.TextLine)
      {
        th = EhLibUtils.GetFontHeight(GetFont(propAxisBar)) * HeightOptions.ContentHeight;
        th = th + padding.Top + padding.Bottom + ButtonPadding.Top + ButtonPadding.Bottom;
      }
      else
      {
        th = HeightOptions.ContentHeight;
        th = th + padding.Top + padding.Bottom + ButtonPadding.Top + ButtonPadding.Bottom;
      }

      return th;
    }

    public override string GetTypeNameAbbr()
    {
      return "Btn";
    }
    #endregion

  }

}
