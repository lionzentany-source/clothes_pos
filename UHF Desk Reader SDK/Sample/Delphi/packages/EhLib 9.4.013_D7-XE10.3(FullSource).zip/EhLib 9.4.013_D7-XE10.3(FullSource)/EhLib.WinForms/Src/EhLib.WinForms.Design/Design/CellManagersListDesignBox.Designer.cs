﻿namespace EhLib.WinForms.Design
{
  partial class CellManagersListDesignBox
  {
    /// <summary> 
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary> 
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Component Designer generated code

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CellManagersListDesignBox));
      this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
      this.framePanel = new EhLib.WinForms.PanelEh();
      this.managerGrid = new EhLib.WinForms.Design.DataGridDesignManagerGrid();
      this.dataGridTextColumn1 = new EhLib.WinForms.DataGridTextColumn();
      this.toolStrip1 = new System.Windows.Forms.ToolStrip();
      this.tbShowEditor = new System.Windows.Forms.ToolStripButton();
      this.tsButton = new System.Windows.Forms.ToolStripButton();
      ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
      this.framePanel.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.managerGrid)).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // bindingSource1
      // 
      this.bindingSource1.CurrentChanged += new System.EventHandler(this.BindingSource1_CurrentChanged);
      // 
      // framePanel
      // 
      this.framePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.framePanel.Controls.Add(this.managerGrid);
      this.framePanel.Controls.Add(this.toolStrip1);
      this.framePanel.CustomBorderColor = System.Drawing.Color.Empty;
      this.framePanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.framePanel.Location = new System.Drawing.Point(0, 0);
      this.framePanel.Name = "framePanel";
      this.framePanel.Size = new System.Drawing.Size(400, 435);
      this.framePanel.TabIndex = 10;
      // 
      // managerGrid
      // 
      this.managerGrid.AutoSizeColumnOptions.FitToClient = true;
      // 
      // 
      // 
      this.managerGrid.Border.BorderSides.Bottom.Visible = false;
      this.managerGrid.Border.BorderSides.Left.Visible = false;
      this.managerGrid.Border.BorderSides.Right.Visible = false;
      this.managerGrid.Border.Style = EhLib.WinForms.ControlBorderStyle.Custom;
      this.managerGrid.ColumnOptions.AllowMoveColumns = false;
      this.managerGrid.ColumnOptions.AllowShowEditor = false;
      this.managerGrid.DataSource = this.bindingSource1;
      this.managerGrid.Dock = System.Windows.Forms.DockStyle.Fill;
      // 
      // managerGrid.IndicatorColumn
      // 
      this.managerGrid.IndicatorColumn.Visible = false;
      this.managerGrid.LineOptions.HorzLines = false;
      this.managerGrid.Location = new System.Drawing.Point(0, 25);
      this.managerGrid.Name = "managerGrid";
      this.managerGrid.ReadOnly = true;
      this.managerGrid.Selection.AllowedSelection.All = false;
      this.managerGrid.Selection.AllowedSelection.Cells = false;
      this.managerGrid.Selection.AllowedSelection.Columns = false;
      this.managerGrid.Selection.AllowedSelection.Rows = false;
      this.managerGrid.Size = new System.Drawing.Size(398, 408);
      this.managerGrid.StaticColumns.AddRange(new EhLib.WinForms.PropertyAxisBar[] {
            this.dataGridTextColumn1});
      this.managerGrid.TabIndex = 7;
      // 
      // managerGrid.Title
      // 
      this.managerGrid.Title.HorzLine.Visible = true;
      // 
      // dataGridTextColumn1
      // 
      this.dataGridTextColumn1.DataPropertyName = "Name";
      this.dataGridTextColumn1.FillWeight = 397F;
      this.dataGridTextColumn1.FormatString = null;
      this.dataGridTextColumn1.Name = "dataGridTextColumn1";
      // 
      // dataGridTextColumn1.Title
      // 
      this.dataGridTextColumn1.Title.Text = "CellManagerList Designer";
      this.dataGridTextColumn1.Width = 0;
      // 
      // toolStrip1
      // 
      this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
      this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tbShowEditor,
            this.tsButton});
      this.toolStrip1.Location = new System.Drawing.Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
      this.toolStrip1.Size = new System.Drawing.Size(398, 25);
      this.toolStrip1.TabIndex = 0;
      this.toolStrip1.Text = "toolStrip1";
      // 
      // tbShowEditor
      // 
      this.tbShowEditor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
      this.tbShowEditor.Image = ((System.Drawing.Image)(resources.GetObject("tbShowEditor.Image")));
      this.tbShowEditor.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tbShowEditor.Name = "tbShowEditor";
      this.tbShowEditor.Size = new System.Drawing.Size(40, 22);
      this.tbShowEditor.Text = "Edit...";
      this.tbShowEditor.Click += new System.EventHandler(this.TbShowEditor_Click);
      // 
      // tsButton
      // 
      this.tsButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
      this.tsButton.Image = ((System.Drawing.Image)(resources.GetObject("tsButton.Image")));
      this.tsButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.tsButton.Name = "tsButton";
      this.tsButton.Size = new System.Drawing.Size(125, 22);
      this.tsButton.Text = "Add from DataSource";
      this.tsButton.Click += new System.EventHandler(this.TsButton_Click);
      // 
      // CellManagersListDesignBox
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.Controls.Add(this.framePanel);
      this.Name = "CellManagersListDesignBox";
      this.Size = new System.Drawing.Size(400, 435);
      ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
      this.framePanel.ResumeLayout(false);
      this.framePanel.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.managerGrid)).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);

    }

    #endregion

    private EhLib.WinForms.PanelEh framePanel;
    private EhLib.WinForms.Design.DataGridDesignManagerGrid managerGrid;
    private DataGridTextColumn dataGridTextColumn1;
    private System.Windows.Forms.ToolStrip toolStrip1;
    private System.Windows.Forms.ToolStripButton tbShowEditor;
    private System.Windows.Forms.BindingSource bindingSource1;
    private System.Windows.Forms.ToolStripButton tsButton;
  }
}
