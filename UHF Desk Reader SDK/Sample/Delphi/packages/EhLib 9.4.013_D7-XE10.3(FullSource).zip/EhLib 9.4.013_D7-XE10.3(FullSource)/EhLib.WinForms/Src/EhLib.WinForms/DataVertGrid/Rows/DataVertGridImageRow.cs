﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Drawing.Drawing2D;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of row in a DataVertGridEh control that displays a graphic.
  /// </summary>
  [DataVertGridRowDesignTimeVisible(true)]
  public class DataVertGridImageRow : DataVertGridRow
  {

    public DataVertGridImageRow()
    {

    }

    #region design-time properties

    [DefaultValue(PictureSizeMode.Fit)]
    public PictureSizeMode SizeMode
    {
      get { return DataCell.SizeMode; }
      set { DataCell.SizeMode = value; }
    }

    [DefaultValue(1.0)]
    public double Scale
    {
      get { return DataCell.Scale; }
      set { DataCell.Scale = value; }
    }
    #endregion

    #region run-time properties
    [Browsable(false)]
    public new ImageDataCellManager DataCell
    {
      get { return (ImageDataCellManager)base.InternalCellManager; }
    }
    #endregion

    #region methods
    protected override BaseDataCellManager CreateTemplateCell()
    {
      return new ImageDataCellManager();
    }
    #endregion
  }

}
