﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  public class DataPropertyGridManager : DataVertGridManager
  {

    #region static fields
    private static DataPropertyGridManager _defaultManager;
    #endregion static fields

    #region privates
    private DataPropertyGridPrintService printService;
    private ContextMenuStrip indicatorTitlePopupMenu;
    private ToolStripMenuItem indicatorTitleVisibleRowsMenuItem;
    private ToolStripMenuItem indicatorTitleCustomizeColumnsMenuItem;
    private ToolStripMenuItem indicatorTitlePrintMenuItem;
    private ToolStripMenuItem indicatorTitlePrintSetupMenuItem;
    #endregion privates

    #region constructor
    public DataPropertyGridManager()
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        if (printService != null) printService.Dispose();
        if (indicatorTitlePopupMenu != null) indicatorTitlePopupMenu.Dispose();

        if (indicatorTitleVisibleRowsMenuItem != null) indicatorTitleVisibleRowsMenuItem.Dispose();
        if (indicatorTitleCustomizeColumnsMenuItem != null) indicatorTitleCustomizeColumnsMenuItem.Dispose();
        if (indicatorTitlePrintMenuItem != null) indicatorTitlePrintMenuItem.Dispose();
        if (indicatorTitlePrintSetupMenuItem != null) indicatorTitlePrintSetupMenuItem.Dispose();
      }

      base.Dispose(disposing);
    }
    #endregion constructor

    public new static DataPropertyGridManager DefaultManager
    {
      get
      {
        if (_defaultManager == null)
          _defaultManager = new DataPropertyGridManager();
        return _defaultManager;
      }
      set
      {
        _defaultManager = value;
      }
    }

    #region properties
    public DataPropertyGridPrintService PrintService
    {
      get
      {
        if (printService == null)
          printService = CreateDefaultPrintService();
        return printService;
      }
      set
      {
        printService = value;
      }
    }
    #endregion

    public virtual void PrintPreview(DataPropertyGridEh grid)
    {
      PrintService.PrintPreview(grid);
    }

    protected virtual DataPropertyGridPrintService CreateDefaultPrintService()
    {
      DataPropertyGridPrintService result = new DataPropertyGridPrintService();
      result.PageFooter.CenterText = "Page &[Page] of &[Pages]";
      result.PageHeader.RightText = "&[Date]";
      return result;

    }

    public override void BuildIndicatorTitleMenu(DataVertGridEh grid, ref ToolStripDropDown popupMenu)
    {
      BuildIndicatorTitleMenu((DataPropertyGridEh)grid, ref popupMenu);
    }

    public virtual void BuildIndicatorTitleMenu(DataPropertyGridEh grid, ref ToolStripDropDown popupMenu)
    {
      ToolStripItem mi;
      ToolStripMenuItem cmi;
      bool isAddMenuItem;

      if (popupMenu == null)
      {
        if (indicatorTitlePopupMenu == null)
        {
          indicatorTitlePopupMenu = new DataGridContextMenuStrip();
        }

        indicatorTitlePopupMenu.Items.Clear();

        popupMenu = indicatorTitlePopupMenu;
      }
      else if (popupMenu.Items.Count > 0)
      {

        mi = new ToolStripSeparator();
        popupMenu.Items.Add(mi);
      }

      if (grid.IndicatorTitle.UseGlobalMenu)
      {

        //Columns visibility
        //BuildVisibleColumnsMenuItem(grid, popupMenu);
        BuildCustomizeColumnsMenuItem(grid, popupMenu);

        //Print
        {
          if (indicatorTitlePrintMenuItem == null)
          {
            indicatorTitlePrintMenuItem = new ToolStripMenuItem();
            indicatorTitlePrintMenuItem.Click += IndicatorTitleMenuPrintClick;
          }
          cmi = indicatorTitlePrintMenuItem;
          if (cmi.Owner != null)
            cmi.Owner.Items.Remove(cmi);

          InitPrintIndicatorTitleMenuItem(grid, popupMenu, cmi, out isAddMenuItem);

          if (isAddMenuItem)
            popupMenu.Items.Add(cmi);
        }

        //Print Setup
        {
          if (indicatorTitlePrintSetupMenuItem == null)
          {
            indicatorTitlePrintSetupMenuItem = new ToolStripMenuItem();
            indicatorTitlePrintSetupMenuItem.Click += IndicatorTitleMenuPrintSetupClick;
          }
          cmi = indicatorTitlePrintSetupMenuItem;
          if (cmi.Owner != null)
            cmi.Owner.Items.Remove(cmi);

          InitPrintSetupIndicatorTitleMenuItem(grid, popupMenu, cmi, out isAddMenuItem);
          if (isAddMenuItem)
            popupMenu.Items.Add(cmi);
        }

      }

    }

    protected virtual void BuildVisibleColumnsMenuItem(DataPropertyGridEh grid, ToolStripDropDown popupMenu)
    {
      //Columns visibility
      if (indicatorTitleVisibleRowsMenuItem == null)
      {
        indicatorTitleVisibleRowsMenuItem = new ToolStripMenuItemEh();
        //indicatorTitleVisibleColumnsMenuItem.DropDown.Closing += ContextMenuClosing;
        //indicatorTitleVisibleColumnsMenuItem.DropDownItemClicked += ContextMenuItemClicked;
      }
      if (indicatorTitleVisibleRowsMenuItem.Owner != null)
        indicatorTitleVisibleRowsMenuItem.Owner.Items.Remove(indicatorTitleVisibleRowsMenuItem);
      indicatorTitleVisibleRowsMenuItem.DropDownItems.Clear();
      indicatorTitleVisibleRowsMenuItem.Text = Properties.Resources.DataGridMenu_VisibleColumns;
      popupMenu.Items.Add(indicatorTitleVisibleRowsMenuItem);

      AddVisibleRowsMenu(grid, indicatorTitleVisibleRowsMenuItem);
    }

    protected virtual void BuildCustomizeColumnsMenuItem(DataPropertyGridEh grid, ToolStripDropDown popupMenu)
    {
      ToolStripMenuItem cmi;
      bool isAddMenuItem;

      if (indicatorTitleCustomizeColumnsMenuItem == null)
      {
        indicatorTitleCustomizeColumnsMenuItem = new ToolStripMenuItem();
        indicatorTitleCustomizeColumnsMenuItem.Click += CustomizeColumnsMenuItemClick;
      }
      cmi = indicatorTitleCustomizeColumnsMenuItem;
      if (cmi.Owner != null)
        cmi.Owner.Items.Remove(cmi);

      InitCustomizeColumnsMenuItem(grid, popupMenu, cmi, out isAddMenuItem);

      if (isAddMenuItem)
        popupMenu.Items.Add(cmi);
    }

    protected virtual void InitCustomizeColumnsMenuItem(DataPropertyGridEh grid, ToolStripDropDown popupMenu, ToolStripMenuItem cmi, out bool isAddMenuItem)
    {
      isAddMenuItem = true;
      cmi.Text = @"Customize rows ...";// EhLib.Properties.Resources.DataGridMenu_SelectAll;
      cmi.Enabled = true;
      cmi.Tag = grid;
    }

    protected virtual void CustomizeColumnsMenuItemClick(object sender, EventArgs e)
    {
      ToolStripMenuItem tsi = (ToolStripMenuItem)sender;
      DataPropertyGridEh grid = (DataPropertyGridEh)tsi.Tag;

      CustomizeDataVertGridRowsDialog.ShowCustomizeRowsDialog(grid);
      //CustomizeDataGridColumnsDialog.ShowCustomizeColumnsDialog(grid);
    }

    private void AddVisibleRowsMenu(DataPropertyGridEh grid, ToolStripMenuItem menuItem)
    {
      ToolStripMenuItemEh cmi;

      foreach (DataVertGridRow row in grid.ViewOrderedRows)
      //for (int i = 0; i <= grid.ViewOrderedColumns.Count - 1; i++)
      {

        if (!String.IsNullOrEmpty(row.Title.Text))
        {
          cmi = new ToolStripMenuItemEh();
          cmi.Tag = row;
          cmi.Text = row.Title.Text;
          //if (Grid.TitleParams.MultiTitle)
          //  cmi.Caption = stringReplace(cmi.Caption, "|", ' - ', [rfReplaceAll]);
          cmi.Checked = row.Visible;
          //cmi.CheckOnClick = true;
          cmi.CloseMenuOnClick = false;
          cmi.Click += MenuVisibleColumnClick;
          //cmi.CloseMenuOnClick = false;
          menuItem.DropDownItems.Add(cmi);
        }
      }
    }

    protected virtual void MenuVisibleColumnClick(object sender, EventArgs e)
    {
      //Debug.WriteLine(sender.GetType().ToString());
      ToolStripMenuItem tsi = (ToolStripMenuItem)sender;
      DataVertGridRow row = tsi.Tag as DataVertGridRow;
      if (row != null)
      {
        row.Visible = !row.Visible;
        tsi.Checked = row.Visible;
      }
    }

    protected virtual void IndicatorTitleMenuPrintClick(object sender, EventArgs e)
    {
      ToolStripMenuItem tsi = (ToolStripMenuItem)sender;
      DataPropertyGridEh grid = (DataPropertyGridEh)tsi.Tag;

      DataPropertyGridPrintService ps = grid.PrintService;
      if (ps == null)
        ps = this.PrintService;

      ps.PrintPreview(grid);
    }

    protected virtual void IndicatorTitleMenuPrintSetupClick(object sender, EventArgs e)
    {
      ToolStripMenuItem tsi = (ToolStripMenuItem)sender;
      DataPropertyGridEh grid = (DataPropertyGridEh)tsi.Tag;

      DataPropertyGridPrintService ps = grid.PrintService;
      if (ps == null)
        ps = this.PrintService;

      PageSetupDialog psd = new PageSetupDialog();
      psd.Execute(ps);
      psd.Dispose();
    }

    protected virtual void InitPrintIndicatorTitleMenuItem(DataPropertyGridEh grid, ToolStripDropDown popupMenu, ToolStripMenuItem cmi, out bool isAddMenuItem)
    {
      isAddMenuItem = true;
      cmi.Text = @"Print";// EhLib.Properties.Resources.DataGridMenu_SelectAll;
      cmi.Enabled = true;
      cmi.Tag = grid;
    }

    protected virtual void InitPrintSetupIndicatorTitleMenuItem(DataPropertyGridEh grid, ToolStripDropDown popupMenu, ToolStripMenuItem menuItem, out bool isAddMenuItem)
    {
      menuItem.Tag = grid;

      menuItem.Text = @"Print Setup";// EhLib.Properties.Resources.DataGridMenu_SelectAll;
      menuItem.Enabled = true;

      if (grid.PrintService != null)
        isAddMenuItem = true;
      else
        isAddMenuItem = false;
    }

  }
}
