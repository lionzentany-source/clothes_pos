﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  /// <summary>
  /// Displays one row of DataSource item in vertial orientation. 
  /// DataPropertyGridEh is <see cref = "DataVertGridEh" /> with only one data colum.
  /// </summary>
  [DesignerCategory("Code")]
  [ToolboxItem(true)]
  [Description("Vertical grid that shows only one list item at a time")]
  [ToolboxBitmap(typeof(DataPropertyGridEh), "ToolboxBitmaps.EhLib_DataPropertyGridEh.bmp")]
  //[ToolboxBitmap(typeof(DataGridEh))]
  //[ComplexBindingProperties("DataSource", "DataMember")]
  public class DataPropertyGridEh : DataVertGridEh
  {
    #region private consts
    #endregion

    #region privates
    private DataPropertyGridPrintService printService;
    #endregion

    public DataPropertyGridEh()
    {
    }

    #region designtime properties
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
    [Editor("EhLib.WinForms.Design.PrintServiceComponentEditor" + EhLibUtils.EhLibDesignDesignerVersionInfo, "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    [DefaultValue(null)]
    public DataPropertyGridPrintService PrintService
    {
      get
      {
        return printService;
      }
      set
      {
        if (printService != value)
        {
          if (printService != null)
            printService.Dispose();

          printService = value;
        }
      }
    }
    #endregion

    #region protected properties
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected new DataVertGridColumnOptions ColumnOptions
    {
      get { return base.ColumnOptions; }
    }

    protected override DataVertGridManager DefaultManager
    {
      get
      {
        return DataPropertyGridManager.DefaultManager;
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Browsable(false)]
    public new DataPropertyGridManager Manager
    {
      get
      {
        return (DataPropertyGridManager)base.Manager;
      }
      set
      {
        base.Manager = value;
      }
    }
    #endregion

    #region methods
    public override void InteractiveFocusCell(int colIndex, int rowIndex, InteractiveActionSource actionSource)
    {
      if ((colIndex == Col) && (rowIndex == Row)) return;
      if (!PrepareChangeCellPos()) return;
      if (!DataLink.Active) return;

      FocusCell(Col, rowIndex, false);
    }

    protected internal override void CurrencyManagerPositionChanged(object sender, EventArgs e)
    {
      ColumnsListChanged();
      //UpdateRowHeights();
    }

    protected internal override void InternalUpdateColumnsList()
    {
      ListItems.Clear();
      if (CurrencyManager != null && CurrencyManager.Count > 0)
      {
        var itemCol = new DataVertGridColumn();
        itemCol.SourceItem = CurrencyManager.Current;
        ListItems.Add(itemCol);
      }
    }

    protected internal override void UpdateBaseColWidths()
    {
      int width = HorzAxis.GridClientLen;

      int titleColWidth = TitleColumn.Width;
      int dataColWidth;


      if (titleColWidth > width - 4)
        titleColWidth = width - 4;
      if (titleColWidth < 0)
        titleColWidth = width / 2;
      dataColWidth = width - titleColWidth;
      if (TitleColumnBaseColIndex >= 0)
        ColWidths[TitleColumnBaseColIndex] = titleColWidth;
      ColWidths[TitleColumnBaseColIndex+1] = dataColWidth;
    }

    protected internal override bool CanShowScrollBar(Orientation kind)
    {
      if (kind == Orientation.Horizontal)
        return false;
      else
        return base.CanShowScrollBar(kind);
    }

    protected override void OnResize(EventArgs e)
    {
      base.OnResize(e);
      if (IsHandleCreated)
      {
        ColumnsListChanged();
        UpdateRowHeights();
      }
    }
    #endregion
  }
}
