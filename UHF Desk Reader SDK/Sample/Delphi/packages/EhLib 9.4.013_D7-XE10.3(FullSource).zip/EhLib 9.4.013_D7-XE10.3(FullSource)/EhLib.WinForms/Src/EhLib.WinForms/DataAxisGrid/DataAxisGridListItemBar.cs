﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace EhLib.WinForms
{
  /// <summary>
  /// Base class for <see cref="DataGridRow"/> in <see cref="DataGridEh "/> control 
  /// and <see cref="DataVertGridColumn"/> in <see cref="DataVertGridEh "/> control 
  /// </summary>
  public class DataAxisGridListItemBar
  {
    #region >privates
    private object srcRow;
    #endregion <privates

    public DataAxisGridListItemBar()
    {
    }

    #region >properties

    //public DataAxisGrid Grid { get { return rows.Grid; } }

    [Browsable(false)]
    public object SourceItem
    {
      get { return srcRow; }
      internal set { srcRow = value; }
    }
    #endregion <roperties

    #region >methods
    #endregion <methods
  }

}
