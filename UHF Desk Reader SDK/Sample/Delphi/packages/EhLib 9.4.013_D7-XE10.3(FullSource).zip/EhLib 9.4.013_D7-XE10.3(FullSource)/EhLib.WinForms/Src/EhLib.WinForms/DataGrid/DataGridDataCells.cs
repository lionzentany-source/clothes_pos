﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Data;
using System.Diagnostics;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Collections.ObjectModel;

namespace EhLib.WinForms
{

  /// <summary>
  /// Base class for cell managers classes that participate in a DataGridColumn component
  /// </summary>
  [ToolboxItem(false)]

  public class DataGridColumnCellMan : DataGridBaseCellMan
  {

    #region privates
    //private DataGridColumn column;
    #endregion privates

    public DataGridColumnCellMan()
    {

    }

    #region Methods
    public override string GetDisplayText(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      if (BoundGrid.VisibleColumns.Count == 0)
        return null;
      else
        return GetDisplayText(BoundGrid.VisibleColumns[areaColIndex], areaRowIndex);
    }

    public virtual string GetDisplayText(DataGridColumn column, int dataRowIndex)
    {
      return "GetDisplayText is not implemented";
    }

    protected internal override bool IsSelected(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      if (BoundGrid.Selection.SelectionType == GridSelectionType.Columns)
        return BoundGrid.VisibleColumns[areaColIndex].Selected;
      else if (BoundGrid.Selection.SelectionType == GridSelectionType.Rows && areaRowIndex < BoundGrid.VisibleRows.Count)
        return BoundGrid.VisibleRows[areaRowIndex].Selected;
      else if (BoundGrid.Selection.SelectionType == GridSelectionType.CellsBox)
        return BoundGrid.Selection.CellsRectContains(areaColIndex, areaRowIndex);
      else if (BoundGrid.Selection.SelectionType == GridSelectionType.All)
        return true;
      else
        return false;
    }

    protected internal virtual int CalcDefaultRowHeight()
    {
      return 0;
    }

    protected internal virtual int CalcRowHeight(DataGridColumn column, DataGridRow row)
    {
      return CalcDefaultRowHeight();
    }


    protected internal override void OnPaintEmptyArea(BaseGridCellPaintEventArgs e)
    {
      if (e.AreaColIndex >= 0)
      {
        DataGridColumn column = BoundGrid.VisibleColumns[e.AreaColIndex];
        Color fromColor = column.BackColor;
        Color toColor = BoundGrid.BackColor;

        if ((BoundGrid.LineOptions.VertCellFreeAreaFillStyle == DataGridVertCellFreeAreaFillStyle.ColumnGradient) && (fromColor != toColor))
        {
          if (fromColor.A != 255)
            toColor = Color.FromArgb(fromColor.A, toColor);
          EhLibUtils.FillRectangleGradient(e.Graphics, e.CellRect, fromColor, toColor);
        }
        else
          EhLibUtils.FillRectangle(e.Graphics, e.CellRect, fromColor);
      }
      else
      {
        base.OnPaintEmptyArea(e);
      }
    }

    #endregion Methods
  }

  public class DataGridColumnRowCells
  {

    #region privates
    private readonly DataGridColumn column;
    private readonly List<DataGridBaseCellMan> rowCells = null;
    #endregion

    #region constructor
    public DataGridColumnRowCells(DataGridColumn column)

    {
      this.column = column;
    }
    #endregion

    #region properties
    public BaseGridCellManager this[DataGridRow row]
    {
      get
      {
        if ((rowCells == null) ||
            (rowCells.Count < row.Index) ||
            (rowCells[row.Index] == null)
        )
          return column.InternalGetRowCellManager(row);
        else
          return rowCells[row.Index];
      }
    }
    #endregion

  }

  public class KeyDisplayValue
  {
    #region constructor
    public KeyDisplayValue(object keyValue, string displayValue)
    {
      KeyValue = keyValue;
      DisplayValue = displayValue;
    }
    #endregion

    #region properties
    public object KeyValue { get; set; }
    public string DisplayValue { get; set; }
    #endregion

    #region methods
    public override string ToString()
    {
      return DisplayValue;
    }
    #endregion
  }

  //public class DataGridColumnPaintCellParams
  //{
  //  #region properties
  //  public int Col { get; internal set; }
  //  public int Row { get; internal set; }

  //  public int DataCol { get; internal set; }
  //  public int DataRow { get; internal set; }
  //  public DataGridColumn Column { get; internal set; }

  //  public Rectangle CellRect { get; internal set; }
  //  public Rectangle ContentRect { get; set; }
  //  public BasePaintCellStates PaintState { get; internal set; }

  //  public object FormattedValue { get; set; }

  //  public CellFillStyle FillStyle { get; set; }
  //  public Color BackColor { get; set; }
  //  //public Color FillColor
  //  public Color SecondFillColor { get; set; }
  //  public CellInnerBorderStyle InnerBorder { get; set; }
  //  public Padding Padding { get; set; }

  //  public Font Font { get; set; }
  //  public Color ForeColor { get; set; }
  //  public HorizontalAlignment HorzAlign { get; set; }
  //  public VerticalAlignment VertAlign { get; set; }
  //  public bool WordWrap { get; set; }
  //  public bool EndEllipsis { get; set; }
  //  #endregion
  //}
}
