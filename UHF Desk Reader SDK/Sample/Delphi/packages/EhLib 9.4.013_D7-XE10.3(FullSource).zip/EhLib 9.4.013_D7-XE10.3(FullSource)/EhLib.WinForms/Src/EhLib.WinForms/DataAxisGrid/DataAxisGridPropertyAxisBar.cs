﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.ComponentModel.Design.Serialization;
using System.Data;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{
  /// <summary>
  /// Base class for DataGridColumn and DataVertGridRow
  /// </summary>
  [DesignerCategory("Code")]
  [TypeConverter(typeof(ExpandableObjectConverter))]
  [DesignTimeVisible(false)]
  [ToolboxItem(false)]
  public class PropertyAxisBar : Component/*, IDataCellHolder*/, IGridRowHeightOptionsOwner
  {
    #region private consts
    #endregion

    #region privates
    private DataAxisGrid grid;
    private DeepPropertyDescriptor propDescr;
    private string dataPropertyName = string.Empty;
    private string name;
    private int displayIndex = -1;
    private bool visible = true;
    private int visibleIndex = -1;
    private Type dataType;
    //private TypeCategory typeCategory;
    private DataValueSource dataValueSource = DataValueSource.DataProperty;
    private bool disposed;

    private Color backColor = Color.Empty;
    private bool backColorStored;

    private DataAxisGridBarTitle title;
    private int index;
    private BaseDataCellManager internalCellManager;
    private BaseDataCellManager externalCellManager;
    //private BaseDataCellManager defaultCellManager;
    private readonly DataAxisGridPropBarCellManagersList extraCellManagers;
    #endregion

    public PropertyAxisBar()
    {
      NewColumn = true;
      extraCellManagers = new DataAxisGridPropBarCellManagersList(this);
    }

    protected override void Dispose(bool disposing)
    {
      if (!disposed)
      {
        if (disposing)
        {
          if (Grid != null)
            Grid.StaticPropBars.Remove(this);
        }
        disposed = true;
      }

      base.Dispose(disposing);
    }

    #region >design-time properties
    [DefaultValue("")]
    //[TypeConverter(typeof(Design.DataAxisGridPropBarDataPropertyNameConverter))]
    [TypeConverter("EhLib.WinForms.Design.DataAxisGridPropBarDataPropertyNameConverter")]
    [Category("Data")]
    public string DataPropertyName
    {
      get { return dataPropertyName; }
      set
      {
        if (value == null)
          value = string.Empty;
        if (dataPropertyName != value)
        {
          dataPropertyName = value;
          DataPropertyNameChanged();
        }
      }
    }

    [DefaultValue(DataValueSource.DataProperty)]
    [Category("Data")]
    public DataValueSource DataValueSource
    {
      get
      {
        return dataValueSource;
      }

      set
      {
        if (value != dataValueSource)
        {
          dataValueSource = value;
          Invalidate();
        }
      }
    }

    [DefaultValue(true)]
    public bool Visible
    {
      get
      {
        return visible;
      }
      set
      {
        if (value != visible)
        {
          visible = value;
          if (Grid != null)
          {
            Grid.PropertyAxisBarVisibleChanged(this, value);
          }
        }
      }
    }

    public Color BackColor
    {
      get
      {
        if (backColorStored)
          return backColor;
        else
          return DefaultBackColor();
      }
      set
      {
        if ((backColorStored == false) || (backColor != value))
        {
          backColorStored = true;
          backColor = value;
          BackColorChanged();
        }
      }
    }

    public Color ForeColor
    {
      get { return InternalCellManager.ForeColor; }
      set { InternalCellManager.ForeColor = value; }
    }

    public Font Font
    {
      get { return InternalCellManager.Font; }
      set { InternalCellManager.Font = value; }
    }

    public HorizontalAlignment HorzAlign
    {
      get { return InternalCellManager.HorzAlign; }
      set { InternalCellManager.HorzAlign = value; }
    }

    public virtual string GetTypeNameAbbr()
    {
      return InternalCellManager.GetTypeNameAbbr();
    }

    public VerticalAlignment VertAlign
    {
      get { return InternalCellManager.VertAlign; }
      set { InternalCellManager.VertAlign = value; }
    }

    public Padding Padding
    {
      get { return InternalCellManager.Padding; }
      set { InternalCellManager.Padding = value; }
    }

    protected internal bool AllowShowEditor
    {
      get { return InternalCellManager.AllowShowEditor; }
      set { InternalCellManager.AllowShowEditor = value; }
    }

    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    //[Browsable(false)]
    [TypeConverter(typeof(DataColumnTypeConverter))]
    public Type DataType
    {
      get
      {
        if (dataType != null)
          return dataType;
        else if (DataValueSource == DataValueSource.DataProperty && PropDescr != null)
          return PropDescr.PropertyType;
        else if (DataValueSource == DataValueSource.ListItem && Grid != null)
        {
          Type listItemType = ListBindingHelper.GetListItemType(Grid.CurrencyManager.List);
          return listItemType;
        }
        else
          return null;
      }
      set
      {
        if (dataType != value)
        {
          dataType = value;
          DataTypeChanged();
        }
      }
    }

    public BaseDataCellManager ExternalCellManager
    {                                               
      get
      {
        return externalCellManager;
      }
      set
      {
        if (externalCellManager != value)
        {
          externalCellManager = value;
          ExternalCellManagerChanged();
        }
      }
    }

    //[Browsable(false)]
    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    [Editor("EhLib.WinForms.Design.DataGridDynaColumnCellsEditor" + EhLibUtils.EhLibDesignDesignerVersionInfo, "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    [ListBindable(false)]
    public DataAxisGridPropBarCellManagersList ExtraCellManagers
    {
      get { return extraCellManagers; }
    }

    [TypeConverter(typeof(StringConverter))]
    [DefaultValue(null)]
    public object Tag { get; set; }
    #endregion

    #region >run-time properties
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected BaseDataCellManager DefaultCellManager
    {
      get
      {
        if (ExternalCellManager != null)
          return ExternalCellManager;
        else
          return InternalCellManager;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public BaseDataCellManager InternalCellManager
    {
      get
      {
        if (internalCellManager == null)
        {
          internalCellManager = CreateTemplateCell();
          internalCellManager.BoundPropAxisBar = this;
        }
        return internalCellManager;
      }
    }

    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Browsable(false)]
    public string Name
    {
      get
      {
        if (Site != null)
          name = Site.Name;
        return name;
      }

      set
      {
        if (string.Equals(this.name, value, StringComparison.Ordinal)) return;

        //if (Site != null)
        //  Site.Name = value;

        this.name = value;

        if (this.Grid != null)
        {
          this.Grid.OnPropBarNameChanged(this);
        }
      }
    }

    [Browsable(false)]
    public DataAxisGrid Grid
    {
      get
      {
        return grid;
      }

      protected internal set
      {
        if (value != grid)
        {
          grid = value;
          GridChanged();
        }
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Browsable(false)]
    public TypeCategory TypeCategory
    {
      get
      {
        return EhLibManager.DefaultEhLibManager.GetTypeCategoryForType(DataType);
        //return typeCategory;
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Browsable(false)]
    public DeepPropertyDescriptor PropDescr
    {
      get
      {
        return propDescr;
      }
      internal set
      {
        if (propDescr != value)
        {
          propDescr = value;
          PropDescrChanged();
        }
      }
    }

    [DefaultValue(0)]
    public int MaxLength { get; set; }

    [Browsable(false)]
    public bool AutoGenerated
    {
      get;
      internal set;
    }

    [Browsable(false)]
    public int Index
    {
      get
      {
        if (Grid == null)
          return -1;
        else
          return index;
      }

      internal set
      {
        index = value;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int DisplayIndex
    {
      get
      {
        return displayIndex;
      }

      set
      {
        if (Grid == null)
          displayIndex = value;
        else
          Grid.SetPropBarDisplayIndex(this, value);
      }
    }

    [Browsable(false)]
    public int VisibleIndex
    {
      get
      {
        return this.visibleIndex;
      }

      internal set
      {
        this.visibleIndex = value;
      }
    }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public Type EditorType
    {
      get { return InternalCellManager.EditorType; }
      set { InternalCellManager.EditorType = value; }
    }


    [Browsable(false)]
    public bool DataValueSourceActive
    {
      get
      {
        if (DataValueSource == DataValueSource.DataProperty)
          return (PropDescr != null);
        else
          return (Grid != null && Grid.DataLink.Active);
      }
    }
    #endregion

    #region internal properties
    internal bool NewColumn
    {
      get;
      set;
    }

    [Browsable(false)]
    public bool IsVisible
    {
      get
      {
        if (Grid == null)
          return Visible;
        else
          return Visible && Grid.PropBarCanBeVisible(this);
      }
    }

    //[Browsable(false)]
    //public virtual bool IsReadOnly
    //{
    //  get
    //  {
    //    if (PropDescr != null)
    //      return PropDescr.IsReadOnly;
    //    else
    //      return true;
    //  }
    //}

    protected internal virtual DataAxisGridBarTitle Title
    {
      get
      {
        if (title == null)
          title = CreateDataAxisGridBarTitle();
        return title;
      }
    }

    internal int DisplayIndexInternal
    {
      set
      {
        this.displayIndex = value;
      }
    }

    [Browsable(false)]
    protected internal virtual bool DisplayValuesCached
    {
      get
      {
        return false;
      }
    }
    #endregion

    #region methods
    /// <summary>
    /// We should not serialize InternalCellManager propety. 
    /// Although this property must have DesignerSerializationVisibility.Content attribute assigned.
    /// </summary>
    /// <returns>
    /// Always returns a false.
    /// </returns>
    protected virtual bool ShouldSerializeInternalCellManager()
    {
      return false;
    }

    //HorzAlign
    public virtual HorizontalAlignment DefaultHorzAlign()
    {
      if (Grid != null)
        return Grid.DefaultHorzAlignForType(DataType);
      else
        return HorizontalAlignment.Left;
    }

    protected virtual void HorzAlignChanged()
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    protected virtual bool ShouldSerializeHorzAlign()
    {
      return InternalCellManager.ShouldSerializeHorzAlign();
    }

    public virtual void ResetHorzAlign()
    {
      InternalCellManager.ResetHorzAlign();
    }

    //VertAlign
    protected internal virtual void VertAlignChanged()
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    public virtual VerticalAlignment DefaultVertAlign()
    {
      return VerticalAlignment.Top;
    }

    public virtual bool ShouldSerializeVertAlign()
    {
      return InternalCellManager.ShouldSerializeVertAlign();
    }

    public virtual void ResetVertAlign()
    {
      InternalCellManager.ResetVertAlign();
    }

    //Padding
    protected virtual void PaddingChanged()
    {
    }

    protected virtual Padding DefaultPadding()
    {
      if (Grid != null)
        return Grid.GetDefaultPaddingForAlign(HorzAlign, VertAlign);
      else
        return Padding.Empty;
    }

    protected virtual bool ShouldSerializePadding()
    {
      return InternalCellManager.ShouldSerializePadding();
    }

    public virtual void ResetPadding()
    {
      InternalCellManager.ResetPadding();
    }


    //AllowShowEditor
    public virtual bool DefaultAllowShowEditor()
    {
      return false;
    }

    protected internal virtual bool ShouldSerializeAllowShowEditor()
    {
      return InternalCellManager.ShouldSerializeAllowShowEditor();
    }

    public virtual void ResetAllowShowEditor()
    {
      InternalCellManager.ResetAllowShowEditor();
    }

    //Font
    protected virtual void FontChanged()
    {
    }

    public virtual Font DefaultFont()
    {
      if (Grid != null)
        return Grid.Font;
      else
        return null;
    }

    protected virtual bool ShouldSerializeFont()
    {
      return InternalCellManager.ShouldSerializeFont();
    }

    public virtual void ResetFont()
    {
      InternalCellManager.ResetFont();
    }

    public bool FontStored()
    {
      return ShouldSerializeFont();
    }

    //BackColor
    public virtual Color DefaultBackColor()
    {
      if (Grid != null)
        return Grid.BackColor;
      else
        return Color.Empty;
    }

    protected virtual void BackColorChanged()
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    protected virtual bool ShouldSerializeBackColor()
    {
      return (backColorStored == true);
    }

    public virtual void ResetBackColor()
    {
      backColorStored = false;
      BackColorChanged();
    }

    //ForeColor
    protected virtual void ForeColorChanged()
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    public virtual Color DefaultForeColor()
    {
      return SystemColors.WindowText;
    }

    protected virtual bool ShouldSerializeForeColor()
    {
      return InternalCellManager.ShouldSerializeForeColor();
    }

    public virtual void ResetForeColor()
    {
      InternalCellManager.ResetForeColor();
    }

    //ReadOnly
    public virtual bool DefaulReadOnly()
    {
      if (PropDescr != null)
        return PropDescr.IsReadOnly;
      else
        return false;
    }

    //DataType
    //public virtual Type DefaultDataType()
    //{
    //  if (Grid != null)
    //    return Grid.BackColor;
    //  else
    //    return Color.Empty;
    //}

    protected virtual void DataTypeChanged()
    {
      UpdateDefaultPadding();
      UpdateTypeCategory();
      if (Grid != null)
        Grid.UpdatePropBarsList();
    }

    protected virtual bool ShouldSerializeDataType()
    {
      return (dataType != null);
    }

    public virtual void ResetDataType()
    {
      dataType = null;
      DataTypeChanged();
    }

    //PullValue
    protected internal virtual DataAxisGridDataCellPullValueEventArgs CreatePullValueEventArgs(
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
    {
      return new DataAxisGridDataCellPullValueEventArgs(propAxisBar, listItemBar, cellMan);
    }

    protected internal virtual void HandlePullValueEvent(DataAxisGridDataCellPullValueEventArgs e)
    {

    }

    protected internal virtual void OnPullValue(DataAxisGridDataCellPullValueEventArgs e)
    {
      throw new InvalidOperationException("PropertyAxisBar.OnPullValue is not implemented");
    }

    //PushValue
    protected internal virtual DataAxisGridDataCellPushValueEventArgs CreatePushValueEventArgs(
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
    {
      return new DataAxisGridDataCellPushValueEventArgs(propAxisBar, listItemBar, cellMan);
    }

    protected internal virtual void HandlePushValueEvent(DataAxisGridDataCellPushValueEventArgs e)
    {

    }

    protected internal virtual void OnPushValue(DataAxisGridDataCellPushValueEventArgs e)
    {
      throw new InvalidOperationException("PropertyAxisBar.OnPushValue is not implemented");
    }

    //ParseValue
    protected internal virtual void HandleParseValueEvent(DataAxisGridDataCellParseValueEventArgs e)
    {

    }

    protected internal virtual void OnParseValue(DataAxisGridDataCellParseValueEventArgs e)
    {
      object srcValue = e.InValue;
      Type targetType = null;
      Type sourceType = null;
      TypeConverter targetConverter = null;
      TypeConverter sourceConverter = null;
      IFormatProvider formatInfo = null;
      object formattedNullValue = "";
      object dataSourceNullValue;

      if (srcValue == null)
        formattedNullValue = null;
      if (srcValue != null)
        sourceType = srcValue.GetType();
      if (sourceType != null)
        sourceConverter = TypeDescriptor.GetConverter(sourceType);

      if (PropDescr != null)
        targetType = PropDescr.PropertyType;
      if (targetType != null)
        targetConverter = TypeDescriptor.GetConverter(targetType);

      dataSourceNullValue = EhLibManager.DefaultEhLibManager.ValueConverter.GetDefaultDataSourceNullValue(targetType);

      e.OutValue = EhLibManager.DefaultEhLibManager.ValueConverter.ParseValue(srcValue,
        targetType, sourceType, targetConverter, sourceConverter, formatInfo,
        formattedNullValue, dataSourceNullValue);
    }

    //ToolTipInfo
    protected internal virtual DataAxisGridDataCellToolTipInfoEventArgs CreateToolTipInfoEventArgs(
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
    {
      return new DataAxisGridDataCellToolTipInfoEventArgs(propAxisBar, listItemBar, cellMan);
    }

    protected internal virtual void HandleDataCellToolTipInfoNeeded(DataAxisGridDataCellToolTipInfoEventArgs e)
    {
    }

    //DataCellContextMenuStripNeeded
    protected internal virtual DataAxisGridDataCellContextMenuStripNeededEventArgs CreateCellContextMenuStripNeededEventArgs(
      BaseDataCellManager cellMan,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, int inCellX, int inCellY,
      Rectangle cellRect, int mousePosX, int mousePosY, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      return new DataAxisGridDataCellContextMenuStripNeededEventArgs(Grid, cellMan, colIndex, rowIndex, areaColIndex,
        areaRowIndex, inCellX, inCellY, cellRect, mousePosX, mousePosY, propAxisBar, listItemBar);
    }

    protected internal virtual void HandleDataCellContextMenuStripNeededEvent(DataAxisGridDataCellContextMenuStripNeededEventArgs e)
    {
    }

    //CanModifyStateNeeded
    //protected internal virtual DataAxisGridDataCellCanModifyStateNeededEventArgs CreateCanModifyStateNeededEventArgs(
    //  PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
    //{
    //  return new DataAxisGridDataCellCanModifyStateNeededEventArgs(propAxisBar, listItemBar, cellMan);
    //}

    protected internal virtual void HandleCanModifyStateNeededEvent(DataAxisGridDataCellCanModifyStateNeededEventArgs e)
    {

    }

    //Other
    protected virtual void PropDescrChanged()
    {
    }

    protected virtual bool ShouldSerializeExternalCellManager()
    {
      return (externalCellManager != null);
    }

    protected virtual void ResetExternalCellManager()
    {
      ExternalCellManager = null;
    }

    protected virtual void DataCellChanged()
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    protected virtual void ExternalCellManagerChanged()
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    protected virtual BaseDataCellManager CreateTemplateCell()
    {
      return new BlankDataCellManager();
    }

    public override string ToString()
    {
      string result = base.ToString();
      if (!String.IsNullOrEmpty(DataPropertyName))
        result = result + " {DataPropertyName=" + DataPropertyName + "}";
      if (!String.IsNullOrEmpty(Title.Text))
        result = result + " {Title.Text=" + Title.Text + "}";
      result = result + " {DisplayIndex=" + DisplayIndex.ToString() + "}";
      return result;
    }

    protected virtual void GridChanged()
    {
      Title.Grid = Grid;
      //UpdateDefaultPadding();
      //UpdateFooterList();
      foreach (BaseGridCellManager c in ExtraCellManagers)
        c.BoundGrid = Grid;
    }

    protected virtual DataAxisGridBarTitle CreateDataAxisGridBarTitle()
    {
      return new DataAxisGridBarTitle(this);
    }

    protected internal virtual void PerformLayout()
    {
      Title.PerformLayout();
    }

    private void DataPropertyNameChanged()
    {
      if (Grid != null)
        Grid.UpdatePropBarsList();
    }

    public virtual void Invalidate()
    {
    }

    public virtual void UpdateDefaultPadding()
    {
    }

    protected virtual void UpdateTypeCategory()
    {
      //typeCategory = EhLibManager.DefaultEhLibManager.GetTypeCategoryForType(DataType);
    }

    protected internal virtual void UpdatedInList()
    {
    }

    public virtual object ParseValue(DataAxisGridListItemBar listItem, object formattedValue)
    {
      BaseGridCellManager cellMan = GetDataCellManager(listItem);

      BaseDataCellManager dataCellMan = cellMan as BaseDataCellManager;
      if (dataCellMan != null)
        return dataCellMan.ProcessParseValue(this, listItem, formattedValue);
      else
        return null;
    }

    protected internal virtual void CellFontChanged()
    {
    }

    protected internal virtual void RowHeightAutoExpandChanged()
    {
    }

    public virtual bool HeightOptionsDefaultAutoExpand(GridRowHeightOptions heightOptions)
    {
      return false;
    }

    public virtual int HeightOptionsDefaultContentHeight(GridRowHeightOptions heightOptions)
    {
      return 1;
    }

    public virtual int HeightOptionsDefaultMaxContentHeight(GridRowHeightOptions heightOptions)
    {
      return 0;
    }

    public virtual GridRowHeightUnit HeightOptionsDefaultUnit(GridRowHeightOptions heightOptions)
    {
      return GridRowHeightUnit.TextLine;
    }

    public virtual void HeightOptionsChanged(GridRowHeightOptions heightOptions)
    {
    }

    public virtual object GetEmptyValue(object listItem)
    {
      //object result;
      if (listItem != null)
      {
        //object v = listItem;
        if (listItem is DataRowView)
          return DBNull.Value;
        else
          return null;
      }
      else
        return null;
    }

    //protected internal virtual void AxisObjectsByDataColRowIndex(int dataColIndex, int dataRowIndex, out PropertyAxisBar propAxisBar, out DataAxisGridListItemBar listItemBar)
    //{
    //  propAxisBar = null;
    //  listItemBar = null;
    //}

    public virtual object GetCachedDisplayValue(object listItem)
    {
      return null;
    }

    public virtual Collection<object> GetEditUniqueValues()
    {
      return null;
    }

    protected internal virtual void HandleDataCellPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellContentPaintEvent(DataAxisGridDataCellContentPaintEventArgs e)
    {
    }

    protected internal virtual void HandleDataCellCustomAreaPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
    }

    public object GetListItemBarValue(DataAxisGridListItemBar listItemBar)
    {
      var e = CreatePullValueEventArgs(this, listItemBar, null);
      HandlePullValueEvent(e);
      if (!e.Handled)
        OnPullValue(e);
      return e.Value;

      //BaseGridCellManager cellMan = GetDataCellMan(listItemBar);

      //BaseDataCellManager dataCellMan = cellMan as BaseDataCellManager;
      //if (dataCellMan != null)
      //  return dataCellMan.ProcessPullValue(this, listItemBar);
      //else
      //  return null;
    }

    public virtual object GetListItemBarSortingValue(DataAxisGridListItemBar listItemBar)
    {
      return GetListItemBarValue(listItemBar);
    }

    protected internal void SetValue(DataAxisGridListItemBar listItemBar, object dataValue)
    {
      var e = CreatePushValueEventArgs(this, listItemBar, null);
      e.Value = dataValue;
      HandlePushValueEvent(e);
      if (!e.Handled)
        OnPushValue(e);
    }

    public virtual BaseGridCellManager GetDataCellManager(DataAxisGridListItemBar listItemBar)
    {
      return null;
    }

    protected internal virtual void PaintCellBackground(BaseDataCellManager cellMan, DataAxisGridDataCellPaintEventArgs e)
    {
      cellMan.InternalPaintCellBackground(e);
    }

    protected internal virtual void OnGetDataCellBorderParams(BaseGridCellBorderEventArgs e)
    {
    }

    protected internal virtual bool IsPaintEditItemBackground(EditItem editButton, DataAxisGridDataCellPaintEventArgs e, Rectangle itemRect)
    {
      return true;
    }

    protected internal virtual bool IsPaintEditItemForeground(EditItem editButton, DataAxisGridDataCellPaintEventArgs e, Rectangle itemRect)
    {
      return true;
    }

    protected internal virtual void SpecifyPaintParams(DataAxisGridDataCellPaintEventArgs e)
    {
      if (((BasePaintCellStates.Current & e.State) != 0) ||
          ((BasePaintCellStates.RowSelected & e.State) != 0)
      )
        e.ForePaintColor = SystemColors.HighlightText;
      else
        e.ForePaintColor = e.ForeColor;
    }

    protected internal virtual void GridCellPosToDataCellPos(int gridColIndex, int gridRowIndex, out int areaColIndex, out int areaRowIndex)
    {
      areaColIndex = gridColIndex;
      areaRowIndex = gridRowIndex;
    }

    protected internal virtual void HandleFormatParamsNeededEvent(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
    }

    protected internal virtual void HandleCanShowEditorStateNeededEvent(DataAxisGridDataCellCanShowEditorStateNeededEventArgs e)
    {
    }

    protected internal virtual void HandleEditorParamsNeededEvent(DataAxisGridDataCellEditorParamsNeededEventArgs e)
    {
    }

    protected internal virtual void DataCellPosToGridCellPos(int areaColIndex, int areaRowIndex, out int gridColIndex, out int gridRowIndex)
    {
      gridColIndex = areaColIndex;
      gridRowIndex = areaRowIndex;
    }

    //protected internal virtual BaseGridCellMouseEventArgs CreateDataCellMouseEventArgs(
    //  int colIndex, int rowIndex, int areaColIndex, int areaRowIndex,
    //  PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell,
    //  int inCellX, int inCellY, Rectangle cellRect, MouseEventArgs gridMouseArgs)
    //{
    //  return new DataAxisGridDataCellMouseEventArgs(
    //    cell, colIndex, rowIndex, areaColIndex, areaRowIndex, propAxisBar, listItemBar, inCellX, inCellY, cellRect, gridMouseArgs);
    //}

    protected internal virtual DataAxisGridDataCellEventArgs CreateDataCellEventArgs(DataAxisGrid grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell
      )
    {
      return new DataAxisGridDataCellEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, propAxisBar, listItemBar, cell);
    }

    //protected internal virtual DataAxisGridDataCellEnterEventArgs CreateDataCellEnterEventArgs(
    //  int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int leaveColIndex, int leaveRowIndex,
    //  PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell)
    //{
    //  return new DataAxisGridDataCellEnterEventArgs(colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, leaveColIndex, leaveRowIndex, propAxisBar, listItemBar, cell);
    //}

    protected internal virtual void HandleDataCellClientAreaNeededEvent(DataAxisGridDataCellClientAreaNeededEventArgs e)
    {
    }

    //protected internal virtual DataAxisGridDataCellClientAreaNeededEventArgs CreateDataCellClientAreaNeededEventArgs(PropertyAxisBar propAxisBar,
    //    DataAxisGridListItemBar listItemBar, Rectangle cellRect, BaseDataCellManager cellMan)
    //{
    //  return new DataAxisGridDataCellClientAreaNeededEventArgs(propAxisBar, listItemBar, cellRect, cellMan);
    //}

    //protected internal virtual DataAxisGridDataCellLeaveEventArgs CreateDataCellLeaveEventArgs(
    //  int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int enterColIndex, int enterRowIndex,
    //  PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell)
    //{
    //  return new DataAxisGridDataCellLeaveEventArgs(colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, enterColIndex, enterRowIndex, propAxisBar, listItemBar, cell);
    //}

    protected internal virtual void OnDataCellContentClick(DataAxisGridDataCellEventArgs e)
    {
    }

    protected internal virtual bool IsDataCellSelected(int dataColIndex, int dataRowIndex)
    {
      return false;
    }

    protected internal virtual void HandleMouseDownEvent(DataAxisGridDataCellMouseEventArgs e)
    {
    }

    protected internal virtual void OnMouseDown(DataAxisGridDataCellMouseEventArgs e)
    {
    }

    protected internal virtual void HandleMouseMoveEvent(DataAxisGridDataCellMouseEventArgs e)
    {
    }

    protected internal virtual void HandleMouseUpEvent(DataAxisGridDataCellMouseEventArgs e)
    {
    }

    protected internal virtual void HandleMouseClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
    }

    protected internal virtual void HandleMouseDoubleClickEvent(DataAxisGridDataCellMouseEventArgs e)
    {
    }

    protected internal virtual void HandleMouseEnterEvent(DataAxisGridDataCellEnterEventArgs e)
    {
    }

    protected internal virtual void HandleMouseLeaveEvent(DataAxisGridDataCellLeaveEventArgs e)
    {
    }

    protected internal virtual void HandleMouseHoverEvent(DataAxisGridDataCellMouseEventArgs e)
    {
    }

    //protected internal virtual BaseGridCellCustomAreaMeasuresEventArgs CreateCellCustomAreaMeasuresEventArgs(
    //  int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, 
    //  CellCustomAreaMeasures areaMeasures)
    //{
    //  return new BaseGridCellCustomAreaMeasuresEventArgs(colIndex, rowIndex, areaColIndex, areaRowIndex, areaMeasures);
    //}

    //protected internal virtual void OnCellCustomAreaMeasuresNeeded(BaseGridCellCustomAreaMeasuresEventArgs e)
    //{
    //}

    protected internal virtual DataAxisGridDataCellOptimalWidthNeededEventArgs CreateDataCellOptimalWidthNeededEventArgs(
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
    {
      return new DataAxisGridDataCellOptimalWidthNeededEventArgs(propAxisBar, listItemBar, cellMan);
    }

    protected internal virtual void HandleCellOptimalWidthNeededEvent(DataAxisGridDataCellOptimalWidthNeededEventArgs e)
    {
    }

    protected internal virtual void HandleDisplayValueNeededEvent(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
    }

    protected internal virtual void HandleEditValueNeededEvent(DataAxisGridDataCellEditValueNeededEventArgs e)
    {
    }

    protected internal virtual void HandleEditorOccupyEvent(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
    }

    protected internal virtual void HandleEditorReleaseEvent(DataAxisGridDataCellEditorReleaseEventArgs e)
    {
    }

    protected internal virtual void EditItemChanged(EditItem editItem)
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    protected internal virtual void InEditControlsCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    protected internal virtual void PaintDataCellServiceArea(DataAxisGridDataCellPaintEventArgs e)
    {
    }

    protected internal virtual Rectangle GetCellCustomRect(DataAxisGridListItemBar listItemBar, Rectangle cellRect)
    {
      return cellRect;
    }

    protected internal virtual void OnEditorKeyDown(DataAxisGridEditorKeyEventArgs ke)
    {
    }

    //protected internal virtual GridBaseVirtualDataCellEventArgs CreateFormatParamsNeededEventArgs(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    //{
    //  return new GridBaseVirtualDataCellEventArgs(e);
    //}
    #endregion
  }

  [TypeConverter(typeof(ExpandableObjectConverter))]
  [DesignerCategory("Code")]
  [ToolboxItem(false)]
  [DesignTimeVisible(false)]
  public class DataAxisGridBarTitle : Component, ICellBackFillerOwner, ICellImageBoxOwner
  {
    #region privates
    private DataAxisGrid grid;
    private readonly PropertyAxisBar propBar;

    private string text = string.Empty;
    private bool textStored;
    private Font font;
    private Color foreColor = Color.Empty;
    private bool foreColorStored;
    private bool endEllipsis;
    private bool endEllipsisStored;

    private HorizontalAlignment horzAlign;
    private bool horzAlignStored;
    private Padding padding = new Padding(0);
    private bool paddingStored;
    private readonly Padding defaultPadding = new Padding(3, 2, 3, 4);
    private VerticalAlignment vertAlign;
    private bool vertAlignStored;
    private CellTextWrapMode wrapMode;
    private bool wrapModeStored;
    private string toolTipText = "";
    private readonly CellBackFiller backFiller;
    private readonly CellImageBox imageBox;
    #endregion

    public DataAxisGridBarTitle(PropertyAxisBar propBar)
    {
      this.propBar = propBar;
      backFiller = new CellBackFiller(this);
      imageBox = new CellImageBox(this);
    }

    #region design-time properties
    [DefaultValue("")]
    public string Text
    {
      get
      {
        if (textStored)
          return text;
        else
          return DefaultText();
      }
      set
      {
        if ((textStored == false) || (text != value))
        {
          textStored = true;
          text = value;
          if (text == null)
            text = string.Empty;
          CaptionChanged();
        }
      }
    }

    public Font Font
    {
      get
      {
        if (font != null)
          return font;
        else
          return DefaultFont();
      }
      set
      {
        font = value;
        FontChanged();
      }
    }

    public Color ForeColor
    {
      get
      {
        if (foreColorStored)
          return foreColor;
        else
          return DefaultForeColor();
      }
      set
      {
        if ((foreColorStored == false) || (foreColor != value))
        {
          foreColorStored = true;
          foreColor = value;
          ForeColorChanged();
        }
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public CellBackFiller BackFiller
    {
      get
      {
        return backFiller;
      }
    }

    public Padding Padding
    {
      get
      {
        if (paddingStored)
          return padding;
        else
          return DefaultPadding();
      }
      set
      {
        padding = value;
        paddingStored = true;
        PaddingChanged();
      }
    }

    public HorizontalAlignment HorzAlign
    {
      get
      {
        if (horzAlignStored)
          return horzAlign;
        else
          return DefaultHorzAlign();
      }
      set
      {
        if ((horzAlignStored == false) || (horzAlign != value))
        {
          horzAlignStored = true;
          horzAlign = value;
          TextAlignChanged();
        }
      }
    }

    public VerticalAlignment VertAlign
    {
      get
      {
        if (vertAlignStored)
          return vertAlign;
        else
          return DefaultVertAlign();
      }
      set
      {
        if ((vertAlignStored == false) || (vertAlign != value))
        {
          vertAlignStored = true;
          vertAlign = value;
          TextAlignChanged();
        }
      }
    }

    public bool EndEllipsis
    {
      get
      {
        if (endEllipsisStored)
          return endEllipsis;
        else
          return DefaultEndEllipsis();
      }
      set
      {
        if ((endEllipsisStored == false) || (endEllipsis != value))
        {
          endEllipsisStored = true;
          endEllipsis = value;
          EndEllipsisChanged();
        }
      }
    }

    [DefaultValue("")]
    [Localizable(true)]
    public string ToolTipText
    {
      get
      {
        return toolTipText;
      }
      set
      {
        if (value != toolTipText)
        {
          toolTipText = value;
          ToolTipTextChanged();
        }
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public CellImageBox ImageBox
    {
      get
      {
        return imageBox;
      }
    }

    [DefaultValue(CellTextWrapMode.Auto)]
    public CellTextWrapMode WrapMode
    {
      get
      {
        if (wrapModeStored)
          return wrapMode;
        else
          return DefaultWrapMode();
      }
      set
      {
        if ((wrapModeStored == false) || (wrapMode != value))
        {
          wrapModeStored = true;
          wrapMode = value;
          WrapModeChanged();
        }
      }
    }
    #endregion

    #region public properties
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [Browsable(false)]
    protected PropertyAxisBar PropBar
    {
      get { return propBar; }
    }

    [Browsable(false)]
    protected internal virtual DataAxisGrid Grid
    {
      get
      {
        return grid;
      }

      set
      {
        if (value != grid)
        {
          grid = value;
          //titleCell.Grid = grid;
        }
      }
    }
    #endregion

    #region methods
    //ICellBackFillerOwner
    void ICellBackFillerOwner.BackFillerChanged(CellBackFiller backFiller)
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    Color ICellBackFillerOwner.BackFillerDefaultColor(CellBackFiller backFiller)
    {
      return Grid.TitleBar.BackFiller.Color;
    }

    Color ICellBackFillerOwner.BackFillerDefaultSecondColor(CellBackFiller backFiller)
    {
      return Grid.TitleBar.BackFiller.SecondColor;
    }

    CellFillStyle ICellBackFillerOwner.BackFillerDefaultFillStyle(CellBackFiller backFiller)
    {
      return Grid.TitleBar.BackFiller.FillStyle;
    }

    CellInnerBorderStyle ICellBackFillerOwner.BackFillerDefaultInnerBorder(CellBackFiller backFiller)
    {
      return Grid.TitleBar.BackFiller.InnerBorder;
    }

    //WrapMode
    private CellTextWrapMode DefaultWrapMode()
    {
      if (PropBar.Grid != null)
        return PropBar.Grid.TitleBar.WrapMode;
      else
        return CellTextWrapMode.Auto;
    }

    public void ResetWrapMode()
    {
      wrapModeStored = false;
      WrapModeChanged();
    }

    protected virtual bool ShouldSerializeWrapMode()
    {
      return (wrapModeStored == true);
    }

    protected internal virtual void WrapModeChanged()
    {
      if (Grid != null)
        Grid.Invalidate();
    }
    //Other
    public virtual string DefaultText()
    {
      return PropBar.DataPropertyName;
    }

    public virtual Color DefaultForeColor()
    {
      if (PropBar.Grid != null)
        return PropBar.Grid.TitleBar.ForeColor;
      else
        return Color.Empty;
    }

    public virtual void ResetCaption()
    {
      textStored = false;
      CaptionChanged();
    }

    public virtual void ResetEndEllipsis()
    {
      endEllipsisStored = false;
      EndEllipsisChanged();
    }

    public virtual void ResetFont()
    {
      font = null;
      FontChanged();
    }

    public virtual void ResetForeColor()
    {
      foreColorStored = false;
      ForeColorChanged();
    }

    //public virtual void ResetHeightAutoExpand()
    //{
    //  heightAutoExpandStored = false;
    //  HeightAutoExpandChanged();
    //}

    public void ResetHorzAlign()
    {
      horzAlignStored = false;
      TextAlignChanged();
    }

    public virtual void ResetPadding()
    {
      paddingStored = false;
      PaddingChanged();
    }

    public void ResetVertAlign()
    {
      vertAlignStored = false;
      TextAlignChanged();
    }

    protected virtual void CaptionChanged()
    {
      if (PropBar.Grid != null)
        PropBar.Grid.UpdatePropBarsList();
    }

    protected virtual bool DefaultEndEllipsis()
    {
      if (PropBar.Grid != null)
        return PropBar.Grid.TitleBar.EndEllipsis;
      else
        return false;
    }

    protected virtual Padding DefaultPadding()
    {
      if (PropBar.Grid != null)
        return PropBar.Grid.TitleBar.Padding;
      else
        return defaultPadding;
    }

    protected virtual void EndEllipsisChanged()
    {
      if (PropBar.Grid != null)
        PropBar.Grid.InvalidateGrid();
    }

    protected virtual void ForeColorChanged()
    {
      if (PropBar.Grid != null)
        PropBar.Grid.InvalidateGrid();
    }

    protected virtual void PaddingChanged()
    {
      if (PropBar.Grid != null)
        PropBar.Grid.UpdateBaseFixedBands();
    }

    protected virtual bool ShouldSerializeCaption()
    {
      return (textStored == true);
    }

    protected virtual bool ShouldSerializeEndEllipsis()
    {
      return (endEllipsisStored == true);
    }

    protected virtual bool ShouldSerializeFont()
    {
      return (font != null);
    }

    protected virtual bool ShouldSerializeForeColor()
    {
      return (foreColorStored == true);
    }

    //protected virtual bool ShouldSerializeHeightAutoExpand()
    //{
    //  return (heightAutoExpandStored == true);
    //}

    protected virtual bool ShouldSerializeHorzAlign()
    {
      return (horzAlignStored == true);
    }

    protected virtual bool ShouldSerializePadding()
    {
      return (paddingStored == true);
    }

    protected virtual bool ShouldSerializeVertAlign()
    {
      return (vertAlignStored == true);
    }

    protected virtual void TextAlignChanged()
    {
      if (PropBar.Grid != null)
        PropBar.Grid.InvalidateGrid();
    }

    protected virtual void TextOrientationChanged()
    {
      if (PropBar.Grid != null)
        PropBar.Grid.UpdatePropBarsList();
    }

    private Font DefaultFont()
    {
      if (PropBar.Grid != null)
        return PropBar.Grid.TitleBar.Font;
      else
        return null;
    }

    private HorizontalAlignment DefaultHorzAlign()
    {
      if (PropBar.Grid != null)
        return PropBar.Grid.TitleBar.HorzAlign;
      else
        return HorizontalAlignment.Left;
    }

    private VerticalAlignment DefaultVertAlign()
    {
      if (PropBar.Grid != null)
        return PropBar.Grid.TitleBar.VertAlign;
      else
        return VerticalAlignment.Top;
    }

    private void FontChanged()
    {
      if (PropBar.Grid != null)
        PropBar.Grid.UpdateBaseFixedBands();
    }

    protected internal virtual void PerformLayout()
    {
      //TitleCell.PerformLayout(this);
    }

    protected internal virtual void UpdateMetrics(Size cellSize)
    {
    }

    protected virtual void ToolTipTextChanged()
    {
    }

    void ICellImageBoxOwner.CellImageBoxChanged(CellImageBox imageBox)
    {
      if (PropBar.Grid != null)
        PropBar.Grid.UpdateBaseFixedBands();
    }
    #endregion Methods

  }

  public class DataColumnTypeConverter : TypeConverter
  {
    private static readonly Type[] types = new Type[] {
            typeof(Boolean),
            typeof(Byte),
            typeof(Byte[]),
            typeof(Char),
            typeof(DateTime),
            typeof(Decimal),
            typeof(Double),
            typeof(Guid),
            typeof(Int16),
            typeof(Int32),
            typeof(Int64),
            typeof(object),
            typeof(SByte),
            typeof(Single),
            typeof(string),
            typeof(TimeSpan),
            typeof(UInt16),
            typeof(UInt32),
            typeof(UInt64),
            typeof(SqlInt16),
            typeof(SqlInt32),
            typeof(SqlInt64),
            typeof(SqlDecimal),
            typeof(SqlSingle),
            typeof(SqlDouble),
            typeof(SqlString),
            typeof(SqlBoolean),
            typeof(SqlBinary),
            typeof(SqlByte),
            typeof(SqlDateTime),
            typeof(SqlGuid),
            typeof(SqlMoney),
            typeof(SqlBytes),
            typeof(SqlChars),
            typeof(SqlXml)
        };
    private StandardValuesCollection values;

    public DataColumnTypeConverter()
    {
    }

    public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType)
    {
      if (destinationType == typeof(InstanceDescriptor))
      {
        return true;
      }
      return base.CanConvertTo(context, destinationType);
    }

    public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
    {
      if (destinationType == null)
      {
        throw new ArgumentNullException("destinationType");
      }

      if (destinationType == typeof(string))
      {
        if (value == null)
        {
          return String.Empty;
        }
        else
        {
          return value.ToString();
        }
      }

      if (value != null && destinationType == typeof(InstanceDescriptor))
      {
        Object newValue = value;
        if (value is string)
        {
          foreach (var t in types)
          {
            if (t.ToString().Equals(value))
            {
              newValue = t;
              break;
            }
          }
        }

        if (value is Type || value is string)
        {
          System.Reflection.MethodInfo method = typeof(Type).GetMethod("GetType", new Type[] { typeof(string) }); // change done for security review 
          if (method != null)
          {
            return new InstanceDescriptor(method, new object[] { ((Type)newValue).AssemblyQualifiedName });
          }
        }
      }

      return base.ConvertTo(context, culture, value, destinationType);
    }

    public override bool CanConvertFrom(ITypeDescriptorContext context, Type sourceType)
    {
      if (sourceType == typeof(string))
      {
        return true;
      }
      return base.CanConvertTo(context, sourceType);
    }

    public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
    {
      if (value != null && value is string)
      {
        foreach (var t in types)
        {
          if (t.ToString().Equals(value))
            return t;
        }

        return typeof(string);
      }

      return base.ConvertFrom(context, culture, value);
    }

    public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
    {
      if (values == null)
      {
        object[] objTypes;

        if (types != null)
        {
          objTypes = new object[types.Length];
          Array.Copy(types, objTypes, types.Length);
        }
        else
        {
          objTypes = null;
        }

        values = new StandardValuesCollection(objTypes);
      }
      return values;
    }

    public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
    {
      return true;
    }

    public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
    {
      return true;
    }
  }

  [ListBindable(false)]
  public class DataAxisGridPropBarCellManagersList : Collection<BaseGridCellManager>
  {
    private readonly PropertyAxisBar propBar;

    public DataAxisGridPropBarCellManagersList(PropertyAxisBar propBar)
    {
      this.propBar = propBar;
    }

    public new void Add(BaseGridCellManager item)
    {
      base.Add(item);
      item.BoundGrid = propBar.Grid;
      BaseDataCellManager itemAsPropertyBar = item as BaseDataCellManager;
      if (itemAsPropertyBar != null)
        itemAsPropertyBar.BoundPropAxisBar = propBar;
    }
  }

}
