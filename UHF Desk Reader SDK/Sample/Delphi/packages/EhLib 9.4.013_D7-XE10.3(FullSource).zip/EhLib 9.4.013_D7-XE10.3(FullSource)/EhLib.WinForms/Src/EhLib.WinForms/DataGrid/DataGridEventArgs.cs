﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  //DataGrid...EventArgs classes

  /// <summary>
  /// Event args for HorzLineParamsNeeded event of a data cell of a DataGridEh control
  /// </summary>
  public class DataGridHorzLineParamsNeededEventArgs : EventArgs
  {
    private readonly DataGridColumn column;
    private readonly DataGridRow row;

    public DataGridHorzLineParamsNeededEventArgs(DataGridColumn column, DataGridRow row)
    {
      this.column = column;
      this.row = row;
    }

    public DataGridColumn Column
    {
      get { return this.column; }
    }

    public DataGridRow Row
    {
      get { return this.row; }
    }

    public bool Visible { get; set; }

    public Color Color { get; set; }

    public DashStyle Style { get; set; }

  }

  /// <summary>
  /// Event args for DataCellManagerNeeded event of a DataGridEh control
  /// </summary>
  public class DataGridDataCellManagerNeededEventArgs : EventArgs
  {
    private readonly DataGridColumn column;
    private readonly DataGridRow row;
    private BaseGridCellManager cellObject;

    public DataGridDataCellManagerNeededEventArgs(DataGridColumn column, DataGridRow row)
    {
      this.column = column;
      this.row = row;
    }

    public DataGridColumn Column
    {
      get { return this.column; }
    }

    public DataGridRow Row
    {
      get { return this.row; }
    }

    public BaseGridCellManager CellManager
    {
      get { return this.cellObject; }
      set { cellObject = value; }
    }

  }

  //public class DataGridDataCellContentPaintEventArgs : EventArgs
  //{
  //  private readonly DataGridDataCellPaintEventArgs dataCellPaintEventArgs;
  //  private readonly Rectangle cellContentRect;

  //  public DataGridDataCellContentPaintEventArgs(DataGridDataCellPaintEventArgs dataCellPaintEventArgs, Rectangle cellContentRect)
  //  {
  //    this.dataCellPaintEventArgs = dataCellPaintEventArgs;
  //    this.cellContentRect = cellContentRect;
  //  }

  //  public DataGridDataCellPaintEventArgs DataCellPaintEventArgs
  //  {
  //    get { return this.dataCellPaintEventArgs; }
  //  }

  //  public Rectangle CellContentRect
  //  {
  //    get { return this.cellContentRect; }
  //  }

  //  public DataGridColumn Column
  //  {
  //    get { return dataCellPaintEventArgs.Column; }
  //  }

  //  public DataGridRow Row
  //  {
  //    get { return dataCellPaintEventArgs.Row; }
  //  }

  //  public BasePaintCellStates State
  //  {
  //    get { return dataCellPaintEventArgs.CellArgs.State; }
  //  }

  //  public Graphics Graphics
  //  {
  //    get { return dataCellPaintEventArgs.CellArgs.Graphics; }
  //  }

  //  public int DataColIndex
  //  {
  //    get { return dataCellPaintEventArgs.CellArgs.DataColIndex; }
  //  }

  //  public int DataRowIndex
  //  {
  //    get { return dataCellPaintEventArgs.CellArgs.DataRowIndex; }
  //  }
  //}

  //public class DataGridProgressBarDataCellPaintEventArgs : DataGridDataCellPaintEventArgs, IDataAxisGridProgressBarDataCellPaintEventArgs
  //{
  //  public DataGridProgressBarDataCellPaintEventArgs(BaseGridCellManager cellManager, Graphics graphics, int colIndex, int rowIndex,
  //    Rectangle cellRect, Rectangle cellAreaRect, BasePaintCellStates state, int areaColIndex, int areaRowIndex, Point inCellMousePos,
  //    PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, DataAxisGridListAxisItemViewState listAxisItemViewState,
  //    DataAxisGridDataCellFormatParamsNeededEventArgs fe) : base(cellManager, graphics, colIndex, rowIndex,
  //    cellRect, cellAreaRect, state, areaColIndex, areaRowIndex, inCellMousePos, propAxisBar, listItemBar,
  //    listAxisItemViewState, fe)
  //  {
  //    var pbfe = fe as DataGridProgressBarDataCellFormatParamsNeededEventArgs;
  //    if (pbfe != null)
  //    {
  //      BarFillColor = pbfe.BarFillColor;
  //      BarFrameColor = pbfe.BarFrameColor;
  //    }
  //  }

  //  public Color BarFillColor { get; set; }
  //  public Color BarFrameColor { get; set; }
  //}

  //public class DataGridDataCellMouseEventArgs : DataAxisGridDataCellMouseEventArgs
  //{

  //  public DataGridDataCellMouseEventArgs(
  //    BaseGridCellManager cellManager,
  //    int colIndex, int rowIndex,
  //    int areaColIndex, int areaRowIndex,
  //    PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar,
  //    int inCellX, int inCellY,
  //    Rectangle cellRect,
  //    MouseEventArgs e) : base(cellManager, colIndex, rowIndex, areaColIndex, areaRowIndex, propAxisBar, listItemBar, 
  //      inCellX, inCellY, cellRect, e)
  //  {
  //  }

  //  public DataGridDataCellMouseEventArgs(
  //    BaseGridCellManager cellManager,
  //    BaseGridCellMouseEventArgs baseArgs,
  //    int areaColIndex, int areaRowIndex,
  //    PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar) :
  //      base(cellManager, baseArgs, areaColIndex, areaRowIndex, propAxisBar, listItemBar)
  //  {
  //  }

  //  public DataGridColumn Column
  //  {
  //    get { return (DataGridColumn)PropAxisBar; }
  //  }

  //  public DataGridRow Row
  //  {
  //    get { return (DataGridRow)ListItemBar; }
  //  }

  //  public virtual void MouseDown(DataGridDataCellMouseEventArgs e)
  //  {
  //    e.CellManager.OnMouseDown(e);
  //  }
  //}

  /// <summary>
  /// Event args for some events of a DataGridEh control that related to a column.
  /// For example ColumnWidthChanged.
  /// </summary>
  public class DataGridColumnEventArgs : EventArgs
  {
    private readonly DataGridColumn column;

    public DataGridColumnEventArgs(DataGridColumn column)
    {
      this.column = column;
    }

    public DataGridColumn Column
    {
      get { return this.column; }
    }
  }

  /// <summary>
  /// Event args for some events of a DataGridEh control that related to a column and a row.
  /// </summary>
  public class DataGridColumnRowEventArgs : EventArgs
  {
    private readonly DataGridColumn column;
    private readonly DataGridRow row;

    public DataGridColumnRowEventArgs(DataGridColumn column, DataGridRow row)
    {
      this.column = column;
      this.row = row;
    }

    public DataGridColumn Column
    {
      get { return this.column; }
    }

    public DataGridRow Row
    {
      get { return this.row; }
    }
  }

  /// <summary>
  /// Event args for DisplayColumnsMoved event of a DataGridEh control
  /// </summary>
  public class DataGridDisplayColumnsMovedEventArgs : EventArgs
  {
    private readonly ReadOnlyCollection<DataGridColumn> movedColumns;
    private readonly int toIndex;
    private readonly DataGridColumn afterColumn;

    public DataGridDisplayColumnsMovedEventArgs(ReadOnlyCollection<DataGridColumn> movedColumns, int toIndex, DataGridColumn afterColumn)
    {
      this.movedColumns = movedColumns;
      this.toIndex = toIndex;
      this.afterColumn = afterColumn;
    }

    public ReadOnlyCollection<DataGridColumn> MovedColumns
    {
      get { return this.movedColumns; }
    }

    public int ToIndex
    {
      get { return this.toIndex; }
    }

    public DataGridColumn AfterColumn
    {
      get { return this.afterColumn; }
    }
  }

  //public class DataGridColumnCellEventArgs : BaseGridCellEventArgs
  //{
  //  private readonly DataGridColumn column;

  //  public DataGridColumnCellEventArgs(BaseGridControl grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, DataGridColumn column) :
  //    base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect)
  //  {
  //    this.column = column;
  //  }

  //  public DataGridColumnCellEventArgs(BaseGridControl grid, BaseGridCellEventArgs baseArgs, DataGridColumn column) :
  //    base(grid, baseArgs.ColIndex, baseArgs.RowIndex, baseArgs.AreaColIndex, baseArgs.AreaRowIndex, baseArgs.CellRect)
  //  {
  //    this.column = column;
  //  }

  //  public DataGridColumn Column
  //  {
  //    get { return this.column; }
  //  }

  //  public override string ToString()
  //  {
  //    return string.Format("ColIndex = {0} RowIndex = {1}",
  //      ColIndex, RowIndex);
  //  }
  //}

  /// <summary>
  /// Event args for RowIsSelectable event of a DataGridEh control
  /// </summary>
  public class DataGridRowIsSelectableEventArgs : EventArgs
  {
    private readonly DataGridRow dataRow;

    public DataGridRowIsSelectableEventArgs(DataGridRow dataRow)
    {
      this.dataRow = dataRow;
    }

    public DataGridRow DataRow
    {
      get { return dataRow; }
    }

    public bool RowIsSelectable { get; set; }
  }

  //public class DataGridDataCellEnterEventArgs : DataAxisGridDataCellEnterEventArgs
  //{
  //  public DataGridDataCellEnterEventArgs(int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int leaveColIndex, int leaveRowIndex,
  //    PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell)
  //    : base(colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, leaveColIndex, leaveRowIndex, propAxisBar, listItemBar, cell)
  //  {
  //  }

  //  public DataGridColumn Column
  //  {
  //    get { return (DataGridColumn)PropAxisBar; }
  //  }

  //  public DataGridRow Row
  //  {
  //    get { return (DataGridRow)ListItemBar; }
  //  }
  //}

  //public class DataGridDataCellLeaveEventArgs : DataAxisGridDataCellLeaveEventArgs
  //{
  //  public DataGridDataCellLeaveEventArgs(int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int enterColIndex, int enterRowIndex,
  //    PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell)
  //    : base(colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, enterColIndex, enterRowIndex, propAxisBar, listItemBar, cell)
  //  {
  //  }

  //  public DataGridColumn Column
  //  {
  //    get { return (DataGridColumn)PropAxisBar; }
  //  }

  //  public DataGridRow Row
  //  {
  //    get { return (DataGridRow)ListItemBar; }
  //  }
  //}

  /// <summary>
  /// Event args for mouse title cell events of a DataGridEh control
  /// </summary>
  public class DataGridTitleCellMouseEventArgs : HandledEventArgs
  {
    private readonly DataGridColumn column;
    private readonly DataGridColumnTitle columnTitle;
    //private readonly DataGridSuperTitle superTitle;
    private readonly BaseGridCellMouseEventArgs baseEventArgs;
    private readonly int inCellX;
    private readonly int inCellY;
    private readonly Rectangle cellRect;

    public DataGridTitleCellMouseEventArgs(BaseGridCellMouseEventArgs baseArgs, DataGridColumn column,
      DataGridColumnTitle columnTitle, int inCellX, int inCellY,
      Rectangle cellRect)
    {
      this.baseEventArgs = baseArgs;
      this.column = column;
      this.columnTitle = columnTitle;
      //this.superTitle = superTitle;
      this.inCellX = inCellX;
      this.inCellY = inCellY;
      this.cellRect = cellRect;
    }

    public DataGridColumn Column
    {
      get { return this.column; }
    }

    public DataGridColumnTitle ColumnTitle
    {
      get { return this.columnTitle; }
    }

    //public DataGridSuperTitle SuperTitle
    //{
    //  get { return this.superTitle; }
    //}

    public BaseGridCellMouseEventArgs BaseEventArgs
    {
      get { return baseEventArgs; }
    }

    public int InCellX
    {
      get { return inCellX; }
    }

    public int InCellY
    {
      get { return inCellY; }
    }

    public Rectangle CellRect
    {
      get { return cellRect; }
    }
  }

  /// <summary>
  /// Event args for title cell events of a DataGridEh control
  /// </summary>
  public class DataGridTitleCellEventArgs : HandledEventArgs
  {
    private readonly DataGridColumn column;
    private readonly DataGridColumnTitle columnTitle;
    private readonly DataGridSuperTitle superTitle;
    private readonly BaseGridCellEventArgs baseEventArgs;

    public DataGridTitleCellEventArgs(BaseGridCellEventArgs baseEventArgs, DataGridColumn column,
      DataGridColumnTitle columnTitle, DataGridSuperTitle superTitle)
    {
      this.baseEventArgs = baseEventArgs;
      this.column = column;
      this.columnTitle = columnTitle;
      this.superTitle = superTitle;
    }

    public DataGridColumn Column
    {
      get { return this.column; }
    }

    public DataGridColumnTitle ColumnTitle
    {
      get { return this.columnTitle; }
    }

    public DataGridSuperTitle SuperTitle
    {
      get { return this.superTitle; }
    }

    public BaseGridCellEventArgs BaseEventArgs
    {
      get { return baseEventArgs; }
    }
  }

  /// <summary>
  /// Event args for DefaultContextMenuStripNeeded event of a DataGridEh control
  /// </summary>
  public class DataGridDefaultContextMenuStripNeededEventArgs : EventArgs
  {
    private ContextMenuStrip contextMenuStrip;

    internal DataGridDefaultContextMenuStripNeededEventArgs(ContextMenuStrip contextMenuStrip)
    {
      this.contextMenuStrip = contextMenuStrip;
    }

    public ContextMenuStrip ContextMenuStrip
    {
      get { return this.contextMenuStrip; }
      set { this.contextMenuStrip = value; }
    }
  }

  /// <summary>
  /// Event args for CheckRowHitSearch event of a DataGridEh control
  /// </summary>
  public class DataGridSearchBoxCheckRowHitSearchEventArgs : EventArgs
  {
    private readonly string hitSearchText;
    private readonly DataGridRow dataRow;

    public DataGridSearchBoxCheckRowHitSearchEventArgs(string hitSearchText, DataGridRow dataRow)
    {
      this.dataRow = dataRow;
      this.hitSearchText = hitSearchText;
    }

    public DataGridRow DataRow
    {
      get { return dataRow; }
    }

    public string HitSearchText
    {
      get { return hitSearchText; }
    }

    public bool RowIsHitSearch { get; set; }

  }

  /// <summary>
  /// Event args for CheckCellHitSearch event of a DataGridEh control
  /// </summary>
  public class DataGridSearchBoxCheckCellHitSearchEventArgs : EventArgs
  {
    private readonly string hitSearchText;
    private readonly DataGridRow dataRow;
    private readonly DataGridColumn dataColumn;

    public DataGridSearchBoxCheckCellHitSearchEventArgs(string hitSearchText, DataGridRow dataRow, DataGridColumn dataColumn)
    {
      this.dataRow = dataRow;
      this.dataColumn = dataColumn;
      this.hitSearchText = hitSearchText;
    }

    public string HitSearchText
    {
      get { return hitSearchText; }
    }

    public DataGridRow DataRow
    {
      get { return dataRow; }
    }

    public DataGridColumn DataColumn
    {
      get { return dataColumn; }
    }

    public bool CellIsHitSearch { get; set; }
  }

  /// <summary>
  /// Event args for GetHighlightedRanges event of a DataGridEh control
  /// </summary>
  public class DataGridSearchGetHighlightedRangesEventArgs : EventArgs
  {
    private readonly string hitSearchText;
    private readonly DataGridRow dataRow;
    private readonly DataGridColumn dataColumn;
    private readonly CharacterRange[] ranges;

    public DataGridSearchGetHighlightedRangesEventArgs(string hitSearchText, DataGridRow dataRow, DataGridColumn dataColumn, CharacterRange[] ranges)
    {
      this.dataRow = dataRow;
      this.dataColumn = dataColumn;
      this.hitSearchText = hitSearchText;
      this.ranges = ranges;
    }

    public string HitSearchText
    {
      get { return hitSearchText; }
    }

    public DataGridRow DataRow
    {
      get { return dataRow; }
    }

    public DataGridColumn DataColumn
    {
      get { return dataColumn; }
    }

    public CharacterRange[] Ranges
    {
      get { return ranges; }
    }
  }

  /// <summary>
  /// Event args for RowHeightQuerying event of a DataGridEh control
  /// </summary>
  public class DataGridRowHeightNeededEventArgs : EventArgs
  {
    private readonly DataGridRow row;

    public DataGridRowHeightNeededEventArgs(DataGridRow row, ReadOnlyCollection<DataGridColumn> columnsToCalcHeight)
    {
      this.row = row;
      ColumnsToCalcHeight = columnsToCalcHeight;
    }

    public DataGridRow Row
    {
      get { return this.row; }
    }

    public bool Handled { get; set; }

    public int RowHeight { get; set; }

    public ReadOnlyCollection<DataGridColumn> ColumnsToCalcHeight { get; internal set; }

    public virtual void CalcRowHeight(DataGridRowHeightNeededEventArgs e)
    {
      e.Row.Grid.OnCalcRowHeight(e);
    }
  }

  public class DataGridSetDataValueErrorEventArgs : EventArgs
  {
    private readonly Exception exception;
    private bool throwException;

    public DataGridSetDataValueErrorEventArgs(Exception exception)
    {
      this.exception = exception;
    }

    public Exception Exception
    {
      get
      {
        return this.exception;
      }
    }

    public bool ThrowException
    {
      get
      {
        return this.throwException;
      }
      set
      {
        if (value && this.exception == null)
        {
          throw new ArgumentException("Cannot Throw Null Exception");
        }
        this.throwException = value;
      }
    }
  }

  public class DataGridSuperTitleContentRectNeededEventArgs : EventArgs
  {
    private DataGridEh grid;
    private DataGridSuperTitle superTitle;
    private Rectangle contentRect;
    private Rectangle cellRect;

    public DataGridSuperTitleContentRectNeededEventArgs(DataGridEh grid)
    {
      this.grid = grid;
    }

    public DataGridEh Grid
    {
      get { return grid; }
    }

    public DataGridSuperTitle SuperTitle
    {
      get { return superTitle; }
    }

    public Rectangle CellRect
    {
      get { return cellRect; }
    }

    public Rectangle ContentRect
    {
      get { return contentRect; }
      set { contentRect = value; }
    }

    public void Reset(DataGridSuperTitle superTitle, Rectangle cellRect)
    {
      this.superTitle = superTitle;
      this.cellRect = cellRect;
    }
  }

  public class DataGridSuperTitleFittedHeightNeededEventArgs : EventArgs
  {
    private DataGridEh grid;
    private DataGridSuperTitle superTitle;
    private Rectangle cellRect;
    private int fittedHeight;

    public DataGridSuperTitleFittedHeightNeededEventArgs(DataGridEh grid)
    {
      this.grid = grid;
      fittedHeight = -1;
    }

    public DataGridEh Grid
    {
      get { return grid; }
    }

    public DataGridSuperTitle SuperTitle
    {
      get { return superTitle; }
    }

    public Rectangle CellRect
    {
      get { return cellRect; }
    }

    public int FittedHeight
    {
      get { return fittedHeight; }
      set { fittedHeight = value; }
    }

    public void Reset(DataGridSuperTitle superTitle, Rectangle cellRect)
    {
      this.superTitle = superTitle;
      this.cellRect = cellRect;
      fittedHeight = -1;
    }
  }

  //public class DataGridDataCellFormatParamsNeededEventArgs : DataAxisGridDataCellFormatParamsNeededEventArgs
  //{
  //  public DataGridDataCellFormatParamsNeededEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell
  //    ) : base(propAxisBar, listItemBar, cell)
  //  {
  //  }

  //  public DataGridColumn Column
  //  {
  //    get { return (DataGridColumn)PropAxisBar; }
  //  }

  //  public DataGridRow Row
  //  {
  //    get { return (DataGridRow)ListItemBar; }
  //  }
  //}

  /// <summary>
  /// Event args for DataCellPullValue event of a DataGridEh control
  /// </summary>
  public class DataGridDataCellPullValueEventArgs : DataAxisGridDataCellPullValueEventArgs
  {

    public DataGridDataCellPullValueEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan) 
      : base(propAxisBar, listItemBar, cellMan)
    {

    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)ListItemBar; }
    }
  }

  /// <summary>
  /// Event args for DataCellPushValue event of a DataGridEh control
  /// </summary>
  public class DataGridDataCellPushValueEventArgs : DataAxisGridDataCellPushValueEventArgs
  {

    public DataGridDataCellPushValueEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
      : base(propAxisBar, listItemBar, cellMan)
    {

    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)ListItemBar; }
    }

    public void PushValue(DataGridDataCellPushValueEventArgs e)
    {
      e.Column.OnPushValue(e);
    }
  }

  /// <summary>
  /// Event args for DynamicColumnsCreating event of a DataGridEh control
  /// </summary>
  public class DataGridDynamicColumnsCreatingEventArgs : DataAxisDynamicColumnsCreatingEventArgs
  {
    //private readonly DataGridColumn[] columns;

    public DataGridDynamicColumnsCreatingEventArgs(DataAxisGrid grid, DeepPropertyDescriptor propertyDescriptor, bool inStaticColumns)
      : base(grid, propertyDescriptor, inStaticColumns)
    {
    }

    public bool InStaticColumns
    {
      get { return PresentInStaticList; }
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
    public DataGridColumn[] Columns
    {
      get { return (DataGridColumn[])PropertyBars; }
      set { PropertyBars = value; }
    }

    public virtual void CreateColumns(DataGridDynamicColumnsCreatingEventArgs e)
    {
      e.Grid.OnCreateDynamicPropBarsForDataProperty(e);
    }
  }

  /// <summary>
  /// Event args for DataCellOptimalWidthNeeded event of a DataGridEh control
  /// </summary>
  public class DataGridDataCellOptimalWidthNeededEventArgs : DataAxisGridDataCellOptimalWidthNeededEventArgs
  {
    public DataGridDataCellOptimalWidthNeededEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell)
      : base(propAxisBar, listItemBar, cell)
    {
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)ListItemBar; }
    }
  }

  /// <summary>
  /// Event args for ValuesAreDuplicatesStateNeeded event of a DataGridEh control
  /// </summary>
  public class DataGridValuesAreDuplicatesStateNeededEventArgs : HandledEventArgs
  {
    private DataGridColumn column;
    private DataGridRow row1;
    private DataGridRow row2;
    private bool valuesAreDuplicates;

    public DataGridValuesAreDuplicatesStateNeededEventArgs(DataGridColumn column,
      DataGridRow row1, DataGridRow row2)
    {
      this.column = column;
      this.row1 = row1;
      this.row2 = row2;
    }

    public DataGridColumn Column
    {
      get { return column; }
    }

    public DataGridRow Row1
    {
      get { return row1; }
    }

    public DataGridRow Row2
    {
      get { return row2; }
    }

    public bool ValuesAreDuplicates
    {
      get { return valuesAreDuplicates; }
      set { this.valuesAreDuplicates = value; }
    }

    public bool AreValuesDuplicates(DataGridValuesAreDuplicatesStateNeededEventArgs e)
    {
      column.InternalOnValuesAreDuplicatesStateNeeded(e);
      return e.ValuesAreDuplicates;
    }
  }

  /// <summary>
  /// Event args for SelectionChanged event of a DataGridEh control
  /// </summary>
  public class DataGridSelectionChangeOperationEventArgs : EventArgs
  {
    private readonly SelectionChangeOperationType changeOpType;
    private readonly object changingObject;

    public DataGridSelectionChangeOperationEventArgs(SelectionChangeOperationType changeOpType, object changingObject)
    {
      this.changeOpType = changeOpType;
      this.changingObject = changingObject;
    }

    public SelectionChangeOperationType ChangeOpType
    {
      get { return this.changeOpType; }
    }

    public object ChangingObject
    {
      get { return this.changingObject; }
    }
  }

  /// <summary>
  /// Event args for GridSettingsWriting event of a DataGridEh control
  /// </summary>
  public class DataGridStorableSettingsWritingEventArgs : HandledEventArgs
  {
    private readonly Dictionary<string, object> settings;
    private readonly DataGridStorableElements elements;

    public DataGridStorableSettingsWritingEventArgs(Dictionary<string, object> settings, DataGridStorableElements elements)
    {
      this.settings = settings;
      this.elements = elements;
    }

    public Dictionary<string, object> Settings
    {
      get { return settings; }
    }

    public DataGridStorableElements Elements
    {
      get { return elements; }
    }

    public void WriteSettings(DataGridEh grid)
    {
      grid.OnGridSettingsWriting(this);
    }
  }

  /// <summary>
  /// Event args for GridSettingsWriting event of a DataGridEh control
  /// </summary>
  public class DataGridStorableSettingsReadingEventArgs : HandledEventArgs
  {
    private readonly Dictionary<string, object> settings;

    public DataGridStorableSettingsReadingEventArgs(DataGridEh grid, Dictionary<string, object> settings)
    {
      this.settings = settings;
      Grid = grid;
    }

    public Dictionary<string, object> Settings
    {
      get { return settings; }
    }

    public DataGridEh Grid { get; internal set; }

    public virtual void ReadSettings(DataGridStorableSettingsReadingEventArgs e)
    {
      e.Grid.OnGridSettingsReading(e);
    }
  }

  /// <summary>
  /// Event args for GridColumnSettingsWriting event of a DataGridEh control
  /// </summary>
  public class DataGridColumnStorableSettingsWritingEventArgs : HandledEventArgs
  {
    private readonly DataGridColumn column;
    private readonly Dictionary<string, object> settings;
    private readonly DataGridColumnStorableElements elements;

    public DataGridColumnStorableSettingsWritingEventArgs(DataGridColumn column, Dictionary<string, object> settings, 
      DataGridColumnStorableElements columnElements)
    {
      this.column = column;
      this.settings = settings;
      this.elements = columnElements;
    }

    public Dictionary<string, object> Settings
    {
      get { return settings; }
    }

    public DataGridColumn Column
    {
      get { return column; }
    }

    public DataGridColumnStorableElements Elements
    {
      get { return elements; }
    }
  }

  public class DataGridColumnStorableSettingsReadingEventArgs : HandledEventArgs
  {
    private readonly DataGridColumn column;
    private readonly Dictionary<string, object> settings;

    public DataGridColumnStorableSettingsReadingEventArgs(DataGridColumn column, Dictionary<string, object> settings)
    {
      this.column = column;
      this.settings = settings;
    }

    public Dictionary<string, object> Settings
    {
      get { return settings; }
    }

    public DataGridColumn Column
    {
      get { return column; }
    }

    public virtual void ReadSettings(DataGridColumnStorableSettingsReadingEventArgs e)
    {
      e.Column.Grid.OnGridColumnSettingsReading(e);
    }
  }

  /// <summary>
  /// Event args for RowVisibleStateNeeded event of a DataGridEh control
  /// </summary>
  public class DataGridRowVisibleStateNeededEventArgs : EventArgs
  {
    public DataGridRowVisibleStateNeededEventArgs(DataGridRow row)
    {
      Row = row;
    }

    public DataGridRow Row
    {
      get;
      internal set;
    }

    public bool RowVisible { get; set; }

    public bool Handled { get; set; }

    public virtual void OnRowVisibleStateNeeded(DataGridRowVisibleStateNeededEventArgs e)
    {
      if (Row.Grid != null)
        Row.Grid.OnRowVisibleStateNeeded(e);
    }

  }

  /// <summary>
  /// Event args for InteractiveSortMarkingChanged event of a DataGridEh control
  /// </summary>
  public class SortMarkingChangedEventArgs :HandledEventArgs
  {
    public SortMarkingChangedEventArgs(DataGridTitleSortMarking sortMarking)
    {
      SortMarking = sortMarking;
    }

    public DataGridTitleSortMarking SortMarking
    {
      get;
      internal set;
    }

    public virtual void Sort(SortMarkingChangedEventArgs e)
    {
      e.SortMarking.Title.OnInteractiveSortMarkingChanged(e);
    }
  }

  /// <summary>
  /// Event args for painting event in a cells free area of the DataGridEh
  /// </summary>
  public class DataGridCellFreeAreaPaintEventArgs : BaseGridCellFreeAreaPaintEventArgs
  {
    public DataGridCellFreeAreaPaintEventArgs(BaseGridControl grid, BaseGridCellManager cellManager,
      GraphicsContext gc, int colIndex, int rowIndex, Rectangle areaRect) :
      base(grid, cellManager, gc, colIndex, rowIndex, areaRect)
    {
    }

    #region properties
    public new DataGridEh Grid { get { return (DataGridEh)base.Grid; } }
    #endregion

    #region methods
    #endregion
  }

}
