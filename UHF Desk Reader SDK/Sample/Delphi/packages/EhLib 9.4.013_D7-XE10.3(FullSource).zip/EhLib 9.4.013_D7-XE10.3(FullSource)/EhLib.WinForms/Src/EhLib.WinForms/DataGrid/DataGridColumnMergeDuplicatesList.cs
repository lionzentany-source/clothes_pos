﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace EhLib.WinForms
{
  public class MergeDuplicatesData
  {
    public MergeDuplicatesData(int masterDataRowIndex, int mergeRowCount/*, Rectangle mergedRect*/)
    {
      this.MasterDataRowIndex = masterDataRowIndex;
      this.MergeRowCount = mergeRowCount;
      //MergedRect = mergedRect;
    }

    public int MasterDataRowIndex { get; private set; }
    public int MergeRowCount { get; private set; }
    //public Rectangle MergedRect { get; }
  }

  public class DataGridColumnMergeDuplicatesList : AutoUpdatableOnAccessList<MergeDuplicatesData>
  {

    private DataGridColumn column;

    public DataGridColumnMergeDuplicatesList(DataGridColumn column)
    {
      this.column = column;
    }

    protected override void UpdateList()
    {
      //object oldValue = null;
      //object nextValue;
      int masterMergeRowIndex = 0;
      int mergeRowCount = 1;
      DataGridRow oldRow = null;
      DataGridRow nextRow;

      //int topVisibleDataRowIndex = column.Grid.VertAxis.RollStartVisCell + column.Grid.VertAxis.FixedCellCount;
      //topVisibleDataRowIndex = column.Grid.RawToDataRowIndex(topVisibleDataRowIndex);
      //int lastVisibleDataRowIndex = topVisibleDataRowIndex + column.Grid.VisibleRowCount;
      //if (column.Grid.RawToDataRowIndex(column.Grid.NewRowIndex) == lastVisibleDataRowIndex)
      //  lastVisibleDataRowIndex--;

      Items.Clear();

      for (int i = 0; i < column.Grid.VisibleRows.Count; i++)
      {
        DataGridRow row = column.Grid.VisibleRows[i];
        if (i == 0)
        {
          oldRow = row;
          //oldValue = column.GetValue(row);
        }
        else
        {
          nextRow = row;
          //nextValue = column.GetValue(row);
          //
          if (column.CheckValuesAreDuplicates(oldRow, nextRow))
          {
            mergeRowCount++;
          }
          else if (mergeRowCount > 1)
          {
            SetMergeSegment(masterMergeRowIndex, mergeRowCount);
            mergeRowCount = 1;
            masterMergeRowIndex = i;
            //oldValue = nextValue;
            oldRow = nextRow;
          }
          else
          {
            Items.Add(null);
            masterMergeRowIndex = i;
            //oldValue = nextValue;
            oldRow = nextRow;
          }
        }
      }

      if (mergeRowCount > 1)
        SetMergeSegment(masterMergeRowIndex, mergeRowCount);
      else
        Items.Add(null);
    }

    //private Rectangle CalcMergeRect(int masterMergeRowIndex, int mergeRowCount)
    //{
    //  int gridRowIndex;
    //  int gridColIndex;

    //  Rectangle result = Rectangle.Empty;
    //  DataGridEh grid = column.Grid;

    //  gridColIndex = column.VisibleIndex - grid.StartDataColIndex;
    //  result.Width = grid.ColWidths[gridColIndex];

    //  for (int i = 0; i < mergeRowCount; i++)
    //  {
    //    gridRowIndex = i + grid.FixedRowCount;
    //    result.Height = result.Height + grid.RowHeights[gridRowIndex];
    //  }

    //  return result;
    //}

    private void SetMergeSegment(int masterMergeRowIndex, int mergeRowCount/*, Rectangle mergedRect*/)
    {
      MergeDuplicatesData mergeData = new MergeDuplicatesData(masterMergeRowIndex, mergeRowCount/*, mergedRect*/);
      for(int i = 0; i < mergeRowCount; i++)
      {
        Items.Add(mergeData);
      }
    }

    //private bool ValuesEqual(object oldValue, object nextValue)
    //{
    //  if (oldValue == null && nextValue != null)
    //    return false;
    //  else if (oldValue != null && nextValue == null)
    //    return false;
    //  else if (oldValue == null && nextValue == null)
    //    return true;
    //  else
    //    return oldValue.Equals(nextValue);
    //}

    //protected override void UpdateList()
    //{
    //  object oldValue = null;
    //  object nextValue;
    //  int i = 0;
    //  int masterMergeRowIndex = 0;
    //  int mergeRowCount = 0;

    //  foreach (DataGridRow row in column.Grid.VisibleRows)
    //  {
    //    if (i == 0)
    //    {
    //      oldValue = column.GetValue(row);
    //    }
    //    else
    //    {
    //      nextValue = column.GetValue(row);
    //      if (ValuesEqual(oldValue, nextValue))
    //      {
    //        masterMergeRowIndex++;
    //      }
    //      else if (mergeRowCount == 0)
    //      {
    //        Items.Add(null);
    //        masterMergeRowIndex = i + 1;
    //        oldValue = nextValue;
    //      }
    //      else if (masterMergeRowIndex > 0)
    //      {
    //        SetMergeSegment(masterMergeRowIndex, mergeRowCount);
    //        mergeRowCount = 0;
    //        masterMergeRowIndex = i + 1;
    //        oldValue = nextValue;
    //      }
    //    }
    //    i++;
    //  }
    //}

  }
}
