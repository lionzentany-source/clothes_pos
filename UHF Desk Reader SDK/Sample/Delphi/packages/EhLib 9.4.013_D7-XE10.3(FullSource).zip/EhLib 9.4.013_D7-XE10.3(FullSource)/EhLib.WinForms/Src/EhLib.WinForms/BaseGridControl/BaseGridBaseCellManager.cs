﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2019 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Base class for all grid cell managers.
  /// Defines methods for painting, reaction to mouse actions, keyboard keystroke reactions, and show cell editor.
  /// </summary>
  [DesignerCategory("Code")]
  [ToolboxItem(false)]
  [DesignTimeVisible(false)]
  public class BaseGridCellManager : Component
  {
    #region privates
    private BaseGridControl boundGrid;
    //private bool backRectHasMouse;

    internal bool CellContentMouseDown;
    #endregion privates

    public BaseGridCellManager()
    {

    }

    #region Properties
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public BaseGridControl BoundGrid
    {
      get { return boundGrid; }
      set { boundGrid = value; }
    }

    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public virtual Type EditorType
    {
      get { return null; }
    }
    #endregion Properties

    #region Methods

    //Paint
    public virtual void ProcessPaint(BaseGridCellPaintEventArgs e)
    {
      HandlePaintEvent(e);
      if (!e.Handled)
        OnPaint(e);
    }

    protected internal virtual void HandlePaintEvent(BaseGridCellPaintEventArgs e)
    {
    }

    protected internal virtual void OnPaint(BaseGridCellPaintEventArgs e)
    {
      OnPaintBackground(e);
      OnPaintForeground(e);
    }

    protected internal virtual void OnPaintBackground(BaseGridCellPaintEventArgs e)
    {
      Color fillColor;

      if ((e.ColIndex >= e.Grid.FixedColCount - e.Grid.FrozenColCount) && (e.RowIndex >= e.Grid.FixedRowCount - e.Grid.FrozenRowCount))
        fillColor = SystemColors.Window;
      else
        fillColor = Color.LightBlue;

      using (
        SolidBrush fillBrush = new SolidBrush(fillColor))
      {
        if ((BasePaintCellStates.Selected & e.State) != 0)
        {
          if (e.Grid.IsActiveControl())
            fillBrush.Color = SystemColors.Highlight;
          else
            fillBrush.Color = SystemColors.ButtonShadow;
        }

        e.Grid.PaintingFillRectangle(e.Graphics, fillBrush, e.CellRect);
      }
    }

    protected internal virtual void OnPaintForeground(BaseGridCellPaintEventArgs e)
    {
      OnPaintClientForeground(e);
      OnPaintCustomArea(e);
    }

    protected internal virtual void OnPaintClientForeground(BaseGridCellPaintEventArgs e)
    {
      Color foreColor;

      if ((BasePaintCellStates.Current & e.State) != 0)
        foreColor = SystemColors.HighlightText;
      else
        foreColor = e.Grid.ForeColor;

      string text = GetDisplayText(e.Grid, e.AreaColIndex, e.AreaRowIndex);
      if (text != null)
      {
        e.GraphicsContext.DrawText(text, e.Grid.Font, e.CellRect, foreColor, HorizontalAlignment.Left, VerticalAlignment.Top, TextFormatFlagsEh.None);
      }
    }

    //protected internal virtual Rectangle GetClientRect(int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect)
    //{
    //  return cellRect;
    //}

    protected internal virtual void OnPaintCustomArea(BaseGridCellPaintEventArgs e)
    {

    }

    protected internal virtual BaseGridCellPaintEventArgs GetCellPaintEmptyAreaEventArgs(
        BaseGridControl grid, GraphicsContext gc, 
        int colIndex, int rowIndex, Rectangle paintRect, BasePaintCellStates state,
        int areaColIndex, int areaRowIndex, Point inCellMousePos
      )
    {
      return new BaseGridCellPaintEventArgs(grid, this, gc, colIndex, rowIndex, paintRect, paintRect, state, areaColIndex, areaRowIndex, inCellMousePos);
    }

    protected internal virtual void OnPaintEmptyArea(BaseGridCellPaintEventArgs e)
    {
      if (e.Grid.Background.Visible) return;

      using (SolidBrush fillBrush = new SolidBrush(e.Grid.BackColor))
      {
        e.Grid.PaintingFillRectangle(e.Graphics, fillBrush, e.CellRect);
      }
    }

    //PaintParams
    public virtual BaseGridCellPaintEventArgs GetCellPaintParams(BaseGridControl grid,
        GraphicsContext gc, int colIndex, int rowIndex, Rectangle paintRect, Rectangle cellAreaRect, BasePaintCellStates state,
        int areaColIndex, int areaRowIndex, Point inCellMousePos
      )
    {
      return new BaseGridCellPaintEventArgs(grid, this, gc, colIndex, rowIndex, paintRect, cellAreaRect, state, areaColIndex, areaRowIndex, inCellMousePos);
    }

    //Other
    protected internal virtual void PrintCell(BaseGridControl grid,
      PrintServiceEventArgs prnSrcEventArgs, Rectangle paintRect, 
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex)
    {
      BaseGridCellPaintEventArgs pea = GetCellPaintParams(grid, prnSrcEventArgs, colIndex, rowIndex, paintRect,
        paintRect, 0, areaColIndex, areaRowIndex, new Point(-1, -1));

      pea.IsPaintBackground = false;
      ProcessPaint(pea);

    }

    public virtual string GetDisplayText(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      return areaColIndex.ToString() + BaseGridControl.CharColonStr + areaRowIndex.ToString(); 
    }

    public virtual bool CanMouseDownShowEditor(BaseGridCellMouseEventArgs e)
    {
      return true;
    }

    public virtual void OccupyEditControl(BaseGridControl grid, Control cellEditControl, bool selectAll, BaseGridCellEditorParamsNeededEventArgs editorParams)
    {
      throw new InvalidOperationException("OccupyEditControl: Must be implemented in the inherited class");
    }

    public virtual void ReleaseEditControl(Control cellEditControl)
    {
    }

    public virtual bool IsCharToEnterEditMode(KeyPressEventArgs e)
    {
      return false;
    }

    protected internal virtual void OnGetCellBorderParams(BaseGridCellBorderEventArgs e)
    {
    }

    //public virtual void GridCellPosToAreaCellPos(int gridColIndex, int gridRowIndex, out int areaColIndex, out int areaRowIndex)
    //{
    //  areaColIndex = gridColIndex;
    //  areaRowIndex = gridRowIndex;
    //}

    //public virtual void AreaCellPosToGridCellPos(int areaColIndex, int areaRowIndex, out int gridColIndex, out int gridRowIndex)
    //{
    //  gridColIndex = areaColIndex;
    //  gridRowIndex = areaRowIndex;
    //}

    protected internal virtual void ProcessMouseDown(BaseGridCellMouseEventArgs e)
    {
      HandleMouseDownEvent(e);
      if (e.Handled) return;
      OnMouseDown(e);
    }

    protected internal virtual void HandleMouseDownEvent(BaseGridCellMouseEventArgs e)
    {
    }

    protected internal virtual void OnMouseDown(BaseGridCellMouseEventArgs e)
    {
      bool moveDrawn = false;
      CellContentMouseDown = true;

      GridCoord mouseDownCellPos = e.Grid.MouseDownCellCoord;

      if ((e.ColIndex >= e.Grid.FixedColCount - e.Grid.FrozenColCount) &&
            (mouseDownCellPos.Y >= e.Grid.FixedRowCount - e.Grid.FrozenRowCount) &&
            (e.ColIndex < e.Grid.ColCount) &&
            (mouseDownCellPos.Y < e.Grid.RowCount)
          )
      {
        if ((GridOptions.Editing & e.Grid.Options) != 0)
        {
          if ((e.ColIndex == e.Grid.Col) && 
              (mouseDownCellPos.Y == e.Grid.Row) &&
              ((GridOptions.Editing & e.Grid.Options) != 0) &&
              (e.Button == MouseButtons.Left && (Control.ModifierKeys & (Keys.Shift | Keys.Alt | Keys.Control)) == 0) &&
              CanMouseDownShowEditor(e)
              )
            e.Grid.ShowEditor(true);
          else
          {
            if ((GridOptions.RangeSelect & e.Grid.Options) != 0)
            {
              e.Grid.GridState = BaseGridState.Selecting;
              e.Grid.SetGridTimer(true, 60);
              if (Control.ModifierKeys == Keys.Shift && e.Button == MouseButtons.Left)
                e.Grid.MoveAnchorCell(e.ColIndex, mouseDownCellPos.Y, true);
              else
                e.Grid.InteractiveFocusCell(e.ColIndex, mouseDownCellPos.Y, InteractiveActionSource.Mouse);
            }
            else
            {
              e.Grid.InteractiveFocusCell(e.ColIndex, mouseDownCellPos.Y, InteractiveActionSource.Mouse);
            }
            e.Grid.UpdateEdit();
          }
          //            Click();
        }
        else
        {
          if ((GridOptions.RangeSelect & e.Grid.Options) != 0)
            e.Grid.GridState = BaseGridState.Selecting;
          e.Grid.SetGridTimer(true, 60);
          if (Control.ModifierKeys == Keys.Shift && e.Button == MouseButtons.Left)
            e.Grid.MoveAnchorCell(e.ColIndex, mouseDownCellPos.Y, true);
          else
            e.Grid.InteractiveFocusCell(e.ColIndex, mouseDownCellPos.Y, InteractiveActionSource.Mouse);
        }
      }
      else if (((GridOptions.RowMoving & e.Grid.Options) != 0) &&
                (e.Button == MouseButtons.Left) &&
                (e.ColIndex >= 0) &&
                (e.ColIndex < e.Grid.FixedColCount) &&
                (mouseDownCellPos.Y >= e.Grid.FixedRowCount) &&
                (mouseDownCellPos.Y < e.Grid.RowCount)
              )
      {
        e.Grid.MoveFromIndex = mouseDownCellPos.Y;
        int moveFromIndex = e.Grid.MoveFromIndex;
        int moveToIndex = moveFromIndex;
        if (e.Grid.CheckBeginRowDrag(ref moveFromIndex, ref moveToIndex, new Point(e.GridMouseArgs.X, e.GridMouseArgs.Y)))
        {
          e.Grid.GridState = BaseGridState.RowMoving;
          e.Grid.Update();
          e.Grid.DrawMove();
          moveDrawn = true;
          e.Grid.SetGridTimer(true, 60);
        }
      }
      else if (((GridOptions.ColMoving & e.Grid.Options) != 0) &&
                (e.Button == MouseButtons.Left) &&
                (mouseDownCellPos.Y >= 0) &&
                (mouseDownCellPos.Y < e.Grid.FixedRowCount) &&
                (e.ColIndex >= e.Grid.FixedColCount) &&
                (e.ColIndex < e.Grid.ColCount)
              )
      {
        int moveFromIndex = e.ColIndex;
        int moveToIndex = e.ColIndex;
        if (e.Grid.CheckBeginColumnDrag(ref moveFromIndex, ref moveToIndex, new Point(e.GridMouseArgs.X, e.GridMouseArgs.Y)))
          e.Grid.StartColMoving(moveFromIndex, moveToIndex, e.GridMouseArgs.X, e.GridMouseArgs.Y);
      }

      if (moveDrawn)
        e.Grid.HideMove();
    }

    protected internal virtual void ProcessMouseMove(BaseGridCellMouseEventArgs e)
    {
      HandleMouseMoveEvent(e);
      if (e.Handled) return;
      OnMouseMove(e);
    }

    protected internal virtual void HandleMouseMoveEvent(BaseGridCellMouseEventArgs e)
    {
    }

    protected internal virtual void OnMouseMove(BaseGridCellMouseEventArgs e)
    {
      //var brnEvArg = new BaseGridCellBackgroundRectNeededEventArgs(e.ColIndex, e.RowIndex, e.AreaColIndex, e.AreaRowIndex, e.CellRect);
      //ProcessBackgroundRectNeeded(brnEvArg);
      //bool backRectHasMouse = brnEvArg.BackgroundRect.Contains(e.GridMouseArgs.Location);
      //if (this.backRectHasMouse != backRectHasMouse)
      //{
      //  this.backRectHasMouse = backRectHasMouse;
      //  Grid.InvalidateCell(e.ColIndex, e.RowIndex);
      //}
    }

    protected internal virtual void ProcessMouseUp(BaseGridCellMouseEventArgs e)
    {
      HandleMouseUpEvent(e);
      if (e.Handled) return;
      OnMouseUp(e);
    }

    protected internal virtual void HandleMouseUpEvent(BaseGridCellMouseEventArgs e)
    {
    }

    protected internal virtual void OnMouseUp(BaseGridCellMouseEventArgs e)
    {
      CellContentMouseDown = false;
    }

    protected internal virtual void ProcessMouseClick(BaseGridCellMouseEventArgs e)
    {
      HandleMouseClickEvent(e);
      if (e.Handled) return;
      OnMouseClick(e);
    }

    protected internal virtual void HandleMouseClickEvent(BaseGridCellMouseEventArgs e)
    {
    }

    protected internal virtual void OnMouseClick(BaseGridCellMouseEventArgs e)
    {
    }

    protected internal virtual void ProcessMouseDoubleClick(BaseGridCellMouseEventArgs e)
    {
      HandleMouseDoubleClickEvent(e);
      if (e.Handled) return;
      OnMouseDoubleClick(e);
    }

    protected internal virtual void HandleMouseDoubleClickEvent(BaseGridCellMouseEventArgs e)
    {
    }

    protected internal virtual void OnMouseDoubleClick(BaseGridCellMouseEventArgs e)
    {
    }

    protected internal virtual void OnMouseCaptureCanceled()
    {
    }

    protected internal virtual void ProcessMouseEnter(BaseGridCellEnterEventArgs e)
    {
      HandleMouseEnterEvent(e);
      OnMouseEnter(e);
    }

    protected virtual void HandleMouseEnterEvent(BaseGridCellEnterEventArgs e)
    {
    }

    protected internal virtual void OnMouseEnter(BaseGridCellEnterEventArgs e)
    {
      //this.backRectHasMouse = true;
    }

    protected internal virtual void ProcessMouseLeave(BaseGridCellLeaveEventArgs e)
    {
      HandleMouseLeaveEvent(e);
      OnMouseLeave(e);
    }

    protected virtual void HandleMouseLeaveEvent(BaseGridCellLeaveEventArgs e)
    {
    }

    protected internal virtual void OnMouseLeave(BaseGridCellLeaveEventArgs e)
    {
      //this.backRectHasMouse = false;
    }

    protected internal virtual void ProcessMouseHover(BaseGridCellMouseEventArgs e)
    {
      HandleMouseHoverEvent(e);
      if (e.Handled) return;
      OnMouseHover(e);
    }

    protected virtual void HandleMouseHoverEvent(BaseGridCellMouseEventArgs e)
    {
    }

    protected virtual void OnMouseHover(BaseGridCellMouseEventArgs e)
    {
    }

    protected internal virtual void CancelMode()
    {
      CellContentMouseDown = false;
    }

    protected internal virtual void OnKeyDown(BaseGridControl grid, KeyEventArgs e)
    {
    }

    protected internal virtual void OnKeyPress(BaseGridControl grid, KeyPressEventArgs e)
    {
    }

    protected internal virtual void OnKeyUp(BaseGridControl grid, KeyEventArgs e)
    {
    }

    protected internal virtual void SetCursor(BaseGridCellMouseEventArgs de, ref Cursor cursor)
    {
      var ce = new BaseGridCellQueryCursorEventArgs(de.Grid, 
        this, de.ColIndex, de.RowIndex, de.AreaColIndex, de.AreaRowIndex, 
        de.InCellX, de.InCellY, de.CellRect, de.GridMouseArgs);
      OnQueryCursor(ce);
      HandleQueryCursorEvent(ce);
      cursor = ce.Cursor;
    }

    protected internal virtual void HandleQueryCursorEvent(BaseGridCellQueryCursorEventArgs e)
    {
    }

    protected internal virtual void OnQueryCursor(BaseGridCellQueryCursorEventArgs e)
    {
    }

    protected internal virtual bool IsSelected(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      return false;
    }

    protected internal virtual void ProcessMouseContextMenuStripNeeded(BaseGridCellContextMenuStripNeededEventArgs e)
    {
      HandleMouseContextMenuStripNeededEvent(e);
      if (e.Handled)
        return;
      else
      {
        OnContextMenuStripNeeded(e);
      }
    }

    protected internal virtual void OnContextMenuStripNeeded(BaseGridCellContextMenuStripNeededEventArgs e)
    {
      if (BoundGrid != null)
        e.ContextMenuStrip = BoundGrid.ContextMenuStrip;
    }

    protected internal virtual void HandleMouseContextMenuStripNeededEvent(BaseGridCellContextMenuStripNeededEventArgs e)
    {
    }

    protected internal virtual BaseGridCellMouseEventArgs CreateMouseEventArgs(
      BaseGridControl grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, int inCellX, int inCellY, Rectangle cellRect, MouseEventArgs gridMouseArgs)
    {
      var de = new BaseGridCellMouseEventArgs(grid, this, colIndex, rowIndex, areaColIndex, areaRowIndex, inCellX, inCellY, cellRect, gridMouseArgs);
      return de;
    }

    protected internal virtual BaseGridCellEventArgs CreateCellEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect)
    {
      BaseGridCellEventArgs de = new BaseGridCellEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect);
      return de;
    }

    protected internal virtual BaseGridCellEnterEventArgs CreateMouseEnterEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int leaveColIndex, int leaveRowIndex)
    {
      var de = new BaseGridCellEnterEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, leaveColIndex, leaveRowIndex);
      return de;
    }

    protected internal virtual BaseGridCellLeaveEventArgs CreateMouseLeaveEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int enterColIndex, int enterRowIndex)
    {
      var de = new BaseGridCellLeaveEventArgs(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, enterColIndex, enterRowIndex);
      return de;
    }

    protected internal virtual BaseGridCellContextMenuStripNeededEventArgs CreateCellContextMenuStripNeededEventArgs(
      BaseGridControl grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, int inCellX, int inCellY,
      Rectangle cellRect, int mousePosX, int mousePosY)
    {
      var de = new BaseGridCellContextMenuStripNeededEventArgs(grid, this, colIndex, rowIndex, areaColIndex, areaRowIndex, inCellX, inCellY, cellRect, mousePosX, mousePosY);
      return de;
    }

    protected internal void InvalidateGrid()
    {
      if (BoundGrid != null)
        BoundGrid.InvalidateGrid();
    }
    #endregion
  }
}
