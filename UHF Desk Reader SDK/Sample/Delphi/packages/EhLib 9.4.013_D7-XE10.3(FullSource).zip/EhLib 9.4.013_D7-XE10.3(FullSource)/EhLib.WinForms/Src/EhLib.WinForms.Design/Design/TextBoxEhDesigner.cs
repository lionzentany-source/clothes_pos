﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System.ComponentModel;

namespace EhLib.WinForms.Design
{
  public class TextBoxEhDesigner : BaseEditBoxDesigner
  {

    internal TextBoxEh TextBox
    {
      get { return this.Component as TextBoxEh; }
    }

    public override System.Windows.Forms.Design.SelectionRules SelectionRules
    {
      get
      {
        System.Windows.Forms.Design.SelectionRules selectionRules = base.SelectionRules;
        object component = Component;
        selectionRules |= System.Windows.Forms.Design.SelectionRules.AllSizeable;
        PropertyDescriptor descriptor = TypeDescriptor.GetProperties(component)["Multiline"];
        if (descriptor != null)
        {
          object obj3 = descriptor.GetValue(component);
          if ((obj3 is bool) && !((bool)obj3))
          {
            PropertyDescriptor descriptor2 = TypeDescriptor.GetProperties(component)["AutoSize"];
            if (descriptor2 != null)
            {
              object obj4 = descriptor2.GetValue(component);
              if ((obj4 is bool) && ((bool)obj4))
              {
                selectionRules &= ~(System.Windows.Forms.Design.SelectionRules.BottomSizeable | System.Windows.Forms.Design.SelectionRules.TopSizeable);
              }
            }
          }
        }
        return selectionRules;
      }
    }

    //public override ICollection AssociatedComponents
    //{
    //  get
    //  {
    //    ArrayList items = new ArrayList();
    //    if (TextBox.EditItem != null)
    //      items.Add(TextBox.EditItem);
    //    return (ICollection)items;
    //  }
    //}
  }
}