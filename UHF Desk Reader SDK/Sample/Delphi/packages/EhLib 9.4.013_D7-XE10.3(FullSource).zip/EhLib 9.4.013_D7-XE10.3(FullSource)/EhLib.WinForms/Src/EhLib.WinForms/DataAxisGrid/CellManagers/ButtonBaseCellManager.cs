﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  //public delegate void EventMethod<TEventArgs>(TEventArgs e) where TEventArgs : EventArgs;

  /// <summary>
  /// Defines a base class for ButtonDataCellManager, CheckBoxDataCellManager and RadioButtonDataCellManager classes.
  /// </summary>
  [DesignerCategory("Code")]
  [DataCellDesignTimeVisible(false)]
  public abstract class ButtonBaseDataCellManager : BaseDataCellManager
  {

    #region privates
    internal bool DownState;
    #endregion privates

    #region Properties
    #endregion Properties

    #region Methods
    public virtual void SetDownState(DataAxisGrid grid, int colIndex, int rowIndex, int dataColIndex, int dataRowIndex, bool downState)
    {
      if (this.DownState != downState)
      {
        this.DownState = downState;
        grid.InvalidateCell(colIndex, rowIndex);
      }
    }

    public virtual void Toggle(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
    }

    public virtual void InteractiveToggle(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      Toggle(propAxisBar, listItemBar);
    }

    protected internal override void OnKeyDown(BaseGridControl grid, KeyEventArgs e)
    {
      switch (e.KeyData & Keys.KeyCode)
      {
        case Keys.Space:
          {
            DataAxisGrid axisGrid = grid as DataAxisGrid;
            SetDownState(axisGrid, axisGrid.Col, axisGrid.Row, axisGrid.CurrentDataColIndex, axisGrid.CurrentDataRowIndex, true);
            e.Handled = true;
            return;
          }
      }
    }

    protected internal override void OnKeyUp(BaseGridControl grid, KeyEventArgs e)
    {
      switch (e.KeyData & Keys.KeyCode)
      {
        case Keys.Space:
          {
            DataAxisGrid axisGrid = grid as DataAxisGrid;

            SetDownState(axisGrid, axisGrid.Col, axisGrid.Row, axisGrid.CurrentDataColIndex, axisGrid.CurrentDataRowIndex, false);
            e.Handled = true;

            PropertyAxisBar propAxisBar;
            DataAxisGridListItemBar listItemBar;
            AxisObjectsByDataColRowIndex(axisGrid, axisGrid.CurrentDataColIndex, axisGrid.CurrentDataRowIndex, out propAxisBar, out listItemBar);

            var evArg = new DataAxisGridDataCellEventArgs(axisGrid, axisGrid.Col, axisGrid.Row,
              axisGrid.CurrentDataColIndex, axisGrid.CurrentDataRowIndex, Rectangle.Empty, propAxisBar, listItemBar, this);
            axisGrid.OnDataCellClick(evArg);
            if (!evArg.Handled)
            {
              bool canModify = CanModify(propAxisBar, listItemBar);
              if (canModify)
                InteractiveToggle(propAxisBar, listItemBar);
            }
            return;
          }
      }
    }

    protected internal override void OnMouseDown(DataAxisGridDataCellMouseEventArgs e)
    {
      base.OnMouseDown(e);
      if (e.ClientRect.Contains(e.GridMouseArgs.Location))
      {
        DownState = true;
      }
    }

    protected internal override void OnMouseUp(DataAxisGridDataCellMouseEventArgs e)
    {
      if (DownState && e.ClientRect.Contains(e.GridMouseArgs.Location))
      {
        bool canModify = CanModify(e.Grid, e.AreaColIndex, e.AreaRowIndex);
        if (canModify)
        {
          PropertyAxisBar propAxisBar;
          DataAxisGridListItemBar listItemBar;
          AxisObjectsByDataColRowIndex(e.Grid, e.AreaColIndex, e.AreaRowIndex, out propAxisBar, out listItemBar);

          InteractiveToggle(propAxisBar, listItemBar);
        }
      }
      base.OnMouseUp(e);
      SetDownState(e.Grid, e.ColIndex, e.RowIndex, e.AreaColIndex, e.AreaRowIndex, false);
    }

    protected internal override void OnMouseEnter(DataAxisGridDataCellEnterEventArgs e)
    {
      e.Grid.InvalidateCell(e.ColIndex, e.RowIndex);
      base.OnMouseEnter(e);
    }

    protected internal override void OnMouseLeave(BaseGridCellLeaveEventArgs e)
    {
      e.Grid.InvalidateCell(e.ColIndex, e.RowIndex);
      base.OnMouseLeave(e);
    }

    #endregion Methods

  }

  //public class ButtonBaseCellWorker
  //{
  //  #region privates
  //  private BaseDataCellManager cellManager;
  //  #endregion privates

  //  public ButtonBaseCellWorker(BaseDataCellManager cellManager)
  //  {
  //    this.cellManager = cellManager;
  //  }

  //  #region Properties
  //  public BaseDataCellManager CellManager
  //  {
  //    get { return cellManager; }
  //  }

  //  public bool DownState { get; set; }
  //  #endregion Properties

  //  #region Methods
  //  public virtual void SetDownState(int colIndex, int rowIndex, int dataColIndex, int dataRowIndex, bool downState)
  //  {
  //    if (this.DownState != downState)
  //    {
  //      this.DownState = downState;
  //      CellManager.Grid.InvalidateCell(colIndex, rowIndex);
  //    }
  //  }

  //  public virtual void Toggle(int dataColIndex, int dataRowIndex)
  //  {
  //  }

  //  public virtual void OnKeyDown(KeyEventArgs e)
  //  {
  //    switch (e.KeyData & Keys.KeyCode)
  //    {
  //      case Keys.Space:
  //        {
  //          SetDownState(CellManager.Grid.Col, CellManager.Grid.Row, CellManager.Grid.CurrentDataColIndex, CellManager.Grid.CurrentDataRowIndex, true);
  //          e.Handled = true;
  //          return;
  //        }
  //    }
  //  }

  //  public virtual void OnKeyUp(KeyEventArgs e)
  //  {
  //    switch (e.KeyData & Keys.KeyCode)
  //    {
  //      case Keys.Space:
  //        {
  //          SetDownState(CellManager.Grid.Col, CellManager.Grid.Row, CellManager.Grid.CurrentDataColIndex, CellManager.Grid.CurrentDataRowIndex, false);
  //          e.Handled = true;

  //          PropertyAxisBar propAxisBar;
  //          DataAxisGridListItemBar listItemBar;
  //          CellManager.AxisObjectsByDataColRowIndex(
  //            CellManager.Grid.CurrentDataColIndex, CellManager.Grid.CurrentDataRowIndex, 
  //            out propAxisBar, out listItemBar);

  //          var evArg = new DataAxisGridDataCellEventArgs(CellManager.Grid.Col, CellManager.Grid.Row,
  //            CellManager.Grid.CurrentDataColIndex, CellManager.Grid.CurrentDataRowIndex, Rectangle.Empty, propAxisBar, listItemBar, CellManager);
  //          CellManager.Grid.OnDataCellClick(evArg);
  //          if (!evArg.Handled)
  //          {
  //            bool canModify = CellManager.CanModify(propAxisBar, listItemBar);
  //            if (canModify)
  //              Toggle(CellManager.Grid.CurrentDataColIndex, CellManager.Grid.CurrentDataRowIndex);
  //          }
  //          return;
  //        }
  //    }
  //  }

  //  public virtual void OnMouseDown(BaseGridCellMouseEventArgs e)
  //  {
  //    //baseOnMouseDown(e);
  //    DownState = true;
  //  }

  //  public virtual void OnMouseUp(BaseGridCellMouseEventArgs e)
  //  {
  //    if ((e.InCellX >= 0) &&
  //        (e.InCellY >= 0) &&
  //        (e.InCellX < e.CellRect.Width) &&
  //        (e.InCellY < e.CellRect.Height) &&
  //        !CellManager.ReadOnly)
  //    {
  //      bool canModify = CellManager.CanModify(e.AreaColIndex, e.AreaRowIndex);
  //      if (canModify)
  //        Toggle(e.AreaColIndex, e.AreaRowIndex);
  //    }
  //    //????????base.OnMouseUp(e);
  //    SetDownState(e.ColIndex, e.RowIndex, e.AreaColIndex, e.AreaRowIndex, false);
  //  }

  //  protected internal virtual void OnMouseEnter(BaseGridCellEnterEventArgs e)
  //  {
  //    CellManager.Grid.InvalidateCell(e.ColIndex, e.RowIndex);
  //    //?????????base.OnMouseEnter(e);
  //  }

  //  protected internal virtual void OnMouseLeave(BaseGridCellLeaveEventArgs e)
  //  {
  //    CellManager.Grid.InvalidateCell(e.ColIndex, e.RowIndex);
  //    //?????????base.OnMouseLeave(e);
  //  }
  //  #endregion 
  //}

}
