﻿//------------------------------------------------------------------------------
// <copyright file=”BaseEditBox.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Design;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{


  /// <summary>
  /// Provides the base class for a <see cref = "BaseTextBoxEh" /> and <see cref = "DateTimeBoxEh" /> 
  /// control.
  /// </summary>
  [DesignerCategory("Code")]
  [Designer("EhLib.WinForms.Design.BaseEditBoxDesigner" + EhLibUtils.EhLibDesignDesignerVersionInfo)]
  [ToolboxItem(false)]
  public class BaseEditBoxEh : ContainerControl, IEditItemOwner, ISupportInitialize
  {

    #region internal fields
    internal Control EditControl;
    //private EditItem inEditControl;

    private BoundLabel boundLabel;

    //private Padding defaultPadding = new Padding(0, 0, 0, 0);
    //private BorderStyle borderStyle = BorderStyle.Fixed3D;
    private bool mouseOver;
    private int requestedHeight;
    private bool internalHeightAdjust;
    private bool initializing;
    private bool backColorStored;
    private EditButton editButton;
    private readonly ObservableCollection<EditItem> inEditControls;
    private readonly EditBoxBorder border;

    #endregion internal fields

    #region constructor
    public BaseEditBoxEh()
    {
      initializing = true;
      try

      {
        InitData();
        EditControl.Parent = this;
        TabStop = true;
        border = new EditBoxBorder();
        border.BorderStateChanged += BorderStateChanged;
        inEditControls = new ObservableCollectioEh<EditItem>();
        inEditControls.CollectionChanged += InEditControls_CollectionChanged;
        InitEditButton();
      }
      finally
      {
        initializing = false;
      }
      //System.Diagnostics.Trace.WriteLine("BaseEditBox's constructor is called.");
    }

    private void InitData()
    {
      EditControl = CreateEditControl();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        EditControl.Dispose();
        //if (inEditControl != null)
        //  inEditControl.Dispose();
        if (BoundLabel != null)
          BoundLabel.Dispose();
        //if (EditButtonAccessible())
        if (editButton != null)
        {
          editButton.DisconnectFromEditor();
          //TODO: editButton.RemoveOwner();
          //editButton.EditItemChanged -= EditItemChanged;
          //editButton.DefaultVisibleStateRequested -= EditButtonDefaultVisibleStateRequested;
          if (editButton.Owner == this)
          {
            editButton.Owner = null;
            editButton.Dispose();
          }
        }

        for (int i = InEditControls.Count - 1; i >= 0; i--)
        {
          EditItem item = InEditControls[i];
          if (item.Owner == this)
            item.Dispose();
        }
      }

      base.Dispose(disposing);
    }
    #endregion

    #region design-time properties
    public override Color BackColor
    {
      get
      {
        if (ShouldSerializeBackColor())
        {
          return base.BackColor;
        }
        else if (ReadOnly)
        {
          return SystemColors.Control;
        }
        else
        {
          return SystemColors.Window;
        }
      }
      set
      {
        base.BackColor = value;
        backColorStored = true;
      }
    }

    /// <summary> 
    /// Gets or sets a value indicating whether the text may only be changed by the
    /// use of the up or down buttons.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1716:IdentifiersShouldNotMatchKeywords", MessageId = "ReadOnly")]
    [DefaultValue(false)]
    [RefreshProperties(RefreshProperties.Repaint)]
    public virtual bool ReadOnly
    {
      get; set;
    }

    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
    //[Editor("EhLib. Design.InEditControlEditor" + EhLibUtils.EhLibDesignDesignerVersionInfo, "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    //public EditItem EditItem
    //{
    //  get
    //  {
    //    return inEditControl;
    //  }
    //  set
    //  {
    //    if (inEditControl != value)
    //    {
    //      EditItem oldInEditControl = inEditControl;

    //      inEditControl = value;

    //      if (oldInEditControl != null)
    //      {
    //        oldInEditControl.InEditWinControl.Parent = null;
    //        oldInEditControl.EditControl = null;
    //      }

    //      if (inEditControl != null)
    //        inEditControl.EditControl = this;
    //      //inEditControl.Parent = this;
    //      RealignControls();
    //    }
    //  }
    //}

    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    protected EditButton EditButton
    {
      get
      {
        //if (editButton == null)
        //{
        //  InitEditButton();
        //}

        return editButton;
      }

      set
      {
        SetEditButton(value);
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    [Editor("EhLib.WinForms.Design.InEditControlsCollectionEditor" + EhLibUtils.EhLibDesignDesignerVersionInfo, "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    public Collection<EditItem> InEditControls
    {
      get { return inEditControls; }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
    [Editor("EhLib.WinForms.Design.BoundLabelEditor" + EhLibUtils.EhLibDesignDesignerVersionInfo, "System.Drawing.Design.UITypeEditor, System.Drawing, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")]
    [DefaultValue(null)]
    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public BoundLabel BoundLabel
    {
      get
      {
        return boundLabel;
      }
      set
      {
        if (boundLabel != value)
        {
          BoundLabel oldBoundLabel = boundLabel;

          boundLabel = value;

          if (oldBoundLabel != null)
          {
            oldBoundLabel.BaseEditBox = null;
            //?oldBoundLabel.Dispose();
          }

          if (boundLabel != null)
          {
            boundLabel.BaseEditBox = this;
            if (!initializing)
              boundLabel.Parent = Parent;
          }

          CheckUpdateBoundLabelControlPosition();
        }
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public EditBoxBorder Border
    {
      get { return border; }
    }

    public override ContextMenuStrip ContextMenuStrip
    {
      get
      {
        return base.ContextMenuStrip;
      }
      set
      {
        base.ContextMenuStrip = value;
        EditControl.ContextMenuStrip = value;
      }
    }

    // Stack overflow
    ///// <summary> 
    ///// Indicates the foreground color for the control.
    ///// </summary>
    //public override Color ForeColor
    //{
    //  get
    //  {
    //    return EditControl.ForeColor;
    //  }
    //  set
    //  {
    //    base.ForeColor = value;
    //    EditControl.ForeColor = value;
    //  }
    //}
    #endregion

    #region run-time properties
    public new string Name
    {
      get
      {
        return base.Name;
      }
      set
      {
        base.Name = value;
        //NameChanged();
      }
    }

    protected override Padding DefaultPadding
    {
      get
      {
        if (Border.Style != ControlBorderStyle.None)
          return Padding.Empty;
        else
          return new Padding(1, 1, 1, 2);
      }
    }

    /// <summary> 
    ///  Deriving classes can override this to configure a default size for their control.
    ///  This is more efficient than setting the size in the control's constructor.
    /// </summary>
    protected override Size DefaultSize
    {
      get
      {
        return new Size(100, PreferredHeight);
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public override bool Focused
    {
      get
      {
        return EditControl.Focused;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    [EditorBrowsable(EditorBrowsableState.Advanced)]
    public virtual int PreferredHeight
    {
      get
      {
        int result = FontHeight;
        if (Border == null || Border.Style != ControlBorderStyle.None)
          result = result + SystemInformation.BorderSize.Height * 4;
        result = result + Padding.Top + Padding.Bottom;
        return result;
      }
    }

    [Browsable(false)]
    public bool MouseOver
    {
      get
      {
        return mouseOver;
      }
      protected set
      {
        if (value != mouseOver)
        {
          mouseOver = value;
          Invalidate();
        }
      }
    }

    [Browsable(false)]
    public virtual bool SupportButtonBorderMerging
    {
      get
      {
        if (Border.Style != ControlBorderStyle.Fixed3D)
          return true;
        else
          return false;
      }
    }

    /// <summary> 
    /// AutoScroll is not relevant to an BaseEditBox
    /// </summary>
    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public override bool AutoScroll
    {
      get
      {
        return false;
      }
      set
      {
        // Don't allow AutoScroll to be set to anything
      }
    }

    /// <summary> 
    /// AutoScrollMargin is not relevant to an BaseEditBox
    /// </summary>
    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    new public Size AutoScrollMargin
    {
      get
      {
        return base.AutoScrollMargin;
      }
      set
      {
        base.AutoScrollMargin = value;
      }
    }

    /// <summary> 
    /// AutoScrollMinSize is not relevant to an BaseEditBox
    /// </summary>
    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    new public Size AutoScrollMinSize
    {
      get
      {
        return base.AutoScrollMinSize;
      }
      set
      {
        base.AutoScrollMinSize = value;
      }
    }

    /// <summary> 
    /// DockPadding is not relevant to BaseEditBox
    /// </summary>
    [Browsable(false)]
    [EditorBrowsable(EditorBrowsableState.Never)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    new public DockPaddingEdges DockPadding
    {
      get
      {
        return base.DockPadding;
      }
    }

    [Browsable(false)]
    public bool Initializing
    {
      get { return initializing; }
    }
    #endregion run-time properties

    #region public methods
    public virtual void BeginInit()
    {
      initializing = true;
    }

    public virtual void EndInit()
    {
      initializing = false;
      CheckUpdateBoundLabelControlPosition();
      RealignControls();
    }

    /// <summary>
    ///  Clears all text from the text box control.
    /// </summary>
    public virtual void Clear()
    {
    }

    /// <summary>
    ///  Copies the current selection in the text box to the Clipboard.
    /// </summary>
    public virtual void Copy()
    {
    }

    /// <summary>
    ///  Moves the current selection in the text box to the Clipboard.
    /// </summary>
    public virtual void Cut()
    {
    }

    /// <summary>
    ///  Replaces the current selection in the text box with the contents of the Clipboard.
    /// </summary>
    public virtual void Paste()
    {
    }

    public virtual void HandleInEditControlDownAction(EditItem inEditControl, DownEventArgs e)
    {
      if (inEditControl.DefaultAction || inEditControl.IsDropDown())
      {
        if (inEditControl.DropDownMenuStrip == null)
          InEditButtonDownDefaultAction(inEditControl, e);
      }
    }

    public virtual void HandleInEditControlClickAction(EditItem inEditControl, InEditControlClickEventArgs e)
    {
      if (inEditControl.DefaultAction)
        InEditButtonClickDefaultAction(inEditControl, e);
    }

    public virtual void InEditButtonDownDefaultAction(EditItem inEditControl, DownEventArgs e)
    {
    }

    public virtual void InEditButtonClickDefaultAction(EditItem inEditControl, InEditControlClickEventArgs e)
    {
      if (inEditControl.DropDownMenuStrip != null)
      {
        EditItemControl winControl = inEditControl.InEditWinControl;
        Point pos = new Point(0, winControl.Height);
        inEditControl.DropDownMenuStrip.Show(winControl, pos);
      }
    }

    public bool ShouldSerializeBackColor()
    {
      return backColorStored;
    }

    public override void ResetBackColor()
    {
      backColorStored = false;
      Invalidate(true);
    }

    public void SetEditButton(EditButton value)
    {
      if (editButton != value)
      {
        SuspendLayout();
        try
        {
          if (editButton != null)
          {
            editButton.DisconnectFromEditor();
            if (editButton.Owner == this)
              editButton.Owner = null;
            //editButton.EditItemChanged -= EditItemChanged;
            //editButton.DefaultVisibleStateRequested -= EditButtonDefaultVisibleStateRequested;
          }

          editButton = value;

          if (editButton != null)
          {
            editButton.ConnectToEditor(this);
            if (editButton.Owner == null)
              editButton.Owner = this;
            //editButton.EditItemChanged += EditItemChanged;
            //editButton.DefaultVisibleStateRequested += EditButtonDefaultVisibleStateRequested;
          }
        }
        finally
        {
          ResumeLayout();
        }
        RealignControls();
      }
    }
    #endregion

    #region internal methos

    //Paddings
    protected override void OnPaddingChanged(EventArgs e)
    {
      base.OnPaddingChanged(e);
      AdjustHeight(false);
      RealignControls();
    }

    /// <summary> 
    /// Due to an error in private Control.ResetPadding(), it doesn't call OnPaddingChanged,
    /// so use our version of ResetPadding()
    /// </summary>
    protected void ResetPadding()
    {
      Padding = DefaultPadding;
    }

    //Other
    public new bool Focus()
    {
      if (!Focused)
        return base.Focus();
      else
        return true;
    }

    private void InEditControls_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
    {
      if (e.Action == NotifyCollectionChangedAction.Remove)
      {
        foreach (EditItem ei in e.OldItems)
        {
          ei.InEditWinControl.Parent = null;
          if (ei.Owner == this)
            ei.Owner = null;
        }
      }

      foreach (EditItem ei in InEditControls)
      {
        ei.EditControl = this;
        if (ei.Owner == null)
          ei.Owner = this;
      }
      RealignControls();
    }

    private void BorderStateChanged(object sender, EventArgs e)
    {
      if (!initializing)
        RealignControls();
    }

    protected override void OnLayout(LayoutEventArgs levent)
    {
      RealignControls();
      base.OnLayout(levent);
    }

    protected override void OnHandleCreated(EventArgs e)
    {
      base.OnHandleCreated(e);
      RealignControls();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
      Rectangle bounds = ClientRectangle;
      base.OnPaint(e);

      if (e == null)
        //nameof is not supported in VS2012
        throw new ArgumentNullException("e");

      using (SolidBrush bkBrush = new SolidBrush(BackColor))
      {
        e.Graphics.FillRectangle(bkBrush, bounds);
      }

      TextBoxState state = EhLibRenderManager.DefaultEhLibRenderManager.TextBoxDrawStyle.GetTextBoxState(mouseOver, ContainsFocus, !Enabled, ReadOnly);
      border.Paint(e.Graphics, bounds, state);
      //EhLibDrawStyle.DefaultTextBoxDrawStyle.DrawTextBoxFrame(e.Graphics, bounds, state, this, BorderStyle);
    }

    protected override void OnParentChanged(EventArgs e)
    {
      base.OnParentChanged(e);
      if (boundLabel != null && !initializing)
        boundLabel.Parent = Parent;
    }

    protected override void OnResize(EventArgs e)
    {
      base.OnResize(e);
      CheckUpdateBoundLabelControlPosition();
      Invalidate(true);
    }

    protected override void OnLocationChanged(EventArgs e)
    {
      base.OnLocationChanged(e);
      CheckUpdateBoundLabelControlPosition();
    }

    protected override void OnVisibleChanged(EventArgs e)
    {
      base.OnVisibleChanged(e);
      if (IsHandleCreated)
        Update();
    }

    protected override void WndProc(ref Message m)
    {
      switch (m.Msg)
      {
        case NativeMethods.WM_SETFOCUS:
          if (EditControl.CanFocus)
          {
            NativeMethods.SetFocus(new HandleRef(EditControl, EditControl.Handle));
          }
          base.WndProc(ref m);
          break;
        case NativeMethods.WM_KILLFOCUS:
          DefWndProc(ref m);
          break;
        default:
          base.WndProc(ref m);
          break;
      }
    }

    protected virtual bool AutoHeight()
    {
      return AutoSize;
    }

    protected override void SetBoundsCore(int x, int y, int width, int height, BoundsSpecified specified)
    {

      if (!internalHeightAdjust && height != Height)
        requestedHeight = height;

      if (AutoHeight())
        height = PreferredHeight;

      base.SetBoundsCore(x, y, width, height, specified);
    }

    protected virtual void RealignControls()
    {
      //if (initializing || !IsHandleCreated) return;
      if (initializing) return;
      if (!IsHandleCreated) return;

      //bool themed = Application.RenderWithVisualStyles;
      List<ControlBounds> rightControlBoundsList = new List<ControlBounds>();
      List<ControlBounds> leftControlBoundsList = new List<ControlBounds>();
      Rectangle clientArea = new Rectangle(Point.Empty, ClientSize);
      ControlBorderStyle borderStyle = Border.Style;
      //int borderFixup = (themed) ? 1 : 0;
      
      int borderWidth = (borderStyle == ControlBorderStyle.None) ? 0 : 2;
      clientArea.Inflate(-borderWidth, -borderWidth);

      if (EditControl != null)
      {
        EditControl.Size = new Size(clientArea.Width, clientArea.Height);
      }

      //Rectangle editControlAreaBound = clientArea;

      //if (inEditControl != null && inEditControl.Visible)
      //{
      //  if (inEditControl.Visible)
      //  {
      //    btnBnds = new ControlBounds
      //    {
      //      Bounds = new Rectangle(0, 0, inEditControl.Width, clientArea.Height),
      //      EditItem = inEditControl
      //    };
      //
      //    btnBndsList.Add(btnBnds);
      //  }
      //  else
      //  {
      //    inEditControl.InEditWinControl.Visible = false;
      //  }
      //}

      foreach(EditItem ei in InEditControls)
      {
        if(ei.Visible)
        {
          ControlBounds btnBnds = new ControlBounds()
          {
            Bounds = new Rectangle(0, 0, ei.Width, clientArea.Height),
            InEditControl = ei
          };
          if (ei.AlignSide == InEditAlignSide.Right)
            rightControlBoundsList.Add(btnBnds);
          else
            leftControlBoundsList.Add(btnBnds);
        }
        else
        {
          ei.InEditWinControl.Visible = false;
        }
      }

      if (EditButtonAccessible() && EditButton.Visible)
      {
        ControlBounds btnBnds = new ControlBounds
        {
          Bounds = new Rectangle(0, 0, EditButton.Width, clientArea.Height),
          InEditControl = EditButton
        };
        if (EditButton.AlignSide == InEditAlignSide.Right)
          rightControlBoundsList.Add(btnBnds);
        else
          leftControlBoundsList.Add(btnBnds);
      }
      else
      {
        if (EditButtonAccessible())
          EditButton.InEditWinControl.Visible = false;
      }

      //Set controls height
      int toSetHeight = clientArea.Height; 
      foreach(ControlBounds b in rightControlBoundsList)
      {
        if (b.InEditControl.MaxHeight < toSetHeight)
          toSetHeight = b.InEditControl.MaxHeight;
      }
      foreach (ControlBounds b in leftControlBoundsList)
      {
        if (b.InEditControl.MaxHeight < toSetHeight)
          toSetHeight = b.InEditControl.MaxHeight;
      }
      //if (toSetHeight > clientArea.Height)
      //  toSetHeight = clientArea.Height;

      //Set LeftAlignSide bounds
      //int leftPos = clientArea.Left;
      for (int i = 0; i < leftControlBoundsList.Count; i++)
      {
        ControlBounds btnBounds = leftControlBoundsList[i];

        btnBounds.Bounds.Y = clientArea.Top;
        btnBounds.Bounds.X = clientArea.X;
        btnBounds.Bounds.Width = btnBounds.InEditControl.Width;
        btnBounds.Bounds.Height = toSetHeight;

        clientArea = EhLibUtils.ChangeRectangle(clientArea, btnBounds.Bounds.Width, 0, -btnBounds.Bounds.Width, 0);

        btnBounds.InEditControl.InEditWinControl.InControlBorderMerging = false;

        btnBounds.InEditControl.InEditWinControl.Bounds = btnBounds.Bounds;
        btnBounds.InEditControl.InEditWinControl.Parent = this;
        btnBounds.InEditControl.InEditWinControl.Visible = true;
      }

      //Set RightAlignSide bounds
      int leftPos = clientArea.Right;
      for (int i = rightControlBoundsList.Count-1; i >= 0; i--)
      {
        ControlBounds btnBounds = rightControlBoundsList[i];

        btnBounds.Bounds.Y = clientArea.Top;
        leftPos = leftPos - btnBounds.Bounds.Width;
        btnBounds.Bounds.X = leftPos;

        if (i == rightControlBoundsList.Count - 1 &&
            SupportButtonBorderMerging &&
            btnBounds.InEditControl.SupportInControlBorderMerging)
        {

          btnBounds.Bounds.X = btnBounds.Bounds.X + borderWidth;
          btnBounds.Bounds.Y = btnBounds.Bounds.Y - borderWidth;
          btnBounds.Bounds.Height = btnBounds.Bounds.Height + borderWidth * 2;
          btnBounds.InEditControl.InEditWinControl.InControlBorderMerging = true;
        }
        else
        {
          btnBounds.InEditControl.InEditWinControl.InControlBorderMerging = false;
          btnBounds.Bounds.Height = toSetHeight;
        }

        btnBounds.InEditControl.InEditWinControl.Bounds = btnBounds.Bounds;
        btnBounds.InEditControl.InEditWinControl.Parent = this;
        btnBounds.InEditControl.InEditWinControl.Visible = true;
      }

      //txtBnds.Width = txtBnds.Width - (clientArea.Right - leftPos);
      //editControlAreaBound.Width = editControlAreaBound.Width - (clientArea.Right - leftPos);
      //SetEditControlBounds(editControlAreaBound);
      clientArea.Width = clientArea.Width - (clientArea.Right - leftPos);
      SetEditControlBounds(clientArea);
    }

    protected virtual void SetEditControlBounds(Rectangle editControlAreaBound)
    {
      Rectangle txtBounds = EhLibUtils.TrimPadding(editControlAreaBound, Padding);
      EditControl.Bounds = txtBounds;
    }

    protected virtual Control CreateEditControl()
    {
      return null;
    }

    protected virtual EditButton CreateDropDownButton()
    {
      return new EditButton();
    }

    public virtual void InitEditButton()
    {
      editButton = CreateDropDownButton();
      if (editButton != null)
      {
        editButton.ConnectToEditor(this);
        editButton.Owner = this;
      }
      //editButton.EditItemChanged += EditItemChanged;
      //editButton.DefaultVisibleStateRequested += EditButtonDefaultVisibleStateRequested;
    }

    private void EditItemChanged(object sender, EventArgs e)
    {
      InEditControlChanged(sender as EditItem);
    }

    internal void InEditControlChanged(EditItem inEditControl)
    {
      RealignControls();
      Invalidate(true);
    }

    //private void EditButtonDefaultVisibleStateRequested(object sender, VisibleStateRequestedEventArgs e)
    //{
    //  e.Visible = EditButtonDefaultVisible();
    //}

    //protected virtual bool EditButtonDefaultVisible()
    //{
    //  return false;
    //}

    protected virtual bool EditButtonAccessible()
    {
      //if (editButton != null || GetEditItemDefaultVisibleState(editButton) == true)
      //  return true;
      //else
      //  return false;
      if (editButton != null)
        return true;
      else
        return false;
    }

    //protected internal virtual bool IsInEditControlDefaultVisible(EditItem inEditControl)
    //{
    //  if (inEditControl == editButton)
    //    return false;
    //  else
    //    return true;
    //}

    protected override void OnMouseEnter(EventArgs e)
    {
      base.OnMouseEnter(e);
      mouseOver = true;
      Invalidate(true);
    }

    protected override void OnMouseLeave(EventArgs e)
    {
      base.OnMouseLeave(e);
      if (ClientRectangle.Contains(PointToClient(MousePosition)))
        return;
      else
      {
        mouseOver = false;
      }
      Invalidate(true);
    }

    protected override void OnLostFocus(EventArgs e)
    {
      base.OnLostFocus(e);
      Invalidate(true);
    }

    protected override void OnGotFocus(EventArgs e)
    {
      base.OnGotFocus(e);
      Invalidate(true);
    }

    protected virtual void AdjustHeight(bool returnIfAnchored)
    {

      // If we're anchored to two opposite sides of the form, don't adjust the size because
      // we'll lose our anchored size by resetting to the requested width.
      //
      if (returnIfAnchored && 
         (Anchor & (AnchorStyles.Top | AnchorStyles.Bottom)) == (AnchorStyles.Top | AnchorStyles.Bottom))
      {
        return;
      }

      int saveHeight = requestedHeight;
      try
      {
        //if (AutoSize && !Multiline)
        if (AutoHeight())
        {
          Height = PreferredHeight;
        }
        else
        {

          //int curHeight = Height;

          //// Changing the font of a multi-line textbox can sometimes cause a painting problem
          //// The only workaround I can find is to size the textbox big enough for the font, and
          //// then restore its correct size.
          ////
          //if (Multiline)
          //{
          //  Height = Math.Max(saveHeight, PreferredHeight + 2); // 2 = fudge factor
          //}

          internalHeightAdjust = true;
          try
          {
            Height = saveHeight;
          }
          finally
          {
            internalHeightAdjust = false;
          }
        }
      }
      finally
      {
        requestedHeight = saveHeight;
      }
    }

    protected internal virtual void OnProcessInEditUpDownButton(UpDownEventArgs e)
    {
    }

    internal void BoundLabelPositionChanged()
    {
    }

    internal void BoundLabelRelativePositionChanged()
    {
      CheckUpdateBoundLabelControlPosition();
    }

    //private void BoundLabelControlSizeChanged(object sender, EventArgs e)
    //{
    //  CheckUpdateBoundLabelControlPosition();
    //}

    internal void CheckUpdateBoundLabelControlPosition()
    {
      if (IsHandleCreated && boundLabel != null)
      {
        Debug.Assert(boundLabel.Parent == Parent, "boundLabel.Parent != Parent");
        Point newPos;
        boundLabel.CalcLabelPosForControl(boundLabel.Width, boundLabel.Height, out newPos);
        SetBoundLabelBounds(newPos.X, newPos.Y, boundLabel.Width, boundLabel.Height);
        //boundLabel.Text = Name;
      }
    }

    internal int GetControlTextBaseLine()
    {
      return FontHeight;
    }

    internal void SetBoundLabelBounds(int x, int y, int width, int height)
    {
      boundLabel.SetBounds(x, y, width, height);
    }

    //internal void SetExternalEditButton(EditButton newEditButton)
    //{
    //  if (editButton != newEditButton)
    //  {
    //    SuspendLayout();
    //    try
    //    {
    //      if (editButton != null)
    //      {
    //        editButton.DisconnectFromEditor();
    //        //editButton.EditItemChanged -= EditItemChanged;
    //        //editButton.DefaultVisibleStateRequested -= EditButtonDefaultVisibleStateRequested;
    //      }

    //      editButton = newEditButton;

    //      if (editButton != null)
    //      {
    //        editButton.ConnectToEditor(this);
    //        //editButton.EditItemChanged += EditItemChanged;
    //        //editButton.DefaultVisibleStateRequested += EditButtonDefaultVisibleStateRequested;
    //      }
    //    }
    //    finally
    //    {
    //      ResumeLayout();
    //    }
    //    RealignControls();
    //  }
    //}

    Font IEditItemOwner.GetDefaultFont()
    {
      return Font;
    }

    void IEditItemOwner.EditItemChanged(EditItem editItem)
    {
      Invalidate(true);
    }

    Color IEditItemOwner.DefaultForeColor()
    {
      return ForeColor;
    }

    void IEditItemOwner.EditItemOwnerChanged(IEditItemOwner oldOwner, IEditItemOwner newOwner)
    {
      RealignControls();
    }

    bool IEditItemOwner.GetDefaultVisibleState(EditItem editItem)
    {
      return GetEditItemDefaultVisibleState(editItem);
    }

    protected virtual bool GetEditItemDefaultVisibleState(EditItem editItem)
    {
      if (editItem == EditButton)
        return false;
      else
        return true;
    }

    #endregion internal methos

    internal class ControlBounds
    {
      //public ControlBounds()
      //{
      //  Bounds = Rectangle.Empty;
      //  Control = null;
      //}
      public Rectangle Bounds;
      public EditItem InEditControl;
    }

  }

  public enum SpacingBound
  {
    NearBound, FarBound
  }

  public enum LabelPosition
  {
    AboveLeft, AboveCenter, AboveRight,
    BelowLeft, BelowCenter, BelowRight,
    LeftTop, LeftTextBaseline, LeftCenter, LeftBottom,
    //- LeftTopFromLabelLeft, LeftCenterFromLabelLeft, LeftBottomFromLabelLeft,
    RightTop, RightTextBaseline, RightCenter, RightBottom
  }

  //  public class BoundLabel : Component
  //  {
  //    private BaseEditBox baseEditBox;
  //    private bool visible = false;
  //    private int spacing = 3;
  //    private int offset = 0;
  //    private bool textStored = false;
  //    private bool foreColorStored = false;
  //    private bool backColorStored = false;
  //    private bool fontStored = false;

  //    private LabelPosition position = LabelPosition.AboveLeft;
  //    private SpacingBound labelSpacingBound = SpacingBound.NearBound;

  //    public BoundLabel(BaseEditBox baseEditBox)
  //    {
  //      this.baseEditBox = baseEditBox;
  //    }

  //    #region properties
  //    public string Text
  //    {
  //      get
  //      {
  //        return baseEditBox.boundLabelControl.Text;
  //      }
  //      set
  //      {
  //        baseEditBox.boundLabelControl.Text = value;
  //        textStored = true;
  //      }
  //    }

  //    public Color ForeColor
  //    {
  //      get
  //      {
  //        return baseEditBox.boundLabelControl.ForeColor;
  //      }
  //      set
  //      {
  //        baseEditBox.boundLabelControl.ForeColor = value;
  //        foreColorStored = true;
  //      }
  //    }

  //    public Font Font
  //    {
  //      get
  //      {
  //        return baseEditBox.boundLabelControl.Font;
  //      }
  //      set
  //      {
  //        baseEditBox.boundLabelControl.Font = value;
  //        fontStored = true;
  //      }
  //    }

  //    public Color BackColor
  //    {
  //      get
  //      {
  //        return baseEditBox.boundLabelControl.BackColor;
  //      }
  //      set
  //      {
  //        baseEditBox.boundLabelControl.BackColor = value;
  //        backColorStored = true;
  //      }
  //    }

  //    [DefaultValue(false)]
  //    public bool Visible
  //    {
  //      get
  //      {
  //        return visible;
  //      }
  //      set
  //      {
  //        if (value != visible)
  //        {
  //          visible = value;
  //          baseEditBox.BoundLabelVisibleChanged();
  //        }
  //      }
  //    }

  //    [DefaultValue(SpacingBound.NearBound)]
  //    public SpacingBound LabelSpacingBound
  //    {
  //      get
  //      {
  //        return labelSpacingBound;
  //      }
  //      set
  //      {
  //        if (value != labelSpacingBound)
  //        {
  //          labelSpacingBound = value;
  //          baseEditBox.BoundLabelPositionChanged();
  //        }
  //      }
  //    }

  //    [DefaultValue(3)]
  //    public int Spacing
  //    {
  //      get
  //      {
  //        return spacing;
  //      }
  //      set
  //      {
  //        if (value != spacing)
  //        {
  //          spacing = value;
  //          baseEditBox.BoundLabelPositionChanged();
  //        }
  //      }
  //    }

  //    [DefaultValue(0)]
  //    public int Offset
  //    {
  //      get
  //      {
  //        return offset;
  //      }
  //      set
  //      {
  //        if (value != offset)
  //        {
  //          offset = value;
  //          baseEditBox.BoundLabelPositionChanged();
  //        }
  //      }
  //    }

  //    [DefaultValue(LabelPosition.AboveLeft)]
  //    public LabelPosition Position
  //    {
  //      get
  //      {
  //        return position;
  //      }
  //      set
  //      {
  //        if (value != position)
  //        {
  //          position = value;
  //          baseEditBox.BoundLabelPositionChanged();
  //        }
  //      }
  //    }
  //    #endregion properties

  //    #region methods
  //    public bool ShouldSerializeText()
  //    {
  //      return textStored;
  //    }

  //    public void ResetText()
  //    {
  //      textStored = false;
  //      baseEditBox.ResetBoundLabelText();
  //    }

  //    internal virtual bool ShouldSerializeForeColor()
  //    {
  //      return foreColorStored;
  //    }

  //    public virtual void ResetForeColor()
  //    {
  //      foreColorStored = false;
  //      baseEditBox.boundLabelControl.ResetForeColor();
  //    }

  //    internal virtual bool ShouldSerializeBackColor()
  //    {
  //      return backColorStored;
  //    }

  //    public virtual void ResetBackColor()
  //    {
  //      backColorStored = false;
  //      baseEditBox.boundLabelControl.ResetBackColor();
  //    }

  //    internal virtual bool ShouldSerializeFont()
  //    {
  //      return fontStored;
  //    }

  //    public virtual void ResetFont()
  //    {
  //      fontStored = false;
  //      baseEditBox.boundLabelControl.ResetFont();
  //    }

  //    internal void CalcLabelPosForControl(int LabelWidth, int LabelHeight, out Point LabelPos)
  //    {
  //      int ExtraSpacing;
  //      LabelPos = new Point(0, 0);

  //      if (LabelSpacingBound == SpacingBound.NearBound)
  //        ExtraSpacing = 0;
  //      else if (Position == LabelPosition.AboveLeft ||
  //               Position == LabelPosition.AboveCenter || 
  //               Position == LabelPosition.AboveRight ||
  //               Position == LabelPosition.BelowLeft || 
  //               Position == LabelPosition.BelowCenter || 
  //               Position == LabelPosition.BelowRight)
  //        ExtraSpacing = LabelHeight;
  //      else
  //        ExtraSpacing = LabelWidth;

  //      if (Position == LabelPosition.AboveLeft)
  //      {
  //        LabelPos.Y = baseEditBox.Top - LabelHeight - Spacing + ExtraSpacing;
  //        LabelPos.X = baseEditBox.Left + Offset;

  //      } else if (Position == LabelPosition.AboveCenter)
  //      {
  //        LabelPos.Y = baseEditBox.Top - LabelHeight - Spacing + ExtraSpacing;
  //        LabelPos.X = baseEditBox.Left + (baseEditBox.Width - LabelWidth) / 2 + Offset;

  //      } else if (Position == LabelPosition.AboveRight)
  //      {
  //        LabelPos.Y = baseEditBox.Top - LabelHeight - Spacing + ExtraSpacing;
  //        LabelPos.X = baseEditBox.Left + baseEditBox.Width - LabelWidth + Offset;

  //      } else if (Position == LabelPosition.BelowLeft)
  //      {
  //        LabelPos.Y = baseEditBox.Top + baseEditBox.Height + Spacing + ExtraSpacing;
  //        LabelPos.X = baseEditBox.Left + Offset;

  //      } else if (Position == LabelPosition.BelowCenter)
  //      {
  //        LabelPos.Y = baseEditBox.Top + baseEditBox.Height + Spacing + ExtraSpacing;
  //        LabelPos.X = baseEditBox.Left + (baseEditBox.Width - LabelWidth) / 2 + Offset;

  //      } else if (Position == LabelPosition.BelowRight)
  //      {
  //        LabelPos.Y = baseEditBox.Top + baseEditBox.Height + Spacing + ExtraSpacing;
  //        LabelPos.X = baseEditBox.Left + baseEditBox.Width  - LabelWidth + Offset;

  //      } else if (Position == LabelPosition.LeftTop)
  //      {
  //        LabelPos.Y = baseEditBox.Top + Offset;
  //        LabelPos.X = baseEditBox.Left - LabelWidth - Spacing + ExtraSpacing;

  //      } else if (Position == LabelPosition.LeftTextBaseline)
  //      {
  //        LabelPos.Y = baseEditBox.Top + baseEditBox.GetControlTextBaseLine() - LabelHeight + Offset;
  //        LabelPos.X = baseEditBox.Left - LabelWidth - Spacing + ExtraSpacing;

  //      } else if (Position == LabelPosition.LeftCenter)
  //      {
  //        LabelPos.Y = baseEditBox.Top + (baseEditBox.Height - LabelHeight) / 2 + Offset;
  //        LabelPos.X = baseEditBox.Left - LabelWidth - Spacing + ExtraSpacing;

  //      } else if (Position == LabelPosition.LeftBottom)
  //      {
  //        LabelPos.Y = baseEditBox.Top + baseEditBox.Height - LabelHeight + Offset;
  //        LabelPos.X = baseEditBox.Left - LabelWidth - Spacing + ExtraSpacing;

  //      } else if (Position == LabelPosition.RightTop)
  //      {
  //        LabelPos.Y = baseEditBox.Top + Offset;
  //        LabelPos.X = baseEditBox.Left + baseEditBox.Width + Spacing + ExtraSpacing;

  //      } else if (Position == LabelPosition.RightTextBaseline)
  //      {
  //        LabelPos.Y = baseEditBox.Top + baseEditBox.GetControlTextBaseLine() - LabelHeight + Offset;
  //        LabelPos.X = baseEditBox.Left + baseEditBox.Width + Spacing + ExtraSpacing;

  //      } else if (Position == LabelPosition.RightCenter)
  //      {
  //        LabelPos.Y = baseEditBox.Top + (baseEditBox.Height - LabelHeight) / 2 + Offset;
  //        LabelPos.X = baseEditBox.Left + baseEditBox.Width + Spacing + ExtraSpacing;

  //      } else if (Position == LabelPosition.RightBottom)
  //      {
  //        LabelPos.Y = baseEditBox.Top + baseEditBox.Height - LabelHeight + Offset;
  //        LabelPos.X = baseEditBox.Left + baseEditBox.Width + Spacing + ExtraSpacing;
  //      }
  //    }

  //  #endregion methods

  //}


  /// <summary>
  /// The label that con be bound to a associated TextBoxEh control. 
  /// BoundLabel maintains a constant location relative to the associated control.
  /// </summary>
  [Designer("EhLib.WinForms.Design.BoundLabelDesigner" + EhLibUtils.EhLibDesignDesignerVersionInfo)]
  [ToolboxItem(false)]
  public class BoundLabel : Label
  {
    internal BaseEditBoxEh BaseEditBox;
    private int spacing = 3;
    private int offset;

    private LabelPosition position = LabelPosition.AboveLeft;
    private SpacingBound labelSpacingBound = SpacingBound.NearBound;
    private bool textStored;

    public BoundLabel()
    {
      InitData();
    }

    private void InitData()
    {
      AutoSize = true;
    }

    #region> properties
    public override string Text
    {
      get
      {
        if (textStored)
          return base.Text;
        else
          return DefaultText();
      }
      set
      {
        textStored = true;
        base.Text = value;
      }
    }

    [DefaultValue(SpacingBound.NearBound)]
    public SpacingBound LabelSpacingBound
    {
      get
      {
        return labelSpacingBound;
      }
      set
      {
        if (value != labelSpacingBound)
        {
          labelSpacingBound = value;
          if (BaseEditBox != null)
            BaseEditBox.BoundLabelRelativePositionChanged();
        }
      }
    }

    [DefaultValue(3)]
    public int Spacing
    {
      get
      {
        return spacing;
      }
      set
      {
        if (value != spacing)
        {
          spacing = value;
          if (BaseEditBox != null)
            BaseEditBox.BoundLabelRelativePositionChanged();
        }
      }
    }

    [DefaultValue(0)]
    public int Offset
    {
      get
      {
        return offset;
      }
      set
      {
        if (value != offset)
        {
          offset = value;
          if (BaseEditBox != null)
            BaseEditBox.BoundLabelRelativePositionChanged();
        }
      }
    }

    [DefaultValue(LabelPosition.AboveLeft)]
    public LabelPosition Position
    {
      get
      {
        return position;
      }
      set
      {
        if (value != position)
        {
          position = value;
          if (BaseEditBox != null)
            BaseEditBox.BoundLabelRelativePositionChanged();
        }
      }
    }
    #endregion< properties

    #region> methods
    internal void CalcLabelPosForControl(int labelWidth, int labelHeight, out Point labelPos)
    {
      int extraSpacing;
      labelPos = new Point(0, 0);

      if (LabelSpacingBound == SpacingBound.NearBound)
        extraSpacing = 0;
      else if (Position == LabelPosition.AboveLeft ||
               Position == LabelPosition.AboveCenter ||
               Position == LabelPosition.AboveRight ||
               Position == LabelPosition.BelowLeft ||
               Position == LabelPosition.BelowCenter ||
               Position == LabelPosition.BelowRight)
        extraSpacing = labelHeight;
      else
        extraSpacing = labelWidth;

      if (Position == LabelPosition.AboveLeft)
      {
        labelPos.Y = BaseEditBox.Top - labelHeight - Spacing + extraSpacing;
        labelPos.X = BaseEditBox.Left + Offset;

      }
      else if (Position == LabelPosition.AboveCenter)
      {
        labelPos.Y = BaseEditBox.Top - labelHeight - Spacing + extraSpacing;
        labelPos.X = BaseEditBox.Left + (BaseEditBox.Width - labelWidth) / 2 + Offset;

      }
      else if (Position == LabelPosition.AboveRight)
      {
        labelPos.Y = BaseEditBox.Top - labelHeight - Spacing + extraSpacing;
        labelPos.X = BaseEditBox.Left + BaseEditBox.Width - labelWidth + Offset;

      }
      else if (Position == LabelPosition.BelowLeft)
      {
        labelPos.Y = BaseEditBox.Top + BaseEditBox.Height + Spacing + extraSpacing;
        labelPos.X = BaseEditBox.Left + Offset;

      }
      else if (Position == LabelPosition.BelowCenter)
      {
        labelPos.Y = BaseEditBox.Top + BaseEditBox.Height + Spacing + extraSpacing;
        labelPos.X = BaseEditBox.Left + (BaseEditBox.Width - labelWidth) / 2 + Offset;

      }
      else if (Position == LabelPosition.BelowRight)
      {
        labelPos.Y = BaseEditBox.Top + BaseEditBox.Height + Spacing + extraSpacing;
        labelPos.X = BaseEditBox.Left + BaseEditBox.Width - labelWidth + Offset;

      }
      else if (Position == LabelPosition.LeftTop)
      {
        labelPos.Y = BaseEditBox.Top + Offset;
        labelPos.X = BaseEditBox.Left - labelWidth - Spacing + extraSpacing;

      }
      else if (Position == LabelPosition.LeftTextBaseline)
      {
        labelPos.Y = BaseEditBox.Top + BaseEditBox.GetControlTextBaseLine() - labelHeight + Offset;
        labelPos.X = BaseEditBox.Left - labelWidth - Spacing + extraSpacing;

      }
      else if (Position == LabelPosition.LeftCenter)
      {
        labelPos.Y = BaseEditBox.Top + (BaseEditBox.Height - labelHeight) / 2 + Offset;
        labelPos.X = BaseEditBox.Left - labelWidth - Spacing + extraSpacing;

      }
      else if (Position == LabelPosition.LeftBottom)
      {
        labelPos.Y = BaseEditBox.Top + BaseEditBox.Height - labelHeight + Offset;
        labelPos.X = BaseEditBox.Left - labelWidth - Spacing + extraSpacing;

      }
      else if (Position == LabelPosition.RightTop)
      {
        labelPos.Y = BaseEditBox.Top + Offset;
        labelPos.X = BaseEditBox.Left + BaseEditBox.Width + Spacing + extraSpacing;

      }
      else if (Position == LabelPosition.RightTextBaseline)
      {
        labelPos.Y = BaseEditBox.Top + BaseEditBox.GetControlTextBaseLine() - labelHeight + Offset;
        labelPos.X = BaseEditBox.Left + BaseEditBox.Width + Spacing + extraSpacing;

      }
      else if (Position == LabelPosition.RightCenter)
      {
        labelPos.Y = BaseEditBox.Top + (BaseEditBox.Height - labelHeight) / 2 + Offset;
        labelPos.X = BaseEditBox.Left + BaseEditBox.Width + Spacing + extraSpacing;

      }
      else if (Position == LabelPosition.RightBottom)
      {
        labelPos.Y = BaseEditBox.Top + BaseEditBox.Height - labelHeight + Offset;
        labelPos.X = BaseEditBox.Left + BaseEditBox.Width + Spacing + extraSpacing;
      }
    }

    protected override void OnResize(EventArgs e)
    {
      base.OnResize(e);
      if (BaseEditBox != null)
        BaseEditBox.BoundLabelRelativePositionChanged();
    }

    protected override void OnLocationChanged(EventArgs e)
    {
      base.OnLocationChanged(e);
      if (BaseEditBox != null)
        BaseEditBox.BoundLabelRelativePositionChanged();
    }

    private string DefaultText()
    {
      if (BaseEditBox != null)
        return BaseEditBox.Name;
      else
        return base.Text;
    }

    public bool ShouldSerializeText()
    {
      return textStored;
    }

    public override void ResetText()
    {
      textStored = false;
      Invalidate();
    }

    #endregion< methods

  }

}
