﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;

namespace EhLib.WinForms
{
  partial class FilterDropDownForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.panelBottom = new System.Windows.Forms.Panel();
      this.bCancel = new System.Windows.Forms.Button();
      this.bOk = new System.Windows.Forms.Button();
      this.panelGrid = new System.Windows.Forms.Panel();
      this.clearSearchButton = new System.Windows.Forms.Button();
      this.searchTextBox = new System.Windows.Forms.TextBox();
      this.valuesDataGrid = new EhLib.WinForms.DataGridEh();
      this.dataGridCheckBoxColumn1 = new EhLib.WinForms.DataGridCheckBoxColumn();
      this.dataGridTextColumn1 = new EhLib.WinForms.DataGridTextColumn();
      this.RowTypeColumn = new EhLib.WinForms.DataGridTextColumn();
      this.panelBottom.SuspendLayout();
      this.panelGrid.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.valuesDataGrid)).BeginInit();
      this.SuspendLayout();
      // 
      // panelBottom
      // 
      this.panelBottom.Controls.Add(this.bCancel);
      this.panelBottom.Controls.Add(this.bOk);
      this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
      this.panelBottom.Location = new System.Drawing.Point(0, 250);
      this.panelBottom.Name = "panelBottom";
      this.panelBottom.Size = new System.Drawing.Size(273, 41);
      this.panelBottom.TabIndex = 1;
      // 
      // bCancel
      // 
      this.bCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.bCancel.Location = new System.Drawing.Point(186, 10);
      this.bCancel.Name = "bCancel";
      this.bCancel.Size = new System.Drawing.Size(75, 23);
      this.bCancel.TabIndex = 1;
      this.bCancel.Text = "Cancel";
      this.bCancel.UseVisualStyleBackColor = true;
      this.bCancel.Click += new System.EventHandler(this.BCancel_Click);
      // 
      // bOk
      // 
      this.bOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.bOk.Location = new System.Drawing.Point(105, 10);
      this.bOk.Name = "bOk";
      this.bOk.Size = new System.Drawing.Size(75, 23);
      this.bOk.TabIndex = 0;
      this.bOk.Text = "Ok";
      this.bOk.UseVisualStyleBackColor = true;
      this.bOk.Click += new System.EventHandler(this.BOk_Click);
      // 
      // panelGrid
      // 
      this.panelGrid.Controls.Add(this.clearSearchButton);
      this.panelGrid.Controls.Add(this.searchTextBox);
      this.panelGrid.Controls.Add(this.valuesDataGrid);
      this.panelGrid.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panelGrid.Location = new System.Drawing.Point(0, 0);
      this.panelGrid.Name = "panelGrid";
      this.panelGrid.Size = new System.Drawing.Size(273, 250);
      this.panelGrid.TabIndex = 1;
      // 
      // clearSearchButton
      // 
      this.clearSearchButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.clearSearchButton.Image = global::EhLib.WinForms.Properties.Resources.SearchBoxCancelFilter;
      this.clearSearchButton.Location = new System.Drawing.Point(239, 9);
      this.clearSearchButton.Name = "clearSearchButton";
      this.clearSearchButton.Size = new System.Drawing.Size(25, 22);
      this.clearSearchButton.TabIndex = 2;
      this.clearSearchButton.UseVisualStyleBackColor = true;
      this.clearSearchButton.Click += new System.EventHandler(this.Button1_Click);
      // 
      // searchTextBox
      // 
      this.searchTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.searchTextBox.Location = new System.Drawing.Point(23, 10);
      this.searchTextBox.Name = "searchTextBox";
      this.searchTextBox.Size = new System.Drawing.Size(212, 20);
      this.searchTextBox.TabIndex = 1;
      this.searchTextBox.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
      this.searchTextBox.Enter += new System.EventHandler(this.TextBox1_Enter);
      this.searchTextBox.Leave += new System.EventHandler(this.TextBox1_Leave);
      // 
      // valuesDataGrid
      // 
      this.valuesDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.valuesDataGrid.AutoSizeColumnOptions.FitToClient = true;
      this.valuesDataGrid.ColumnOptions.AllowMoveColumns = false;
      this.valuesDataGrid.ColumnOptions.AllowResizeColumns = false;
      this.valuesDataGrid.ColumnOptions.AllowShowEditor = false;
      this.valuesDataGrid.Cursor = System.Windows.Forms.Cursors.Default;
      // 
      // 
      // 
      this.valuesDataGrid.IndicatorColumn.Visible = false;
      this.valuesDataGrid.KeyboardOptions.TabKeyAction = EhLib.WinForms.GridKeyboardAction.None;
      this.valuesDataGrid.LineOptions.HorzLines = false;
      this.valuesDataGrid.LineOptions.VertLines = false;
      this.valuesDataGrid.Location = new System.Drawing.Point(23, 36);
      this.valuesDataGrid.Name = "valuesDataGrid";
      // 
      // 
      // 
      this.valuesDataGrid.SearchBox.CheckRowHitSearch += new System.EventHandler<EhLib.WinForms.DataGridSearchBoxCheckRowHitSearchEventArgs>(this.DataGrid1_SearchBox_CheckRowHitSearch);
      this.valuesDataGrid.Selection.KeepSelection = true;
      this.valuesDataGrid.Selection.RowSelect = true;
      this.valuesDataGrid.Size = new System.Drawing.Size(241, 205);
      this.valuesDataGrid.StaticColumns.AddRange(new EhLib.WinForms.PropertyAxisBar[] {
            this.dataGridCheckBoxColumn1,
            this.dataGridTextColumn1,
            this.RowTypeColumn});
      this.valuesDataGrid.TabIndex = 1;
      this.valuesDataGrid.Text = "dataGrid1";
      // 
      // 
      // 
      this.valuesDataGrid.Title.Visible = false;
      this.valuesDataGrid.DataCellMouseDown += new System.EventHandler<EhLib.WinForms.DataGridDataCellMouseEventArgs>(this.DataGrid1_DataCellMouseDown);
      this.valuesDataGrid.RowIsSelectable += new System.EventHandler<EhLib.WinForms.DataGridRowIsSelectableEventArgs>(this.DataGrid1_RowIsSelectable);
      this.valuesDataGrid.SelectionChanged += new System.EventHandler<EhLib.WinForms.DataGridSelectionChangeOperationEventArgs>(this.DataGrid1_SelectionChanged);
      this.valuesDataGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DataGrid1_KeyDown);
      // 
      // dataGridCheckBoxColumn1
      // 
      this.dataGridCheckBoxColumn1.FillWeight = 41F;
      this.dataGridCheckBoxColumn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
      this.dataGridCheckBoxColumn1.Name = "dataGridCheckBoxColumn1";
      this.dataGridCheckBoxColumn1.ReadOnly = true;
      this.dataGridCheckBoxColumn1.Width = 41;
      this.dataGridCheckBoxColumn1.QueryCheckState += new System.EventHandler<EhLib.WinForms.DataGridCheckBoxColumnQueryCheckStateEventArgs>(this.DataGridCheckBoxColumn1_GetCheckState);
      // 
      // dataGridTextColumn1
      // 
      this.dataGridTextColumn1.DataPropertyName = "DisplayValue";
      this.dataGridTextColumn1.FillWeight = 198F;
      this.dataGridTextColumn1.Name = "dataGridTextColumn1";
      // 
      // 
      // 
      this.dataGridTextColumn1.Title.Text = "DisplayValue";
      this.dataGridTextColumn1.Width = 198;
      // 
      // RowTypeColumn
      // 
      this.RowTypeColumn.DataPropertyName = "RowType";
      this.RowTypeColumn.FillWeight = 70F;
      this.RowTypeColumn.Name = "RowTypeColumn";
      // 
      // 
      // 
      this.RowTypeColumn.Title.Text = "RowType";
      this.RowTypeColumn.Visible = false;
      this.RowTypeColumn.Width = 70;
      // 
      // FilterDropDownForm
      // 
      this.AcceptButton = this.bOk;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.CancelButton = this.bCancel;
      this.ClientSize = new System.Drawing.Size(273, 291);
      this.Controls.Add(this.panelGrid);
      this.Controls.Add(this.panelBottom);
      this.Name = "FilterDropDownForm";
      this.Text = "FilterDropDownForm";
      this.Controls.SetChildIndex(this.panelBottom, 0);
      this.Controls.SetChildIndex(this.panelGrid, 0);
      this.panelBottom.ResumeLayout(false);
      this.panelGrid.ResumeLayout(false);
      this.panelGrid.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.valuesDataGrid)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion
    private DataGridCheckBoxColumn dataGridCheckBoxColumn1;
    private DataGridTextColumn dataGridTextColumn1;
    private DataGridTextColumn RowTypeColumn;
    protected System.Windows.Forms.TextBox searchTextBox;
    protected System.Windows.Forms.Button clearSearchButton;
    protected System.Windows.Forms.Button bCancel;
    protected System.Windows.Forms.Button bOk;
    protected System.Windows.Forms.Panel panelGrid;
    protected System.Windows.Forms.Panel panelBottom;
    private DataGridEh valuesDataGrid;
  }
}