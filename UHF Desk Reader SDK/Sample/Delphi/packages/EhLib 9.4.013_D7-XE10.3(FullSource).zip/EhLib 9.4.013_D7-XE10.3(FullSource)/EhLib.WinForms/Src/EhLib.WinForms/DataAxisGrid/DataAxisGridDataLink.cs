﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  /// <summary>
  /// Maintains the interaction between the grid and the data source.
  /// </summary>
  public class DataAxisGridDataLink
  {
    #region GridDataLink privates
    private readonly DataAxisGrid grid;
    private readonly ListChangedEventHandler listChangedHandler;
    private readonly EventHandler positionChangedHandler;

    private object dataSource;
    private string dataMember;
    private CurrencyManager currencyManager;
    private NewRowEditState newCurrentRowState = NewRowEditState.Unchanged;
    private RowEditState currentListItemState;
    private bool currentRowModified;
    private bool editorHasValueToPush;
    #endregion GridDataLink Properties

    public DataAxisGridDataLink(DataAxisGrid grid)
    {
      this.grid = grid;
      listChangedHandler = CurrencyManagerListChanged;
      positionChangedHandler = CurrencyManagerPositionChanged;
      EditorHasValueToPush = false;
    }

    #region properties
    [Browsable(false)]
    public DataAxisGrid Grid
    {
      get { return grid; }
    }

    /// <summary>
    /// Gets a value indicating whether this <see cref="DataAxisGridDataLink"/> is active.
    /// </summary>
    /// <remarks>
    /// DataLink is active when data source is connected and is in a consistent state for reading data from it.
    /// </remarks>
    public bool Active
    {
      get { return (CurrencyManager != null); }
    }

    /// <summary>Gets a value indicating whether DataSource allows to add items.</summary>
    public bool AllowAdd
    {
      get
      {
        var bList = List as IBindingList;

        if ((bList != null) &&
            bList.AllowNew &&
            bList.SupportsChangeNotification &&
            (List != null) &&
            !List.IsReadOnly &&
            !List.IsFixedSize
        )
          return true;
        else
          return false;
      }
    }

    /// <summary>Gets a value indicating whether DataSource allows to edit items.</summary>
    public bool AllowEdit
    {
      get
      {
        var bList = List as IBindingList;

        if ((bList != null) &&
            bList.AllowEdit &&
            (List != null) &&
            !List.IsReadOnly
        )
          return true;
        else
          return false;
      }
    }

    /// <summary>Gets a value indicating whether DataSource allows to delete items.</summary>
    public bool AllowRemove
    {
      get
      {
        var bList = List as IBindingList;

        if ((bList != null) &&
            bList.AllowRemove &&
            bList.SupportsChangeNotification &&
            (List != null) &&
            !List.IsReadOnly &&
            !List.IsFixedSize
        )
          return true;
        else
          return false;
      }
    }

    /// <summary>Gets the edit state of the current list item the grid.</summary>
    public RowEditState CurrentListItemState
    {
      get
      {
        return currentListItemState;
      }

      private set
      {
        if (value != currentListItemState)
        {
          currentListItemState = value;
          OnCurrentListItemStateChanged();
        }
      }
    }

    public bool CurrentRowModified
    {
      get
      {
        return currentRowModified;
      }

      private set
      {
        if (value != currentRowModified)
        {
          currentRowModified = value;
          OnCurrentListItemModifiedStateChanged();
        }
      }
    }

    public bool EditorHasValueToPush
    {
      get
      {
        return editorHasValueToPush;
      }

      private set
      {
        if (value != editorHasValueToPush)
        {
          editorHasValueToPush = value;
          OnEditorHasValueToPushChanged();
        }
      }
    }

    public int Position
    {
      get
      {
        return currencyManager.Position;
      }
      set
      {
        if (currencyManager.Position != value)
        {
          if (CurrentListItemState != RowEditState.Browse)
          {
            Grid.PushEditorData();
            if (CurrentRowModified)
            {
              bool succeeded = EndCurrentEdit();
              if (!succeeded) return;
            }
            else
              CancelCurrentEdit();
          }
          currencyManager.Position = value;
        }
      }
    }

    public object DataSource
    {
      get
      {
        return dataSource;
      }
      set
      {
        if (dataSource != value)
        {
          UnwireDataSource();
          dataSource = value;
          WireDataSource();
          TryDataBinding();
        }
      }
    }

    public string DataMember
    {
      get
      {
        return dataMember;
      }
      set
      {
        if (dataMember != value)
        {
          dataMember = value;
          TryDataBinding();
        }
      }
    }

    public CurrencyManager CurrencyManager
    {
      get
      {
        return currencyManager;
      }
    }

    /// <summary>
    /// Gets the list for data source.
    /// </summary>
    public IList List
    {
      get
      {
        if (currencyManager != null)
        {
          return currencyManager.List;
        }
        else
        {
          return null;
        }
      }
    }

    /// <summary>
    /// Gets whether the DataSource list supports sorting.
    /// </summary>
    public bool SupportsSorting
    {
      get
      {
        IBindingList bList = null;

        if (CurrencyManager != null)
          bList = CurrencyManager.List as IBindingList;

        if (bList != null && bList.SupportsSorting)
          return true;
        else
          return false;
      }
    }

    /// <summary>
    /// Gets a value indicating whether the data source supports advanced sorting.
    /// </summary>
    /// <remarks>
    /// Advanced sorting refers to the ability to sort by multiple columns.
    /// </remarks>
    public bool SupportsAdvancedSorting
    {
      get
      {
        IBindingList bList = null;
        IBindingListView bListView = null;

        if (CurrencyManager != null)
          bList = CurrencyManager.List as IBindingList;

        if (bList != null)
          bListView = bList as IBindingListView;

        if (bListView != null && bListView.SupportsAdvancedSorting)
          return true;
        else
          return false;
      }
    }

    /// <summary>
    /// Gets a value indicating whether the data source supports functionality 
    /// to commit or rollback changes to an list item object.
    /// </summary>
    public bool SupportsEditMode
    {
      get
      {
        bool result = currencyManager.Current is IEditableObject;
        return result;
      }
    }
    #endregion properties

    #region public methods
    public void SetCurrentRowValue(DeepPropertyDescriptor propDescr, object value)
    {
      object srcRow = CurrencyManager.Current;
      propDescr.SetValue(srcRow, value);
      CurrencyManagerListChanged(currencyManager, new ListChangedEventArgs(ListChangedType.ItemChanged, CurrencyManager.Position));
      CurrentRowModified = true;
      EditorHasValueToPush = false;
    }

    public void AddNew()
    {
      if (CurrentListItemState != RowEditState.Edit)
      {
          if (EditorHasValueToPush)
          Grid.HideEditor(true);

        if (CurrentRowModified)
          EndCurrentEdit();
        else
          CancelCurrentEdit();
      }

      newCurrentRowState = NewRowEditState.New;
      currencyManager.AddNew();
      newCurrentRowState = NewRowEditState.Unchanged;
    }

    public void BeginCurrentEdit()
    {
      if (CurrentListItemState == RowEditState.New ||
          CurrentListItemState == RowEditState.Edit)
        return;

      var iEditObj = currencyManager.Current as IEditableObject;
      if (iEditObj != null)
      {
        newCurrentRowState = NewRowEditState.Edit;
        iEditObj.BeginEdit();
        CurrentListItemState = RowEditState.Edit;
        newCurrentRowState = NewRowEditState.Unchanged;
        Grid.InvalidateGrid();
      }
    }

    public void CancelCurrentEdit()
    {
      newCurrentRowState = NewRowEditState.Browse;
      currencyManager.CancelCurrentEdit();
      newCurrentRowState = NewRowEditState.Unchanged;
      CurrentRowModified = false;
      CurrentListItemState = RowEditState.Browse;
      EditorHasValueToPush = false;
      Grid.InvalidateGrid();
    }

    public bool EndCurrentEdit()
    {
      try
      {
        newCurrentRowState = NewRowEditState.Browse;
        currencyManager.EndCurrentEdit();
        newCurrentRowState = NewRowEditState.Unchanged;
      }
      catch (Exception e)
      {
        newCurrentRowState = NewRowEditState.Unchanged;
        if (EhLibUtils.IsCriticalException(e))
        {
          throw;
        }

        DataGridSetDataValueErrorEventArgs evArgs = new DataGridSetDataValueErrorEventArgs(e);
        Grid.OnSetDataValueError(evArgs);
        return false;
      }

      CurrentListItemState = RowEditState.Browse;
      CurrentRowModified = false;
      EditorHasValueToPush = false;
      Grid.InvalidateGrid();
      return true;
    }

    public void CheckBrowseMode()
    {
      if (CurrentListItemState != RowEditState.Browse)
      {
        Grid.PrepareChangeCellPos();
        EndCurrentEdit();
      }
    }

    public int MoveBy(int distance)
    {
      int maxDisc;

      if (distance > 0)
      {
        maxDisc = (currencyManager.Count - Position - 1);
        if (distance > maxDisc)
          distance = maxDisc;
        Position = Position + distance;
        return distance;
      }
      else
      {
        maxDisc = Position;
        if (-distance > maxDisc)
          distance = -maxDisc;
        Position = Position + distance;
        return distance;
      }
    }

    public void DeleteCurrent()
    {
      Grid.DeleteCurrentListItem();
    }

    public void ReloadData(bool reloadPropertiesData)
    {
      if (reloadPropertiesData)
        CurrencyManagerListChanged(currencyManager, new ListChangedEventArgs(ListChangedType.Reset, -1));
      else
        CurrencyManagerListChanged(currencyManager, new ListChangedEventArgs(ListChangedType.Reset, -1));
    }
    #endregion

    #region internal methods
    private void UnwireDataSource()
    {
      var source = dataSource as IComponent;
      if (source != null)
      {
        source.Disposed -= DataSourceDisposed;
      }
    }

    private void WireDataSource()
    {
      var source = this.dataSource as IComponent;
      if (source != null)
      {
        source.Disposed += DataSourceDisposed;
      }
    }

    private void DataSourceDisposed(object sender, EventArgs e)
    {
      Debug.Assert(sender == this.dataSource, "dispose notification for other than our dataSource?");
      DataSource = null;
    }

    internal void TryDataBinding()
    {
      CurrencyManager cm;

      if (DataSource == null || Grid.BindingContext == null)
      {
        cm = null;
      }
      else
      {
        //try
        //{
        cm = (CurrencyManager)Grid.BindingContext[DataSource, DataMember];
        //}
        //catch (System.ArgumentException)
        //{
        //  return;
        //}
      }

      if (currencyManager != cm)
      {
        if (currencyManager != null)
        {
          currencyManager.ListChanged -= listChangedHandler;
          currencyManager.PositionChanged -= positionChangedHandler;
          currencyManager.MetaDataChanged -= CurrencyManager_MetaDataChanged;
        }

        currencyManager = cm;

        if (currencyManager != null)
        {
          currencyManager.ListChanged += listChangedHandler;
          currencyManager.PositionChanged += positionChangedHandler;
          currencyManager.MetaDataChanged += CurrencyManager_MetaDataChanged;
        }

        CurrencyManagerListChanged(currencyManager, new ListChangedEventArgs(ListChangedType.Reset, -1));
      }
    }

    private void CurrencyManager_MetaDataChanged(object sender, EventArgs e)
    {
      Grid.CurrencyManagerMetaDataChanged(sender, e);
    }

    private void CurrencyManagerListChanged(object sender, ListChangedEventArgs e)
    {
      if (newCurrentRowState == NewRowEditState.New)
        CurrentListItemState = RowEditState.New;
      else if (newCurrentRowState == NewRowEditState.Browse)
        CurrentListItemState = RowEditState.Browse;
      else if (newCurrentRowState == NewRowEditState.Edit)
        CurrentListItemState = RowEditState.Edit;

      if (e.ListChangedType == ListChangedType.Reset)
        TryDataBinding();

      Grid.CurrencyManagerListChanged(sender, e);
    }

    private void CurrencyManagerPositionChanged(object sender, EventArgs e)
    {
      Grid.CurrencyManagerPositionChanged(sender, e);
    }

    public bool CheckSupportsEditMode(out IEditableObject editableObject)
    {
      editableObject = currencyManager.Current as IEditableObject;
      return (editableObject != null);
    }

    internal IList GetDataSortDescription()
    {
      IBindingList bList = null;
      IBindingListView bListView = null;
      IList res;
      ListSortDescription lsDesc;

      if (Grid.CurrencyManager != null)
        bList = Grid.CurrencyManager.List as IBindingList;

      if (bList != null)
        bListView = bList as IBindingListView;

      if (bList == null || !bList.SupportsSorting || !bList.IsSorted)
      {
        //res = new List<ListSortDescription>();
        res = null;
      }
      else if (bList.SortProperty != null)
      {
        res = new List<ListSortDescription>();
        lsDesc = new ListSortDescription(bList.SortProperty, bList.SortDirection);
        res.Add(lsDesc);

      }
      else if (bListView != null)
      {
        res = bListView.SortDescriptions;
      }
      else
      {
        res = null;
      }

      return res;
    }

    internal virtual void Sort(DataGridColumn column, SortOrder sortOrder)
    {
      Debug.Assert(column.IsDataBound, "GridDataLink.Sort(..) column.IsDataBound = false");
      Debug.Assert(List is IBindingList, "GridDataLink.Sort(..) List is not IBindingList");

      IBindingList bndList = ((IBindingList)List);
      if (sortOrder == SortOrder.Ascending)
        bndList.ApplySort(column.PropDescr.ButtomPropDescr, ListSortDirection.Ascending);
      else if (sortOrder == SortOrder.Descending)
        bndList.ApplySort(column.PropDescr.ButtomPropDescr, ListSortDirection.Descending);
      else
        bndList.RemoveSort();
    }

    internal virtual void Sort(DataGridSortCollection sortMarkers)
    {
      Debug.Assert(SupportsSorting, "GridDataLink.Sorting is not Supported");
      if (sortMarkers.Count > 1)
        Debug.Assert(SupportsAdvancedSorting, "GridDataLink Sorting by multiple columns are not Supported");

      IBindingListView bListView = (IBindingListView)List;

      if (SupportsAdvancedSorting)
      {
        //ListSortDescriptionCollection sorts = new ListSortDescriptionCollection();
        List<ListSortDescription> sdList = new List<ListSortDescription>();

        foreach (DataGridSortItem sni in sortMarkers)
        {
          ListSortDescription sd = new ListSortDescription(sni.Column.PropDescr.ButtomPropDescr, sni.SortDirection);
          sdList.Add(sd);
        }
        bListView.ApplySort(new ListSortDescriptionCollection(sdList.ToArray()));
      }
    }

    internal void EditorValueChanged()
    {
      if (EditorHasValueToPush == false)
      {
        Grid.InvalidateGrid();
        EditorHasValueToPush = true;
      }
      if (SupportsEditMode && CurrentListItemState == RowEditState.Browse)
        BeginCurrentEdit();
    }

    internal void EditorClosed()
    {
      if (EditorHasValueToPush == true)
      {
        EditorHasValueToPush = false;
        Grid.InvalidateGrid();
      }
    }

    private void OnCurrentListItemStateChanged()
    {
      Grid.OnCurrentListItemStateChanged();
    }

    private void OnCurrentListItemModifiedStateChanged()
    {
      Grid.OnCurrentListItemModifiedStateChanged();
    }

    private void OnEditorHasValueToPushChanged()
    {
      Grid.OnEditorHasValueToPushChanged();
    }

    internal string GetRowError(int rowIndex)
    {
      IDataErrorInfo errInfo = null;
      try
      {
        errInfo = CurrencyManager.List[rowIndex] as IDataErrorInfo;
      }
      catch (Exception exception)
      {
        if (EhLibUtils.IsCriticalException(exception) && !(exception is IndexOutOfRangeException))
        {
          throw;
        }
        //DataGridViewDataErrorEventArgs dgvdee = new DataGridViewDataErrorEventArgs(exception, -1 /*columnIndex*/, rowIndex,
        //                                                                           DataGridViewDataErrorContexts.Display);
        //owner.OnDataErrorInternal(dgvdee);
        //if (dgvdee.ThrowException)
        //{
        //  throw dgvdee.Exception;
        //}
      }

      if (errInfo != null)
      {
        return errInfo.Error;
      }
      else
      {
        return String.Empty;
      }
    }
    #endregion
  }
}
