﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;

namespace EhLib.WinForms
{

  /// <summary>
  /// Class for DataGridEh.TreeViewArea property. Defines properties and events to 
  /// show and react mouse click on tree node sign in the DataGridEh cell.
  /// </summary>
  [DesignerCategory("Code")]
  [ToolboxItem(false)]
  [DesignTimeVisible(false)]
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridTreeViewArea : Component
  {
    #region private consts
    //private static readonly object EventKeyExpandedStateNeeded = new object();
    //private static readonly object EventKeyLevelNeeded = new object();
    //private static readonly object EventKeyHasChildrenNeeded = new object();
    //private static readonly object EventKeyParentNeeded = new object();
    private static readonly object EventKeyExpandedStateSet = new object();
    private static readonly object EventKeyTreeNodeStateNeeded = new object();
    //private static readonly object EventKeyCollapseStateSet = new object();
    private static readonly object EventKeyTreeNodeSignPaint = new object();
    private static readonly object EventKeyTreeNodeAreaPaint = new object();
    #endregion

    #region privates
    private int levelIndent = 16;
    private TreeNodeStateRenderer nodeStateRenderer;
    #endregion

    public DataGridTreeViewArea(DataGridEh grid)
    {
      Grid = grid;
    }

    #region run-time properties
    [Browsable(false)]
    public DataGridEh Grid
    {
      get;
      internal set;
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public TreeNodeStateRenderer NodeStateRenderer
    {
      get
      {
        if (nodeStateRenderer == null)
          return Grid.DrawStyle.TreeNodeStateRenderer;
        else
          return nodeStateRenderer;
      }
      set
      {
        if (nodeStateRenderer != value)
        {
          nodeStateRenderer = value;
          Grid.Invalidate();
        }
      }
    }
    #endregion

    #region design-time properties
    [DefaultValue(false)]
    public bool Visible { get; set; }

    [DefaultValue(false)]
    public bool HighlightSelection { get; set; }

    [DefaultValue(16)]
    public int LevelIndent
    {
      get
      {
        return levelIndent;
      }
      set
      {
        if (levelIndent != value)
        {
          levelIndent = value;
          Grid.UpdateColumnsList();
        }
      }
    }
    #endregion

    #region events
    //public event EventHandler<EventArgs> ExpandedStateNeeded
    //{
    //  add
    //  {
    //    Events.AddHandler(EventKeyExpandedStateNeeded, value);
    //  }
    //  remove
    //  {
    //    Events.RemoveHandler(EventKeyExpandedStateNeeded, value);
    //  }
    //}

    //public event EventHandler<DataGridTreeViewAreaLevelNeededEventArgs> LevelNeeded
    //{
    //  add
    //  {
    //    Events.AddHandler(EventKeyLevelNeeded, value);
    //  }
    //  remove
    //  {
    //    Events.RemoveHandler(EventKeyLevelNeeded, value);
    //  }
    //}

    //public event EventHandler<EventArgs> HasChildrenNeeded
    //{
    //  add
    //  {
    //    Events.AddHandler(EventKeyHasChildrenNeeded, value);
    //  }
    //  remove
    //  {
    //    Events.RemoveHandler(EventKeyHasChildrenNeeded, value);
    //  }
    //}

    //public event EventHandler<EventArgs> ParentNeeded
    //{
    //  add
    //  {
    //    Events.AddHandler(EventKeyParentNeeded, value);
    //  }
    //  remove
    //  {
    //    Events.RemoveHandler(EventKeyParentNeeded, value);
    //  }
    //}

    public event EventHandler<DataGridTreeViewNodeExpandedStateSetEventArgs> ExpandedStateSet
    {
      add
      {
        Events.AddHandler(EventKeyExpandedStateSet, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyExpandedStateSet, value);
      }
    }

    //public event EventHandler<EventArgs> CollapseStateSet
    //{
    //  add
    //  {
    //    Events.AddHandler(EventKeyCollapseStateSet, value);
    //  }
    //  remove
    //  {
    //    Events.RemoveHandler(EventKeyCollapseStateSet, value);
    //  }
    //}

    public event EventHandler<DataGridTreeViewNodeStateNeededEventArgs> NodeStateNeeded
    {
      add
      {
        Events.AddHandler(EventKeyTreeNodeStateNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyTreeNodeStateNeeded, value);
      }
    }
    #endregion

    #region methods
    public virtual void PaintTreeArea(DataGridDataCellPaintEventArgs e)
    {
      Rectangle treeViewRect = e.CellArgs.CellRect;
      //int treeNodeAreaWidth = GetTreeNodeAreaWidth(e.Column, e.Row);
      DataGridTreeViewNodeStateNeededEventArgs nodeState = GetTreeNodeState(e.Row);
      treeViewRect.Width = nodeState.NodeLevel * LevelIndent;
      DataGridEh grid = e.Column.Grid;

      e.CellArgs.Graphics.FillRectangle(new SolidBrush(Grid.BackColor), treeViewRect);

      if (nodeState.HasChildren)
      {
        Rectangle treeSignRect = treeViewRect;
        treeSignRect.X = treeSignRect.Right - LevelIndent;
        treeSignRect.Width = LevelIndent;

        TreeNodeStateRenderer renderer = NodeStateRenderer;
        renderer.DrawNodeStateGlyph(e.CellArgs.Graphics, treeSignRect, nodeState.Expanded, false);
      }
    }

    protected virtual void ProcessPaint(DataGridDataCellPaintEventArgs e)
    {
      HandlePaintEvent(e);
      if (!e.Handled)
        OnPaint(e);
    }

    protected virtual void HandlePaintEvent(DataGridDataCellPaintEventArgs e)
    {
      //var eh = this.Events[EventKeyPaint] as EventHandler<DataGridDataCellPaintEventArgs>;
      //if (eh != null)
      //  eh(this, (DataGridDataCellPaintEventArgs)e);
    }

    private void OnPaint(DataGridDataCellPaintEventArgs e)
    {
      Rectangle treeAreaBounds = e.CellArgs.CellRect;
      treeAreaBounds.Width = e.CellArgs.CustomRect.Left - e.CellArgs.CellRect.Left;

      e.CellArgs.Graphics.FillRectangle(SystemBrushes.Window, treeAreaBounds);
    }

    public int GetTreeNodeAreaWidth(DataGridColumn column, DataGridRow row)
    {
      DataGridTreeViewNodeStateNeededEventArgs nodeState = GetTreeNodeState(row);
      return nodeState.NodeLevel * LevelIndent;
    }

    public bool TreeNodeHasChildren(DataGridColumn column, DataGridRow row)
    {
      return false;
    }

    //public int GetTreeNodeLevel(DataGridColumn column, DataGridRow row)
    //{
    //  var e = new DataGridTreeViewAreaLevelNeededEventArgs(column, row);
    //  var eh = this.Events[EventKeyLevelNeeded] as EventHandler<DataGridTreeViewAreaLevelNeededEventArgs>;

    //  if (eh != null)
    //    eh(this, e);
      
    //  return e.NodeLevel;
    //}

    public DataGridTreeViewNodeStateNeededEventArgs GetTreeNodeState(DataGridRow row)
    {
      var e = new DataGridTreeViewNodeStateNeededEventArgs(row);

      if (e.Row != null)
      {
        var eh = this.Events[EventKeyTreeNodeStateNeeded] as EventHandler<DataGridTreeViewNodeStateNeededEventArgs>;

        if (eh != null)
          eh(this, e);
      }
      return e;
    }

    public void SetTreeNodeExpandedState(DataGridRow row, bool expanded)
    {
      long savedScrollPos = Grid.VertScrollBar.ScrollPos;
      List<object> parentList = new List<object>();
      if (!expanded && Grid.CurrentRow != null)
      {
        FillParentList(parentList, Grid.CurrentRow);
      }

      var e = new DataGridTreeViewNodeExpandedStateSetEventArgs(row, expanded);
      OnExpandedStateSet(e);

      if (!expanded && Grid.CurrentRow != null)
      {
        for (int i = 0; i < parentList.Count; i++)
        {
          int rowVisibleIndex = Grid.VisibleRows.IndexOfSourceItem(parentList[i]);
          if (rowVisibleIndex >= 0)
          {
            Grid.CurrentRowIndex = rowVisibleIndex;
            break;
          }
        }
      }

      Grid.VertScrollBar.ScrollPos = savedScrollPos;
    }

    protected void FillParentList(List<object> parentList, DataGridRow row)
    {
      object curNode = row.SourceItem;
      while (row != null)
      {
        parentList.Add(row.SourceItem);
        DataGridTreeViewNodeStateNeededEventArgs nodeState = GetTreeNodeState(row);
        if (nodeState.ParentItem != null)
        {
          int parentRowIndex = Grid.Rows.IndexOfSourceItem(nodeState.ParentItem);
          if (parentRowIndex >= 0)
          {
            row = Grid.Rows[parentRowIndex];
          }
          else
          {
            row = null;
          }
        }
        else
        {
          row = null;
        }
      }
    }

    protected virtual void OnExpandedStateSet(DataGridTreeViewNodeExpandedStateSetEventArgs e)
    {
      var eh = this.Events[EventKeyExpandedStateSet] as EventHandler<DataGridTreeViewNodeExpandedStateSetEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    #endregion

  }

  public class DataGridTreeViewAreaLevelNeededEventArgs : DataGridColumnRowEventArgs
  {
    public DataGridTreeViewAreaLevelNeededEventArgs(DataGridColumn column, DataGridRow row)
      : base(column, row)
    {
      NodeLevel = 0;
    }

    public int NodeLevel { get; set; }
  }

  public class DataGridTreeViewNodeStateNeededEventArgs : EventArgs
  {
    public DataGridTreeViewNodeStateNeededEventArgs(DataGridRow row)
    {
      Row = row;
      NodeLevel = 0;
      HasChildren = false;
      Expanded = false;
      ParentItem = null;
    }

    public DataGridRow Row
    {
      get;
      internal set;
    }

    public int NodeLevel { get; set; }
    public bool HasChildren { get; set; }
    public bool Expanded { get; set; }
    public object ParentItem { get; set; }
  }

  public class DataGridTreeViewNodeExpandedStateSetEventArgs : EventArgs
  {
    public DataGridTreeViewNodeExpandedStateSetEventArgs(DataGridRow row, bool expanded)
    {
      Expanded = expanded;
      Row = row;
    }

    public bool Expanded
    {
      get;
      internal set;
    }

    public DataGridRow Row
    {
      get;
      internal set;
    }
  }

}