﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of cell manager control that displays empty uneditable cell in the grid.
  /// </summary>
  //[DataAxisGridDataCellDesignTimeVisible(true)]
  //[ToolboxItem(true)]
  public class BlankDataCellManager : BaseDataCellManager, ICellBackFillerOwner
  {

    #region private consts
    protected static readonly object EventKeyPaint = new object();
    protected static readonly object EventKeyCustomAreaPaint = new object();
    protected static readonly object EventKeyClientAreaNeeded = new object();
    protected static readonly object EventKeyDisplayValueNeeded = new object();
    #endregion

    #region privates
    private readonly CellBackFiller backFiller;
    #endregion

    #region constructor
    public BlankDataCellManager()
    {
      backFiller = new CellBackFiller(this);
    }
    #endregion

    #region properties
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public CellBackFiller BackFiller
    {
      get
      {
        return backFiller;
      }
    }
    #endregion

    #region public methods
    //public override string GetDisplayText(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    //{
    //  return null;
    //}

    protected internal override void OnDisplayValueNeeded(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      e.DisplayValue = null;
    }

    public override string GetTypeNameAbbr()
    {
      return "Blnk";
    }
    #endregion

    #region internal methods
    //ICellBackFillerOwner
    void ICellBackFillerOwner.BackFillerChanged(CellBackFiller backFiller)
    {
      if (BoundGrid != null)
        BoundGrid.Invalidate();
    }

    Color ICellBackFillerOwner.BackFillerDefaultColor(CellBackFiller backFiller)
    {
      if (BoundGrid != null)
        return BoundGrid.FixedBackFiller.Color;
      else
        return SystemColors.ButtonFace;
    }

    Color ICellBackFillerOwner.BackFillerDefaultSecondColor(CellBackFiller backFiller)
    {
      if (BoundGrid != null)
        return BoundGrid.FixedBackFiller.SecondColor;
      else
        return SystemColors.ButtonFace;
    }

    CellFillStyle ICellBackFillerOwner.BackFillerDefaultFillStyle(CellBackFiller backFiller)
    {
      if (BoundGrid != null)
        return BoundGrid.FixedBackFiller.FillStyle;
      else
        return CellFillStyle.Solid;
    }

    CellInnerBorderStyle ICellBackFillerOwner.BackFillerDefaultInnerBorder(CellBackFiller backFiller)
    {
      if (BoundGrid != null)
        return BoundGrid.FixedBackFiller.InnerBorder;
      else
        return CellInnerBorderStyle.RaisedTopLeft;
    }

    //Other
    protected override void PaintBackground(DataAxisGridDataCellPaintEventArgs e)
    {
      if (!e.IsPaintBackground) return;

      Color backColor = BackFiller.Color;

      BaseGridFillFixedCellEventArgs styledPaintArgs = new BaseGridFillFixedCellEventArgs();

      styledPaintArgs.CellRect = e.CellRect;
      styledPaintArgs.Graphics = e.Graphics;
      styledPaintArgs.IsHot = false;
      styledPaintArgs.IsPressed = false;
      styledPaintArgs.IsSelected = (e.State & BasePaintCellStates.Selected) != 0 || IsSelected(e.Grid, e.AreaColIndex, e.AreaRowIndex);
      styledPaintArgs.BackColor = backColor;
      styledPaintArgs.FillColor = BackFiller.Color;
      styledPaintArgs.SecondFillColor = BackFiller.SecondColor;
      styledPaintArgs.FillStyle = BackFiller.FillStyle;
      styledPaintArgs.InnerBorder = BackFiller.InnerBorder;

      e.Grid.DrawStyle.FillFixedCell(e.Grid, styledPaintArgs);
    }

    protected override void PaintForeground(DataAxisGridDataCellPaintEventArgs e)
    {
      base.PaintForeground(e);
    }

    protected override void HandlePaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = this.Events[EventKeyPaint] as EventHandler<DataAxisGridDataCellPaintEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal override void HandleCustomAreaPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = this.Events[EventKeyCustomAreaPaint] as EventHandler<DataAxisGridDataCellPaintEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected override void HandleClientAreaNeededEvent(DataAxisGridDataCellClientAreaNeededEventArgs e)
    {
      var eh = this.Events[EventKeyClientAreaNeeded] as EventHandler<DataAxisGridDataCellClientAreaNeededEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }

    protected override void HandleDisplayValueNeededEvent(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDisplayValueNeeded] as EventHandler<DataAxisGridDataCellDisplayValueNeededEventArgs>;
      if (eh != null)
        eh(this, e);
      //eh.Invoke()
    }
    #endregion
  }
}
