﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  //public class GridBaseVirtualDataCellEventArgs : HandledEventArgs
  //{

  //  public GridBaseVirtualDataCellEventArgs(DataAxisGridVirtualDataCellEventArgs cellEventArgs)
  //  {
  //    CellEventArgs = cellEventArgs;
  //  }

  //  protected internal DataAxisGridVirtualDataCellEventArgs CellEventArgs { get; set; }
  //}

  //public class DataAxisGridVirtualDataCellEventArgs : HandledEventArgs
  //{
  //  private PropertyAxisBar propAxisBar;
  //  private DataAxisGridListItemBar listItemBar;
  //  private readonly BaseDataCellManager cell;

  //  public DataAxisGridVirtualDataCellEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell)
  //  {
  //    this.propAxisBar = propAxisBar;
  //    this.listItemBar = listItemBar;
  //    this.cell = cell;
  //  }

  //  public PropertyAxisBar PropAxisBar
  //  {
  //    get { return propAxisBar; }
  //  }

  //  public DataAxisGridListItemBar listItemBar
  //  {
  //    get { return listItemBar; }
  //  }

  //  public BaseDataCellManager Cell
  //  {
  //    get { return this.cell; }
  //  }
  //}

  /// <summary>
  /// Event args for some events for the Cell of the DataAxisGrid
  /// like OnDataCellClick, OnDataCellContentClick
  /// </summary>
  public class DataAxisGridDataCellEventArgs : BaseGridCellEventArgs
  {
    private PropertyAxisBar propAxisBar;
    private DataAxisGridListItemBar listItemBar;
    private readonly BaseDataCellManager cell;

    public DataAxisGridDataCellEventArgs(BaseGridControl grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell) :
      base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect)
    {
      this.propAxisBar = propAxisBar;
      this.listItemBar = listItemBar;
      this.cell = cell;
      this.Handled = false;
    }

    public PropertyAxisBar PropAxisBar
    {
      get { return propAxisBar; }
    }

    public DataAxisGridListItemBar ListItemBar
    {
      get { return listItemBar; }
    }

    public BaseDataCellManager Cell
    {
      get { return this.cell; }
    }

    public bool Handled { get; set; }
  }

  /// <summary>
  /// Event args for painting event in the data cell of the DataAxisGrid
  /// Base class for DataGridDataCellPaintEventArgs, DataVertGridDataCellPaintEventArgs classes
  /// </summary>
  public class DataAxisGridDataCellPaintEventArgs : BaseGridCellPaintEventArgs
  {
    private readonly PropertyAxisBar propAxisBar;
    private readonly DataAxisGridListItemBar listItemBar;

    public DataAxisGridDataCellPaintEventArgs(DataAxisGrid grid, BaseGridCellManager cellManager, GraphicsContext gc, int colIndex, int rowIndex,
      Rectangle cellRect, Rectangle cellAreaRect, BasePaintCellStates state, int areaColIndex, int areaRowIndex, Point inCellMousePos,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, DataAxisGridListAxisItemViewState listAxisItemViewState,
      DataAxisGridDataCellFormatParamsNeededEventArgs fe)
      : base(grid, cellManager, gc, colIndex, rowIndex, cellRect, cellAreaRect, state, areaColIndex, areaRowIndex, inCellMousePos)
    {
      this.propAxisBar = propAxisBar;
      this.listItemBar = listItemBar;
      ListAxisItemViewState = listAxisItemViewState;
      IsPaintBackground = true;
      IsPaintForeground = true;
      HorzAlign = fe.HorzAlign;
      VertAlign = fe.VertAlign;
      Font = fe.Font;
      BackColor = fe.BackColor;
      ForeColor = fe.ForeColor;
      Padding = fe.Padding;
      Grid = grid;
    }

    public new DataAxisGrid Grid { get; private set; }

    public DataAxisGridListAxisItemViewState ListAxisItemViewState { get; private set; }

    public PropertyAxisBar PropAxisBar
    {
      get { return this.propAxisBar; }
    }

    public DataAxisGridListItemBar ListItemBar
    {
      get { return this.listItemBar; }
    }

    public int DataColIndex
    {
      get { return this.AreaColIndex; }
    }

    public int DataRowIndex
    {
      get { return this.AreaRowIndex; }
    }

    public Rectangle CustomRect
    {
      get;
      set; 
    }

    public Rectangle ContentRect
    {
      get;
      set;
    }

    public HorizontalAlignment HorzAlign { get; set; }

    public VerticalAlignment VertAlign { get; set; }

    public Font Font { get; set; }

    public Color BackColor { get; set; }

    public Color BackPaintColor { get; set; }

    public Color ForeColor { get; set; }

    public Color ForePaintColor { get; set; }

    public Padding Padding { get; set; }

    public Color BackFilledColor { get; set; }
  }

  /// <summary>
  /// Event args for mouse events in the Cell of the DataAxisGrid
  /// MouseDown, MouseMove, MouseUp, MouseClick
  /// </summary>
  public class DataAxisGridDataCellMouseEventArgs : BaseGridCellMouseEventArgs
  {
    private PropertyAxisBar propAxisBar;
    private DataAxisGridListItemBar listItemBar;

    public DataAxisGridDataCellMouseEventArgs(
      DataAxisGrid grid, BaseGridCellManager cellManager,
      int colIndex, int rowIndex,
      int areaColIndex, int areaRowIndex,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar,
      int inCellX, int inCellY,
      Rectangle cellRect,
      MouseEventArgs e) : base(grid, cellManager, colIndex, rowIndex, areaColIndex, areaRowIndex, inCellX, inCellY, cellRect, e)
    {
      this.propAxisBar = propAxisBar;
      this.listItemBar = listItemBar;
      Grid = grid;
    }

    public DataAxisGridDataCellMouseEventArgs(
      DataAxisGrid grid,
      BaseGridCellManager cellManager,
      BaseGridCellMouseEventArgs baseArgs,
      int areaColIndex, int areaRowIndex,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar) :
        base(grid, cellManager, baseArgs.ColIndex, baseArgs.RowIndex, baseArgs.AreaColIndex, baseArgs.AreaRowIndex,
             baseArgs.InCellX, baseArgs.InCellY, baseArgs.CellRect, baseArgs.GridMouseArgs)
    {
      this.propAxisBar = propAxisBar;
      this.listItemBar = listItemBar;
      Grid = grid;
    }

    public new DataAxisGrid Grid { get; internal set; }

    public PropertyAxisBar PropAxisBar
    {
      get { return this.propAxisBar; }
    }

    public DataAxisGridListItemBar ListItemBar
    {
      get { return this.listItemBar; }
    }

    public Rectangle CustomRect
    {
      get;
      set;
    }

    public Rectangle ClientRect
    {
      get;
      set;
    }

    public Rectangle ContentRect
    {
      get;
      set;
    }

    public new BaseDataCellManager CellManager
    {
      get { return (BaseDataCellManager)base.CellManager; }
    }
  }

  /// <summary>
  /// Event args for mouse enter event in the Cell of the DataAxisGrid
  /// OnMouseEnter
  /// </summary>
  public class DataAxisGridDataCellEnterEventArgs : BaseGridCellEnterEventArgs
  {
    private PropertyAxisBar propAxisBar;
    private DataAxisGridListItemBar listItemBar;
    private readonly BaseDataCellManager cell;

    public DataAxisGridDataCellEnterEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int leaveColIndex, int leaveRowIndex, 
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, leaveColIndex, leaveRowIndex)
    {
      this.propAxisBar = propAxisBar;
      this.listItemBar = listItemBar;
      this.cell = cell;
      Grid = grid as DataAxisGrid;
    }

    public PropertyAxisBar PropAxisBar
    {
      get { return propAxisBar; }
    }

    public DataAxisGridListItemBar ListItemBar
    {
      get { return listItemBar; }
    }

    public BaseDataCellManager Cell
    {
      get { return this.cell; }
    }

    public new DataAxisGrid Grid { get; private set; }
  }

  /// <summary>
  /// Event args for mouse leave event in the Cell of the DataAxisGrid
  /// OnMouseLeave
  /// </summary>
  public class DataAxisGridDataCellLeaveEventArgs : BaseGridCellLeaveEventArgs
  {
    private PropertyAxisBar propAxisBar;
    private DataAxisGridListItemBar listItemBar;
    private readonly BaseDataCellManager cell;

    public DataAxisGridDataCellLeaveEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int enterColIndex, int enterRowIndex,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, enterColIndex, enterRowIndex)
    {
      this.propAxisBar = propAxisBar;
      this.listItemBar = listItemBar;
      this.cell = cell;
    }

    public PropertyAxisBar PropAxisBar
    {
      get { return propAxisBar; }
    }

    public DataAxisGridListItemBar ListItemBar
    {
      get { return listItemBar; }
    }

    public BaseDataCellManager Cell
    {
      get { return this.cell; }
    }
  }

  /// <summary>
  /// Event args for ContentPaint event in BaseDataCellManager component.
  /// </summary>
  public class DataAxisGridDataCellContentPaintEventArgs : HandledEventArgs
  {
    private readonly DataAxisGridDataCellPaintEventArgs parentCellPaintArgs;
    private readonly Rectangle cellContentRect;

    public DataAxisGridDataCellContentPaintEventArgs(DataAxisGridDataCellPaintEventArgs dataCellPaintArgs, Rectangle cellContentRect)
    {
      this.parentCellPaintArgs = dataCellPaintArgs;
      this.cellContentRect = cellContentRect;
    }

    public DataAxisGrid Grid { get { return ParentCellPaintArgs.Grid; } }

    public DataAxisGridDataCellPaintEventArgs ParentCellPaintArgs
    {
      get { return this.parentCellPaintArgs; }
    }

    public Rectangle CellContentRect
    {
      get { return this.cellContentRect; }
    }

    public PropertyAxisBar PropAxisBar
    {
      get { return parentCellPaintArgs.PropAxisBar; }
    }

    public DataAxisGridListItemBar ListItemBar
    {
      get { return parentCellPaintArgs.ListItemBar; }
    }

    public BasePaintCellStates State
    {
      get { return parentCellPaintArgs.State; }
    }

    public GraphicsContext GraphicsContext
    {
      get { return parentCellPaintArgs.GraphicsContext; }
    }

    public Graphics Graphics
    {
      get { return parentCellPaintArgs.Graphics; }
    }

    public int DataColIndex
    {
      get { return parentCellPaintArgs.DataColIndex; }
    }

    public int DataRowIndex
    {
      get { return parentCellPaintArgs.DataRowIndex; }
    }

    public int ColIndex
    {
      get { return parentCellPaintArgs.ColIndex; }
    }

    public int RowIndex
    {
      get { return parentCellPaintArgs.RowIndex; }
    }

    public HorizontalAlignment HorzAlign
    {
      get { return parentCellPaintArgs.HorzAlign; }
      set { parentCellPaintArgs.HorzAlign = value; }
    }

    public VerticalAlignment VertAlign
    {
      get { return parentCellPaintArgs.VertAlign; }
      set { parentCellPaintArgs.VertAlign = value; }
    }

    public Font Font
    {
      get { return parentCellPaintArgs.Font; }
      set { parentCellPaintArgs.Font = value; }
    }

    public Color ForeColor
    {
      get { return parentCellPaintArgs.ForeColor; }
      set { parentCellPaintArgs.ForeColor = value; }
    }

    public Color ForePaintColor
    {
      get { return parentCellPaintArgs.ForePaintColor; }
      set { parentCellPaintArgs.ForePaintColor = value; }
    }

    public Padding Padding
    {
      get { return parentCellPaintArgs.Padding; }
      set { parentCellPaintArgs.Padding = value; }
    }

    internal void PaintContent(DataAxisGridDataCellContentPaintEventArgs cellArgs)
    {
      var dataCellManager = cellArgs.ParentCellPaintArgs.CellManager as BaseDataCellManager;
      if (dataCellManager != null)
        dataCellManager.OnPaintContent(cellArgs);
    }
  }

  /// <summary>
  /// Base class for DataAxisGridDataCellPullValueEventArgs, DataAxisGridDataCellPullValueEventArgs, 
  /// DataAxisGridDataCellParseValueEventArgs, DataAxisGridDataCellToolTipInfoEventArgs classes
  /// </summary>
  public class DataAxisGridDataBarCellEventArgs : EventArgs
  {
    private PropertyAxisBar propAxisBar;
    private DataAxisGridListItemBar listItemBar;
    private readonly BaseDataCellManager cellMan;

    public DataAxisGridDataBarCellEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
    {
      this.propAxisBar = propAxisBar;
      this.listItemBar = listItemBar;
      this.cellMan = cellMan;
      this.Handled = false;
    }

    public PropertyAxisBar PropAxisBar
    {
      get { return propAxisBar; }
    }

    public DataAxisGridListItemBar ListItemBar
    {
      get { return listItemBar; }
    }

    public BaseDataCellManager CellMan
    {
      get { return this.cellMan; }
    }

    public bool Handled { get; set; }
  }

  /// <summary>
  /// Event args for the checkbox status request in the CkeckBoxCell of the DataAxisGrid
  /// </summary>
  public class DataAxisGridCheckBoxQueryDataCellCheckStateEventArgs : HandledEventArgs
  {
    private DataAxisGridListItemBar listItemBar;
    private CheckState checkState;

    public DataAxisGridCheckBoxQueryDataCellCheckStateEventArgs(DataAxisGridListItemBar listItemBar)
    {
      this.listItemBar = listItemBar;
    }

    public DataAxisGridListItemBar ListItemBar
    {
      get { return this.listItemBar; }
      internal set { this.listItemBar = value; }
    }

    public CheckState CheckState
    {
      get { return this.checkState; }
      set { this.checkState = value; }
    }

  }

  /// <summary>
  /// Event args for requesting the data cell format parameters of the DataAxisGrid
  /// </summary>
  public class DataAxisGridDataCellFormatParamsNeededEventArgs : DataAxisGridDataBarCellEventArgs
  {
    public DataAxisGridDataCellFormatParamsNeededEventArgs(DataAxisGrid grid, PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell)
      : base(propAxisBar, listItemBar, cell)
    {
      Grid = grid;
    }

    public DataAxisGrid Grid { get; internal set; }
    public HorizontalAlignment HorzAlign { get; set; }
    public VerticalAlignment VertAlign { get; set; }
    public Font Font { get; set; }
    public Color BackColor { get; set; }
    public Color ForeColor { get; set; }
    public Padding Padding { get; set; }
    //public DataAxisGridDataCellFormatApplying FormatApplying { get; protected set; }
  }

  /// <summary>
  /// Event args for requesting the data cell editor parameters of the DataAxisGrid
  /// </summary>
  public class DataAxisGridDataCellEditorParamsNeededEventArgs : BaseGridCellEditorParamsNeededEventArgs
  {
    private PropertyAxisBar propAxisBar;
    private DataAxisGridListItemBar listItemBar;

    public DataAxisGridDataCellEditorParamsNeededEventArgs(BaseGridControl grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell)
      : base(grid, cell, colIndex, rowIndex, areaColIndex, areaRowIndex)
    {
      this.propAxisBar = propAxisBar;
      this.listItemBar = listItemBar;
    }

    public PropertyAxisBar PropAxisBar
    {
      get { return propAxisBar; }
    }

    public DataAxisGridListItemBar ListItemBar
    {
      get { return listItemBar; }
    }

    public Font Font { get; set; }
    public Color BackColor { get; set; }
    public Color ForeColor { get; set; }
    public Padding Padding { get; set; }

    public virtual void AssignFormatParams(DataAxisGridDataCellFormatParamsNeededEventArgs fe)
    {
      Font = fe.Font;
      Padding = fe.Padding;
    }
    //public bool ReadOnly { get; set; }
    //public bool CanShowEditor { get; set; }
    //public Type EditorType { get; set; }
  }

  /// <summary>
  /// Event args for EditorOccupy event in BaseDataCellManager component.
  /// </summary>
  public class DataAxisGridDataCellEditorOccupyEventArgs : DataAxisGridDataCellEventArgs
  {

    public DataAxisGridDataCellEditorOccupyEventArgs(BaseGridControl grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell, Control editor, object value, bool selectAll,
      DataAxisGridDataCellEditorParamsNeededEventArgs editorParams)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, propAxisBar, listItemBar, cell)
    {
      Editor = editor;
      Value = value;
      SelectAll = selectAll;
      EditorParams = editorParams;
    }

    public Control Editor { get; internal set; }
    public object Value { get; internal set; }
    public bool SelectAll { get; internal set; }
    public DataAxisGridDataCellEditorParamsNeededEventArgs EditorParams { get; internal set; }

    public void OccupyEditor(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
      e.Cell.OnEditorOccupy(e);
    }
  }

  /// <summary>
  /// Event args for EditorRelease event in BaseDataCellManager component.
  /// </summary>
  public class DataAxisGridDataCellEditorReleaseEventArgs : DataAxisGridDataBarCellEventArgs
  {

    public DataAxisGridDataCellEditorReleaseEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, Control editor, BaseDataCellManager cellMan)
      : base(propAxisBar, listItemBar, cellMan)
    {
      Editor = editor;
    }

    public Control Editor { get; private set; }
  }

  /// <summary>
  /// Event args for requesting if editor can be shown in the data cell of the DataAxisGrid
  /// </summary>
  public class DataAxisGridDataCellCanShowEditorStateNeededEventArgs : BaseGridCellCanShowEditorStateNeededEventArgs
  {
    private PropertyAxisBar propAxisBar;
    private DataAxisGridListItemBar listItemBar;

    public DataAxisGridDataCellCanShowEditorStateNeededEventArgs(BaseGridControl grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell)
      : base(grid, cell, colIndex, rowIndex, areaColIndex, areaRowIndex)
    {
      this.propAxisBar = propAxisBar;
      this.listItemBar = listItemBar;
    }

    public PropertyAxisBar PropAxisBar
    {
      get { return propAxisBar; }
    }

    public DataAxisGridListItemBar ListItemBar
    {
      get { return listItemBar; }
    }
  }

  /// <summary>
  /// Event args for pulling cell value event in the data cell of the DataAxisGrid
  /// Event occurs when value is read from DataSource item 
  /// </summary>
  public class DataAxisGridDataCellPullValueEventArgs : DataAxisGridDataBarCellEventArgs
  {

    public DataAxisGridDataCellPullValueEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan) 
      : base(propAxisBar, listItemBar, cellMan)
    {

    }

    public object Value { get; set; }

    public virtual void PullValue(DataAxisGridDataCellPullValueEventArgs e)
    {
      e.PropAxisBar.OnPullValue(e);
    }
  }

  /// <summary>
  /// Event args for pushing cell value event in the data cell of the DataAxisGrid
  /// Event occurs when value moves from cell editor to the DataSource item
  /// </summary>
  public class DataAxisGridDataCellPushValueEventArgs : DataAxisGridDataBarCellEventArgs
  {

    public DataAxisGridDataCellPushValueEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
      : base(propAxisBar, listItemBar, cellMan)
    {

    }

    public object Value { get; set; }
  }

  /// <summary>
  /// Event args for parsing event in the data cell editor of the DataAxisGrid
  /// Event occurs when value is read from cell editor and convered before writing to the DataSource item
  /// </summary>
  public class DataAxisGridDataCellParseValueEventArgs : DataAxisGridDataBarCellEventArgs
  {

    public DataAxisGridDataCellParseValueEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan, object inValue)
      : base(propAxisBar, listItemBar, cellMan)
    {
      InValue = inValue;
    }

    public object InValue { get; set; }

    public object OutValue { get; set; }

    public virtual void ParseValue(DataAxisGridDataCellParseValueEventArgs e)
    {
      e.CellMan.OnParseValue(e);
    }
  }

  /// <summary>
  /// Event args for the event of creating dymanic columns in the DataAxisGrid
  /// </summary>
  public class DataAxisDynamicColumnsCreatingEventArgs : HandledEventArgs
  {
    private readonly DeepPropertyDescriptor propertyDescriptor;
    private readonly bool presentInStaticList;
    private readonly DataAxisGrid grid;

    public DataAxisDynamicColumnsCreatingEventArgs(DataAxisGrid grid, DeepPropertyDescriptor propertyDescriptor, bool presentInStaticList)
    {
      this.propertyDescriptor = propertyDescriptor;
      this.presentInStaticList = presentInStaticList;
      this.grid = grid;
    }

    public DataAxisGrid Grid
    {
      get { return this.grid; }
    }

    public DeepPropertyDescriptor PropertyDescriptor
    {
      get { return this.propertyDescriptor; }
    }

    /// <summary>
    /// True if PropertyBar already exists in the list of static PropBars
    /// </summary>
    protected internal bool PresentInStaticList
    {
      get { return this.presentInStaticList; }
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
    protected internal PropertyAxisBar[] PropertyBars { get; set; }
  }

  /// <summary>
  /// Event args for ToolTipInfoNeeded event in the data cell of the DataAxisGrid
  /// Event occurs when mouse hovers above the cell
  /// </summary>
  public class DataAxisGridDataCellToolTipInfoEventArgs : DataAxisGridDataBarCellEventArgs
  {
    private string toolTipText;

    public DataAxisGridDataCellToolTipInfoEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan)
      : base(propAxisBar, listItemBar, cellMan)
    {

    }

    public string ToolTipText
    {
      get { return this.toolTipText; }
      set { this.toolTipText = value; }
    }
  }

  /// <summary>
  /// Event args for ContextMenuStripNeeded event in the data cell of the DataAxisGrid
  /// Event occurs when user clicks right mouse button above the cell
  /// </summary>
  public class DataAxisGridDataCellContextMenuStripNeededEventArgs : BaseGridCellContextMenuStripNeededEventArgs
  {
    private PropertyAxisBar propAxisBar;
    private DataAxisGridListItemBar listItemBar;

    public DataAxisGridDataCellContextMenuStripNeededEventArgs(
      BaseGridControl grid, BaseGridCellManager cellManager, 
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex,
      int inCellX, int inCellY, Rectangle cellRect, int mousePosX, int mousePosY,
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
      : base (grid, cellManager, colIndex, rowIndex, areaColIndex, areaRowIndex, inCellX, inCellY, cellRect, mousePosX, mousePosY)

    {
      this.propAxisBar = propAxisBar;
      this.listItemBar = listItemBar;
    }

    public PropertyAxisBar PropAxisBar
    {
      get { return this.propAxisBar; }
    }

    public DataAxisGridListItemBar ListItemBar
    {
      get { return this.listItemBar; }
    }

    public BaseDataCellManager CellMan
    {
      get { return (BaseDataCellManager)base.CellManager; }
    }

  }

  /// <summary>
  /// Event args for ClientAreaNeeded event for the data cell of the DataAxisGrid
  /// Event occurs when grid request the size of client rectangle inside the cell rectangle 
  /// every time when draw or edit action happens
  /// </summary>
  public class DataAxisGridDataCellClientAreaNeededEventArgs : DataAxisGridDataBarCellEventArgs
  {
    private readonly Rectangle cellRect;
    private Rectangle cellClientRect;

    public DataAxisGridDataCellClientAreaNeededEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, Rectangle cellRect, BaseDataCellManager cell) :
      base(propAxisBar, listItemBar, cell)
    {
      this.cellRect = cellRect;
      this.cellClientRect = cellRect;
    }

    public Rectangle CellRect
    {
      get { return cellRect; }
    }

    public Rectangle CellClientRect
    {
      get { return cellClientRect; }
      set { cellClientRect = value; }
    }
  }

  /// <summary>
  /// Event args for optimal width calculation event in the data cell of the DataAxisGrid
  /// Event occurs when grid needed to calculate the optimal width a the column
  /// </summary>
  public class DataAxisGridDataCellOptimalWidthNeededEventArgs : EventArgs
  {
    private PropertyAxisBar propAxisBar;
    private DataAxisGridListItemBar listItemBar;
    private readonly BaseDataCellManager cell;

    private int optimalWidth;

    public DataAxisGridDataCellOptimalWidthNeededEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell)
    {
      this.propAxisBar = propAxisBar;
      this.listItemBar = listItemBar;
      this.cell = cell;
    }

    public PropertyAxisBar PropAxisBar
    {
      get { return propAxisBar; }
    }

    public DataAxisGridListItemBar ListItemBar
    {
      get { return listItemBar; }
    }

    public int OptimalWidth
    {
      get { return optimalWidth; }
      set { optimalWidth = value; }
    }

    public BaseDataCellManager Cell
    {
      get { return this.cell; }
    }
  }

  /// <summary>
  /// Event args for CanModifyStateNeeded event in the data cell of the DataAxisGrid.
  /// Event occurs when the grid want to know if it can change the value in the cell or cell editor.
  /// </summary>
  public class DataAxisGridDataCellCanModifyStateNeededEventArgs : DataAxisGridDataBarCellEventArgs
  {
    public DataAxisGridDataCellCanModifyStateNeededEventArgs(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, 
      BaseDataCellManager cellMan)
      : base(propAxisBar, listItemBar, cellMan)
    {
    }

    public bool CanModify { get; set; }
  }

  /// <summary>
  /// Event args for DisplayValueNeeded event in the data cell of the DataAxisGrid.
  /// Event occurs every time the grid convert cell value to value for display data.
  /// </summary>
  public class DataAxisGridDataCellDisplayValueNeededEventArgs : HandledEventArgs
  {
    private PropertyAxisBar propAxisBar;
    private readonly BaseDataCellManager cellMan;

    public DataAxisGridDataCellDisplayValueNeededEventArgs(PropertyAxisBar propAxisBar,
      DataAxisGridListItemBar listItemBar, BaseDataCellManager cellMan, object value)
    {
      this.Value = value;
      this.cellMan = cellMan;
      this.propAxisBar = propAxisBar;
      ListItemBar = listItemBar;
    }

    public PropertyAxisBar PropAxisBar
    {
      get { return propAxisBar; }
    }

    public DataAxisGridListItemBar ListItemBar
    {
      get;
      private set;
    }

    public BaseDataCellManager CellMan
    {
      get { return this.cellMan; }
    }

    public object Value { get; internal set; }

    public object DisplayValue { get; set; }

    public object GetDisplayValue(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      e.CellMan.OnDisplayValueNeeded(e);
      return e.DisplayValue;
    }
  }

  /// <summary>
  /// Event args for EditValueNeeded event in the data cell of the DataAxisGrid.
  /// Event occurs every time the grid convert cell value to value for inplace editor.
  /// </summary>
  public class DataAxisGridDataCellEditValueNeededEventArgs : HandledEventArgs
  {
    private PropertyAxisBar propAxisBar;
    private readonly BaseDataCellManager cellMan;

    public DataAxisGridDataCellEditValueNeededEventArgs(PropertyAxisBar propAxisBar,
      BaseDataCellManager cellMan, object value)
    {
      this.Value = value;
      this.cellMan = cellMan;
      this.propAxisBar = propAxisBar;
    }

    public PropertyAxisBar PropAxisBar
    {
      get { return propAxisBar; }
    }

    public BaseDataCellManager CellMan
    {
      get { return this.cellMan; }
    }

    public object Value { get; internal set; }

    public object EditValue { get; set; }
  }

  public class DataAxisGridEditorKeyEventArgs : HandledEventArgs
  {

    public DataAxisGridEditorKeyEventArgs(DataAxisGrid grid, 
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar,
      Control cellEditControl, BaseDataCellManager cellMan, KeyEventArgs keyEventArgs)
    {
      Grid = grid;
      PropAxisBar = propAxisBar;
      ListItemBar = listItemBar;
      CellEditControl = cellEditControl;
      CellMan = cellMan;
      KeyEventArgs = keyEventArgs;
    }

    public KeyEventArgs KeyEventArgs { get; internal set; }

    public BaseDataCellManager CellMan { get; internal set; }

    public Control CellEditControl { get; internal set; }

    public PropertyAxisBar PropAxisBar { get; internal set; }

    public DataAxisGridListItemBar ListItemBar { get; internal set; }

    public DataAxisGrid Grid { get; internal set; }
  }

}
