﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.ComponentModel.Design;
using System.Collections.ObjectModel;
using System.ComponentModel.Design.Serialization;

namespace EhLib.WinForms.Design
{
  internal partial class DataAxisGridAddBoundBandsDialog : Form
  {

    //private DataAxisGrid grid;

    private Component component;
    private object dataSource;
    private string dataMember;
    private List<string> excludedDataProperties;
    string itemNameSuffix;
    string itemNamePrefix;

    public DataAxisGridAddBoundBandsDialog()
    {
      InitializeComponent();
    }

    //public void InitData(DataAxisGrid grid)
    //{
    //  this.grid = grid;
    //  if (grid is DataGridEh)
    //    textBoxColNameFormat.Text = grid.Name + "{DataPropertyName}Column";
    //  else if (grid is DataVertGridEh)
    //    textBoxColNameFormat.Text = grid.Name + "{DataPropertyName}Row";
    //  else
    //    textBoxColNameFormat.Text = grid.Name + "{DataPropertyName}";
    //  UpdateListBox();
    //}

    public void InitData(Component component,  object dataSource, string dataMember, List<string> excludedDataProperties,
      string itemNamePrefix, string itemNameSuffix)
    {
      //this.grid = grid;
      //if (grid is DataGridEh)
      //  textBoxColNameFormat.Text = grid.Name + "{DataPropertyName}Column";
      //else if (grid is DataVertGridEh)
      //  textBoxColNameFormat.Text = grid.Name + "{DataPropertyName}Row";
      //else
      //  textBoxColNameFormat.Text = grid.Name + "{DataPropertyName}";
      this.component = component;
      this.dataSource = dataSource;
      this.dataMember = dataMember;
      this.excludedDataProperties = excludedDataProperties;
      this.itemNameSuffix = itemNameSuffix;
      this.itemNamePrefix = itemNamePrefix;

      textBoxColNameFormat.Text = itemNamePrefix + "{DataPropertyName}" + itemNameSuffix;
      UpdateListBox();
    }

    public static void AddBoundAxisBars(DataAxisGrid grid)
    {
      DataAxisGridAddBoundBandsDialog dlg = new DataAxisGridAddBoundBandsDialog();

      Component component = grid;
      object dataSource = grid.DataSource;
      string dataMember = grid.DataMember;
      List<string> excludedDataProperties = new List<string>();
      string itemNamePrefix = grid.Name;
      string itemNameSuffix;

      foreach(var ab in grid.StaticPropBars)
      {
        if (ab.DataPropertyName != null)
          excludedDataProperties.Add(ab.DataPropertyName);
      }

      if (grid is DataGridEh)
        itemNameSuffix = "Column";
      else if (grid is DataVertGridEh)
        itemNameSuffix = "Row";
      else
        itemNameSuffix = "";

      //dlg.InitData(grid);
      dlg.InitData(component, dataSource, dataMember, excludedDataProperties, itemNamePrefix, itemNameSuffix);

      DialogResult result = dlg.ShowDialog();
      if (result == DialogResult.OK)
      {
        Collection<PropertyAxisBar> selectedCols = dlg.CreateAxisBarsFromSelectedProperties(grid);
        PropertyAxisBar[] selColsArray = new PropertyAxisBar[selectedCols.Count];
        selectedCols.CopyTo(selColsArray, 0);
        grid.StaticPropBars.AddRange(selColsArray);
      }
    }

    public static List<PropertyDescriptor> GetSelectedListProperties(Component component, object dataSource, string dataMember, List<string> excludedDataProperties,
      string itemNamePrefix, string itemNameSuffix)
    {
      DataAxisGridAddBoundBandsDialog dlg = new DataAxisGridAddBoundBandsDialog();

      //dlg.InitData(grid);
      dlg.InitData(component, dataSource, dataMember, excludedDataProperties, itemNamePrefix, itemNameSuffix);

      DialogResult result = dlg.ShowDialog();
      if (result == DialogResult.OK)
      {
        List<PropertyDescriptor> resultList = new List<PropertyDescriptor>();

        for (int i = 0; i < dlg.AxisBarListBox.Items.Count; i++)
        {
          if (dlg.AxisBarListBox.GetSelected(i) == true)
          {
            PropertyDescriptor prop = ((ListBoxItem)dlg.AxisBarListBox.Items[i]).PropertyDesc;
            resultList.Add(prop);
          }
        }

        return resultList;
      }
      else
      {
        return null;
      }
    }

    public Collection<PropertyAxisBar> CreateAxisBarsFromSelectedProperties(DataAxisGrid grid)
    {
      Collection<PropertyAxisBar> colList = new Collection<PropertyAxisBar>();

      if (component.Site != null)
      {
        var selService = (ISelectionService)component.Site.GetService(typeof(ISelectionService));
        selService.SetSelectedComponents(new object[] { component });
      }

      for (int i = 0; i < AxisBarListBox.Items.Count; i++)
      {
        if (AxisBarListBox.GetSelected(i) == true)
        {
          
          PropertyDescriptor prop = ((ListBoxItem)AxisBarListBox.Items[i]).PropertyDesc;
          PropertyAxisBar band;

          Type colType = grid.GetAxisBarTypeForDataType(prop.PropertyType);
          if (colType == null) continue;

          if (component.Site != null)
          {
            IDesignerHost host = (IDesignerHost)component.Site.GetService(typeof(IDesignerHost));
            string compName = GenerateUniqueName(prop.Name);
            if (!String.IsNullOrEmpty(compName))
              band = (PropertyAxisBar)host.CreateComponent(colType, compName);
            else
              band = (PropertyAxisBar)host.CreateComponent(colType);
          }
          else
          {
            band = (PropertyAxisBar)Activator.CreateInstance(colType);
          }

          band.DataPropertyName = prop.Name;

          //Columns will be added in DataGridDesigner.ChangeService_ComponentAdded
          //Just select DataGridEh
          //colList.Add(band);
        }
      }
      return colList;
    }

    private string GenerateUniqueName(string propName)
    {
      INameCreationService nameService = (INameCreationService)component.Site.GetService(typeof(INameCreationService));
      string result = textBoxColNameFormat.Text;
      result = result.Replace("{DataPropertyName}", propName);

      int num = 0;
      string numS = "";
      while (true)
      {
        if (nameService.IsValidName(result + numS))
        {
          result = result + numS;
          break;
        }
        num = num + 1;
        numS = num.ToString();
      }

      return result;
    }

    private void UpdateListBox()
    {
      CurrencyManager cm;

      if (dataSource == null) return;
      AxisBarListBox.Items.Clear();

      try
      {
        cm = this.BindingContext[dataSource, dataMember] as CurrencyManager;
      }
      catch (ArgumentException ae)
      {
        MessageBox.Show(ae.Message);
        cm = null;
      }
      if (cm == null) return;

      PropertyDescriptorCollection props = cm.GetItemProperties();

      if (props != null)
      {
        for (int i = 0; i < props.Count; i++)
        {
          if (typeof(IList).IsAssignableFrom(props[i].PropertyType))
          {
            // we have an IList. It could be a byte[] in which case we want to generate an Image column
            // 
            TypeConverter imageTypeConverter = TypeDescriptor.GetConverter(typeof(Image));
            if (!imageTypeConverter.CanConvertFrom(props[i].PropertyType))
            {
              continue;
            }
          }

          

          if (radioButtonNewColumns.Checked &&
              excludedDataProperties.IndexOf(props[i].Name) >= 0)
          {
            EhLibUtils.DoNothing();
          }
          else
          {
            this.AxisBarListBox.Items.Add(new ListBoxItem(props[i], props[i].Name));
          }
        }
      }

      for (int i = 0; i < AxisBarListBox.Items.Count; i++)
      {
        AxisBarListBox.SetSelected(i, true);
      }
    }

    private void radioButtonAllColumns_Click(object sender, EventArgs e)
    {
      UpdateListBox();
    }

    private void radioButtonNewColumns_Click(object sender, EventArgs e)
    {
      UpdateListBox();
    }

    private class ListBoxItem
    {
      readonly PropertyDescriptor propertyDesc;
      readonly string propertyName;

      public ListBoxItem(PropertyDescriptor propertyDesc, string propertyName)
      {
        this.propertyDesc = propertyDesc;
        this.propertyName = propertyName;
      }

      public PropertyDescriptor PropertyDesc
      {
        get
        {
          return this.propertyDesc;
        }
      }

      //public string PropertyName
      //{
      //  get
      //  {
      //    return this.propertyName;
      //  }
      //}

      public override string ToString()
      {
        return this.propertyName + " (" + PropertyDesc.PropertyType.ToString() + ")";
      }
    }

  }
}
