﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms.Design
{

  public class TextAutoCompletingSourceDataPropertyNameConverter : TypeConverter
  {

    public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
    {
      return true;
    }

    public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
    {
      return false;
    }

    public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
    {

      TextAutoCompletingSource completingSource = (context.Instance as TextAutoCompletingSource);
      Debug.Assert(completingSource != null, @"TextAutoCompletingSourceDataPropertyNameConverter.StandardValuesCollection - completingSource == null");

      BindingSource bSource = new BindingSource(completingSource.DataSource, null);

      List<string> sList = new List<string>();

      string propName;
      foreach (PropertyDescriptor prop in bSource.GetItemProperties(null))
      {
        propName = prop.Name;
        sList.Add(propName);
      }

      StandardValuesCollection svc = new StandardValuesCollection(sList);
      return svc;
    }

    public override bool CanConvertFrom(ITypeDescriptorContext context,
       Type sourceType)
    {
      if (sourceType == typeof(string))
        return true;
      else
        return base.CanConvertFrom(context, sourceType);
    }

    public override object ConvertFrom(ITypeDescriptorContext context, CultureInfo culture, object value)
    {
      var s = value as string;
      if (s != null)
        return s;
      else
        return base.ConvertFrom(context, culture, value);
    }

  }

}
