﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  /// <summary>
  /// Specify the type of filtering rows in ComboBoxEh
  /// </summary>
  public enum ComboBoxFilterType
  {
    /// <summary>
    /// Filtering by part of text that start a cell value 
    /// </summary>
    StartOfText,

    /// <summary>
    /// Filtering by part of text that is contained in the cell value 
    /// </summary>
    AnyPartOfText
  }

  /// <summary>
  /// Defines parts that compound the ComboBox
  /// </summary>
  public enum ComboBoxCompound
  {
    /// <summary>
    /// ComboBox consist of the text editor
    /// </summary>
    TextEditor,

    /// <summary>
    /// ComboBox consist of the text editor and a custom area
    /// </summary>
    CustomAreaAndTextEditor,

    /// <summary>
    /// ComboBox consist of a custom area. 
    /// CustomAreaPaint event handler should be writen to define display image of this part.
    /// </summary>
    CustomArea
  }

  /// <summary>
  /// The origin of data for generating list for ComboBoxEh
  /// </summary>
  public enum ListSourceOrigin
  {
    /// <summary>
    /// Data comes from the source of the given DataSource property.
    /// </summary>
    DataSource,

    /// <summary>
    /// Data comes from the source of the given Items property.
    /// </summary>
    Items
  }

  /// <summary>
  ///       Displays an editing field and a list, allowing the user to select from the
  ///       list or to enter new text. Displays only the editing field until the user
  ///       explicitly displays the list.
  /// </summary>
  [System.ComponentModel.DesignerCategory("Code")]
  [Designer("EhLib.WinForms.Design.ComboBoxDesigner" + EhLibUtils.EhLibDesignDesignerVersionInfo)]
  [ToolboxItem(true)]
  [LookupBindingProperties("DataSource", "DisplayMember", "ValueMember", "SelectedValue")]
  [ClassInterface(ClassInterfaceType.AutoDispatch)]
  [ToolboxBitmap(typeof(ComboBoxEh), "ToolboxBitmaps.EhLib_ComboBox.bmp")]
  [Description("Displays an editable text box with a drop-down list of permitted values")]
  //[ComVisible(true)]
  public class ComboBoxEh : BaseTextBoxEh, IObjectCollectionObserver, IComboBoxDropDownBoxOwner
  {
    #region private consts
    private static readonly object EventKeySelectedValueChanged = new object();
    private static readonly object EventKeySelectedIndexChanged = new object();
    private static readonly object EventKeyCustomAreaPaint = new object();
    private static readonly object EventKeyTextAreaPaint = new object();
    private static readonly object EventKeyListItemStatusNeeded = new object();
    #endregion

    #region privates
    private object dataSource;
    private readonly CurrencyManager dataManager;
    //private readonly bool dataManagerActive = false;
    private BindingMemberInfo displayMember;
    private BindingMemberInfo valueMember;
    private PropertyDescriptor displayMemberProperty;

    private bool inSetDataConnection;
    private bool isDataSourceInitEventHooked;
    private bool isDataSourceInitialized;
    private int selectedIndex = -1;
    private object selectedValueKey;
    private bool listVisible;
    private bool textAutoComplete = true;
    private bool textSearchIgnoreCase = true;
    private bool limitTextToListValuesStored;
    private bool limitTextToListValues;

    private readonly ComboBoxMessageFilter messageFilter;
    private readonly BindingSource bindingSource;

    private readonly PopupDataGridForm dropDownList;
    private readonly ComboBoxDropDownBox dropDownBox;
    private ComboBoxDropDownBox externalDropDownBox;
    private bool sorted;
    private ObjectCollection itemsCollection;
    private ComboBoxCompound compound;
    private int customAreaWidth = 16;
    private ComboBoxCustomAreaControl customAreaControl;
    private bool userTextChanged;
    #endregion privates

    #region constructor
    public ComboBoxEh()
    {
      WordWrap = false;

      dropDownList = new ComboBoxPopupDataGridForm(this);
      messageFilter = new ComboBoxMessageFilter(this);
      bindingSource = new BindingSource();
      dropDownBox = new ComboBoxDropDownBox(this);

      dataManager = bindingSource.CurrencyManager;
      dataManager.ListChanged += DataManager_ListChanged;

      InitData();

    }

    private void InitData()
    {
      InitEditButton();

      customAreaControl = new ComboBoxCustomAreaControl(this);
      customAreaControl.Parent = this;
    }

    protected override void Dispose(bool disposing)
    {
      CloseUp(false);
      if (disposing)
      {
        UnwireDataSource();
        dropDownList.Dispose();
        bindingSource.Dispose();
        dropDownBox.Dispose();
      }

      base.Dispose(disposing);
    }
    #endregion constructor

    #region design-time properties
    /// <summary>
    /// Contains the properties of the button that opens a drop-down list.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public new EditButton EditButton
    {
      get
      {
        return base.EditButton;
      }
    }

    /// <summary>
    /// Sets the parameter of which parts the combo box consists of.
    /// Сombo box can consists of text OR text and the image that is drawn in a special area to the 
    /// left of the text.
    /// </summary>
    [DefaultValue(ComboBoxCompound.TextEditor)]
    public ComboBoxCompound Compound
    {
      get
      {
        return compound;
      }
      set
      {
        if (value != compound)
        {
          compound = value;
          OnCompoundChanged();
        }
      }
    }

    /// <summary>
    /// Gets or sets the data source for this ComboBox dropdrop list.
    /// </summary>
    [Category("Data")]
    [DefaultValue(null)]
    [RefreshProperties(RefreshProperties.Repaint)]
    [AttributeProvider(typeof(IListSource))]
    //[SRDescription(SR.ListControlDataSourceDescr)
    public object DataSource
    {
      get
      {
        return dataSource;
      }

      set
      {
        if (value != null && !(value is IList || value is IListSource))
          throw new ArgumentException("BadDataSourceForComplexBinding");
        if (dataSource == value)
          return;
        try
        {
          SetDataConnection(value, displayMember, false);
        }
        catch(ArgumentException)
        {
          DisplayMember = "";
        }
        if (value == null)
          DisplayMember = "";
      }
    }

    /// <summary>
    /// Gets or sets the property to display for this ComboBox editor.
    /// </summary>
    [Editor("System.Windows.Forms.Design.DataMemberFieldEditor", typeof(UITypeEditor))]
    [Category("Data")]
    [DefaultValue("")]
    [TypeConverter("System.Windows.Forms.Design.DataMemberFieldConverter")]
    //[Description("ListControlDisplayMemberDescr")]
    public string DisplayMember
    {
      get
      {
        return displayMember.BindingMember;
      }

      set
      {
        if (value != displayMember.BindingPath)
        {
          BindingMemberInfo oldDisplayMember = displayMember;
          try
          {
            SetDataConnection(dataSource, new BindingMemberInfo(value), false);
          }
          catch (Exception e)
          {
            if (EhLibUtils.IsCriticalException(e))
            {
              throw;
            }
            displayMember = oldDisplayMember;
          }
        }
      }
    }

    /// <summary>
    ///  Gets or sets the path of the property to use as the actual value for the items in the ListControl.
    ///  When this property is filled, the control activates the lookup mode.
    /// </summary>
    [Category("Data")]
    [DefaultValue("")]
    [Editor("System.Windows.Forms.Design.DataMemberFieldEditor", typeof(UITypeEditor))]
    //[Description("ListControlValueMemberDescr")]
    public string ValueMember
    {
      get
      {
        return valueMember.BindingMember;
      }

      set
      {
        if (value == null)
          value = "";
        BindingMemberInfo newValueMember = new BindingMemberInfo(value);
        //BindingMemberInfo oldValueMember = valueMember;
        if (!newValueMember.Equals(valueMember))
        {
          if (DisplayMember.Length == 0)
            SetDataConnection(DataSource, newValueMember, false);
          if (isDataSourceInitialized && value.Length != 0)
            if (!BindingMemberInfoInDataManager(newValueMember))
            {
              throw new ArgumentException("ListControlWrongValueMember");
            }

          valueMember = newValueMember;
          if (!LookupMode)
            selectedValueKey = null;
          //OnValueMemberChanged(EventArgs.Empty);
          //OnSelectedValueChanged(EventArgs.Empty);
        }
      }
    }

    /// <summary>
    /// Gets or sets a value indicating whether the found text should be substituted in the editor 
    /// when user type text from the keyboard?
    /// </summary>
    [DefaultValue(true)]
    public bool TextAutoComplete
    {
      get
      {
        return textAutoComplete;
      }

      set
      {
        textAutoComplete = value;
      }
    }

    /// <summary>
    /// Gets or sets a value indicating whether letters be case sensitive when searching for text.
    /// </summary>
    [DefaultValue(true)]
    public bool TextSearchIgnoreCase
    {
      get
      {
        return textSearchIgnoreCase;
      }

      set
      {
        textSearchIgnoreCase = value;
      }
    }

    /// <summary>
    /// Gets or sets a value indicating whether the control allow to type text that is not in the ListSources list.
    /// </summary>
    //[DefaultValue(true)]
    public bool LimitTextToListValues
    {
      get
      {
        if (limitTextToListValuesStored)
          return limitTextToListValues;
        else
          return DefaultLimitTextToListValues();
      }
      set
      {
        if ((limitTextToListValuesStored == false) || (limitTextToListValues != value))
        {
          limitTextToListValuesStored = true;
          limitTextToListValues = value;
          LimitTextToListValuesChanged();
        }
      }
    }

    /// <summary>
    /// Contains properties and events that control the behavior and display a drop-down list.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public ComboBoxDropDownBox DropDownBox
    {
      get
      {
        if (externalDropDownBox != null)
          return externalDropDownBox;
        else
          return dropDownBox;
      }
    }

    /// <summary>
    /// Gets or sets a value indicating whether the items in the combo box are sorted.
    /// </summary>
    [DefaultValue(false)]
    public bool Sorted
    {
      get
      {
        return sorted;
      }
      set
      {
        if (sorted != value)
        {
          if (this.DataSource != null && value)
          {
            throw new ArgumentException("ComboBoxSortWithDataSource");
          }

          sorted = value;
          Items.Sorted = value;
          //RefreshItems();
          SelectedIndex = -1;
        }
      }
    }

    /// <summary>
    /// Gets an object representing the collection of the items contained in this ComboBox.
    /// If this property is filled, the DataSource property must be empty.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    [Localizable(true)]
    [Editor("System.Windows.Forms.Design.ListControlStringCollectionEditor", typeof(UITypeEditor))]
    [MergableProperty(false)]
    [Category("Data")]
    //[Description("ComboBoxItemsDescr")]
    public ObjectCollection Items
    {
      get
      {
        if (itemsCollection == null)
        {
          itemsCollection = new ObjectCollection(this);
        }
        return itemsCollection;
      }
    }

    //[DefaultValue(HorizontalAlignment.Left)]
    //[Localizable(true)]
    //public new HorizontalAlignment TextAlign
    //{
    //  get { return base.TextAlign; }
    //  set { base.TextAlign = value; }
    //}

    /// <summary>
    /// Gets or sets a value indicating whether the selected text in the text box control remains 
    /// highlighted when the control loses focus.
    /// </summary>
    [DefaultValue(true)]
    public new bool HideSelection
    {
      get { return base.HideSelection; }
      set { base.HideSelection = value; }
    }

    /// <summary>
    /// Indicates whether a multiline text box control automatically wraps words to the beginning of 
    /// the next line when necessary.
    /// </summary>
    [DefaultValue(false)]
    [Localizable(true)]
    public new bool WordWrap
    {
      get
      {
        return base.WordWrap;
      }

      set
      {
        if (value != WordWrap)
        {
          base.WordWrap = value;
          Multiline = WordWrap;
        }
      }
    }

    /// <summary>
    ///     Specify a width if the custom area in combobox editor at the left part of the control.
    ///     This area is drawn in the CustomAreaPaint event handler.
    /// </summary>
    [DefaultValue(16)]
    public int CustomAreaWidth
    {
      get
      {
        return customAreaWidth;
      }

      set
      {
        if (value != customAreaWidth)
        {
          customAreaWidth = value;
          RealignControls();
        }
      }
    }

    [Localizable(true)]
    public override string Text
    {
      get
      {
        return InternalText;
      }
      set
      {
        if (LookupMode && LimitTextToListValues)
        {
          int index = FindStringInList(value, false, false, false);
          if (index == -1)
            throw new InvalidOperationException("Text: '" + value + "' is not in the list");
        }
        InternalText = value;
        UpdateRelatedDataFromText();
      }
    }
    #endregion

    #region run-time properties     

    /// <summary>
    ///     The [zero based] index of the currently selected item in the combobox list.
    ///     Note If the value of index is -1, then the ComboBox is set to have no selection.
    /// </summary>
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int SelectedIndex
    {
      get
      {
        return selectedIndex;
      }
      set
      {
        SetSelectedIndex(value, true);
      }
    }

    /// <summary>
    ///     The value specified by the ValueMember property in the list row that is currently 
    ///     selected in the combobox list.
    /// </summary>
    [Category("Data")]
    [Browsable(false)]
    [Bindable(true)]
    [DefaultValue(null)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    //[Description("ListControlSelectedValueDescr")]
    public object SelectedValue
    {
      get
      {
        if (LookupMode)
        {
          return selectedValueKey;
        }
        else
        {
          if (SelectedIndex != -1 && dataManager != null)
          {
            object item = GetListItemByIndex(SelectedIndex);
            object filteredItem = GetListItemValue(item);
            return filteredItem;
          }
          else
          {
            return null;
          }
        }
      }
      set
      {
        if (LookupMode)
        {
          bool valueEqual = ValuesEqual(selectedValueKey, value);
          if (valueEqual) return;

          selectedValueKey = value;
          UpdateRelatedDataFromValue();

          OnSelectedValueChanged(EventArgs.Empty);
        }
        else
        {
          throw new InvalidOperationException("Assign SelectedValue is supported only in Lookup mode");
          //if (dataManager != null)
          //{
          //  string propertyName = valueMember.BindingField;
          //  if (string.IsNullOrEmpty(propertyName))
          //    throw new InvalidOperationException("Assign SelectedValue is supported only in Lookup mode");
          //  PropertyDescriptorCollection props = dataManager.GetItemProperties();
          //  PropertyDescriptor property = props.Find(propertyName, true);
          //  int index = FindInDataManager(property, value, true);
          //  SelectedIndex = index;
          //}
        }
      }
    }

    /// <summary>
    ///     The reference to the list row that is currently selected in the combobox list.
    /// </summary>
    [Category("Data")]
    [Browsable(false)]
    [Bindable(true)]
    [DefaultValue(null)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public object SelectedItem
    {
      get
      {
        if (SelectedIndex == -1)
          return null;
        else
          return dataManager.List[SelectedIndex];
      }
      set
      {
        int idx = dataManager.List.IndexOf(value);

        if (idx != -1)
          SelectedIndex = idx;
      }
    }

    /// <summary>
    ///    Returns true when ValueMember is assigned and DataSource is active
    /// </summary>
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool LookupMode
    {
      get
      {
        return !string.IsNullOrEmpty(ValueMember);
      }
    }

    /// <summary>
    ///    Returns true when dropdown box is visible
    /// </summary>
    [Browsable(false)]
    public bool ListVisible
    {
      get
      {
        return listVisible;
      }
    }

    /// <summary>
    ///    Returns a CurrencyManager of Binding list assigned by the DataSource property.
    /// </summary>
    [Browsable(false)]
    protected CurrencyManager DataManager
    {
      get
      {
        return this.dataManager;
      }
    }

    /// <summary>
    ///    Returns a ListSource origin: external assigned by DataSource property or internal filled by Items property.
    /// </summary>
    [Browsable(false)]
    public ListSourceOrigin ListSourceOrigin
    {
      get
      {
        if (DataSource == null && Items.Count > 0)
          return ListSourceOrigin.Items;
        else
          return ListSourceOrigin.DataSource;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    protected string InternalText
    {
      get
      {
        return base.Text;
      }
      set
      {
        base.Text = value;
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public ComboBoxDropDownBox ExternalDropDownBox
    {
      get
      {
        return externalDropDownBox;
      }
      set
      {
        if (externalDropDownBox != value)
        {
          if (externalDropDownBox != null)
            externalDropDownBox.Owner = null;

          externalDropDownBox = value;
          if (externalDropDownBox != null)
            externalDropDownBox.Owner = this;
        }
      }
    }
    #endregion

    #region events
    public event EventHandler SelectedValueChanged
    {
      add
      {
        base.Events.AddHandler(EventKeySelectedValueChanged, value);
      }
      remove
      {
        base.Events.RemoveHandler(EventKeySelectedValueChanged, value);
      }
    }

    public event EventHandler SelectedIndexChanged
    {
      add
      {
        Events.AddHandler(EventKeySelectedIndexChanged, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeySelectedIndexChanged, value);
      }
    }

    public event EventHandler<ComboBoxCustomAreaPaintEventArgs> CustomAreaPaint
    {
      add
      {
        Events.AddHandler(EventKeyCustomAreaPaint, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyCustomAreaPaint, value);
      }
    }

    public event EventHandler<ComboBoxTextAreaPaintEventArgs> TextAreaPaint
    {
      add
      {
        Events.AddHandler(EventKeyTextAreaPaint, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyTextAreaPaint, value);
      }
    }

    public event EventHandler<ComboBoxListItemStatusNeededEventArgs> ListItemStatusNeeded
    {
      add
      {
        Events.AddHandler(EventKeyListItemStatusNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyListItemStatusNeeded, value);
      }
    }
    //
    #endregion events

    #region public methos
    public string GetListItemText(object item)
    {

      object itemValue;

      if (item == null)
      {
        return string.Empty;
      }

      if (displayMemberProperty != null)
        itemValue = displayMemberProperty.GetValue(item);
      else
        itemValue = item;

      if (itemValue != null)
        return Convert.ToString(itemValue, CultureInfo.CurrentCulture);
      else
        return "";
    }

    public object GetListItemValue(object item)
    {
      object filteredItem;

      if (!String.IsNullOrEmpty(ValueMember))
        filteredItem = FilterItemOnProperty(item, valueMember.BindingField);
      else if (!String.IsNullOrEmpty(DisplayMember))
        filteredItem = FilterItemOnProperty(item, displayMember.BindingField);
      else
        filteredItem = item;

      return filteredItem;
    }

    public object GetListItemByIndex(int index)
    {
      if (index != -1 && dataManager != null)
      {
        return dataManager.List[index];
      }
      else
      {
        return null;
      }
    }

    public override void InEditButtonDownDefaultAction(EditItem inEditControl, DownEventArgs e)
    {
      if (listVisible)
        CloseUp(false);
      else
        DropDown();
      e.Handled = true;
    }

    public void DropDown()
    {
      if (listVisible) return;
      if (ReadOnly && !EditButton.Visible) return;

      dropDownList.ListSourceOrigin = ListSourceOrigin;
      if (DropDownBox.DataSource != null)
        dropDownList.DataSource = DropDownBox.bindingSource;
      else
        dropDownList.DataSource = bindingSource;
      //dropDownList.dataGrid.DataMember = displayMember.BindingPath;
      dropDownList.DisplayMember = displayMember.BindingField;
      dropDownList.ValueMember = valueMember.BindingField;

      if (LookupMode)
        dropDownList.SelectedValue = SelectedValue;
      else
        dropDownList.SelectedIndex = SelectedIndex;

      dropDownList.Grid.Font = DropDownBox.Font;
      dropDownList.Grid.BackColor = DropDownBox.BackColor;
      dropDownList.Grid.ForeColor = DropDownBox.ForeColor;
      dropDownList.Grid.Sizable = DropDownBox.Sizable;

      dropDownList.Grid.RowOptions.HeightOptions.AutoExpand = DropDownBox.RowOptions.HeightOptions.AutoExpand;
      dropDownList.Grid.RowOptions.HeightOptions.ContentHeight = DropDownBox.RowOptions.HeightOptions.ContentHeight;
      dropDownList.Grid.RowOptions.HeightOptions.MaxContentHeight = DropDownBox.RowOptions.HeightOptions.MaxContentHeight;
      dropDownList.Grid.RowOptions.HeightOptions.Unit = DropDownBox.RowOptions.HeightOptions.Unit;

      dropDownList.Grid.RowOptions.HorzLine.Visible = DropDownBox.RowOptions.HorzLine.Visible;
      dropDownList.Grid.RowOptions.HorzLine.Color = DropDownBox.RowOptions.HorzLine.Color;
      dropDownList.Grid.RowOptions.HorzLine.Style = DropDownBox.RowOptions.HorzLine.Style;

      dropDownList.Grid.AutoGenerateColumns = true;
      dropDownList.FilterType = DropDownBox.FilterType;

      Rectangle screenEditRect = RectangleToScreen(ClientRectangle);
      int winWidth;
      if (DropDownBox.Width != 0)
        winWidth = DropDownBox.Width;
      else
        winWidth = Width;

      dropDownList.AlignWindow(screenEditRect, DropDownBox.HeightInRows, winWidth);

      dropDownList.Show();
      dropDownList.ResetOldSizeInfo();
      listVisible = true;
      Application.AddMessageFilter(messageFilter);
    }

    public void CloseUp(bool acceptValue)
    {
      if (!listVisible) return;

      Application.RemoveMessageFilter(messageFilter);
      dropDownList.Hide();
      listVisible = false;

      if (dropDownList.WidthChanged)
        DropDownBox.Width = dropDownList.Width;

      if (dropDownList.HeightChanged)
        DropDownBox.HeightInRows = dropDownList.VisibleRowCount;

      object selectedItem;
      if (acceptValue)
        selectedItem = dropDownList.SelectedItem;
      else
        selectedItem = null;

      var e = new PopupListClosedUpEventArgs(acceptValue, selectedItem);
      DropDownBox.ProcessClosedUp(e);

      if (e.AcceptValue && selectedItem != null && !ReadOnly)
      {
        if (LookupMode)
          SelectedValue = dropDownList.SelectedValue;
        else
          SelectedIndex = dropDownList.SelectedIndex;
        SelectAll();
      }

      dropDownList.FilterText = "";
      dropDownList.DataSource = null;
      dropDownList.DisplayMember = null;
    }

    public bool ProcessInteractiveSearchStr(string str)
    {
      int oldSelLenght;
      bool result = false;

      if (str == "" && TextAutoComplete == false)
      {
        InteractiveLocateStr(Text, false, false);
      }
      else if (str.Length == 1 && str[0] == (char)Keys.Back)
      {
        if (Text.Length == SelectionLength)
        {
          Select(Text.Length, -1);
        }
        else
        {
          oldSelLenght = Math.Abs(SelectionLength);
          Select(Text.Length, -oldSelLenght - 1);
        }
      }
      else
      {
        string s;
        string searchText = "";

        if (Text.Length > 0)
          searchText = Text.Substring(0, SelectionStart);
        s = searchText + str;
        if (!String.IsNullOrEmpty(s))
          result = InteractiveLocateStr(s, true, TextSearchIgnoreCase);
      }

      if (DropDownBox.AutoFilter && listVisible)
      {
        string filterText = Text.Substring(0, SelectionStart);
        dropDownList.FilterText = filterText;
        //dropDownList.SelectedIndex = DropDownBox.;
      }

      return result;
    }

    public bool InteractiveLocateStr(string str, bool partialKey, bool ignoreCase)
    {
      int index;
      int oldSelectedIndex = SelectedIndex;

      index = FindStringInList(str, partialKey, ignoreCase, true);

      if (index >= 0 && TextAutoComplete)
      {
        SetSelectedIndex(index, false);
        UpdateTextFromIndex(false);
        Select(Text.Length, str.Length - Text.Length);
        ScrollToCaret();
      }
      else if (!LimitTextToListValues)
      {
        object oldSelValue = SelectedValue;
        InternalSetSelectedIndex(index);
        if (oldSelectedIndex != SelectedIndex)
        {
          if (LookupMode)
            selectedValueKey = null;
          if (!ValuesEqual(oldSelValue, SelectedValue))
            OnSelectedValueChanged(EventArgs.Empty);
        }
      }

      if (oldSelectedIndex != SelectedIndex)
        return true;
      else
        return false;
    }

    public int FindStringInList(string str, bool partialKey, bool ignoreCase, bool checkDisplayList)
    {
      int result = InternalFindStringInList(str, false, false, checkDisplayList);

      if ((result == -1) && ignoreCase)
        result = InternalFindStringInList(str, true, false, checkDisplayList);

      if ((result == -1) && partialKey)
      {
        result = InternalFindStringInList(str, false, true, checkDisplayList);

        if ((result == -1) && ignoreCase)
          result = InternalFindStringInList(str, true, true, checkDisplayList);
      }

      return result;
    }

    void InternalSetSelectedIndex(int index)
    {
      if (selectedIndex != index)
      {
        CheckSelectedIndex(index);
        selectedIndex = index;
        if (listVisible)
          dropDownList.SelectedIndex = index;
        //  dropDownList.SelectedValue = SelectedValue;
        customAreaControl.Invalidate();
        OnSelectedIndexChanged(EventArgs.Empty);
        //Debug.WriteLine("selectedIndex:" + selectedIndex.ToString());
      }
    }

    void SetSelectedIndex(int index, bool isSelectAll)
    {
      if (selectedIndex == index) return;

      if (LookupMode)
      {
        object item = GetListItemByIndex(index);
        SelectedValue = GetListItemValue(item);
      }
      else
      {
        SetSelectedIndexAsIndex(index);
      }

      if (isSelectAll)
        SelectAll();
    }

    private void SetSelectedIndexAsIndex(int value)
    {
      if (value != selectedIndex)
      {
        CheckSelectedIndex(value);

        //if (value < -1 || value >= itemCount)
        //{
        //  throw new ArgumentOutOfRangeException("SelectedIndex: " + value.ToString() + " is invalid");
        //}

        selectedIndex = value;
        if (!LookupMode && listVisible)
          dropDownList.SelectedIndex = value;
        UpdateTextFromIndex(true);
        customAreaControl.Invalidate();
        OnSelectedIndexChanged(EventArgs.Empty);
      }
    }

    private void CheckSelectedIndex(int value)
    {
      int itemCount = 0;

      if (dataManager != null)
        itemCount = dataManager.Count;

      if (value < -1 || value >= itemCount)
      {
        throw new ArgumentOutOfRangeException("SelectedIndex: " + value.ToString() + " is invalid");
      }
    }

    public bool SelectNextValue()
    {
      if (dataManager != null && !ReadOnly)
      {
        if (DropDownBox.DataSource != null)
        {
          object nextValue;
          if (DropDownBox.GetNextListItemValue(SelectedValue, valueMember.BindingField, out nextValue))
          {
            SelectedValue = nextValue;
            return true;
          }
        }
        else if (SelectedIndex < dataManager.Count - 1)
        {
          for (int i = SelectedIndex + 1; i < dataManager.List.Count; i++)
          {
            object listItem = dataManager.List[i];
            if (ListItemIsSelectable(listItem))
            {
              SelectedIndex = i;
              break;
            }
          }
          return true;
        }
      }

      return false;
    }

    public bool SelectPriorValue()
    {
      if (dataManager != null && !ReadOnly)
      {
        if (DropDownBox.DataSource != null)
        {
          object priorValue;
          if (DropDownBox.GetPriorListItemValue(SelectedValue, valueMember.BindingField, out priorValue))
          {
            SelectedValue = priorValue;
            return true;
          }
        }
        else if (SelectedIndex > 0)
        {
          for (int i = SelectedIndex - 1; i >= 0; i--)
          {
            object listItem = dataManager.List[i];
            if (ListItemIsSelectable(listItem))
            {
              SelectedIndex = i;
              break;
            }
          }
          return true;
        }
      }

      return false;
    }
    #endregion

    #region >methods
    public override void EndInit()
    {
      if (LookupMode)
        UpdateTextFromIndex(true);
      base.EndInit();
    }

    protected override TextBoxBase CreateTextEditControl()
    {
      return new ComboBoxTextEditControl(this);
    }

    protected PropertyDescriptor GetMemberProperty(string memberName)
    {
      if (dataManager != null)
      {
        PropertyDescriptorCollection propCol = dataManager.GetItemProperties();
        return propCol.Find(memberName, true);
      } else
      {
        return null;
      }
    }

    protected int FindInDataManager(PropertyDescriptor property, object key, bool keepIndex)
    {
      //if (key == null)
      //{
      //  throw new ArgumentNullException("key");
      //}
      if (((property != null) && (dataManager.List is IBindingList)) && ((IBindingList)dataManager.List).SupportsSearching)
      {
        return ((IBindingList)dataManager.List).Find(property, key);
      }
      for (int i = 0; i < this.dataManager.List.Count; i++)
      {
        Debug.Assert(property != null, @"property != null");
        object obj2 = property.GetValue(dataManager.List[i]);
        if (ValuesEqual(key, obj2))
        {
          return i;
        }
      }
      return -1;
    }

    protected object FilterItemOnProperty(object item)
    {
      return FilterItemOnProperty(item, displayMember.BindingField);
    }

    protected object FilterItemOnProperty(object item, string field)
    {
      object result = item;

      if (item != null && field.Length > 0)
      {
        // if we have a dataSource, then use that to display the string
        PropertyDescriptor descriptor;
        if (this.dataManager != null)
          descriptor = this.dataManager.GetItemProperties().Find(field, true);
        else
          descriptor = TypeDescriptor.GetProperties(item).Find(field, true);
        if (descriptor != null)
        {
          result = descriptor.GetValue(item);
        }
      }

      return result;
    }

    protected virtual bool ValuesEqual(object x, object y)
    {
      if (x == null && y == null)
        return true;
      else if (x == null)
        return false;
      else if (y == null)
        return false;
      else if (x.GetType() != y.GetType())
        return false;
      else
      {
        IComparable cmp = x as IComparable;
        if (cmp != null)
          return cmp.CompareTo(y) == 0;
        else
          return x.Equals(y);
      }
    }

    private bool BindingMemberInfoInDataManager(BindingMemberInfo bindingMemberInfo)
    {
      if (dataManager == null)
        return false;
      PropertyDescriptorCollection props = dataManager.GetItemProperties();
      int propsCount = props.Count;

      for (int i = 0; i < propsCount; i++)
      {
        if (typeof(IList).IsAssignableFrom(props[i].PropertyType))
          continue;
        if (props[i].Name.Equals(bindingMemberInfo.BindingField))
        {
          return true;
        }
      }

      for (int i = 0; i < propsCount; i++)
      {
        if (typeof(IList).IsAssignableFrom(props[i].PropertyType))
          continue;
        if (string.Compare(props[i].Name, bindingMemberInfo.BindingField, true, CultureInfo.CurrentCulture) == 0)
        {
          return true;
        }
      }

      return false;
    }

    //private void DataManager_PositionChanged(object sender, EventArgs e)
    //{
    //}

    protected virtual void DataManager_ItemChanged(object sender, ItemChangedEventArgs e)
    {
    }

    private void DataManager_ListChanged(object sender, ListChangedEventArgs e)
    {
      if (!Initializing)
      {
        if (LookupMode)
          UpdateRelatedDataFromValue();
        else
          UpdateSelectedIndexFromText();
      }
    }

    private void DataSourceDisposed(object sender, EventArgs e)
    {
      Debug.Assert(sender == this.dataSource, "dispose notification for other than our dataSource?");
      SetDataConnection(null, new BindingMemberInfo(""), true);
    }

    private void DataSourceInitialized(object sender, EventArgs e)
    {
      ISupportInitializeNotification dsInit = (this.dataSource as ISupportInitializeNotification);
      Debug.Assert(dsInit != null, "ListControl: ISupportInitializeNotification.Initialized event received, but current DataSource does not support ISupportInitializeNotification!");
      Debug.Assert(dsInit.IsInitialized, "ListControl: DataSource sent ISupportInitializeNotification.Initialized event but before it had finished initializing.");
      SetDataConnection(this.dataSource, this.displayMember, true);
    }

    private void SetDataConnection(object newDataSource, BindingMemberInfo newDisplayMember, bool force)
    {
      bool dataSourceChanged = (dataSource != newDataSource);
      bool displayMemberChanged = (!displayMember.Equals(newDisplayMember));

      if (inSetDataConnection)
        return;

      try
      {
        if (force || dataSourceChanged || displayMemberChanged)
        {
          inSetDataConnection = true;
          //IList currentList = this.DataManager != null ? this.DataManager.List : null;
          //bool currentManagerIsNull = this.DataManager == null;

          UnwireDataSource();

          dataSource = newDataSource;
          displayMember = newDisplayMember;

          WireDataSource();

          if (isDataSourceInitialized)
          {
            bindingSource.DataSource = DataSource;
            bindingSource.DataMember = displayMember.BindingPath;

            if (dataManager != null && 
                (displayMemberChanged || dataSourceChanged) && 
                !string.IsNullOrEmpty(displayMember.BindingMember))
            {
              //if (!BindingMemberInfoInDataManager(displayMember))
              //  throw new ArgumentException("ListControlWrongDisplayMember");
            }

            if (dataManager != null)
            {
              if (displayMemberChanged)
              {
                DataManager_ItemChanged(dataManager, null);
              }
            }
          }
          //this.displayMemberConverter = null;
        }

        displayMemberProperty = GetMemberProperty(displayMember.BindingField);

        //if (dataSourceChanged)
        //{
        //  OnDataSourceChanged(EventArgs.Empty);
        //}

        //if (displayMemberChanged)
        //{
        //  OnDisplayMemberChanged(EventArgs.Empty);
        //}
      }
      finally
      {
        inSetDataConnection = false;
      }
    }

    private void UnwireDataSource()
    {
      var source = this.dataSource as IComponent;
      if (source != null)
      {
        source.Disposed -= DataSourceDisposed;
      }

      ISupportInitializeNotification dsInit = (this.dataSource as ISupportInitializeNotification);

      if (dsInit != null && isDataSourceInitEventHooked)
      {
        dsInit.Initialized -= DataSourceInitialized;
        isDataSourceInitEventHooked = false;
      }
    }

    private void WireDataSource()
    {
      var source = this.dataSource as IComponent;
      if (source != null)
      {
        source.Disposed += DataSourceDisposed;
      }

      ISupportInitializeNotification dsInit = (this.dataSource as ISupportInitializeNotification);

      if (dsInit != null && !dsInit.IsInitialized)
      {
        dsInit.Initialized += DataSourceInitialized;
        isDataSourceInitEventHooked = true;
        isDataSourceInitialized = false;
      }
      else if (this.dataSource != null)
      {
        isDataSourceInitialized = true;
      }
    }

    private void UpdateTextFromIndex(bool selectAll)
    {
      string newText = "";

      if (dataManager != null && SelectedIndex >= 0 && SelectedIndex < dataManager.Count)
      {
        object rowItem = dataManager.List[SelectedIndex];
        object valItem = FilterItemOnProperty(rowItem);
        if (valItem == null)
          newText = "";
        else
          newText = valItem.ToString();
      }

      if (!ValuesEqual(Text, newText))
        InternalText = newText;
      if (selectAll)
        SelectAll();
    }

    private void UpdateSelectedIndexFromText()
    {
      int index = FindStringInList(Text, false, false, false);
      InternalSetSelectedIndex(index);
    }

    //private void UpdateSelectedIndexFromSelectedValue()
    //{
    //}

    private void AppMouseDown(ref Message m)
    {
      Control ctrl = FromHandle(m.HWnd);
      if (!EhLibManager.DefaultEhLibManager.DropDownDebug)
      {
        if (!(ctrl == this || Contains(ctrl) || ctrl == dropDownList || dropDownList.Contains(ctrl)))
          CloseUp(false);
      }
    }

    protected override void OnGotFocus(EventArgs e)
    {
      base.OnGotFocus(e);
      if (!EhLibManager.DefaultEhLibManager.DropDownDebug)
        SelectAll();
    }

    protected override void OnLostFocus(EventArgs e)
    {
      base.OnLostFocus(e);
      if (!EhLibManager.DefaultEhLibManager.DropDownDebug)
        CloseUp(false);
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
      base.OnKeyDown(e);

      {
      if (listVisible)
        dropDownList.ProcessKeyDown(e);
        if (listVisible && e.Handled && !ReadOnly)
        {
          if (LookupMode)
            SelectedValue = dropDownList.SelectedValue;
          else
            SelectedIndex = dropDownList.SelectedIndex;
        }
      }

      if (!e.Handled)
      {
        switch (e.KeyCode)
        {
          case Keys.Escape:
            if (listVisible)
            {
              CloseUp(false);
              e.Handled = true;
            }
            break;

          case Keys.Delete:
            if (LimitTextToListValues && !ReadOnly)
            {
              SelectedIndex = -1;
              e.Handled = true;
            }
            break;

          case Keys.Up:
            e.Handled = SelectPriorValue();
            break;

          case Keys.Down:
            if (e.Alt && !e.Shift && !e.Control)
            {
              if (listVisible)
                CloseUp(false);
              else
                DropDown();
              e.Handled = true;
            }
            else
              e.Handled = SelectNextValue();
            break;

          case Keys.Enter:
            if (!Multiline)
              e.Handled = true;
            break;
        }
      }

      if (e.Handled)
      {
        e.SuppressKeyPress = true;
      }

    }

    internal int Compare(object item1, object item2)
    {
      throw new NotSupportedException("NotImplemented");
    }

    protected override void OnMouseWheel(MouseEventArgs e)
    {
      base.OnMouseWheel(e);
      HandledMouseEventArgs hme = (HandledMouseEventArgs)e;
      //if (hme != null)
      //{
      if (hme.Handled)
      {
        return;
      }
      hme.Handled = true;
      //}

      if ((ModifierKeys & (Keys.Shift | Keys.Alt)) != 0 || MouseButtons != MouseButtons.None)
      {
        return; // Do not scroll when Shift or Alt key is down, or when a mouse button is down.
      }

      if (e.Delta > 0)
        hme.Handled = SelectPriorValue();
      else if (e.Delta < 0)
        hme.Handled = SelectNextValue();
    }

    protected override void OnTextChanged(EventArgs e)
    {
      //if (UserTextChanged)
      //  UpdateSelectedIndexFromText();          
      base.OnTextChanged(e);
    }

    protected internal override void UserTextChanged()
    {
      userTextChanged = true;
    }

    protected internal override void TextBoxControl_WndProc(ref Message msg, WndProcDelegate baseTextWndProc)
    //protected internal override void TextBoxControl_WndProc(ref Message msg, ref bool handled)
    {
      bool handled = false;
      userTextChanged = false;

      switch (msg.Msg)
      {
        case NativeMethods.WM_CUT:
          WmCut(ref handled);
          break;

        case NativeMethods.WM_PASTE:
          WmPaste(ref handled);
          break;

        case NativeMethods.WM_CLEAR:
          WmClear(ref handled);
          break;
      }

      if (!handled)
        base.TextBoxControl_WndProc(ref msg, baseTextWndProc);

      if (!handled &&
            ((msg.Msg == NativeMethods.WM_CUT) ||
             (msg.Msg == NativeMethods.WM_PASTE) ||
             (msg.Msg == NativeMethods.WM_CLEAR))
         )
      {
        if (userTextChanged == true)
        {
          int oldSelStart = SelectionStart;
          bool ignoreCase = TextSearchIgnoreCase && TextAutoComplete;
          if (InteractiveLocateStr(Text, false, ignoreCase))
          {
            Select(Text.Length, oldSelStart - Text.Length);
          }
        }
      }
    }

    private void WmCut(ref bool handled)
    {
      if (LimitTextToListValues)
      {
        Copy();
        handled = true;
      }
    }

    private void WmPaste(ref bool handled)
    {
      if (LimitTextToListValues && Clipboard.ContainsText())
      {
        ProcessInteractiveSearchStr(Clipboard.GetText());
        handled = true;
      }
    }

    private void WmClear(ref bool handled)
    {
      if (LimitTextToListValues && !ReadOnly)
      {
        SelectedIndex = -1;
        handled = true;
      }
    }

    protected override void OnKeyPress(KeyPressEventArgs e)
    {
      switch (e.KeyChar)
      {
        case (char)Keys.Back:
          if (LimitTextToListValues && !ReadOnly)
          {
            ProcessInteractiveSearchStr(e.KeyChar.ToString());
            e.Handled = true;
          }
          break;
        default:
          if (e.KeyChar >= 32)
          {
            if (DropDownBox.AutoDrop && !listVisible)
              DropDown();
            if (LimitTextToListValues && !ReadOnly)
            {
              if (TextAutoComplete)
                ProcessInteractiveSearchStr(e.KeyChar.ToString());
              e.Handled = true;
            }
          }
          break;
      }
      base.OnKeyPress(e);
    }

    protected internal override void OnKeyPressProcessed(KeyPressEventArgs e)
    {
      int oldSelStart;
      if (userTextChanged &&
          !LimitTextToListValues /*&&
          TextAutoComplete &&
          e.KeyChar != (char)Keys.Delete*/)
      {
        if (( !(SelectionStart == Text.Length && SelectionLength == 0) ||
              (e.KeyChar == (char)Keys.Back)
            )  && TextAutoComplete
           )
        {
          oldSelStart = SelectionStart;
          if (InteractiveLocateStr(Text, false, TextSearchIgnoreCase))
          {
            Select(Text.Length, oldSelStart - Text.Length);
          }

          if (DropDownBox.AutoFilter && listVisible)
          {
            string filterText = Text.Substring(0, SelectionStart);
            dropDownList.FilterText = filterText;
          }
        }
        else
        {
          ProcessInteractiveSearchStr("");
        }
      }
      userTextChanged = false;
    }

    protected internal override void OnKeyDownProcessed(KeyEventArgs e)
    {
      //int oldSelStart;
      if (e.KeyCode == Keys.Delete &&
          userTextChanged &&
          !LimitTextToListValues /*&&
          TextAutoComplete*/
          )
      {
        bool ignoreCase = TextSearchIgnoreCase && TextAutoComplete;
        InteractiveLocateStr(Text, false, ignoreCase);
      }

      userTextChanged = false;
    }

    protected override bool ProcessKeyEventArgs(ref Message m)
    {
      //int oldSelStart;
      //char charCode = unchecked((char)(long)m.WParam);
      bool result = base.ProcessKeyEventArgs(ref m);

      //if ( (m.Msg == NativeMethods.WM_CHAR) &&
      //   //          !LimitTextToListValues and
      //    !(charCode == (char)Keys.Delete))
      ////     not(ssCtrl in KeyDataToShiftState(Message.KeyData))
      //{
      //  if (!(SelectionStart == Text.Length && SelectionLength = 0) ||
      //        (charCode == (char)Keys.Back))
      //  {
      //    oldSelStart = SelectionStart;
      //    //GetItemsList;
      //    if (LocateStr(Text, false))
      //    {
      //      SelectionStart = Text.Length;
      //      SelectionLength = oldSelStart - SelectionStart;
      //    }
      //  }
      //  else
      //  {
      //    ProcessSearchStr("");
      //  }
      //}
      return result;
    }
    //protected internal override bool ProcessKeyMessage(ref Message m)
    //{
    //  return base.ProcessKeyEventArgs(ref m);
    //}

    protected override bool IsInputKey(Keys keyData)
    {
      switch (keyData & Keys.KeyCode)
      {
        case Keys.Enter:
          if (listVisible) return true;
          break;
      }
      return base.IsInputKey(keyData);
    }

    protected virtual void OnSelectedIndexChanged(EventArgs e)
    {
      var handler = Events[EventKeySelectedIndexChanged] as EventHandler;
      if (handler != null)
      {
        handler(this, e);
      }

      //OnSelectedValueChanged(e);
    }

    protected virtual void OnSelectedValueChanged(EventArgs e)
    {
      customAreaControl.Invalidate();
      //if (listVisible)
      //  dropDownList.SelectedValue = SelectedValue;

      var handler = Events[EventKeySelectedValueChanged] as EventHandler;
      if (handler != null)
      {
        handler(this, e);
      }
    }

    private void OnDislpayTextChanged(EventArgs empty)
    {
    }

    protected virtual void LimitTextToListValuesChanged()
    {
    }

    private bool DefaultLimitTextToListValues()
    {
      return !string.IsNullOrEmpty(ValueMember);
    }

    protected virtual bool ShouldSerializeLimitTextToListValues()
    {
      return (limitTextToListValuesStored == true);
    }

    public virtual void ResetLimitTextToListValues()
    {
      limitTextToListValuesStored = false;
      LimitTextToListValuesChanged();
    }

    protected int InternalFindStringInList(string str, bool ignoreCase, bool partialKey, bool checkDisplayList)
    {
      int result = -1;
      //int OldSelectedIndex = SelectedIndex;

      if (checkDisplayList && DropDownBox.DataSource != null)
      {
        string fullStrValue;
        if (CheckDisplayList(str, ignoreCase, partialKey, out fullStrValue))
        {
          str = fullStrValue;
          ignoreCase = false;
          partialKey = false;
        }
        else
        {
          return -1;
        }
      }

      if (dataManager != null)
      {
        for (int i = 0; i < dataManager.List.Count; i++)
        {
          object listItem = dataManager.List[i];
          if (!ListItemIsSelectable(listItem))
            continue;

          object value = GetListItemText(listItem);

          if (value != null)
          {
            string valAsStr = value.ToString();

            if (EhLibUtils.StringEquals(str, valAsStr, ignoreCase, partialKey))
            {
              result = i;
              break;
            }
          }
        }
      }
      return result;
    }

    public bool CheckDisplayList(string str, bool partialKey, bool ignoreCase, out string fullStrValue)
    {
      int result = DropDownBox.FindStringInDataSourceList(str, displayMember.BindingField, partialKey, ignoreCase, out fullStrValue);
      return result >= 0;
    }

    private void CheckNoDataSource(string errorText)
    {
      if (DataSource != null)
      {
        throw new ArgumentException(errorText);
      }
    }

    //private void RefreshItems()
    //{
    //  ObjectCollection savedItems = itemsCollection;
    //  object[] newItems;
    //  newItems = new object[savedItems.Count];
    //  savedItems.CopyTo(newItems, 0);
    //}

    private void ResetItemsConnection()
    {
      if (DataSource == null)
      {
        if (Items.Count > 0)
        {
          bindingSource.DataSource = Items;
          bindingSource.DataMember = "";
        }
        else
        {
          bindingSource.DataSource = null;
          bindingSource.DataMember = "";
        }
      }
    }

    private void ItemsChanged()
    {
      ResetItemsConnection();
    }

    //protected internal override bool IsInEditControlDefaultVisible(EditItem inEditControl)
    //{
    //  return true;
    //}
    protected override bool GetEditItemDefaultVisibleState(EditItem editItem)
    {
        return true;
    }

    //protected override bool EditButtonDefaultVisible()
    //{
    //  return true;
    //}

    protected virtual void OnCompoundChanged()
    {
      RealignControls();
    }

    protected override void SetEditControlBounds(Rectangle editControlAreaBound)
    {
      if (customAreaControl != null)
      {
        if (Compound == ComboBoxCompound.CustomAreaAndTextEditor)
        {
          customAreaControl.Visible = true;
          customAreaControl.Bounds = new Rectangle(editControlAreaBound.Location,
                                                   new Size(CustomAreaWidth, editControlAreaBound.Height));
          customAreaControl.Visible = true;
          editControlAreaBound.X += CustomAreaWidth;
          editControlAreaBound.Width -= CustomAreaWidth;
        }
        else
        {
          customAreaControl.Visible = false;
          customAreaControl.Bounds = Rectangle.Empty;
        }
      }
      base.SetEditControlBounds(editControlAreaBound);
    }

    protected internal virtual void OnCustomAreaPaint(ComboBoxCustomAreaPaintEventArgs e)
    {
      var handler = Events[EventKeyCustomAreaPaint] as EventHandler<ComboBoxCustomAreaPaintEventArgs>;
      if (handler != null)
      {
        handler(this, e);
      }
      if (!e.Handled)
      {
        using (Pen pen = new Pen(ForeColor))
        {
          Rectangle drawRect = e.AreaRect;
          e.Graphics.FillRectangle(new SolidBrush(BackColor), e.AreaRect);
          drawRect.Inflate(-1, -1);
          Rectangle frameRect = drawRect;
          frameRect.Width = frameRect.Width - 1;
          frameRect.Height = frameRect.Height - 1;
          e.Graphics.DrawRectangle(pen, frameRect);
          e.Graphics.DrawLine(pen, frameRect.Location, new Point(frameRect.Right, frameRect.Bottom));
          e.Graphics.DrawLine(pen, new Point(frameRect.Left, frameRect.Bottom), new Point(frameRect.Right, frameRect.Top));
        }
      }
    }

    protected internal virtual void OnTextAreaPaint(ComboBoxTextAreaPaintEventArgs e)
    {
      var handler = Events[EventKeyTextAreaPaint] as EventHandler<ComboBoxTextAreaPaintEventArgs>;
      if (handler != null)
      {
        handler(this, e);
      }
      if (!e.Handled)
      {
        e.DrawContent(e);
      }
    }

    private void UpdateRelatedDataFromValue()
    {
      int newIndex = selectedIndex;

      if (dataManager != null && LookupMode)
      {
        string propertyName = valueMember.BindingField;
        if (string.IsNullOrEmpty(propertyName))
          throw new InvalidOperationException("ListControlEmptyValueMemberInSettingSelectedValue");
        PropertyDescriptorCollection props = dataManager.GetItemProperties();
        PropertyDescriptor property = props.Find(propertyName, true);
        newIndex = FindInDataManager(property, SelectedValue, true);
      }
      if (selectedIndex != newIndex)
      {
        selectedIndex = newIndex;
        OnSelectedIndexChanged(EventArgs.Empty);
      }
      if (LookupMode && listVisible)
        dropDownList.SelectedValue = SelectedValue;
      UpdateTextFromIndex(true);
    }

    private void UpdateRelatedDataFromText()
    {
      int index = FindStringInList(Text, false, false, false);
      if (SelectedIndex != index)
      {
        selectedIndex = index;
        OnSelectedIndexChanged(EventArgs.Empty);
      }
      if (LookupMode)
      {
        object item = GetListItemByIndex(index);
        object newValueKey = GetListItemValue(item);
        if (!ValuesEqual(selectedValueKey, newValueKey))
        {
          selectedValueKey = newValueKey;
          OnSelectedValueChanged(EventArgs.Empty);
        }
      }
    }

    public bool ListItemIsSelectable(object listItem)
    {
      var e = new ComboBoxListItemStatusNeededEventArgs(listItem);
      var handler = Events[EventKeyListItemStatusNeeded] as EventHandler<ComboBoxListItemStatusNeededEventArgs>;
      if (handler != null)
      {
        handler(this, e);
      }
      return e.Selectable;
    }

    protected override void OnVisibleChanged(EventArgs e)
    {
      if (!Visible)
        CloseUp(false);
      base.OnVisibleChanged(e);
    }

    void IObjectCollectionObserver.OnCollectionChangeAction(ObjectCollection collection, CollectionExtendedChangeAction action, int index, object oldItem, object newItem)
    {
      if (action == CollectionExtendedChangeAction.CollectionChanging ||
          action == CollectionExtendedChangeAction.ItemAdding ||
          action == CollectionExtendedChangeAction.ItemChanging ||
          action == CollectionExtendedChangeAction.ItemRemoving)
      {
        CheckNoDataSource("Attempt to change ComboBox.Items when the DataSource != null.");
      }
      else
      {
        ItemsChanged();
      }
    }

    int IObjectCollectionObserver.OnCompareCollectionItems(object item1, object item2)
    {
      string itemName1 = GetListItemText(item1);
      string itemName2 = GetListItemText(item2);

      CompareInfo compInfo = (Application.CurrentCulture).CompareInfo;
      return compInfo.Compare(itemName1, itemName2, CompareOptions.StringSort);
    }

    Color IComboBoxDropDownBoxOwner.GetBackColor()
    {
      return BackColor;
    }

    Color IComboBoxDropDownBoxOwner.GetForeColor()
    {
      return ForeColor;
    }

    Font IComboBoxDropDownBoxOwner.GetFont()
    {
      return Font;
    }
    #endregion methods

    #region internal classes
    //private class ItemComparer : IComparer
    //{
    //  private ComboBoxEh comboBox;

    //  public ItemComparer(ComboBoxEh comboBox)
    //  {
    //    this.comboBox = comboBox;
    //  }

    //  public int Compare(object item1, object item2)
    //  {
    //    if (item1 == null)
    //    {
    //      if (item2 == null)
    //        return 0; //both null, then they are equal

    //      return -1; //item1 is null, but item2 is valid (greater)
    //    }
    //    if (item2 == null)
    //      return 1; //item2 is null, so item 1 is greater

    //    String itemName1 = comboBox.GetItemText(item1);
    //    String itemName2 = comboBox.GetItemText(item2);

    //    CompareInfo compInfo = (Application.CurrentCulture).CompareInfo;
    //    return compInfo.Compare(itemName1, itemName2, CompareOptions.StringSort);
    //  }
    //}

    //[ListBindable(false)]
    //public class ObjectCollection : IList
    //{

    //  private ComboBoxEh owner;
    //  private ArrayList innerList;
    //  private IComparer comparer;

    //  public ObjectCollection(ComboBoxEh owner)
    //  {
    //    this.owner = owner;
    //  }

    //  private IComparer Comparer
    //  {
    //    get
    //    {
    //      if (comparer == null)
    //      {
    //        comparer = new ItemComparer(owner);
    //      }
    //      return comparer;
    //    }
    //  }

    //  private ArrayList InnerList
    //  {
    //    get
    //    {
    //      if (innerList == null)
    //      {
    //        innerList = new ArrayList();
    //      }
    //      return innerList;
    //    }
    //  }

    //  public int Count
    //  {
    //    get
    //    {
    //      return InnerList.Count;
    //    }
    //  }

    //  object ICollection.SyncRoot
    //  {
    //    get
    //    {
    //      return this;
    //    }
    //  }

    //  bool ICollection.IsSynchronized
    //  {
    //    get
    //    {
    //      return false;
    //    }
    //  }

    //  bool IList.IsFixedSize
    //  {
    //    get
    //    {
    //      return false;
    //    }
    //  }

    //  public bool IsReadOnly
    //  {
    //    get
    //    {
    //      return false;
    //    }
    //  }

    //  public int Add(object item)
    //  {
    //    owner.CheckNoDataSource();
    //    int index = AddInternal(item);
    //    //if (owner.UpdateNeeded() && owner.AutoCompleteSource == AutoCompleteSource.ListItems)
    //    //{
    //    //  owner.SetAutoComplete(false, false);
    //    //}
    //    return index;
    //  }


    //  private int AddInternal(object item)
    //  {

    //    if (item == null)
    //    {
    //      throw new ArgumentNullException("item");
    //    }
    //    int index = -1;
    //    if (!owner.sorted)
    //    {
    //      InnerList.Add(item);
    //    }
    //    else
    //    {
    //      index = InnerList.BinarySearch(item, Comparer);
    //      if (index < 0)
    //      {
    //        index = ~index; // getting the index of the first element that is larger than the search value
    //      }

    //      Debug.Assert(index >= 0 && index <= InnerList.Count, "Wrong index for insert");

    //      InnerList.Insert(index, item);
    //    }

    //    return index;
    //  }

    //  int IList.Add(object item)
    //  {
    //    return Add(item);
    //  }

    //  public void AddRange(object[] items)
    //  {
    //    owner.CheckNoDataSource();
    //    //owner.BeginUpdate();
    //    try
    //    {
    //      AddRangeInternal(items);
    //    }
    //    finally
    //    {
    //      //owner.EndUpdate();
    //      owner.ItemsChanged();
    //    }
    //  }

    //  internal void AddRangeInternal(IList items)
    //  {

    //    if (items == null)
    //      throw new ArgumentNullException("items");

    //    foreach (object item in items)
    //    {
    //      AddInternal(item);
    //    }

    //    //if (owner.AutoCompleteSource == AutoCompleteSource.ListItems)
    //    //{
    //    //  owner.SetAutoComplete(false, false);
    //    //}
    //  }

    //  [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    //  public virtual object this[int index]
    //  {
    //    get
    //    {
    //      if (index < 0 || index >= InnerList.Count)
    //      {
    //        throw new ArgumentOutOfRangeException("index", "InvalidArgument");
    //      }

    //      return InnerList[index];
    //    }

    //    set
    //    {
    //      owner.CheckNoDataSource();
    //      SetItemInternal(index, value);
    //    }
    //  }

    //  public void Clear()
    //  {
    //    owner.CheckNoDataSource();
    //    ClearInternal();
    //  }

    //  internal void ClearInternal()
    //  {
    //    InnerList.Clear();
    //    owner.selectedIndex = -1;
    //  }

    //  public bool Contains(object value)
    //  {
    //    return IndexOf(value) != -1;
    //  }

    //  public void CopyTo(object[] destination, int arrayIndex)
    //  {
    //    InnerList.CopyTo(destination, arrayIndex);
    //  }

    //  void ICollection.CopyTo(Array destination, int index)
    //  {
    //    InnerList.CopyTo(destination, index);
    //  }

    //  public IEnumerator GetEnumerator()
    //  {
    //    return InnerList.GetEnumerator();
    //  }

    //  public int IndexOf(object value)
    //  {
    //    if (value == null)
    //    {
    //      throw new ArgumentNullException("value");
    //    }

    //    return InnerList.IndexOf(value);
    //  }

    //  public void Insert(int index, object item)
    //  {
    //    owner.CheckNoDataSource();

    //    if (item == null)
    //    {
    //      throw new ArgumentNullException("item");
    //    }

    //    if (index < 0 || index > InnerList.Count)
    //    {
    //      throw new ArgumentOutOfRangeException("index", "InvalidArgument");
    //    }

    //    if (owner.sorted)
    //      Add(item);
    //    else
    //      InnerList.Insert(index, item);
    //  }

    //  public void RemoveAt(int index)
    //  {
    //    owner.CheckNoDataSource();

    //    if (index < 0 || index >= InnerList.Count)
    //      throw new ArgumentOutOfRangeException("index", "InvalidArgument");

    //    InnerList.RemoveAt(index);

    //    if (!owner.IsHandleCreated && index < owner.selectedIndex)
    //    {
    //      owner.selectedIndex--;
    //    }
    //  }

    //  public void Remove(object value)
    //  {

    //    int index = InnerList.IndexOf(value);

    //    if (index != -1)
    //    {
    //      RemoveAt(index);
    //    }
    //  }

    //  internal void SetItemInternal(int index, object value)
    //  {
    //    if (value == null)
    //      throw new ArgumentNullException("value");

    //    if (index < 0 || index >= InnerList.Count)
    //      throw new ArgumentOutOfRangeException("index", "InvalidArgument");

    //    InnerList[index] = value;

    //  }

    //}
    private class ComboBoxMessageFilter : IMessageFilter
    {
      private readonly ComboBoxEh comboBox;

      public ComboBoxMessageFilter(ComboBoxEh comboBox)
      {
        this.comboBox = comboBox;
      }

      bool IMessageFilter.PreFilterMessage(ref Message m)
      {
        if (m.Msg == NativeMethods.WM_LBUTTONDOWN ||
            m.Msg == NativeMethods.WM_RBUTTONDOWN ||
            m.Msg == NativeMethods.WM_MBUTTONDOWN ||
            m.Msg == NativeMethods.WM_NCLBUTTONDOWN ||
            m.Msg == NativeMethods.WM_NCRBUTTONDOWN ||
            m.Msg == NativeMethods.WM_NCMBUTTONDOWN
           )
        {
          comboBox.AppMouseDown(ref m);
        }
        return false;
      }
    }
    #endregion internal classes
  }

  [ToolboxItem(false)]
  public class ComboBoxTextEditControl : TextEditControl
  {
    private bool mouseActive;

    public ComboBoxTextEditControl(BaseTextBoxEh textBox) : base(textBox)
    {
    }

    protected override CreateParams CreateParams
    {
      get
      {
        CreateParams createParams = base.CreateParams;
        createParams.Style = createParams.Style | NativeMethods.ES_MULTILINE;
        return createParams;
      }
    }

    public ComboBoxEh ComboBox
    {
      get
      {
        return (ComboBoxEh)TextBox;
      }
    }

    protected override void WndProc(ref Message m)
    {
      switch (m.Msg)
      {
        case NativeMethods.WM_LBUTTONDOWN:
          break;

        case NativeMethods.WM_MOUSEACTIVATE:
          break;

      }

      base.WndProc(ref m);

      switch (m.Msg)
      {
        case NativeMethods.WM_SETFOCUS:
          SelectAll();
          break;

        case NativeMethods.WM_ACTIVATE:
          SelectAll();
          break;

        case NativeMethods.WM_LBUTTONDOWN:
          if (mouseActive == true)
          {
            mouseActive = false;
            SelectAll();
          }
          break;

        case NativeMethods.WM_MOUSEACTIVATE:
          if (!Focused)
            mouseActive = true;
          break;

      }
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
      //int ss = SelectionStart;
      //int sl = SelectionLength;
      base.OnMouseDown(e);
      //ss = SelectionStart;
      //sl = SelectionLength;
    }

    protected override void OnMouseWheel(MouseEventArgs e)
    {
      base.OnMouseWheel(e);
      if (e.Delta > 0)
        ComboBox.SelectPriorValue();
      else if (e.Delta < 0)
        ComboBox.SelectNextValue();
    }

    protected override void OnGotFocus(EventArgs e)
    {
      base.OnGotFocus(e);
    }

    //protected override void OnActivated(EventArgs e)
    //{

    //}

  }

  /// <summary>
  /// Row options for DroppedDownBox of ComboBoxEh
  /// </summary>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class ComboBoxDropDownBoxRowOptions : IGridLineHost, IGridRowHeightOptionsOwner
  {
    #region privates
    private readonly GridLine horzLine;
    private readonly GridRowHeightOptions heightOptions;
    private readonly ComboBoxDropDownBox dropDownBox;
    #endregion

    #region constructor
    public ComboBoxDropDownBoxRowOptions(ComboBoxDropDownBox dropDownBox)
    {
      this.dropDownBox = dropDownBox;
      horzLine = new GridLine(this);
      heightOptions = new GridRowHeightOptions(this);
    }
    #endregion

    #region design-time properties
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridRowHeightOptions HeightOptions
    {
      get
      {
        return heightOptions;
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridLine HorzLine
    {
      get
      {
        return horzLine;
      }
    }
    #endregion

    #region methods
    //IGridLineHost
    void IGridLineHost.GridLineChanged(GridLine gl)
    {
      dropDownBox.RowOptionsLineChanged();
    }

    bool IGridLineHost.GridLineDefaultVisible(GridLine gl)
    {
      return dropDownBox.RowOptionsHorzLineDefaultVisible();
    }

    Color IGridLineHost.GridLineDefaultColor(GridLine gl)
    {
      return dropDownBox.RowOptionsHorzLineDefaultColor();
    }

    DashStyle IGridLineHost.GridLineDefaultStyle(GridLine gl)
    {
      return DashStyle.Solid;
    }

    //IGridRowHeightOptionsOwner
    void IGridRowHeightOptionsOwner.HeightOptionsChanged(GridRowHeightOptions heightOptions)
    {
      dropDownBox.RowOptinsHeightOptionsChanged();
    }

    bool IGridRowHeightOptionsOwner.HeightOptionsDefaultAutoExpand(GridRowHeightOptions heightOptions)
    {
      return false;
    }

    int IGridRowHeightOptionsOwner.HeightOptionsDefaultContentHeight(GridRowHeightOptions heightOptions)
    {
      return 1;
    }

    int IGridRowHeightOptionsOwner.HeightOptionsDefaultMaxContentHeight(GridRowHeightOptions heightOptions)
    {
      return 0;
    }

    GridRowHeightUnit IGridRowHeightOptionsOwner.HeightOptionsDefaultUnit(GridRowHeightOptions heightOptions)
    {
      return GridRowHeightUnit.TextLine;
    }

    //Other
    #endregion
  }

  public interface IComboBoxDropDownBoxOwner
  {
    Color GetBackColor();
    Color GetForeColor();
    Font GetFont();
  }

  /// <summary>
  ///       Defines properties for DroppedDown list box of ComboBoxEh
  /// </summary>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class ComboBoxDropDownBox : Component
  {

    #region private consts
    private static readonly object EventKeyDataCellFormatParamsNeeded = new object();
    private static readonly object EventKeyDataCellPaint = new object();
    private static readonly object EventKeyClosedUp = new object();
    #endregion

    #region privates
    private IComboBoxDropDownBoxOwner owner;
    private readonly ComboBoxDropDownBoxRowOptions rowOptions;
    private Color backColor = Color.Empty;
    private bool backColorStored;
    private Color foreColor = Color.Empty;
    private bool foreColorStored;
    private Font font;
    private object dataSource;
    internal readonly BindingSource bindingSource;
    #endregion

    #region constructor
    public ComboBoxDropDownBox(IComboBoxDropDownBoxOwner owner)
    {
      this.owner = owner;
      rowOptions = new ComboBoxDropDownBoxRowOptions(this);
      HeightInRows = 20;
      Sizable = true;
      bindingSource = new BindingSource();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        DataSource = null;
        bindingSource.Dispose();
      }
      base.Dispose(disposing);
    }
    #endregion

    #region design-time properties
    /// <summary>
    ///     Controls text alignment in the DroppedDown list box.
    /// </summary>
    [DefaultValue(DropDownAlign.Left)]
    public DropDownAlign Align { get; set; }

    /// <summary>
    ///     Indicates whether the list box is shown immediately on first key press in the editbox.
    /// </summary>
    [DefaultValue(false)]
    public bool AutoDrop { get; set; }

    /// <summary>
    ///       Specify the height of the DroppedDown list box unsing hight of one row 
    ///       in the list as a measure unit
    /// </summary>
    [DefaultValue(20)]
    public int HeightInRows { get; set; }

    /// <summary>
    ///       Indicates whether to show SizeGrip in the corner of the list
    ///       SizeGrip allows to resize list using mouse
    /// </summary>
    [DefaultValue(true)]
    public bool Sizable { get; set; }

    /// <summary>
    ///       Specify the width of the DroppedDown list box.
    ///       0 means that the width of the list box will be same as width of editBox.
    /// </summary>
    [DefaultValue(0)]
    public int Width { get; set; }

    /// <summary>
    ///       Define options of a row in the DroppedDow list box.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public ComboBoxDropDownBoxRowOptions RowOptions
    {
      get { return rowOptions; }
    }

    /// <summary>
    ///     Indicates whether the list values of DroppedDownBox should by filtered
    ///     by the value of the typed text in the editor
    /// </summary>
    [DefaultValue(false)]
    public bool AutoFilter { get; set; }

    /// <summary>
    ///     The type of filtering of rows when AutoFilter = true.  
    ///     The value would come from EhLib.ComboBoxFilterType enumeration.
    /// </summary>
    [DefaultValue(ComboBoxFilterType.StartOfText)]
    public ComboBoxFilterType FilterType { get; set; }

    /// <summary>
    ///     The background color of this DroppedDown list box.
    /// </summary>
    public Color BackColor
    {
      get
      {
        if (backColorStored)
          return backColor;
        else
          return DefaultBackColor();
      }
      set
      {
        if ((backColorStored == false) || (backColor != value))
        {
          backColorStored = true;
          backColor = value;
          BackColorChanged();
        }
      }
    }

    /// <summary>
    ///  The foreground color of the DroppedDown list box.
    /// </summary>
    public Color ForeColor
    {
      get
      {
        if (foreColorStored)
          return foreColor;
        else
          return DefaultForeColor();
      }
      set
      {
        if ((foreColorStored == false) || (foreColor != value))
        {
          foreColorStored = true;
          foreColor = value;
          ForeColorChanged();
        }
      }
    }

    /// <summary>
    ///     Retrieves the current font for DroppedDown list box.
    /// </summary>
    public Font Font
    {
      get
      {
        if (font != null)
          return font;
        else
          return DefaultFont();
      }
      set
      {
        font = value;
        FontChanged();
      }
    }

    /// <summary>
    /// Gets or sets the data source for DropDownBox. 
    /// </summary>
    /// <remarks>
    /// Assign this property when list of items in DropDownBox should be different from items in the <see cref="ComboBoxEh.DataSource"/>.
    /// </remarks>
    [Category("Data")]
    [DefaultValue(null)]
    [RefreshProperties(RefreshProperties.Repaint)]
    [AttributeProvider(typeof(IListSource))]
    public object DataSource
    {
      get
      {
        return dataSource;
      }

      set
      {
        if (dataSource != value)
        {
          if (dataSource != null)
          {
            var sourceAsComponent = this.dataSource as IComponent;
            if (sourceAsComponent != null)
            {
              sourceAsComponent.Disposed -= DataSourceDisposed;
            }
          }

          dataSource = value;
          bindingSource.DataSource = value;

          if (dataSource != null)
          {
            var source = this.dataSource as IComponent;
            if (source != null)
            {
              source.Disposed += DataSourceDisposed;
            }
          }
        }
      }
    }
    #endregion

    #region Events
    /// <summary>
    /// Occurs when a "data" cell paint params like BackColor, Font, etc should be specified.
    /// </summary>
    public event EventHandler<DataGridDataCellFormatParamsNeededEventArgs> DataCellFormatParamsNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellFormatParamsNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellFormatParamsNeeded, value);
      }
    }

    /// <summary>
    /// Occurs when a cell in the grid data area needs to be drawn.
    /// </summary>
    public event EventHandler<DataGridDataCellPaintEventArgs> DataCellPaint
    {
      add
      {
        Events.AddHandler(EventKeyDataCellPaint, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellPaint, value);
      }
    }

    public event EventHandler<PopupListClosedUpEventArgs> ClosedUp
    {
      add
      {
        Events.AddHandler(EventKeyClosedUp, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyClosedUp, value);
      }
    }
    #endregion

    #region run-time properties
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public IComboBoxDropDownBoxOwner Owner
    {
      get
      {
        return owner;
      }
      set
      {
        owner = value;
      }
    }
    #endregion

    #region methods
    //BackColor
    protected virtual void BackColorChanged()
    {
    }

    public virtual Color DefaultBackColor()
    {
      if (owner != null)
        return owner.GetBackColor();
      else
        return Color.Empty;
    }

    protected virtual bool ShouldSerializeBackColor()
    {
      return (backColorStored == true);
    }

    public virtual void ResetBackColor()
    {
      backColorStored = false;
      BackColorChanged();
    }

    //ForeColor
    protected virtual void ForeColorChanged()
    {
    }

    public virtual Color DefaultForeColor()
    {
      if (owner != null)
        return owner.GetForeColor();
      else
        return Color.Empty;
    }

    protected internal virtual bool ShouldSerializeForeColor()
    {
      return (foreColorStored == true);
    }

    public virtual void ResetForeColor()
    {
      foreColorStored = false;
      ForeColorChanged();
    }

    //Font
    protected virtual void FontChanged()
    {
    }

    public virtual Font DefaultFont()
    {
      if (owner != null)
        return owner.GetFont();
      else
        return null;
    }

    public virtual bool ShouldSerializeFont()
    {
      return (font != null);
    }

    public virtual void ResetFont()
    {
      if (font != null)
      {
        font = null;
        FontChanged();
      }
    }

    //Other
    internal void RowOptinsHeightOptionsChanged()
    {
    }

    internal Color RowOptionsHorzLineDefaultColor()
    {
      return SystemColors.ButtonFace;
    }

    internal bool RowOptionsHorzLineDefaultVisible()
    {
      return false;
    }

    internal void RowOptionsLineChanged()
    {
    }

    private void DataSourceDisposed(object sender, EventArgs e)
    {
      Debug.Assert(sender == DataSource, "dispose notification for other than our dataSource?");
      DataSource = null;
    }

    public int FindStringInDataSourceList(string str, string propertyName, bool ignoreCase, bool partialKey, out string fullStrValue)
    {
      string valAsStr;
      int result = -1;
      fullStrValue = null;
      PropertyDescriptor descriptor = bindingSource.GetItemProperties(null).Find(propertyName, true);

      if (bindingSource != null)
      {
        for (int i = 0; i < bindingSource.List.Count; i++)
        {
          object listValue = bindingSource.List[i];
          object value = descriptor.GetValue(listValue);

          if (value != null)
          {
            valAsStr = value.ToString();

            if (EhLibUtils.StringEquals(str, valAsStr, ignoreCase, partialKey))
            {
              result = i;
              fullStrValue = valAsStr;
              break;
            }
          }
        }
      }
      return result;
    }

    protected virtual bool ValuesEqual(object x, object y)
    {
      if (x == null && y == null)
        return true;
      else if (x == null)
        return false;
      else if (y == null)
        return false;
      else if (x.GetType() != y.GetType())
        return false;
      else
      {
        IComparable cmp = x as IComparable;
        if (cmp != null)
          return cmp.CompareTo(y) == 0;
        else
          return x.Equals(y);
      }
    }

    public bool GetNextListItemValue(object curValue, string propertyName, out object nextValue)
    {
      return GetNextPriorListItemValue(curValue, propertyName, out nextValue, true);
    }

    public bool GetPriorListItemValue(object curValue, string propertyName, out object nextValue)
    {
      return GetNextPriorListItemValue(curValue, propertyName, out nextValue, false);
    }

    public bool GetNextPriorListItemValue(object curValue, string propertyName, out object nextValue, bool isNext)
    {
      int foundCurPos = -1;
      PropertyDescriptor descriptor = bindingSource.GetItemProperties(null).Find(propertyName, true);

      if (bindingSource == null ||
          bindingSource.List == null ||
          bindingSource.List.Count == 0)
      {
        nextValue = null;
        return false;
      }

      for (int i = 0; i < bindingSource.List.Count; i++)
      {
        object listValue = bindingSource.List[i];
        object value = descriptor.GetValue(listValue);

        if (ValuesEqual(value, curValue))
        {
          foundCurPos = i;
          break;
        }
      }

      if (foundCurPos == -1)
      {
        object listValue;
        if (isNext) 
          listValue = bindingSource.List[0];
        else
          listValue = bindingSource.List[bindingSource.List.Count - 1];
        nextValue = descriptor.GetValue(listValue);
        return true;
      }
      else if (isNext && foundCurPos == bindingSource.List.Count - 1)
      {
        nextValue = null;
        return false;
      }
      else if (!isNext && foundCurPos == 0)
      {
        nextValue = null;
        return false;
      }
      else
      {
        object listValue;
        if (isNext)
          listValue = bindingSource.List[foundCurPos + 1];
        else
          listValue = bindingSource.List[foundCurPos - 1];
        nextValue = descriptor.GetValue(listValue);
        return true;
      }
    }

    protected internal virtual void HandleFormatParamsNeededEvent(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
      var eh = Events[EventKeyDataCellFormatParamsNeeded] as EventHandler<DataGridDataCellFormatParamsNeededEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellFormatParamsNeededEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal virtual void HandleDataCellPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = Events[EventKeyDataCellPaint] as EventHandler<DataGridDataCellPaintEventArgs>;
      if (eh != null)
      {
        var ge = new DataGridDataCellPaintEventArgs(e);
        eh(this, ge);
      }
    }

    protected internal virtual void ProcessClosedUp(PopupListClosedUpEventArgs e)
    {
      var eh = Events[EventKeyClosedUp] as EventHandler<PopupListClosedUpEventArgs>;
      if (eh != null)
      {
        eh(this, e);
      }
    }
    #endregion
  }

}
