﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2019 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{
  public interface IRadioButtonDataCellHolder
  {
    void SetCheckedStateAsChecked(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar);
  }

  /// <summary>
  /// Defines a type of data cell manager that displays a readio button user interface (UI). 
  /// </summary>
  //[DataCellDesignTimeVisible(true)]
  //[ToolboxItem(true)]
  [DataCellDesignTimeVisible(true)]
  public class RadioButtonDataCellManager : ButtonBaseDataCellManager
  {

    #region privates
    //private static Type checkStateType = typeof(System.Windows.Forms.CheckState);
    private static readonly Type BooleanType = typeof(bool);

    object trueValue;
    object falseValue;
    private FlatStyle flatStyle;
    #endregion privates

    public RadioButtonDataCellManager()
    {
      flatStyle = FlatStyle.Standard;
    }

    #region properties
    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object TrueValue
    {
      get
      {
        return this.trueValue;
      }
      set
      {
        if (this.trueValue != value)
        {
          this.trueValue = value;
          if (BoundGrid != null)
            BoundGrid.InvalidateGrid();
        }
      }
    }

    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object FalseValue
    {
      get
      {
        return this.falseValue;
      }
      set
      {
        if (this.falseValue != value)
        {
          this.falseValue = value;
          if (BoundGrid != null)
            BoundGrid.InvalidateGrid();
        }
      }
    }

    [DefaultValue(FlatStyle.Standard)]
    public FlatStyle FlatStyle
    {
      get
      {
        return this.flatStyle;
      }
      set
      {
        if (this.flatStyle != value)
        {
          flatStyle = value;
          if (BoundGrid != null)
            BoundGrid.InvalidateGrid();
        }
      }
    }
    #endregion

    #region Methods
    public bool GetCheckedStateFromValue(object value)
    {
      bool result;

      if (value == null)
        result = false;
      else if (TrueValue != null && value.Equals(TrueValue))
        result = true;
      else if (FalseValue != null && value.Equals(FalseValue))
        result = false;
      //else if (IndeterminateValue != null && value.Equals(IndeterminateValue))
      //  result = CheckState.Indeterminate;
      else if (value.Equals(true))
        result = true;
      else if (value.Equals(false))
        result = false;
      else
        result = false;

      return result;
    }

    public void SetCheckedStateAsChecked(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      IRadioButtonDataCellHolder radioButtonHolder = propAxisBar as IRadioButtonDataCellHolder;
      if (radioButtonHolder != null)
        radioButtonHolder.SetCheckedStateAsChecked(propAxisBar, listItemBar);
    }

    public virtual bool GetCheckedState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      object value = propAxisBar.GetListItemBarValue(listItemBar);
      bool result = GetCheckedStateFromValue(value);
      return result;
    }

    public RadioButtonState GetRadioButtonState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      bool cState = GetCheckedState(propAxisBar, listItemBar);
      if (cState == true)
        return RadioButtonState.CheckedNormal;
      else
        return RadioButtonState.UncheckedNormal;
    }

    public void SetCheckedState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, bool isChecked)
    {
      IRadioButtonDataCellHolder radioButtonHolder = propAxisBar as IRadioButtonDataCellHolder;
      if (radioButtonHolder != null)
      {
        if (isChecked == true)
          SetCheckedStateAsChecked(propAxisBar, listItemBar);
      }
      else
      {
        object value = GetDataValueFromCheckState(propAxisBar, listItemBar, isChecked);
        propAxisBar.Grid.SetDataValue(propAxisBar, value);
      }
    }

    public object GetDataValueFromCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, bool isChecked)
    {
      object result = null;

      if (isChecked)
      {
        if (TrueValue != null)
        {
          result = TrueValue;
        }
        else
        {
          if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(BooleanType))
            result = true;
        }
      }
      else
      {
        if (FalseValue != null)
        {
          result = FalseValue;
        }
        else
        {
          if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(BooleanType))
            result = false;
        }
      }

      return result;
    }

    public bool NextCheckedState(PropertyAxisBar propAxisBar, bool checkedState)
    {
      IRadioButtonDataCellHolder radioButtonHolder = propAxisBar as IRadioButtonDataCellHolder;
      if (radioButtonHolder != null)
        return true;
      else
        return !checkedState;
    }

    public override void Toggle(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      bool cbState = GetCheckedState(propAxisBar, listItemBar);
      cbState = NextCheckedState(propAxisBar, cbState);
      SetCheckedState(propAxisBar, listItemBar, cbState);
    }

    //protected override void PaintForeground(DataAxisGridDataCellPaintEventArgs e)
    //{
    //  Rectangle chRect = new Rectangle();
    //  bool isHot = false;
    //  bool isDown = false;
    //  GridCoord mouseHolderCellCoord = e.Grid.MouseHolderCellCoord;

    //  RadioButtonState cbState = GetRadioButtonState(e.PropAxisBar, e.ListItemBar);
    //  Size cbSize = RadioButtonRenderer.GetGlyphSize(e.Graphics, cbState);
    //  chRect.Size = cbSize;
    //  chRect = EhLibUtils.RectCenter(chRect, e.CellRect);

    //  if (DownState && (e.Grid.CurrentDataRowIndex == e.AreaRowIndex))
    //  {
    //    isDown = true;
    //  }
    //  else if (!DownState &&
    //            mouseHolderCellCoord.X == e.ColIndex &&
    //            mouseHolderCellCoord.Y == e.RowIndex
    //            )
    //  {
    //    isHot = true;
    //  }

    //  //      ButtonState
    //  cbState = EhLibUtilsInternal.FixRadioButtonStateByState(cbState, isHot, isDown, true);

    //  RadioButtonRenderer.DrawRadioButton(e.Graphics, chRect.Location, cbState);
    //}

    protected internal override void OnPaintContent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      Rectangle chRect = new Rectangle();
      bool isHot = false;
      bool isDown = false;
      GridCoord mouseHolderCellCoord = e.Grid.MouseHolderCellCoord;

      RadioButtonState cbState = GetRadioButtonState(e.PropAxisBar, e.ListItemBar);

      if (DownState && (e.Grid.CurrentDataRowIndex == e.DataRowIndex))
      {
        isDown = true;
      }
      else if (!DownState &&
                mouseHolderCellCoord.X == e.ColIndex &&
                mouseHolderCellCoord.Y == e.RowIndex
                )
      {
        isHot = true;
      }

      cbState = EhLibUtilsInternal.FixRadioButtonStateByState(cbState, isHot, isDown, true);

      ////
      //Size cbSize = RadioButtonRenderer.GetGlyphSize(e.Graphics, cbState);
      //chRect.Size = cbSize;
      //chRect = EhLibUtils.RectCenter(chRect, e.CellContentRect);
      //RadioButtonRenderer.DrawRadioButton(e.Graphics, chRect.Location, cbState);

      ////
      EhLibRadioButtonRenderer cbRenderer = EhLibRenderManager.DefaultEhLibRenderManager.RadioButtonRenderer;

      Size cbSize = cbRenderer.GetGlyphSize(e.Graphics, cbState);
      chRect = EhLibUtils.RectCenter(chRect, e.CellContentRect);
      cbRenderer.DrawRadioButton(e.Graphics, chRect, cbState);
    }

    public override string GetTypeNameAbbr()
    {
      return "RdBtn";
    }
    #endregion Methods
  }

}
