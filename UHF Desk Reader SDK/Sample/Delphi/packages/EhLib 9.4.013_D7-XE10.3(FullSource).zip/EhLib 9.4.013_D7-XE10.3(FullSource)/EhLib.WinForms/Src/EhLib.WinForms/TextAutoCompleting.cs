﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2019 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Design;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  /// <summary>
  /// Specifies the source of strings for automatic completion in text editors
  /// </summary>
  public enum TextAutoCompletingSourceType
  {
    /// <summary>
    /// Source of strings is the StringCollection property
    /// </summary>
    StringCollection,

    /// <summary>
    /// Source of strings is the DataSource and DataMember properties
    /// </summary>
    DataSource,

    /// <summary>
    /// Source of strings is the DataSource that is bound to the Text property of the text editor
    /// </summary>
    BindDataSource

    //,CustomSource
  }

  /// <summary>
  /// Specifies the mode for the automatic completion feature used in the 
  /// <see cref="BaseTextBoxEh"/> control and <see cref="DataGridTextColumn"/> component.
  /// </summary>
  /// <seealso cref="TextAutoCompleting.CompleteMode"/>
  public enum TextAutoCompletingCompleteMode
  {
    /// <summary>
    /// Displays the auxiliary drop-down list associated with the edit control. 
    /// This drop-down is populated with one or more suggested completion strings
    /// </summary>
    Suggest

    //Append mode is not supported in this version of the Library.
    /*, Append*/
  }

  /// <summary>
  /// Specifies the type of matching a text when the completion process find and filter items in completion source.
  /// </summary>
  public enum TextAutoCompletingMatching
  {
    StartOfItem, AnyPartOfItem
  }

  /// <summary>
  ///  Defines properties to customize automatic completion in text editors like TextBoxEh.
  /// </summary>
  /// <remarks>
  /// You can retrieve an instance of this class through the <see cref="TextAutoCompleting.DataSourceParams"/> property.
  /// </remarks>
  [DesignerCategory("Code")]
  [ToolboxItem(false)]
  public class TextAutoCompleting : Component
  {
    private EventHandler onCompletingSourceChanged;

    public TextAutoCompleting()
    {
      DataSourceParams = new TextAutoCompletingSource(this);
      ShowListOnClickWhenEmpty = true;
      Shortcut = Shortcut.AltDownArrow;
      DropDownListWidth = 0;
    }

    #region> design-time properties
    [DefaultValue(false)]
    public bool Active { get; set; }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public TextAutoCompletingSource DataSourceParams { get; internal set; }

    [DefaultValue(Shortcut.AltDownArrow)]
    public Shortcut Shortcut { get; set; }

    [DefaultValue(true)]
    public bool ShowListOnClickWhenEmpty { get; set; }

    //[DefaultValue(false)]
    //public bool AutoAppend { get; set; }

    [DefaultValue(TextAutoCompletingMatching.StartOfItem)]
    public TextAutoCompletingMatching Match { get; set; }
    #endregion< design-time properties

    #region> run-time properties
    [DefaultValue(TextAutoCompletingCompleteMode.Suggest)]
    [Browsable(false)]
    public TextAutoCompletingCompleteMode CompleteMode { get; set; }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int DropDownListWidth { get; set; }
    #endregion< run-time properties

    #region> events
    [Browsable(false)]
    public event EventHandler CollectionChanged
    {
      add {onCompletingSourceChanged += value; }
      remove {onCompletingSourceChanged -= value; }
    }
    #endregion< events

    #region> methods
    protected internal virtual void CompletingSourceChanged()
    {
      if (onCompletingSourceChanged != null)
      {
        onCompletingSourceChanged(this, EventArgs.Empty);
      }
    }
    #endregion< methods
  }

  /// <summary>
  ///  Defines properties to customize data source for automatic completion.
  /// </summary>
  /// <remarks>
  /// You can retrieve an instance of this class through the <see cref="TextBoxEh.AutoCompleting"/> property.
  /// </remarks>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class TextAutoCompletingSource
  {
    #region> privates
    private readonly BindingSource sourceTracker;
    private bool dataSourceChanged;
    private TextAutoCompletingSourceType sourceType;
    #endregion< privates

    public TextAutoCompletingSource(TextAutoCompleting autoCompleting)
    {
      AutoCompleting = autoCompleting;
      StringCollection = new AutoCompleteStringCollectionEh();
      StringCollection.CollectionChanged += StringCollectionChanged;
      DataPropertyName = "";

      sourceTracker = new BindingSource();
      sourceTracker.ListChanged += SourceTracker_ListChanged;
    }

    #region> design-time properties
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    [Localizable(true)]
    //[Editor("System.Windows.Forms.Design.ListControlStringCollectionEditor", typeof(UITypeEditor))]
    [Editor("System.Windows.Forms.Design.StringCollectionEditor", typeof(UITypeEditor))]
    [MergableProperty(false)]
    public AutoCompleteStringCollectionEh StringCollection { get; internal set; }

    [TypeConverter("System.Windows.Forms.Design.DataSourceConverter, System.Design")]
    [DefaultValue(null)]
    public object DataSource { get; set; }

    //[Editor("System.Windows.Forms.Design.DataMemberListEditor, System.Design", "System.Drawing.Design.UITypeEditor, System.Drawing")]
    //[DefaultValue(null)]
    //public string DataMember { get; set; }

    [DefaultValue("")]
    //[TypeConverter(typeof(Design.DataAxisGridPropBarDataPropertyNameConverter))]
    [TypeConverter("EhLib.WinForms.Design.TextAutoCompletingSourceDataPropertyNameConverter")]
    public string DataPropertyName { get; set; }

    [DefaultValue(TextAutoCompletingSourceType.StringCollection)]
    public TextAutoCompletingSourceType SourceType
    {
      get
      {
        return sourceType;
      }
      set
      {
        if (sourceType != value)
        {
          sourceType = value;
          dataSourceChanged = true;
        }
      }
    }
    #endregion< design-time properties

    #region> run-time properties
    [Browsable(false)]
    public TextAutoCompleting AutoCompleting { get; internal set; }

    [Browsable(false)]
    protected object CurDataSource { get; set; }
    #endregion< run-time properties

    #region> methods
    public virtual List<string> GetUniqueListValues(object dataSource, string propName)
    {
      var srcVals = new List<string>();
      var resVals = new List<string>();
      string ats;
      BindingSource bindingSource = new BindingSource();
      PropertyDescriptor propDesc;

      bindingSource.DataSource = dataSource;

      propDesc = bindingSource.GetItemProperties(null).Find(propName, true);
      if (propDesc == null) return null;

      foreach (object listItem in bindingSource.List)
      {
        object o = propDesc.GetValue(listItem);
        if (o == null)
          continue;
        else if (o is string && (string)o == String.Empty)
          continue;
        else
          srcVals.Add(o.ToString());
      }

      if (srcVals.Count == 0)
        return null;

      srcVals.Sort(EhLibUtils.DBCompareValues);

      ats = srcVals[0];
      resVals.Add(ats);

      for (int i = 1; i < srcVals.Count; i++)
      {
        if (EhLibUtils.DBCompareValues(ats, srcVals[i]) != 0)
        {
          ats = srcVals[i];
          resVals.Add(ats);
        }
      }

      return resVals;
    }

    public void ResetDataSourceChangedState()
    {
      dataSourceChanged = false;
    }

    protected internal virtual void GetDataSourceInfo(Control control, string dataPropertyName, out object dataSource, out string propName)
    {
      if (SourceType == TextAutoCompletingSourceType.StringCollection)
      {
        dataSource = StringCollection;
        propName = "";
        ResetDataSourceChangedState();
      }
      else if (SourceType == TextAutoCompletingSourceType.DataSource)
      {
        dataSource = DataSource;
        propName = DataPropertyName;
        ResetDataSourceChangedState();
      }
      else if (SourceType == TextAutoCompletingSourceType.BindDataSource)
      {
        if (dataSourceChanged == false)
        {
          dataSource = CurDataSource;
          propName = null;
        }
        else
        {
          foreach (Binding db in control.DataBindings)
          {
            if (db.PropertyName == dataPropertyName)
            {
              dataSource = GetUniqueListValues(db.DataSource, db.BindingMemberInfo.BindingField);
              propName = null;
              sourceTracker.DataSource = db.DataSource;
              ResetDataSourceChangedState();
              CurDataSource = dataSource;
              return;
            }
          }
          dataSource = null;
          propName = null;
          ResetDataSourceChangedState();
          CurDataSource = dataSource;
        }
      }
      else
      {
        dataSource = null;
        propName = null;
        ResetDataSourceChangedState();
      }
    }

    private void SourceTracker_ListChanged(object sender, ListChangedEventArgs e)
    {
      dataSourceChanged = true;
    }

    private void StringCollectionChanged(object sender, CollectionChangeEventArgs e)
    {
      AutoCompleting.CompletingSourceChanged();
    }
    #endregion< methods

  }

  /// <summary>
  ///  Class that manages the automatic completion in text editors.
  /// </summary>
  [ToolboxItem(false)]
  public class TextAutoCompletingManager : Component
  {
    #region >private consts
    private static readonly object EventKeyClosedUp = new object();
    #endregion <privates consts

    #region >privates
    private PopupDataGridForm popupListBox;
    private Control editBox;
    private object dataSource;
    private string propName;
    private TextAutoCompletingMatching matching;
    private int dropDownListWidth;
    #endregion <pprivates

    public TextAutoCompletingManager()
    {
      popupListBox = CreatePopupListBox();
      popupListBox.CloseUpNeeded += PopupListBox_CloseUpNeeded;
    }

    #region >events
    public event EventHandler<TextAutoCompletingClosedUpEventArgs> ClosedUp
    {
      add
      {
        this.Events.AddHandler(EventKeyClosedUp, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyClosedUp, value);
      }
    }
    #endregion <events

    #region >property
    public bool PopUpListBoxVisible
    {
      get { return popupListBox.Visible; }
    }

    //public bool Active { get; set; }
    #endregion <property

    #region >methods
    public virtual void SetFilterText(string text)
    {

      if (matching == TextAutoCompletingMatching.StartOfItem)
        popupListBox.FilterType = ComboBoxFilterType.StartOfText;
      else if (matching == TextAutoCompletingMatching.AnyPartOfItem)
        popupListBox.FilterType = ComboBoxFilterType.AnyPartOfText;
      else
        throw new NotImplementedException();

      popupListBox.FilterText = text;
      //if (Active && popupListBox.Grid.VisibleRows.Count > 0)
      if (popupListBox.Grid.VisibleRows.Count > 0)
        ShowPopUpListBox();
      else
        HidePopUpListBox();
    }

    public virtual void SetParams(Control editBox, object dataSource, string propName, TextAutoCompletingMatching matching, int dropDownListWidth)
    {
      this.editBox = editBox;
      this.dataSource = dataSource;
      this.propName = propName;
      this.matching = matching;
      this.dropDownListWidth = dropDownListWidth;

      InitPopupListBoxData();
    }

    public virtual void ResetParams()
    {
      this.editBox = null;
      this.dataSource = null;
      this.propName = null;
      this.matching = TextAutoCompletingMatching.StartOfItem;

      InitPopupListBoxData();
    }

    public virtual void ShowPopUpListBox()
    {
      if (PopUpListBoxVisible) return;

      Rectangle screenEditRect = new Rectangle(Point.Empty, editBox.ClientSize);
      screenEditRect = editBox.RectangleToScreen(screenEditRect);

      int listWidth;
      if (dropDownListWidth > screenEditRect.Width)
        listWidth = dropDownListWidth;
      else
        listWidth = screenEditRect.Width;

      popupListBox.AlignWindow(screenEditRect, 50, listWidth);

      popupListBox.Show();
      popupListBox.ResetOldSizeInfo();
      if (PopUpListBoxVisible)
        EhLibUtils.AppMouseDownManager.AppMouseDown += AppMouseDownManager_AppMouseDown;
    }

    public void HidePopUpListBox()
    {
      if (!PopUpListBoxVisible) return;
      CloseUp(false);
      if (!PopUpListBoxVisible)
        EhLibUtils.AppMouseDownManager.AppMouseDown -= AppMouseDownManager_AppMouseDown;
    }

    private void AppMouseDownManager_AppMouseDown(object sender, AppMouseDownManagerEventArgs e)
    {
      Control ctrl = Control.FromHandle(e.Message.HWnd);
      if (EhLibManager.DefaultEhLibManager.DropDownDebug == false && editBox != null)
      {
        if (!(ctrl == editBox ||
              editBox.Contains(ctrl) ||
              ctrl == popupListBox ||
              popupListBox.Contains(ctrl)))
        {
          HidePopUpListBox();
        }
      }
    }

    //public void SetPopUpListBoxInfo(Rectangle screenEditRect, object dataSource, string propName)
    //{

    //}

    public virtual void ProcessKeyDown(KeyEventArgs e)
    {
      if (popupListBox.Visible)
        popupListBox.ProcessKeyDown(e);
    }

    private void InitPopupListBoxData()
    {
      popupListBox.DataSource = dataSource;
      popupListBox.DisplayMember = propName;
    }

    private void PopupListBox_CloseUpNeeded(object sender, PopupListCloseUpNeededEventArgs e)
    {
      CloseUp(e.AcceptValue);
    }

    protected internal virtual void CloseUp(bool acceptValue)
    {
      popupListBox.Hide();
      string selVal;
      int changedListWindowWidth = 0;

      if (popupListBox.Grid.CurrentRow == null)
      {
        acceptValue = false;
        selVal = null;
      }
      else
      {
        object val;
        if (String.IsNullOrEmpty(popupListBox.DisplayMember))
          val = popupListBox.Grid.CurrentRow.SourceItem;
        else
          val = popupListBox.SelectedValue;
        selVal = val as string;
      }

      if (popupListBox.WidthChanged)
        changedListWindowWidth = popupListBox.Width;

      OnClosedUp(new TextAutoCompletingClosedUpEventArgs(acceptValue, selVal, changedListWindowWidth));
    }

    protected internal virtual void OnClosedUp(TextAutoCompletingClosedUpEventArgs e)
    {
      var eh = this.Events[EventKeyClosedUp] as EventHandler<TextAutoCompletingClosedUpEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual PopupDataGridForm CreatePopupListBox()
    {
      return new PopupDataGridForm();
    }

    protected internal virtual void GetCompletingDataSourceInfo(TextAutoCompleting autoCompletingObj, Control control, string dataPropertyName, out object dataSource, out string propName)
    {
      TextAutoCompletingSource srcParams = autoCompletingObj.DataSourceParams;
      srcParams.GetDataSourceInfo(control, dataPropertyName, out dataSource, out propName);
    }
    #endregion <methods

  }

  /// <summary>
  ///  EventArgs for ClosedUp event in TextAutoCompletingManager.
  /// </summary>
  public class TextAutoCompletingClosedUpEventArgs : EventArgs
  {

    public TextAutoCompletingClosedUpEventArgs(bool acceptValue, string selectedValue, int changedListWindowWidth)
    {
      AcceptValue = acceptValue;
      SelectedValue = selectedValue;
      ChangedListWindowWidth = changedListWindowWidth;
    }

    public bool AcceptValue { get; private set; }

    public string SelectedValue { get; private set; }

    public int ChangedListWindowWidth { get; private set; }
  }

  /// <summary>
  ///  Extended version of AutoCompleteStringCollection class.
  /// </summary>
  /// <remarks>
  /// Contains a collection of strings to use for the auto-complete feature on certain EhLib controls.
  /// </remarks>
  public class AutoCompleteStringCollectionEh : AutoCompleteStringCollection
  {

    /// <summary>
    ///  Adds the elements of a other AutoCompleteStringCollection to this collection to the end.
    /// </summary>
    /// <param name="values">The Collection of string values to add to the collection.</param>
    public void AddRange(AutoCompleteStringCollection values)
    {
      string[] valsArray = new string[values.Count];
      values.CopyTo(valsArray, 0);
      AddRange(valsArray);
    }

  }

}
