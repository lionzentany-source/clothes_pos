﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Design;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  [ToolboxItem(false)]
  [ToolboxBitmap(typeof(EditBoxPushEditButton), "ToolboxBitmaps.EhLib_EditButton.bmp")]
  public class EditBoxPushEditButton : EditItem
  {

    #region private consts
    private static readonly object EventKeyPaint = new object();
    private static readonly object EventKeyDown = new object();
    private static readonly object EventKeyClick = new object();
    #endregion private consts

    #region fields
    private TextImageRelation textImageRelation = TextImageRelation.ImageBeforeText;
    #endregion fields

    #region constructor
    public EditBoxPushEditButton()
    {
      Shortcut = Shortcut.AltDownArrow;
      ImageElement = new PushEditButtonImageElement(this);
      TextElement = new PushEditButtonTextElement(this);
    }
    #endregion constructor

    #region design-time properties
    [DefaultValue(Shortcut.AltDownArrow)]
    public Shortcut Shortcut { get; set; }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public PushEditButtonImageElement ImageElement { get; internal set; }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public PushEditButtonTextElement TextElement { get; internal set; }

    [DefaultValue(TextImageRelation.ImageBeforeText)]
    public TextImageRelation TextImageRelation
    {
      get
      {
        return textImageRelation;
      }
      set
      {
        if (value != TextImageRelation)
        {
          textImageRelation = value;
          //LayoutTransaction.DoLayoutIf(AutoSize, ParentInternal, this, PropertyNames.TextImageRelation);
          TextImageRelationChanged();
        }
      }
    }
    #endregion

    #region run-time properties
    public override bool SupportInControlBorderMerging
    {
      get
      {
        return false;
      }
    }
    #endregion

    #region events
    public event EventHandler<DownEventArgs> Down
    {
      add
      {
        Events.AddHandler(EventKeyDown, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDown, value);
      }
    }

    public event EventHandler<InEditControlClickEventArgs> Click
    {
      add
      {
        Events.AddHandler(EventKeyClick, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyClick, value);
      }
    }

    public event EventHandler<EditItemContextPaintEventArgs> Paint
    {
      add
      {
        Events.AddHandler(EventKeyPaint, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyPaint, value);
      }
    }

    #endregion

    #region methods
    protected override EditItemControl CreateInEditWinControl()
    {
      return new EditButtonControl(this);
    }

    public override bool IntegratedInBorder()
    {
      return false;
    }

    public override bool IsDropDown()
    {
      return false;
    }

    protected internal override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
      if ((int)keyData == (int)Shortcut)
      {
        DownEventArgs e = new DownEventArgs(false, 0);
        ProcessDown(e); 
        if (e.Handled)
          return true; 
        else
          return false;
      }
      else
      {
        return false;
      }
    }

    internal void ConnectToEditor(BaseEditBoxEh editor)
    {
      if (EditControl != null)
        throw new ArgumentException("Edit item already connected to the EditBox");

      InEditWinControl.Parent = editor;
      EditControl = editor;
    }

    internal void DisconnectFromEditor()
    {
      InEditWinControl.Parent = null;
      EditControl = null;
    }

    protected override void HandlePaintEvent(EditItemContextPaintEventArgs e)
    {
      var eh = Events[EventKeyPaint] as EventHandler<EditItemContextPaintEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal override void OnPaintBackground(EditItemContextPaintEventArgs e)
    {
      bool themed = Application.RenderWithVisualStyles;

      Rectangle btnRect = e.ClientRect;
      if (themed)
        btnRect.Inflate(1, 1);

      PushButtonState state = EhLibUtils.GetPushButtonState(e.Hot, e.Pressed && e.Hot, e.Disabled);
      EhLibPushButtonRenderer cbRenderer = EhLibRenderManager.DefaultEhLibRenderManager.PushButtonRenderer;
      cbRenderer.DrawButton(e.GraphicsContext, btnRect, state);

      //ButtonRenderer.DrawButton(e. Graphics, btnRect, state);
    }

    protected internal override void OnPaintForeground(EditItemContextPaintEventArgs e)
    {
      bool themed = Application.RenderWithVisualStyles;
      Rectangle btnRect = e.ClientRect;
      Rectangle imageRect;
      Rectangle textRect;

      TextLayoutParams textLayout = new TextLayoutParams()
      {
        Text = TextElement.Text,
        Font = TextElement.Font,
        HorzAlign = TextElement.HorzAlign,
        VertAlign = TextElement.VertAlign,
        WrapMode = CellTextWrapMode.NoWrap
      };

      LayoutImageAndText(btnRect, textLayout, out imageRect, out textRect);

      TextElement.ProcessPaint(textRect, e);
      ImageElement.ProcessPaint(imageRect, e);
    }

    public override void DefaultHandleDownAction(DownEventArgs e)
    {
      if (e.Handled) return;
      if (DefaultAction)
        EditControl.HandleInEditControlDownAction(this, e);
    }

    protected override void HandleDownEvent(DownEventArgs e)
    {
      var eh = Events[EventKeyDown] as EventHandler<DownEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected override void HandleClickEvent(InEditControlClickEventArgs e)
    {
      var eh = Events[EventKeyClick] as EventHandler<InEditControlClickEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal virtual void ImageElementChanged(PushEditButtonImageElement pushEditButtonImageElement)
    {
      //throw new NotImplementedException();
    }

    protected internal virtual void TextElementChanged(PushEditButtonTextElement pushEditButtonTextElement)
    {
      if (Owner != null)
        Owner.EditItemChanged(this);
    }

    protected virtual void TextImageRelationChanged()
    {
      //throw new NotImplementedException();
    }

    public virtual void LayoutImageAndText(Rectangle clientRect, TextLayoutParams textLayout, out Rectangle imageRect, out Rectangle textRect)
    {
      imageRect = Rectangle.Empty;
      textRect = clientRect;

      if (!Visible)
        return;

      Size imageAreaSize = ImageElement.GetFittedSizeFor(clientRect.Size);
      Size checkTextSize;
      Size textSize;

      switch (TextImageRelation)
      {
        case TextImageRelation.Overlay:
          textRect = clientRect;
          imageRect = clientRect;
          break;

        case TextImageRelation.ImageAboveText:
          switch (ImageElement.VertAlign)
          {
            case VerticalAlignment.Top:
              imageRect = new Rectangle(clientRect.Left, clientRect.Top, clientRect.Width, imageAreaSize.Height);
              textRect = new Rectangle(clientRect.Left, imageRect.Bottom, clientRect.Width, clientRect.Bottom - imageRect.Bottom);
              break;
            case VerticalAlignment.Center:
            case VerticalAlignment.Bottom:
              checkTextSize = new Size(clientRect.Width, clientRect.Height - imageAreaSize.Height);
              textSize = EhLibUtils.MeasureText(EhLibUtils.DisplayGraphicsCash, textLayout.Text, textLayout.Font, checkTextSize, textLayout.WrapMode);

              int totalHeight = textSize.Height + ImageElement.Size.Height;
              Rectangle totalRect = new Rectangle(clientRect.Left, clientRect.Top, clientRect.Width, totalHeight);
              if (ImageElement.VertAlign == VerticalAlignment.Center)
                totalRect = EhLibUtils.RectCenter(totalRect, clientRect);
              else
                totalRect.Y = clientRect.Bottom - totalRect.Height;

              imageRect = new Rectangle(totalRect.Left, totalRect.Top, totalRect.Width, imageAreaSize.Height);
              textRect = new Rectangle(totalRect.Left, imageRect.Bottom, totalRect.Width, totalRect.Bottom - imageRect.Bottom);
              break;
          }
          break;

        case TextImageRelation.TextAboveImage:
          checkTextSize = new Size(clientRect.Width, 0);
          textSize = EhLibUtils.MeasureText(EhLibUtils.DisplayGraphicsCash, textLayout.Text, textLayout.Font, checkTextSize, textLayout.WrapMode);

          switch (ImageElement.VertAlign)
          {
            case VerticalAlignment.Top:
              textRect = new Rectangle(clientRect.Left, clientRect.Top, clientRect.Width, textSize.Height);
              imageRect = new Rectangle(clientRect.Left, clientRect.Top + textSize.Height, clientRect.Width, imageAreaSize.Height);
              break;
            case VerticalAlignment.Center:
            case VerticalAlignment.Bottom:

              int totalHeight = textSize.Height + ImageElement.Size.Height;
              Rectangle totalRect = new Rectangle(clientRect.Left, clientRect.Top, clientRect.Width, totalHeight);
              if (ImageElement.VertAlign == VerticalAlignment.Center)
                totalRect = EhLibUtils.RectCenter(totalRect, clientRect);
              else
                totalRect.Y = clientRect.Bottom - totalRect.Height;

              textRect = new Rectangle(totalRect.Left, totalRect.Top, totalRect.Width, textSize.Height);
              imageRect = new Rectangle(totalRect.Left, totalRect.Top + textSize.Height, totalRect.Width, imageAreaSize.Height);
              break;
          }
          break;

        case TextImageRelation.ImageBeforeText:
          switch (ImageElement.HorzAlign)
          {
            case HorizontalAlignment.Left:
              imageRect = new Rectangle(clientRect.Left, clientRect.Top, imageAreaSize.Width, clientRect.Height);
              textRect = new Rectangle(imageRect.Right, clientRect.Top, clientRect.Right - imageRect.Right, clientRect.Height);
              break;
            case HorizontalAlignment.Center:
            case HorizontalAlignment.Right:
              checkTextSize = new Size(clientRect.Width - imageAreaSize.Width, clientRect.Height);
              textSize = EhLibUtils.MeasureText(EhLibUtils.DisplayGraphicsCash, textLayout.Text, textLayout.Font, checkTextSize, textLayout.WrapMode);

              int totalWidth = textSize.Width + imageAreaSize.Width;
              Rectangle totalRect = new Rectangle(clientRect.Left, clientRect.Top, totalWidth, clientRect.Height);
              if (ImageElement.HorzAlign == HorizontalAlignment.Center)
                totalRect = EhLibUtils.RectCenter(totalRect, clientRect);
              else
                totalRect.X = clientRect.Right - totalRect.Width;

              if (totalRect.Width < clientRect.Width)
              {
                imageRect = new Rectangle(totalRect.Left, totalRect.Top, imageAreaSize.Width, totalRect.Height);
                textRect = new Rectangle(imageRect.Right, totalRect.Top, totalRect.Right - imageRect.Right, totalRect.Height);
              }
              else
              {
                imageRect = new Rectangle(clientRect.Left, clientRect.Top, imageAreaSize.Width, clientRect.Height);
                textRect = new Rectangle(imageRect.Right, clientRect.Top, clientRect.Right - imageRect.Right, clientRect.Height);
              }
              break;
          }
          if (imageRect.Right > clientRect.Right)
          {
            imageRect.Width = clientRect.Width;
            textRect.Width = 0;
          }
          break;

        case TextImageRelation.TextBeforeImage:
          checkTextSize = new Size(clientRect.Width - imageAreaSize.Width, clientRect.Height);
          textSize = EhLibUtils.MeasureText(EhLibUtils.DisplayGraphicsCash, textLayout.Text, textLayout.Font, checkTextSize, textLayout.WrapMode);

          switch (textLayout.HorzAlign)
          {
            case HorizontalAlignment.Left:
              textRect = new Rectangle(clientRect.Left, clientRect.Top, textSize.Width, clientRect.Height);
              imageRect = new Rectangle(clientRect.Left + textSize.Width, clientRect.Top, clientRect.Width - textSize.Width, clientRect.Height);
              break;
            case HorizontalAlignment.Center:
            case HorizontalAlignment.Right:

              int totalWidth = textSize.Width + imageAreaSize.Width;
              Rectangle totalRect = new Rectangle(clientRect.Left, clientRect.Top, totalWidth, clientRect.Height);
              if (textLayout.HorzAlign == HorizontalAlignment.Center)
                totalRect = EhLibUtils.RectCenter(totalRect, clientRect);
              else
                totalRect.X = clientRect.Right - totalRect.Width;

              if (totalRect.Width < clientRect.Width)
              {
                textRect = new Rectangle(totalRect.Left, totalRect.Top, textSize.Width, totalRect.Height);
                imageRect = new Rectangle(totalRect.Left + textSize.Width, totalRect.Top, imageAreaSize.Width, totalRect.Height);
              }
              else
              {
                textRect = new Rectangle(clientRect.Left, clientRect.Top, textSize.Width, clientRect.Height);
                imageRect = new Rectangle(clientRect.Left + textSize.Width, clientRect.Top, clientRect.Width - textSize.Width, clientRect.Height);
              }
              break;
          }
          if (textRect.Right > clientRect.Right)
          {
            textRect.Width = clientRect.Width;
            imageRect.Width = 0;
          }
          if (imageRect.Width < 0)
          {
            imageRect.Width = 0;
          }
          break;

        default:
          textRect = clientRect;
          imageRect = clientRect;
          break;
      }

      if (!ImageElement.Visible)
        imageRect = Rectangle.Empty;
      if (!TextElement.Visible)
        textRect = Rectangle.Empty;
    }
    #endregion
  }

  [DesignerCategory("Code")]
  [ToolboxItem(false)]
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class PushEditButtonImageElement 
  {

    #region private consts
    //private static readonly object EventKeyPaint = new object();
    #endregion

    #region privates
    private HorizontalAlignment horzAlign = HorizontalAlignment.Left;
    private VerticalAlignment vertAlign = VerticalAlignment.Center;
    private int imageIndex;
    private string imageKey = String.Empty;
    private bool useIntegerIndex = true;
    private ImageList imageList;
    private Image image;
    private Padding padding = Padding.Empty;
    private bool sizeStored;
    private Size customSize;
    #endregion

    public PushEditButtonImageElement(EditBoxPushEditButton editButton)
    {
      EditButton = editButton;
      imageIndex = -1;
    }

    #region design-time properties
    [DefaultValue(null)]
    public Image Image
    {
      get
      {
        if (image == null && imageList != null)
        {
          int actualIndex = ActualImageIndex;

          if (actualIndex >= imageList.Images.Count)
          {
            actualIndex = imageList.Images.Count - 1;
          }

          if (actualIndex >= 0)
          {
            return imageList.Images[actualIndex];
          }
        }
        return image;
      }

      set
      {
        if (Image != value)
        {
          image = value;
          if (image != null)
          {
            ImageIndex = -1;
            ImageList = null;
          }
          EditButton.ImageElementChanged(this);
        }
      }
    }

    [DefaultValue(HorizontalAlignment.Left)]
    public HorizontalAlignment HorzAlign
    {
      get
      {
        return horzAlign;
      }
      set
      {
        if (value != horzAlign)
        {
          horzAlign = value;
          EditButton.ImageElementChanged(this);
        }
      }
    }

    [DefaultValue(VerticalAlignment.Center)]
    public VerticalAlignment VertAlign
    {
      get
      {
        return vertAlign;
      }
      set
      {
        if (value != vertAlign)
        {
          vertAlign = value;
          EditButton.ImageElementChanged(this);
        }
      }
    }

    [TypeConverterAttribute(typeof(ImageIndexConverter))]
    [Editor("System.Windows.Forms.Design.ImageIndexEditor", typeof(UITypeEditor))]
    [DefaultValue(-1)]
    [RefreshProperties(RefreshProperties.Repaint)]
    public int ImageIndex
    {
      get
      {
        if (imageIndex != -1 &&
            imageList != null &&
            imageIndex >= imageList.Images.Count)
        {
          return imageList.Images.Count - 1;
        }
        else
        {
          return ActualImageIndex;
        }
      }
      set
      {
        if (value < -1)
        {
          throw new ArgumentOutOfRangeException("value");
        }
        if (imageIndex != value)
        {
          if (value != -1)
          {
            image = null;
          }

          imageKey = String.Empty;
          imageIndex = value;
          useIntegerIndex = true;

          EditButton.ImageElementChanged(this);
        }
      }
    }

    [TypeConverter(typeof(ImageKeyConverter))]
    [Editor("System.Windows.Forms.Design.ImageIndexEditor", typeof(UITypeEditor))]
    [DefaultValue("")]
    [RefreshProperties(RefreshProperties.Repaint)]
    public string ImageKey
    {
      get
      {
        return imageKey;
      }
      set
      {
        if (imageKey != value)
        {
          if (value != null)
            image = null;

          imageIndex = -1;
          imageKey = (value == null ? String.Empty : value);
          useIntegerIndex = false;
          EditButton.ImageElementChanged(this);
        }
      }
    }

    [DefaultValue(null)]
    [RefreshProperties(RefreshProperties.Repaint)]
    public ImageList ImageList
    {
      get
      {
        return imageList;
      }
      set
      {
        if (imageList != value)
        {
          EventHandler recreateHandler = ImageListRecreateHandle;
          EventHandler disposedHandler = DetachImageList;

          if (imageList != null)
          {
            imageList.RecreateHandle -= recreateHandler;
            imageList.Disposed -= disposedHandler;
          }

          if (value != null)
            image = null;

          imageList = value;

          if (value != null)
          {
            value.RecreateHandle += recreateHandler;
            value.Disposed += disposedHandler;
          }
          EditButton.ImageElementChanged(this);
        }
      }
    }

    public Padding Padding
    {
      get
      {
        return padding;
      }
      set
      {
        padding = value;
        EditButton.ImageElementChanged(this);
      }
    }

    public Size Size
    {
      get
      {
        if (sizeStored)
          return customSize;
        else
          return DefaultSize();
      }
      set
      {
        customSize = value;
        sizeStored = true;
        EditButton.ImageElementChanged(this);
      }
    }

    #endregion

    #region event

    //public event EventHandler<CellImageBoxPaintEventArgs> Paint
    //{
    //  add
    //  {
    //    this.Events.AddHandler(EventKeyPaint, value);
    //  }
    //  remove
    //  {
    //    this.Events.RemoveHandler(EventKeyPaint, value);
    //  }
    //}
    #endregion

    #region run-time properties
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool Visible
    {
      get
      {
        return DefaultVisible();
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public EditBoxPushEditButton EditButton { get; internal set; }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public virtual int ActualImageIndex
    {
      get
      {
        if (useIntegerIndex)
        {
          return imageIndex;
        }
        else if (ImageList != null)
        {
          return ImageList.Images.IndexOfKey(ImageKey);
        }
        else
        {
          return -1;
        }
      }
    }
    #endregion

    #region methods
    private void ImageListRecreateHandle(object sender, EventArgs e)
    {
      EditButton.ImageElementChanged(this);
    }

    private void DetachImageList(object sender, EventArgs e)
    {
      ImageList = null;
    }

    public virtual bool ShouldSerializePadding()
    {
      return (padding != Padding.Empty);
    }

    public virtual void ResetPadding()
    {
      padding = Padding.Empty;
      EditButton.ImageElementChanged(this);
    }

    public virtual Size DefaultSize()
    {
      if (Image != null)
        return new Size(Image.Size.Width + Padding.Left + Padding.Right,
                        Image.Size.Height + Padding.Top + Padding.Bottom);
      else
        return Size.Empty;
    }

    public virtual bool ShouldSerializeSize()
    {
      return sizeStored;
    }

    public virtual void ResetSize()
    {
      sizeStored = false;
      EditButton.ImageElementChanged(this);
    }

    public bool DefaultVisible()
    {
      if (Image != null)
        return true;
      else if (ImageList != null && (ImageIndex >= 0 || !String.IsNullOrEmpty(ImageKey)))
        return true;
      else
        return false;
    }

    public virtual Size GetFittedSizeFor(Size sizeFor)
    {
      Size sizeForImage = new Size(sizeFor.Width - Padding.Left - Padding.Right, sizeFor.Height - Padding.Top - Padding.Bottom);
      Size imageSize = new Size(Size.Width - Padding.Left - Padding.Right, Size.Height - Padding.Top - Padding.Bottom);
      Size result = EhLibUtils.GetFittedImageSize(imageSize, sizeForImage);
      return new Size(result.Width + Padding.Left + Padding.Right, result.Height + Padding.Top + Padding.Bottom);
    }

    //protected internal virtual Rectangle CalcTextRect(Rectangle clientRect, TextLayoutParams textLayout)
    //{
    //  switch (TextImageRelation)
    //  {
    //    case TextImageRelation.Overlay:
    //    case TextImageRelation.ImageAboveText:
    //    case TextImageRelation.TextAboveImage:
    //      return clientRect;

    //    case TextImageRelation.ImageBeforeText:
    //    case TextImageRelation.TextBeforeImage:
    //      Rectangle result = clientRect;
    //      result.Width = result.Width - Size.Width;
    //      if (result.Width < 0)
    //        result.Width = 0;

    //      return result;

    //    default:
    //      return clientRect;
    //  }
    //}

    //protected internal virtual void ProcessPaint(CellImageBoxPaintEventArgs e)
    //{
    //  //HandlePaintEvent(e);
    //  //if (!e.Handled)
    //  OnPaint(e);
    //}

    //protected void HandlePaintEvent(CellImageBoxPaintEventArgs e)
    //{
    //  var eh = this.Events[EventKeyPaint] as EventHandler<CellImageBoxPaintEventArgs>;

    //  if (eh != null)
    //    eh(this, e);
    //}

    //protected internal void OnPaint(CellImageBoxPaintEventArgs e)
    //{
    //  if (Image == null) return;

    //  Rectangle clientRect = EhLibUtils.TrimPadding(e.PaintRect, Padding);
    //  EhLibUtils.DrawFitImage(e.Graphics, Image, clientRect, HorzAlign, VertAlign);
    //}

    internal void ProcessPaint(Rectangle imageRect, EditItemContextPaintEventArgs e)
    {
      Rectangle clientRect = EhLibUtils.TrimPadding(imageRect, Padding);
      EhLibUtils.DrawFitImage(e.Graphics, Image, clientRect, HorzAlign, VertAlign);
    }
    #endregion
  }


  [DesignerCategory("Code")]
  [ToolboxItem(false)]
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class PushEditButtonTextElement
  {

    #region private consts
    //private static readonly object EventKeyPaint = new object();
    #endregion

    #region privates
    private HorizontalAlignment horzAlign = HorizontalAlignment.Left;
    private VerticalAlignment vertAlign = VerticalAlignment.Center;
    private Padding padding = Padding.Empty;
    private Color foreColor;
    private bool foreColorStored;
    private Font font;
    private string text;
    #endregion

    public PushEditButtonTextElement(EditBoxPushEditButton editButton)
    {
      EditButton = editButton;
      //ForeColor = Color.Empty;
    }

    #region design-time properties
    [DefaultValue(HorizontalAlignment.Left)]
    public HorizontalAlignment HorzAlign
    {
      get
      {
        return horzAlign;
      }
      set
      {
        if (value != horzAlign)
        {
          horzAlign = value;
          EditButton.TextElementChanged(this);
        }
      }
    }

    [DefaultValue(VerticalAlignment.Center)]
    public VerticalAlignment VertAlign
    {
      get
      {
        return vertAlign;
      }
      set
      {
        if (value != vertAlign)
        {
          vertAlign = value;
          EditButton.TextElementChanged(this);
        }
      }
    }

    public Padding Padding
    {
      get
      {
        return padding;
      }
      set
      {
        padding = value;
        EditButton.TextElementChanged(this);
      }
    }

    public Color ForeColor
    {
      get
      {
        if (foreColorStored)
          return foreColor;
        else
          return DefaultForeColor();
      }
      set
      {
        if ((foreColorStored == false) || (foreColor != value))
        {
          foreColorStored = true;
          foreColor = value;
          EditButton.TextElementChanged(this);
        }
      }
    }

    public Font Font
    {
      get
      {
        if (font != null)
          return font;
        else
          return DefaultFont();
      }
      set
      {
        font = value;
        EditButton.TextElementChanged(this);
      }
    }

    [DefaultValue(null)]
    public string Text
    {
      get
      {
        return text;
      }
      set
      {
        text = value;
        EditButton.TextElementChanged(this);
      }
    }
    #endregion

    #region event
    //public event EventHandler<CellImageBoxPaintEventArgs> Paint
    //{
    //  add
    //  {
    //    this.Events.AddHandler(EventKeyPaint, value);
    //  }
    //  remove
    //  {
    //    this.Events.RemoveHandler(EventKeyPaint, value);
    //  }
    //}
    #endregion

    #region run-time properties
    [Browsable(false)]
    public EditBoxPushEditButton EditButton { get; internal set; }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool Visible
    {
      get
      {
        return !String.IsNullOrEmpty(Text);
      }
    }
    #endregion

    #region methods

    public virtual bool ShouldSerializePadding()
    {
      return (padding != Padding.Empty);
    }

    public virtual void ResetPadding()
    {
      padding = Padding.Empty;
      EditButton.TextElementChanged(this);
    }

    protected internal virtual Rectangle CalcTextRect(Rectangle clientRect, TextLayoutParams textLayout)
    {
      return Rectangle.Empty;
    }

    //protected internal virtual void ProcessPaint(CellImageBoxPaintEventArgs e)
    //{
    //  //HandlePaintEvent(e);
    //  //if (!e.Handled)
    //  OnPaint(e);
    //}

    //protected void HandlePaintEvent(CellImageBoxPaintEventArgs e)
    //{
    //  var eh = this.Events[EventKeyPaint] as EventHandler<CellImageBoxPaintEventArgs>;

    //  if (eh != null)
    //    eh(this, e);
    //}

    //protected internal void OnPaint(CellImageBoxPaintEventArgs e)
    //{
    //  //if (Image == null) return;

    //  //Rectangle clientRect = EhLibUtils.TrimPadding(e.PaintRect, Padding);
    //  //EhLibUtils.DrawFitImage(e.Graphics, Image, clientRect, HorzAlign, VertAlign);
    //}

    internal void ProcessPaint(Rectangle textRect, EditItemContextPaintEventArgs e)
    {
      e.GraphicsContext.DrawText(Text, Font, textRect, ForeColor, HorzAlign, VertAlign, 0);
      //EhLibUtils.DrawText(e.Graphics, Text, Font, textRect, ForeColor, HorzAlign, VertAlign, 0);
    }

    public virtual Font DefaultFont()
    {
      if (EditButton.Owner != null)
        return EditButton.Owner.GetDefaultFont();
      else
        return null;
    }

    public virtual void ResetFont()
    {
      if (font != null)
      {
        font = null;
        EditButton.TextElementChanged(this);
      }
    }

    protected virtual bool ShouldSerializeFont()
    {
      return (font != null);
    }

    public virtual Color DefaultForeColor()
    {
      if (EditButton.Owner != null)
        return EditButton.Owner.DefaultForeColor();
      else
        return SystemColors.WindowText;
    }

    protected virtual bool ShouldSerializeForeColor()
    {
      return ForeColor != Color.Empty;
    }

    [EditorBrowsable(EditorBrowsableState.Never)]
    public virtual void ResetForeColor()
    {
      ForeColor = Color.Empty;
    }
    #endregion
  }

  [DesignTimeVisible(false)]
  [ToolboxItem(false)]
  public class EditBoxPushEditButtonControl : EditItemControl
  {

    #region constructor
    public EditBoxPushEditButtonControl(EditItem editItem) : base(editItem)
    {
      //SetStyle(ControlStyles.Opaque, false);
    }
    #endregion constructor

    #region properties
    protected internal EditBoxPushEditButton InEditButton
    {
      get { return (EditBoxPushEditButton)EditItem; }
    }
    #endregion properties

  }

}
