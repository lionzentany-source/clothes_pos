﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2019 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Globalization;
using System.Linq;
using System.Text;

namespace EhLib.WinForms
{

  class DataCellManagerConverter : ReferenceConverter
  {
    public DataCellManagerConverter(Type type) : base(type)
    {
    }

    public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
    {
      List<object> list = new List<object>();
      foreach (var v in base.GetStandardValues(context))
        list.Add(v);

      list.Sort(CompareVals);

      return new StandardValuesCollection(list);
    }

    public int CompareVals(object n1, object n2)
    {
      BaseDataCellManager c1 = n1 as BaseDataCellManager;
      BaseDataCellManager c2 = n2 as BaseDataCellManager;
      PropertyAxisBar bar1 = null;
      PropertyAxisBar bar2 = null;

      if (c1 != null)
        bar1 = c1.BoundPropAxisBar;
      if (c2 != null)
        bar2 = c2.BoundPropAxisBar;

      if (bar1 != null && bar2 != null && bar1.Site != null && bar2.Site != null)
        return String.Compare(bar1.Site.Name + ".ExternalCellManager", bar2.Site.Name + ".ExternalCellManager");
      else if (bar1 != null && bar1.Site != null)
        return 1;
      else if (bar2 != null && bar2.Site != null)
        return -1;
      else
        return 0;
    }

  }

  //class DataCellManagerConverter : ReferenceConverter
  //{
  //  private ReferenceConverter propAxisBarConverter;

  //  public DataCellManagerConverter(Type type) : base(type)
  //  {
  //    propAxisBarConverter = new ReferenceConverter(typeof(PropertyAxisBar));
  //  }

  //  public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, System.Type destinationType)
  //  {
  //    object result = base.ConvertTo(context, culture, value, destinationType);
  //    string resultStr = result as string;
  //    BaseDataCellManager cellMan = value as BaseDataCellManager;
  //    if (destinationType == typeof(string) &&
  //        resultStr == string.Empty &&
  //        cellMan != null)
  //    {
  //      if (cellMan.BoundPropAxisBar != null &&
  //          cellMan.BoundPropAxisBar.Site != null &&
  //          cellMan.BoundPropAxisBar.InternalCellManager == value)
  //      {
  //        result = cellMan.BoundPropAxisBar.Site.Name + ".InternalCellManager";
  //        return result;
  //      }
  //    }

  //    return result;
  //  }

  //  public override object ConvertFrom(
  //    ITypeDescriptorContext context,
  //    CultureInfo culture,
  //    object value)
  //  {
  //    if (!(value is string))
  //      return base.ConvertFrom(context, culture, value);

  //    string index = ((string)value).Trim();
  //    string[] split2 = index.Split('.');
  //    if (split2.Length == 2 && split2[1] == "InternalCellManager")
  //    {
  //      IReferenceService service = (IReferenceService)context.GetService(typeof(IReferenceService));
  //      object obj0 = service.GetReference(split2[0]);
  //      PropertyAxisBar propAxisBar = obj0 as PropertyAxisBar;
  //      if (propAxisBar != null)
  //        return propAxisBar.InternalCellManager;
  //    }

  //    return base.ConvertFrom(context, culture, value);
  //  }

  //  public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
  //  {
  //    ArrayList list = new ArrayList(base.GetStandardValues(context));
  //    TypeConverter.StandardValuesCollection allPropAxisBars = propAxisBarConverter.GetStandardValues(context);

  //    foreach (var o in allPropAxisBars)
  //    {
  //      PropertyAxisBar pab = o as PropertyAxisBar;
  //      if (pab != null)
  //      {
  //        list.Add(pab.InternalCellManager);
  //      }
  //    }
  //    //list.Add(null);
  //    return new StandardValuesCollection(list);
  //  }
  //}
}
