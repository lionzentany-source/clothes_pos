﻿namespace EhLib.WinForms.Design
{
  partial class FormSelectDataSource
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.dataGridEh1 = new EhLib.WinForms.DataGridEh();
      this.bOk = new System.Windows.Forms.Button();
      this.bCancel = new System.Windows.Forms.Button();
      this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
      ((System.ComponentModel.ISupportInitialize)(this.dataGridEh1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
      this.SuspendLayout();
      // 
      // dataGridEh1
      // 
      this.dataGridEh1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dataGridEh1.AutoSizeColumnOptions.FitToClient = true;
      this.dataGridEh1.DataSource = this.bindingSource1;
      // 
      // dataGridEh1.IndicatorColumn
      // 
      this.dataGridEh1.IndicatorColumn.Visible = false;
      this.dataGridEh1.Location = new System.Drawing.Point(19, 17);
      this.dataGridEh1.Name = "dataGridEh1";
      this.dataGridEh1.Selection.AllowedSelection.All = false;
      this.dataGridEh1.Selection.AllowedSelection.Cells = false;
      this.dataGridEh1.Selection.AllowedSelection.Columns = false;
      this.dataGridEh1.Selection.AllowedSelection.Rows = false;
      this.dataGridEh1.Size = new System.Drawing.Size(414, 442);
      this.dataGridEh1.TabIndex = 0;
      // 
      // dataGridEh1.Title
      // 
      this.dataGridEh1.Title.Visible = false;
      // 
      // bOk
      // 
      this.bOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.bOk.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.bOk.Location = new System.Drawing.Point(254, 477);
      this.bOk.Name = "bOk";
      this.bOk.Size = new System.Drawing.Size(75, 23);
      this.bOk.TabIndex = 1;
      this.bOk.Text = "Ok";
      this.bOk.UseVisualStyleBackColor = true;
      // 
      // bCancel
      // 
      this.bCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.bCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.bCancel.Location = new System.Drawing.Point(335, 477);
      this.bCancel.Name = "bCancel";
      this.bCancel.Size = new System.Drawing.Size(75, 23);
      this.bCancel.TabIndex = 2;
      this.bCancel.Text = "Cancel";
      this.bCancel.UseVisualStyleBackColor = true;
      // 
      // FormSelectDataSource
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(451, 512);
      this.Controls.Add(this.bCancel);
      this.Controls.Add(this.bOk);
      this.Controls.Add(this.dataGridEh1);
      this.Name = "FormSelectDataSource";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "FormSelectDataSource";
      this.Shown += new System.EventHandler(this.FormSelectDataSource_Shown);
      ((System.ComponentModel.ISupportInitialize)(this.dataGridEh1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    private DataGridEh dataGridEh1;
    private System.Windows.Forms.BindingSource bindingSource1;
    private System.Windows.Forms.Button bOk;
    private System.Windows.Forms.Button bCancel;
  }
}