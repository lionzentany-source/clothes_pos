﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;

namespace EhLib.WinForms
{
  [ToolboxItem(false)]
  public class DataVertGridBaseCellMan : BaseGridCellManager
  {
    #region privates
    #endregion privates

    public DataVertGridBaseCellMan()
    {

    }

    #region properties
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public new DataVertGridEh BoundGrid
    {
      get { return (DataVertGridEh)base.BoundGrid; }
      set { base.BoundGrid = value; }
    }
    #endregion

    #region methods
    protected internal override void OnPaintBackground(BaseGridCellPaintEventArgs e)
    {
      using (
        SolidBrush fillBrush = new SolidBrush(BoundGrid.BackColor))
      {
        if ((BasePaintCellStates.Selected & e.State) != 0)
        {
          if (BoundGrid.IsActiveControl())
            fillBrush.Color = SystemColors.Highlight;
          else
            fillBrush.Color = SystemColors.ButtonShadow;
        }

        BoundGrid.PaintingFillRectangle(e.Graphics, fillBrush, e.ClientRect);
      }
    }

    public override string GetDisplayText(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      return "GetDisplayText is not implemented";
    }
    #endregion
  }

  public class DataVertGridBaseIndicatorCellMan : DataVertGridBaseCellMan
  {
    protected BaseGridFillFixedCellEventArgs StyledPaintArgs = new BaseGridFillFixedCellEventArgs();

    protected internal override void OnGetCellBorderParams(BaseGridCellBorderEventArgs e)
    {
      if ((e.BorderType == GridCellBorderSide.Left) || (e.BorderType == GridCellBorderSide.Right))
      {
        e.Visible = BoundGrid.TitleColumn.VertLine.Visible;
        e.IsExtent = true;
      }
      else
      {
        e.Visible = BoundGrid.TitleColumn.HorzLine.Visible;
        e.IsExtent = true;
      }

      if (e.BorderType == GridCellBorderSide.Top || e.BorderType == GridCellBorderSide.Bottom)
      {
        e.Color = BoundGrid.TitleColumn.HorzLine.Color;
        e.Style = BoundGrid.TitleColumn.HorzLine.Style;
      }
      else
      {
        e.Color = BoundGrid.TitleColumn.VertLine.Color;
        e.Style = BoundGrid.TitleColumn.VertLine.Style;
      }
    }

    protected internal override bool IsSelected(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      return false;
    }

    protected internal virtual bool IsPressed(int col, int row,
        Rectangle paintRect,
        BasePaintCellStates state,
        int dataColIndex, int dataRowIndex)
    {
      return false;
    }

    protected internal override void OnPaintBackground(BaseGridCellPaintEventArgs e)
    {

      Color backColor = BoundGrid.FixedBackColor;

      StyledPaintArgs.CellRect = e.ClientRect;
      StyledPaintArgs.Graphics = e.Graphics;
      StyledPaintArgs.IsHot = false;
      StyledPaintArgs.IsPressed = IsPressed(e.ColIndex, e.RowIndex, e.ClientRect, e.State, e.AreaColIndex, e.AreaRowIndex);
      StyledPaintArgs.IsSelected = (e.State & BasePaintCellStates.Selected) != 0;
      StyledPaintArgs.BackColor = backColor;
      StyledPaintArgs.FillStyle = BoundGrid.FixedBackFiller.FillStyle;
      StyledPaintArgs.InnerBorder = BoundGrid.FixedBackFiller.InnerBorder;
      StyledPaintArgs.FillColor = BoundGrid.FixedBackFiller.Color;
      StyledPaintArgs.SecondFillColor = BoundGrid.FixedBackFiller.SecondColor;

      BoundGrid.GetDrawStyle().FillTitleCell(BoundGrid, StyledPaintArgs);
    }
  }

}
