﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2019 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  //virtual cells

  /// <summary>
  /// Represents the base class for classes that contain event data in cells of a DataGridEh control.
  /// </summary>
  public class DataGridVirtualDataCellEventArgs : EventArgs
  {
    public DataGridVirtualDataCellEventArgs(DataAxisGridDataBarCellEventArgs cellEventArgs)
    {
      CellArgs = cellEventArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    protected internal DataAxisGridDataBarCellEventArgs CellArgs { get; set; }
  }

  /// <summary>
  /// Event args for requesting the data cell format parameters of a DataGridEh control
  /// </summary>
  public class DataGridDataCellFormatParamsNeededEventArgs : DataGridVirtualDataCellEventArgs
  {
    public DataGridDataCellFormatParamsNeededEventArgs(DataAxisGridDataCellFormatParamsNeededEventArgs cellEventArgs) : base(cellEventArgs)
    {
      CellArgs = cellEventArgs;
    }

    public new DataAxisGridDataCellFormatParamsNeededEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for painting event in the data cell of a DataGridEh control
  /// </summary>
  public class DataGridDataCellPaintEventArgs : EventArgs
  {
    public DataGridDataCellPaintEventArgs(DataAxisGridDataCellPaintEventArgs cellEventArgs)
    {
      CellArgs = cellEventArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public new DataAxisGridDataCellPaintEventArgs CellArgs { get; internal set; }

    public Graphics Graphics
    {
      get { return CellArgs.Graphics; }
    }

    public bool Handled
    {
      get { return CellArgs.Handled; }
      set { CellArgs.Handled = value; }
    }

    public virtual void Paint(DataGridDataCellPaintEventArgs e)
    {
      PaintBackground(e);
      PaintForeground(e);
    }

    public virtual void PaintBackground(DataGridDataCellPaintEventArgs e)
    {
      e.CellArgs.PaintBackground(e.CellArgs);
    }

    public virtual void PaintForeground(DataGridDataCellPaintEventArgs e)
    {
      e.CellArgs.PaintForeground(e.CellArgs);
    }

    public virtual void PaintForegroundServiceArea(DataGridDataCellPaintEventArgs e)
    {
      BaseDataCellManager dataCellManager = e.CellArgs.CellManager as BaseDataCellManager;
      if (dataCellManager != null)
        dataCellManager.OnPaintServiceArea(e.CellArgs);
    }
  }

  /// <summary>
  /// Event args for painting event in the data cell of a DataGridEh control
  /// </summary>
  public class DataGridDataCellContentPaintEventArgs: EventArgs
  {
    public DataGridDataCellContentPaintEventArgs(DataAxisGridDataCellContentPaintEventArgs cellEventArgs)
    {
      CellArgs = cellEventArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public new DataAxisGridDataCellContentPaintEventArgs CellArgs { get; internal set; }

    public bool Handled
    {
      get { return CellArgs.Handled; }
      set { CellArgs.Handled = value; }
    }

    public virtual void PaintContent(DataGridDataCellContentPaintEventArgs e)
    {
      e.CellArgs.PaintContent(e.CellArgs);
    }

  }

  /// <summary>
  /// Event args for DataCellDisplayValueNeeded event in the data cell of a DataGridEh control
  /// </summary>
  public class DataGridDataCellDisplayValueNeededEventArgs : EventArgs
  {
    public DataGridDataCellDisplayValueNeededEventArgs(DataAxisGridDataCellDisplayValueNeededEventArgs cellEventArgs)
    {
      CellArgs = cellEventArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellDisplayValueNeededEventArgs CellArgs { get; internal set; }

    public bool Handled
    {
      get
      {
        return CellArgs.Handled;
      }
      set
      {
        CellArgs.Handled = value;
      }
    }

    public object Value
    {
      get { return CellArgs.Value; }
    }

    public object DisplayValue
    {
      get { return CellArgs.DisplayValue; } 
      set { CellArgs.DisplayValue = value; } 
    }

    public object GetDisplayValue(DataGridDataCellDisplayValueNeededEventArgs e)
    {
      e.CellArgs.GetDisplayValue(e.CellArgs);
      return e.CellArgs.DisplayValue;
    }
  }

  /// <summary>
  /// Event args for DataCellClientAreaNeeded event for the data cell of a DataGridEh control
  /// </summary>
  public class DataGridDataCellClientAreaNeededEventArgs : DataGridVirtualDataCellEventArgs
  {
    public DataGridDataCellClientAreaNeededEventArgs(DataAxisGridDataCellClientAreaNeededEventArgs cellArgs) : base(cellArgs)
    {
      CellArgs = cellArgs;
    }

    public new DataAxisGridDataCellClientAreaNeededEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Provides data for mouse related routed events in data cells of a DataGridEh control
  /// </summary>
  public class DataGridDataCellMouseEventArgs : EventArgs
  {
    public DataGridDataCellMouseEventArgs(DataAxisGridDataCellMouseEventArgs cellEventArgs)
    {
      CellArgs = cellEventArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellMouseEventArgs CellArgs { get; internal set; }

    public bool Handled
    {
      get { return CellArgs.Handled; }
      set { CellArgs.Handled = value; }
    }

  }

  /// <summary>
  /// Provides data for mouse enter event in data cells of a DataGridEh control
  /// </summary>
  public class DataGridDataCellEnterEventArgs : HandledEventArgs
  {
    public DataGridDataCellEnterEventArgs(DataAxisGridDataCellEnterEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellEnterEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Provides data for mouse leave event in cells of a DataGridEh control
  /// </summary>
  public class DataGridDataCellLeaveEventArgs : HandledEventArgs
  {
    public DataGridDataCellLeaveEventArgs(DataAxisGridDataCellLeaveEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellLeaveEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for ToolTipInfoNeeded event in the data cell a DataGridEh control
  /// </summary>
  public class DataGridDataCellToolTipInfoEventArgs : DataGridVirtualDataCellEventArgs
  {

    public DataGridDataCellToolTipInfoEventArgs(DataAxisGridDataCellToolTipInfoEventArgs cellArgs) : base(cellArgs)
    {
      CellArgs = cellArgs;
    }

    public new DataAxisGridDataCellToolTipInfoEventArgs CellArgs { get; internal set; }

    public string ToolTipText
    {
      get
      {
        return CellArgs.ToolTipText;
      }
      set
      {
        CellArgs.ToolTipText = value;
      }
    }
  }

  /// <summary>
  /// Event args for CanModifyStateNeeded event in the data cell of a DataGridEh control
  /// </summary>
  public class DataGridDataCellCanModifyStateNeededEventArgs : EventArgs
  {
    public DataGridDataCellCanModifyStateNeededEventArgs(DataAxisGridDataCellCanModifyStateNeededEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public bool CanModify
    {
      get { return CellArgs.CanModify; }
      set { CellArgs.CanModify = value; }
    }

    public DataAxisGridDataCellCanModifyStateNeededEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for requesting if editor can be shown in the data cell of a DataGridEh control
  /// </summary>
  public class DataGridDataCellCanShowEditorStateNeededEventArgs : EventArgs
  {
    public DataGridDataCellCanShowEditorStateNeededEventArgs(DataAxisGridDataCellCanShowEditorStateNeededEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public bool CanShowEditor
    {
      get { return CellArgs.CanShowEditor; }
      set { CellArgs.CanShowEditor = value; }
    }

    public DataAxisGridDataCellCanShowEditorStateNeededEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for DataCellEditorParamsNeeded event in a data cell of a DataGridEh control
  /// </summary>
  public class DataGridDataCellEditorParamsEventArgs : EventArgs
  {
    public DataGridDataCellEditorParamsEventArgs(DataAxisGridDataCellEditorParamsNeededEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellEditorParamsNeededEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for DataCellEditValueNeeded event in the data cell of a DataGridEh control
  /// </summary>
  public class DataGridDataCellEditValueNeededEventArgs : HandledEventArgs
  {
    public DataGridDataCellEditValueNeededEventArgs(DataAxisGridDataCellEditValueNeededEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    //TODO : DataGridRow Row is needed
    //public DataGridRow Row
    //{
    //  get { return (DataGridRow)CellArgs.ListItemBar; }
    //}

    public DataAxisGridDataCellEditValueNeededEventArgs CellArgs { get; internal set; }

    public object Value
    {
      get { return CellArgs.Value; }
      set { CellArgs.Value = value; }
    }

    public object EditValue
    {
      get { return CellArgs.EditValue; }
      set { CellArgs.EditValue = value; }
    }
  }

  /// <summary>
  /// Event args for DataCellEditorOccupy event in the data cell of a DataGridEh control
  /// </summary>
  public class DataGridDataCellEditorOccupyEventArgs : EventArgs
  {

    public DataGridDataCellEditorOccupyEventArgs(DataAxisGridDataCellEditorOccupyEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellEditorOccupyEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for DataCellEditorRelease event in the data cell of a DataGridEh control
  /// </summary>
  public class DataGridDataCellEditorReleaseEventArgs : EventArgs
  {

    public DataGridDataCellEditorReleaseEventArgs(DataAxisGridDataCellEditorReleaseEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellEditorReleaseEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for parsing event in the data cell editor of a DataGridEh control
  /// </summary>
  public class DataGridDataCellParseValueEventArgs : EventArgs
  {

    public DataGridDataCellParseValueEventArgs(DataAxisGridDataCellParseValueEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellParseValueEventArgs CellArgs { get; internal set; }

    public object InValue
    {
      get { return CellArgs.InValue; }
      set { CellArgs.InValue = value; }
    }

    public object OutValue
    {
      get { return CellArgs.OutValue; }
      set { CellArgs.OutValue = value; }
    }

    public bool Handled
    {
      get { return CellArgs.Handled; }
      set { CellArgs.Handled = value; }
    }

    protected virtual void ParseValue(DataGridDataCellParseValueEventArgs e)
    {
      e.CellArgs.ParseValue(e.CellArgs);
    }
  }

  /// <summary>
  /// Event args for ContextMenuStripNeeded event in the data cell of a DataGridEh control
  /// </summary>
  public class DataGridDataCellContextMenuStripNeededEventArgs : EventArgs
  {
    public DataGridDataCellContextMenuStripNeededEventArgs(DataAxisGridDataCellContextMenuStripNeededEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellContextMenuStripNeededEventArgs CellArgs { get; internal set; }

    public ContextMenuStrip ContextMenuStrip
    {
      get { return CellArgs.ContextMenuStrip; }
      set { CellArgs.ContextMenuStrip = value; }
    }

    public bool Handled
    {
      get { return CellArgs.Handled; }
      set { CellArgs.Handled = value; }
    }

    public virtual void DoContextMenuStripNeeded(DataGridDataCellContextMenuStripNeededEventArgs e)
    {
      e.CellArgs.DoContextMenuStripNeeded(e.CellArgs);
    }
  }

  //positioned cells

  /// <summary>
  /// Event args for some events for a data cell a DataGridEh control
  /// like OnDataCellClick, OnDataCellContentClick
  /// </summary>
  public class DataGridDataCellEventArgs : HandledEventArgs
  {
    //public DataGridDataCellEventArgs(DataAxisGrid grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect,
    //  PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, BaseDataCellManager cell) :
    //  base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, propAxisBar, listItemBar, cell)
    //{
    //}

    public DataGridDataCellEventArgs(DataAxisGridDataCellEventArgs cellArgs)
    {
      CellArgs = cellArgs;
    }

    public DataGridColumn Column
    {
      get { return (DataGridColumn)CellArgs.PropAxisBar; }
    }

    public DataGridRow Row
    {
      get { return (DataGridRow)CellArgs.ListItemBar; }
    }

    public DataAxisGridDataCellEventArgs CellArgs { get; internal set; }
  }

}
