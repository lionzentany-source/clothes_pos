﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Drawing.Drawing2D;

namespace EhLib.WinForms
{

  public class DataGridIndicatorCellPaintEventArgs : BaseGridCellPaintEventArgs
  {
    private readonly DataGridRow dataRowIndex;

    public DataGridIndicatorCellPaintEventArgs(BaseGridControl grid, BaseGridCellManager cellManager, GraphicsContext gc, int colIndex, int rowIndex,
      Rectangle cellRect, Rectangle cellAreaRect, BasePaintCellStates state, int areaColIndex, int areaRowIndex, Point inCellMousePos, DataGridRow dataRowIndex)
      : base (grid, cellManager, gc, colIndex, rowIndex, cellRect, cellAreaRect, state, areaColIndex, areaRowIndex, inCellMousePos)
    {
      this.dataRowIndex = dataRowIndex;
    }

    public DataGridRow Row
    {
      get { return dataRowIndex; }
    }
  }

  public class DataGridIndicatorCellMouseEventArgs : BaseGridCellMouseEventArgs
  {
    private readonly DataGridRow row;

    public DataGridIndicatorCellMouseEventArgs(BaseGridControl grid, BaseGridCellManager cellManager, int colIndex, int rowIndex,
      int areaColIndex, int areaRowIndex, int inCellX, int inCellY,Rectangle cellRect,
      MouseEventArgs e, DataGridRow row)
      : base(grid, cellManager, colIndex, rowIndex, areaColIndex, areaRowIndex, inCellX, inCellY, cellRect, e)
    {
      this.row = row;
    }

    public DataGridRow Row
    {
      get { return row; }
    }
  }

  public class DataGridIndicatorCellEventArgs : BaseGridCellEventArgs
  {
    private readonly DataGridRow row;

    public DataGridIndicatorCellEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, DataGridRow row)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect)
    {
      this.row = row;
    }

    public DataGridRow Row
    {
      get { return row; }
    }
  }

  public class DataGridIndicatorCellWidthNeededEventArgs : DataGridIndicatorCellEventArgs
  {
    int cellWidth;

    public DataGridIndicatorCellWidthNeededEventArgs(
      BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, DataGridRow row, int cellWidth)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, row)
    {
      this.cellWidth = cellWidth;
    }

    public int CellWidth 
    {
      get { return cellWidth; }
      set { cellWidth = value; }
    }
  }

  public class DataGridIndicatorCellHeightNeededEventArgs : DataGridIndicatorCellEventArgs
  {
    int cellHeight;

    public DataGridIndicatorCellHeightNeededEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, DataGridRow row, int cellHeight)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, row)
    {
      this.cellHeight = cellHeight;
    }

    public int CellHeight
    {
      get { return cellHeight; }
      set { cellHeight = value; }
    }
  }

  public class DataGridIndicatorCellEnterEventArgs : BaseGridCellEnterEventArgs
  {
    private readonly DataGridRow row;

    public DataGridIndicatorCellEnterEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int leaveColIndex, int leaveRowIndex, DataGridRow row)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, leaveColIndex, leaveRowIndex)
    {
      this.row = row;
    }

    public DataGridRow Row
    {
      get { return row; }
    }
  }

  public class DataGridIndicatorCellLeaveEventArgs : BaseGridCellLeaveEventArgs
  {
    private readonly DataGridRow row;

    public DataGridIndicatorCellLeaveEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int enterColIndex, int enterRowIndex, DataGridRow row)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, enterColIndex, enterRowIndex)
    {
      this.row = row;
    }

    public DataGridRow Row
    {
      get { return row; }
    }
  }

}