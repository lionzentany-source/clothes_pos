﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace EhLib.WinForms.Design
{
  class CellManagersListDesigner : ComponentDesigner
  {

    internal CellManagersListDesignBox DesignBox = null;
    internal ISelectionService SelService;
    internal bool disposed = false;
    private IDesignerHost host;
    private int designBoxDefaultWidth = 400;

    public CellManagersListDesigner()
    {
    }

    public override void Initialize(IComponent component)
    {
      base.Initialize(component);

      host = (IDesignerHost)this.GetService(typeof(IDesignerHost));

      SelService = (ISelectionService)GetService(typeof(ISelectionService));
      if (SelService != null)
      {
        SelService.SelectionChanged += SelService_SelectionChanged;
        SelService.SelectionChanging += SelService_SelectionChanging;
      }

      DesignBox = new CellManagersListDesignBox();
      DesignBox.Visible = false;
      CellManagersList cellManList = Component as CellManagersList;
      //DesignBox.SetCellManagersList(cellManList);
      Control rootComponent = host.RootComponent as Control;
      rootComponent.Controls.Add(DesignBox);
      DesignBox.SendToBack();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        HideDesignBox();

        if (DesignBox != null)
        {
          DesignBox.SetCellManagersList(null);
          Control rootComponent = this.host.RootComponent as Control;
          rootComponent.Controls.Remove(DesignBox);
          DesignBox.Dispose();
          DesignBox = null;
        }

        if (SelService != null)
        {
          SelService.SelectionChanged -= SelService_SelectionChanged;
          SelService.SelectionChanging -= SelService_SelectionChanging;
          SelService = null;
        }
      }

      host = null;

      base.Dispose(disposing);
      disposed = true;
    }

    public object GetSelectionIfOne
    {
      get
      {
        ICollection sel = SelService.GetSelectedComponents();

        if (sel.Count != 1)
          return null;

        foreach (object o in sel)
        {
          return o;
        }

        return null;
      }
    }

    public override ICollection AssociatedComponents
    {
      get
      {
        ArrayList acItems = new ArrayList();
        CellManagersList cellManagersList = Component as CellManagersList;

        foreach (var c in cellManagersList.CellManagers)
        {
          acItems.Add(c);
        }

        return acItems;
      }
    }

    protected virtual void SelService_SelectionChanged(object sender, EventArgs e)
    {
      object selComp = GetSelectionIfOne;
      bool selInDesignBox = false;
      CellManagersList cellManagersList = Component as CellManagersList;

      if (selComp == cellManagersList)
        selInDesignBox = true;
      else
      {
        foreach(var cm in cellManagersList.CellManagers)
        {
          if (cm == selComp)
          {
            selInDesignBox = true;
            break;
          }
        }
      }

      if (selInDesignBox && !DesignBox.Visible)
        ShowtDesignBox();
      else if (!selInDesignBox && DesignBox.Visible)
        HideDesignBox();
    }

    private void HideDesignBox()
    {
      if (DesignBox == null || DesignBox.Visible == false) return;

      DesignBox.Visible = false;
      DesignBox.SendToBack();
      DesignBox.SetCellManagersList(null);
      //DesignBox.Parent = null;
    }

    private void ShowtDesignBox()
    {
      if (DesignBox != null && DesignBox.Visible == true) return;

      Control rootComponent = host.RootComponent as Control;
      Rectangle rootRect = rootComponent.ClientRectangle;
      int designBoxWidth;
      if (rootRect.Width < designBoxDefaultWidth - 8 * 2)
        designBoxWidth = rootRect.Width - 8 * 2;
      else
        designBoxWidth = designBoxDefaultWidth;

      DesignBox.SetBounds(8, 8, designBoxWidth, rootRect.Height - 8 * 2);
      DesignBox.SetCellManagersList(Component as CellManagersList);
      DesignBox.Visible = true;
      DesignBox.BringToFront();
    }

    protected virtual void SelService_SelectionChanging(object sender, EventArgs e)
    {
    }

  }
}
