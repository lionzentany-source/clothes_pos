﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Data;
using System.Diagnostics;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Collections.ObjectModel;

namespace EhLib.WinForms
{
  public class DataVertGridRowCellManager : DataVertGridBaseCellManager
  {

    #region privates
    //private DataGridColumn column;
    #endregion privates

    public DataVertGridRowCellManager()
    {

    }

    #region Methods
    public override string GetDisplayText(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      DataVertGridEh dataGrid = grid as DataVertGridEh;
      if (areaRowIndex < dataGrid.VisibleRows.Count)
        return GetDisplayText(dataGrid.VisibleRows[areaRowIndex], areaColIndex);
      else
        return null;
    }

    public virtual string GetDisplayText(DataVertGridRow row, int dataColIndex)
    {
      return "GetDisplayText is not implemented";
    }

    protected internal override bool IsSelected(BaseGridControl grid, int areaColIndex, int areaRowIndex)
    {
      return false;
    }

    protected internal virtual int CalcDefaultRowHeight()
    {
      return 0;
    }

    protected internal virtual int CalcRowHeight(DataVertGridRow row, object listItem)
    {
      return CalcDefaultRowHeight();
    }

    protected internal override void OnPaintEmptyArea(BaseGridCellPaintEventArgs e)
    {
      if (e.AreaColIndex >= 0)
      {
        DataVertGridRow gridRowIndex = BoundGrid.VisibleRows[e.AreaRowIndex];
        Color fromColor = gridRowIndex.BackColor;
        //Color toColor = Grid.BackColor;

        EhLibUtils.FillRectangle(e.Graphics, e.CellRect, fromColor);
      }
      else
      {
        base.OnPaintEmptyArea(e);
      }
    }

    #endregion Methods
  }

  public class DataVertGridRowPaintCellParams
  {
    #region properties
    public int ColIndex { get; internal set; }
    public int RowIndex { get; internal set; }

    public int DataCol { get; internal set; }
    public int DataRow { get; internal set; }
    public DataVertGridRow Row { get; internal set; }

    public Rectangle CellRect { get; internal set; }
    public Rectangle ContentRect { get; set; }
    public BasePaintCellStates PaintState { get; internal set; }

    public object FormattedValue { get; set; }

    public CellFillStyle FillStyle { get; set; }
    public Color BackColor { get; set; }
    //public Color FillColor
    public Color SecondFillColor { get; set; }
    public CellInnerBorderStyle InnerBorder { get; set; }
    public Padding Padding { get; set; }

    public Font Font { get; set; }
    public Color ForeColor { get; set; }
    public HorizontalAlignment HorzAlign { get; set; }
    public VerticalAlignment VertAlign { get; set; }
    public bool WordWrap { get; set; }
    public bool EndEllipsis { get; set; }
    #endregion
  }

  //[DataVertGridDataCellDesignTimeVisible(true)]
  //public class DataVertGridBlankDataCellManager : DataVertGridBaseDataCellManager, ICellBackFillerOwner
  //{
  //  #region privates
  //  private readonly CellBackFiller backFiller;
  //  #endregion

  //  #region constructor
  //  public DataVertGridBlankDataCellManager()
  //  {
  //    backFiller = new CellBackFiller(this);
  //  }
  //  #endregion

  //  #region properties
  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
  //  public CellBackFiller BackFiller
  //  {
  //    get
  //    {
  //      return backFiller;
  //    }
  //  }
  //  #endregion

  //  #region public methods
  //  public override string GetDisplayText(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    return null;
  //  }
  //  #endregion

  //  #region internal methods
  //  //ICellBackFillerOwner
  //  void ICellBackFillerOwner.BackFillerChanged(CellBackFiller backFiller)
  //  {
  //    if (Grid != null)
  //      Grid.Invalidate();
  //  }

  //  Color ICellBackFillerOwner.BackFillerDefaultColor(CellBackFiller backFiller)
  //  {
  //    if (Grid != null)
  //      return Grid.FixedBackFiller.Color;
  //    else
  //      return SystemColors.ButtonFace;
  //  }

  //  Color ICellBackFillerOwner.BackFillerDefaultSecondColor(CellBackFiller backFiller)
  //  {
  //    if (Grid != null)
  //      return Grid.FixedBackFiller.SecondColor;
  //    else
  //      return SystemColors.ButtonFace;
  //  }

  //  CellFillStyle ICellBackFillerOwner.BackFillerDefaultFillStyle(CellBackFiller backFiller)
  //  {
  //    if (Grid != null)
  //      return Grid.FixedBackFiller.FillStyle;
  //    else
  //      return CellFillStyle.Solid;
  //  }

  //  CellInnerBorderStyle ICellBackFillerOwner.BackFillerDefaultInnerBorder(CellBackFiller backFiller)
  //  {
  //    if (Grid != null)
  //      return Grid.FixedBackFiller.InnerBorder;
  //    else
  //      return CellInnerBorderStyle.RaisedTopLeft;
  //  }

  //  //Other
  //  protected override void PaintBackground(DataAxisGridDataCellPaintEventArgs e)
  //  {
  //    if (!e.IsPaintBackground) return;

  //    Color backColor = BackFiller.Color;

  //    BaseGridFillFixedCellEventArgs styledPaintArgs = new BaseGridFillFixedCellEventArgs();

  //    styledPaintArgs.CellRect = e.CellRect;
  //    styledPaintArgs.Graphics = e.Graphics;
  //    styledPaintArgs.IsHot = false;
  //    styledPaintArgs.IsPressed = false;
  //    styledPaintArgs.IsSelected = (e.State & BasePaintCellStates.Selected) != 0 || IsSelected(e.AreaColIndex, e.AreaRowIndex);
  //    styledPaintArgs.BackColor = backColor;
  //    styledPaintArgs.FillColor = BackFiller.Color;
  //    styledPaintArgs.SecondFillColor = BackFiller.SecondColor;
  //    styledPaintArgs.FillStyle = BackFiller.FillStyle;
  //    styledPaintArgs.InnerBorder = BackFiller.InnerBorder;

  //    Grid.DrawStyle.FillFixedCell(Grid, styledPaintArgs);
  //  }

  //  protected override void PaintForeground(DataAxisGridDataCellPaintEventArgs e)
  //  {
  //    base.PaintForeground(e);
  //  }
  //  #endregion
  //}

}
