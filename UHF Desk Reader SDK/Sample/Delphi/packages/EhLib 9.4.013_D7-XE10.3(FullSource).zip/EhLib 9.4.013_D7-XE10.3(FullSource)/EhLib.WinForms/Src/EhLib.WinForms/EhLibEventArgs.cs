﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2019 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  /// <summary>
  /// Extended version on PaintEventArgs class with Handled property. 
  /// Allows you to perform all the drawing in the event handler instead of 
  /// or over the standard drawing.
  /// </summary>
  public class ControlPaintEventArgs : HandledEventArgs
  {

    public ControlPaintEventArgs(GraphicsContext graphicsContext, Control control)
    {
      GraphicsContext = graphicsContext;
      Control = control;
    }

    public GraphicsContext GraphicsContext { get; internal set; }

    public Control Control { get; internal set; }

    public virtual void Paint(ControlPaintEventArgs e)
    {

    }
  }

  public class ContextPaintEventArgs : EventArgs
  {

    public ContextPaintEventArgs(GraphicsContext graphicsContext)
    {
      GraphicsContext = graphicsContext;
    }

    public GraphicsContext GraphicsContext { get; internal set; }

  }

}
