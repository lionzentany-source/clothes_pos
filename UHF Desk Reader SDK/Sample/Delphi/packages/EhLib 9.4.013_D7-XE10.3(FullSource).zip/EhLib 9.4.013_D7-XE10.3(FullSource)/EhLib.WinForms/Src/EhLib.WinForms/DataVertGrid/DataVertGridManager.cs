﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  public class DataVertGridManager : object, IDisposable
  {

    #region static fields
    private static DataVertGridManager _defaultManager;
    #endregion static fields

    #region privates
    //bool closeMenuOnClick;
    private bool disposed;
    #endregion privates

    #region constructor
    public DataVertGridManager()
    {
    }

    ~DataVertGridManager()
    {
      Dispose(false);
    }

    public void Dispose()
    {
      Dispose(true);
      GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
      if (disposed)
        return;
      if (disposing)
      {
      }
      disposed = true;
    }
    #endregion constructor

    public static DataVertGridManager DefaultManager
    {
      get
      {
        if (_defaultManager == null)
          _defaultManager = new DataVertGridManager();
        return _defaultManager;
      }
      set
      {
        _defaultManager = value;
      }
    }

    public virtual PropertyAxisBar GetDataVertGridRowFromType(Type type)
    {
      Type colType = GetDataVertGridRowTypeForDataType(type);
      if (colType != null)
        return (PropertyAxisBar)Activator.CreateInstance(colType);
      else
        return null;
    }

    public virtual Type GetDataVertGridRowTypeForDataType(Type type)
    {
      Type colType;

      TypeConverter imageTypeConverter = TypeDescriptor.GetConverter(typeof(Image));
      if (type == typeof(bool) || type == typeof(CheckState))
      {
        colType = typeof(DataVertGridCheckBoxRow);
        //colType = typeof(DataVertGridTextRow);
      }
      else if (typeof(System.Drawing.Image).IsAssignableFrom(type) || imageTypeConverter.CanConvertFrom(type))
      {
        colType = typeof(DataVertGridImageRow);
        //colType = typeof(DataVertGridTextRow);
      }
      else if (typeof(IList).IsAssignableFrom(type))
      {
        colType = null;
      }
      else if (typeof(DateTime).IsAssignableFrom(type))
      {
        colType = typeof(DataVertGridDateTimeRow);
      }
      else
      {
        colType = typeof(DataVertGridTextRow);
      }
      return colType;
    }

    public virtual void BuildIndicatorTitleMenu(DataVertGridEh grid, ref ToolStripDropDown popupMenu)
    {
    }
  }
}
