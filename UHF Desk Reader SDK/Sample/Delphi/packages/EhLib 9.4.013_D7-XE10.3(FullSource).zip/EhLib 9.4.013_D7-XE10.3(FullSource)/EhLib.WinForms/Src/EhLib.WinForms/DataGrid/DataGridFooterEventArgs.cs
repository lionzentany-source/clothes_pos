﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Reflection;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  public class DataGridFooterCellPaintEventArgs : BaseGridCellPaintEventArgs
  {

    public DataGridFooterCellPaintEventArgs(DataAxisGrid grid, BaseGridCellManager cellManager, GraphicsContext gc, int colIndex, int rowIndex,
      Rectangle cellRect, Rectangle cellAreaRect, BasePaintCellStates state, int areaColIndex, int areaRowIndex, Point inCellMousePos,
      DataGridColumn column)
      : base(grid, cellManager, gc, colIndex, rowIndex, cellRect, cellAreaRect, state, areaColIndex, areaRowIndex, inCellMousePos)
    {
      Column = column;
    }

    public DataGridColumn Column { get; internal set; }

    public new DataGridFooterCellManager CellManager
    {
      get { return (DataGridFooterCellManager)base.CellManager; }
    }

    //public Rectangle ContentRect { get; internal set; }
    public TextFormatFlags AlignFlags { get; set; }
    public Color BackColor { get; set; }
    public bool EndEllipsis { get; set; }
    public Font Font { get; set; }
    public Color ForeColor { get; set; }
    public Padding Padding { get; set; }
    public Orientation TextOrientation { get; set; }
    public CellTextWrapMode WrapMode { get; set; }

    public CellFillStyle FillStyle { get; set; }
    public Color SecondFillColor { get; set; }
    public CellInnerBorderStyle InnerBorder { get; set; }
    public HorizontalAlignment HorzAlign { get; set; }
    public VerticalAlignment VertAlign { get; set; }
    public bool WordWrap { get; set; }


    public virtual void Paint(DataGridFooterCellPaintEventArgs e)
    {
      CellManager.OnPaint(e);
    }

    public virtual void PaintBackground(DataGridFooterCellPaintEventArgs e)
    {
      CellManager.OnPaintBackground(e);
    }

    public virtual void PaintForeground(DataGridFooterCellPaintEventArgs e)
    {
      CellManager.OnPaintForeground(e);
    }
  }

  public class DataGridFooterCalculationEventArgs : HandledEventArgs
  {

    public DataGridFooterCalculationEventArgs(DataGridColumn column, DataGridRow row, DataGridColumnFooterItem footerItem, int footerItemIndex, int step)
    {
      Column = column;
      Row = row;
      FooterItem = footerItem;
      FooterItemIndex = footerItemIndex;
      Step = step;
    }

    public void Reset(DataGridColumn column, DataGridRow row, DataGridColumnFooterItem footerItem, int footerItemIndex, int step)
    {
      Column = column;
      Row = row;
      FooterItem = footerItem;
      FooterItemIndex = footerItemIndex;
      Step = step;
      Handled = false;
    }

    public DataGridColumn Column { get; internal set; }

    public DataGridRow Row { get; internal set; }

    public DataGridColumnFooterItem FooterItem { get; internal set; }

    public int FooterItemIndex { get; internal set; }

    public int Step { get; internal set; }

    public object Value { get; set; }

  }

  public class DataGridFooterCellFormatValueEventArgs : HandledEventArgs
  {

    public DataGridFooterCellFormatValueEventArgs(DataGridColumn column, DataGridColumnFooterItem footerItem, int footerItemIndex, object sourceValue)
    {
      Column = column;
      FooterItem = footerItem;
      FooterItemIndex = footerItemIndex;
      SourceValue = sourceValue;
    }

    public void Reset(DataGridColumn column, DataGridColumnFooterItem footerItem, int footerItemIndex, object sourceValue)
    {
      Column = column;
      FooterItem = footerItem;
      FooterItemIndex = footerItemIndex;
      SourceValue = sourceValue;
      Handled = false;
    }

    public DataGridColumn Column { get; internal set; }

    public DataGridRow Row { get; internal set; }

    public DataGridColumnFooterItem FooterItem { get; internal set; }

    public int FooterItemIndex { get; internal set; }

    public object SourceValue { get; internal set; }

    public object FormattedValue { get; set; }

  }

  public class DataGridFooterCellMouseEventArgs : BaseGridCellMouseEventArgs
  {
    public DataGridFooterCellMouseEventArgs(BaseGridControl grid, BaseGridCellManager cellManager, int colIndex, int rowIndex,
      int areaColIndex, int areaRowIndex, int inCellX, int inCellY, Rectangle cellRect,
      MouseEventArgs e, DataGridColumn column, DataGridColumnFooterItem footerItem, int footerItemIndex)
      : base(grid, cellManager, colIndex, rowIndex, areaColIndex, areaRowIndex, inCellX, inCellY, cellRect, e)
    {
      this.Column = column;
      this.FooterItem = footerItem;
      this.FooterItemIndex = footerItemIndex;
    }

    public DataGridColumn Column { get; internal set; }

    public DataGridColumnFooterItem FooterItem { get; internal set; }

    public int FooterItemIndex { get; internal set; }
  }

  public class DataGridFooterCellEnterEventArgs : BaseGridCellEnterEventArgs
  {
    public DataGridFooterCellEnterEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int leaveColIndex, int leaveRowIndex, 
      DataGridColumn column, DataGridColumnFooterItem footerItem, int footerItemIndex)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, leaveColIndex, leaveRowIndex)
    {
      this.Column = column;
      this.FooterItem = footerItem;
      this.FooterItemIndex = footerItemIndex;
    }

    public DataGridColumn Column { get; internal set; }

    public DataGridColumnFooterItem FooterItem { get; internal set; }

    public int FooterItemIndex { get; internal set; }

    public new DataGridEh Grid { get { return base.Grid as DataGridEh; } }

  }

  public class DataGridFooterCellLeaveEventArgs : BaseGridCellLeaveEventArgs
  {
    public DataGridFooterCellLeaveEventArgs(BaseGridControl grid,
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, Rectangle cellRect, int enterColIndex, int enterRowIndex,
      DataGridColumn column, DataGridColumnFooterItem footerItem, int footerItemIndex)
      : base(grid, colIndex, rowIndex, areaColIndex, areaRowIndex, cellRect, enterColIndex, enterRowIndex)
    {
      this.Column = column;
      this.FooterItem = footerItem;
      this.FooterItemIndex = footerItemIndex;
    }

    public DataGridColumn Column { get; internal set; }

    public DataGridColumnFooterItem FooterItem { get; internal set; }

    public int FooterItemIndex { get; internal set; }

  }

}