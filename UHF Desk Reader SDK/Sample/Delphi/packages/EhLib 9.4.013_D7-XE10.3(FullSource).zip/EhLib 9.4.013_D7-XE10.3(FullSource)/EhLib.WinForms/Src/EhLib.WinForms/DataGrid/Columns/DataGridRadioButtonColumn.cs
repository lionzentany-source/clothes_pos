﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of column in a DataGridEh control that displays a radio button user interface (UI).
  /// </summary>
  [DataGridColumnDesignTimeVisible(true)]
  public class DataGridRadioButtonColumn : DataGridColumn, IRadioButtonDataCellHolder
  {

    #region private consts
    //private static readonly object EventKey_GetCheckboxState = new object();
    #endregion private consts

    #region privates
    #endregion privates

    public DataGridRadioButtonColumn()
    {

    }

    #region properties
    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object TrueValue
    {
      get { return DataCell.TrueValue; }
      set { DataCell.TrueValue = value; }
    }

    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object FalseValue
    {
      get { return DataCell.FalseValue; }
      set { DataCell.FalseValue = value; }
    }

    [DefaultValue(FlatStyle.Standard)]
    public FlatStyle FlatStyle
    {
      get { return DataCell.FlatStyle; }
      set { DataCell.FlatStyle = value; }
    }
    #endregion

    #region run-rime properties
    [Browsable(false)]
    public new RadioButtonDataCellManager DataCell
    {
      get { return (RadioButtonDataCellManager)base.InternalCellManager; }
    }
    #endregion

    #region events
    #endregion events

    #region Methods
    protected override BaseDataCellManager CreateTemplateCell()
    {
      return new RadioButtonDataCellManager();
    }

    public void SetCheckedStateAsChecked(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      bool curState = GetCheckedState(propAxisBar, listItemBar);

      var e = CreatePushValueEventArgs(this, listItemBar, null);
      object trueValue = GetDataValueFromCheckState(propAxisBar, listItemBar, true);
      e.Value = trueValue;
      HandlePushValueEvent(e);
      if (!e.Handled)
      {
        OnPushValue(e);
      }
    }

    protected internal override void OnPushValue(DataAxisGridDataCellPushValueEventArgs e)
    {
      bool iRowState;
      bool curState = GetCheckedState(e.PropAxisBar, e.ListItemBar);
      object trueValue = GetDataValueFromCheckState(e.PropAxisBar, e.ListItemBar, true);
      object falseValue = GetDataValueFromCheckState(e.PropAxisBar, e.ListItemBar, false);

      if (curState == false)
      {
        foreach (DataGridRow r in Grid.Rows)
        {
          iRowState = GetCheckedState(this, r);
          if ((r != e.ListItemBar) && (iRowState == true) && (PropDescr != null))
            PropDescr.SetValue(r.SourceItem, falseValue);
        }
        Debug.Assert(PropDescr != null, @"PropDescr != null");
        PropDescr.SetValue(e.ListItemBar.SourceItem, trueValue);
      }
    }

    public virtual bool GetCheckedState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      object value = propAxisBar.GetListItemBarValue(listItemBar);
      bool result = GetCheckedStateFromValue(value);
      return result;
    }

    public bool GetCheckedStateFromValue(object value)
    {
      bool result;

      if (value == null)
        result = false;
      else if (TrueValue != null && value.Equals(TrueValue))
        result = true;
      else if (FalseValue != null && value.Equals(FalseValue))
        result = false;
      else if (value.Equals(true))
        result = true;
      else if (value.Equals(false))
        result = false;
      else
        result = false;

      return result;
    }

    public object GetDataValueFromCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, bool checkState)
    {
      object result = null;

      switch (checkState)
      {
        case false:
          {
            if (FalseValue != null)
            {
              result = FalseValue;
            }
            else
            {
              if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(typeof(bool)))
                result = false;
            }
            break;
          }
        case true:
          {
            if (TrueValue != null)
            {
              result = TrueValue;
            }
            else
            {
              if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(typeof(bool)))
                //EhLibUtils.DoNothing(); 
                result = true;
            }
            break;
          }
      }
      return result;
    }

    #endregion

  }

  //[DataGridDataCellDesignTimeVisible(true)]
  //public class DataGridRadioButtonDataCellManager : DataGridBaseDataCellManager
  //{
  //  #region privates
  //  private RadioButtonDataCellWorker cellWorker;
  //  #endregion privates

  //  public DataGridRadioButtonDataCellManager()
  //  {
  //    cellWorker = new RadioButtonDataCellWorker(this);
  //  }

  //  #region properties
  //  [DefaultValue(null)]
  //  [TypeConverter(typeof(StringConverter))]
  //  public object TrueValue
  //  {
  //    get
  //    {
  //      return cellWorker.TrueValue;
  //    }
  //    set
  //    {
  //      cellWorker.TrueValue = value;
  //    }
  //  }

  //  [DefaultValue(null)]
  //  [TypeConverter(typeof(StringConverter))]
  //  public object FalseValue
  //  {
  //    get
  //    {
  //      return cellWorker.FalseValue;
  //    }
  //    set
  //    {
  //      cellWorker.FalseValue = value;
  //    }
  //  }

  //  [DefaultValue(FlatStyle.Standard)]
  //  public FlatStyle FlatStyle
  //  {
  //    get
  //    {
  //      return cellWorker.FlatStyle;
  //    }
  //    set
  //    {
  //      cellWorker.FlatStyle = value;
  //    }
  //  }
  //  #endregion

  //  #region Methods
  //  public bool GetCheckedStateFromValue(object value)
  //  {
  //    return cellWorker.GetCheckedStateFromValue(value);
  //  }

  //  public void SetCheckedStateAsChecked(DataGridColumn column, DataGridRow row)
  //  {
  //    cellWorker.SetCheckedStateAsChecked(column, row);
  //  }

  //  public virtual bool GetCheckedState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    return cellWorker.GetCheckedState(propAxisBar, listItemBar);
  //  }

  //  public RadioButtonState GetRadioButtonState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    return cellWorker.GetRadioButtonState(propAxisBar, listItemBar);
  //  }

  //  public void SetCheckedState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, bool isChecked)
  //  {
  //    cellWorker.SetCheckedState(propAxisBar, listItemBar, isChecked);
  //  }

  //  public object GetDataValueFromCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, bool isChecked)
  //  {
  //    return cellWorker.GetDataValueFromCheckState(propAxisBar, listItemBar, isChecked);
  //  }

  //  public bool NextCheckedState(bool checkedState)
  //  {
  //    return cellWorker.NextCheckedState(checkedState);
  //  }

  //  public virtual void Toggle(int dataColIndex, int dataRowIndex)
  //  {
  //    cellWorker.Toggle(dataColIndex, dataRowIndex);
  //  }

  //  protected override void PaintForeground(DataAxisGridDataCellPaintEventArgs e)
  //  {
  //    cellWorker.PaintForeground(e);
  //  }

  //  protected internal override void OnKeyDown(KeyEventArgs e)
  //  {
  //    cellWorker.OnKeyDown(e);
  //  }

  //  protected internal override void OnKeyUp(KeyEventArgs e)
  //  {
  //    cellWorker.OnKeyUp(e);
  //  }

  //  protected internal override void OnMouseDown(DataAxisGridDataCellMouseEventArgs e)
  //  {
  //    base.OnMouseDown(e);
  //    cellWorker.OnMouseDown(e);
  //  }

  //  protected internal override void OnMouseMove(DataAxisGridDataCellMouseEventArgs e)
  //  {
  //    base.OnMouseMove(e);
  //    //cellWorker.OnMouseMove(e);
  //  }

  //  protected internal override void OnMouseUp(DataAxisGridDataCellMouseEventArgs e)
  //  {
  //    cellWorker.OnMouseUp(e);
  //    base.OnMouseUp(e);
  //  }

  //  protected internal override void OnMouseEnter(DataAxisGridDataCellEnterEventArgs e)
  //  {
  //    Grid.InvalidateCell(e.ColIndex, e.RowIndex);
  //    base.OnMouseEnter(e);
  //  }

  //  protected internal override void OnMouseLeave(DataAxisGridDataCellLeaveEventArgs e)
  //  {
  //    Grid.InvalidateCell(e.ColIndex, e.RowIndex);
  //    base.OnMouseLeave(e);
  //    cellWorker.OnMouseLeave(e);
  //  }
  //  #endregion Methods
  //}
}
