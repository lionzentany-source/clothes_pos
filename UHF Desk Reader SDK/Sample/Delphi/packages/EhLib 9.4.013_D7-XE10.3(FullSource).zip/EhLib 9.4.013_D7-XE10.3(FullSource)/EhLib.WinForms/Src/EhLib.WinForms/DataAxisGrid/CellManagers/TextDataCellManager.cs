﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of data cell manager that displays a text.
  /// </summary>
  //[DataAxisGridDataCellDesignTimeVisible(true)]
  //[ToolboxItem(true)]
  public class TextDataCellManager : BaseDataCellManager
  {

    #region privates
    private bool cellDataIsLink;
    private CellTextWrapMode wrapMode;
    private Rectangle inCellLinkBounds;
    private GridCoord linkCellIndex = new GridCoord(-1, -1);
    private string formatString = "";
    private readonly TextAutoCompleting autoCompleting;
    #endregion

    public TextDataCellManager()
    {
      autoCompleting = new TextAutoCompleting();
    }

    #region properties
    protected override Type DefaultEditorType
    {
      get
      {
        return typeof(DataAxisGridTextBoxEditControl);
      }
    }

    [DefaultValue(CellTextWrapMode.Auto)]
    public CellTextWrapMode WrapMode
    {
      get
      {
        return wrapMode;
      }
      set
      {
        if (wrapMode != value)
        {
          wrapMode = value;
          WrapModeChanged();
        }
      }
    }

    [DefaultValue(false)]
    public bool CellDataIsLink
    {
      get { return cellDataIsLink; }
      set { cellDataIsLink = value; }
    }

    [DefaultValue("")]
    public string FormatString
    {
      get
      {
        return formatString;
      }
      set
      {
        if (formatString != value)
        {
          formatString = value;
          FormatStringChanged();
        }
      }
    }

    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public TextAutoCompleting AutoCompleting
    {
      get
      {
        return autoCompleting;
      }
    }
    #endregion

    #region methods
    protected virtual void FormatStringChanged()
    {
      if (BoundGrid != null)
        BoundGrid.Invalidate();
    }

    private void WrapModeChanged()
    {
      if (BoundGrid != null)
        BoundGrid.RowHeightAffectPropertyChanged();
    }

    protected override void PaintBackground(DataAxisGridDataCellPaintEventArgs e)
    {
      base.PaintBackground(e);
    }

    protected internal override void OnPaintContent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      Rectangle textRect;
      bool wordWrap;
      Font drawFont = e.ParentCellPaintArgs.Font;
      Color foreColor = e.ParentCellPaintArgs.ForePaintColor;
      var grid = e.ParentCellPaintArgs.Grid as DataAxisGrid;

      //if (((BasePaintCellStates.Current & e.State) != 0) ||
      //    ((BasePaintCellStates.RowSelected & e.State) != 0)
      //)
      //  foreColor = SystemColors.HighlightText;
      //else
      //  foreColor = e.ParentCellPaintArgs.ForeColor;

      string text = GetDisplayText(e.ParentCellPaintArgs.Grid, e.DataColIndex, e.DataRowIndex);
      if (text != null)
      {
        textRect = EhLibUtils.TrimPadding(e.CellContentRect, e.ParentCellPaintArgs.Padding);
        wordWrap = CheckWordWrap(e.PropAxisBar, textRect);

        if (linkCellIndex.X == e.ParentCellPaintArgs.ColIndex &&
            linkCellIndex.Y == e.ParentCellPaintArgs.RowIndex)
        {
          drawFont = new Font(drawFont, drawFont.Style | FontStyle.Underline);
        }

        grid.PaintingDrawText(e.GraphicsContext, text, drawFont, textRect, foreColor,
          e.ParentCellPaintArgs.HorzAlign, e.ParentCellPaintArgs.VertAlign, wordWrap);

      }

      CharacterRange[] charRanges;
      string searchingText = grid.GetHighlightSearchingData(e.PropAxisBar, e.ListItemBar, text, out charRanges);
      if (!String.IsNullOrEmpty(searchingText))
      {
        PaintHighlightedText(e, searchingText, charRanges);
      }
    }

    protected internal virtual void PaintHighlightedText(DataAxisGridDataCellContentPaintEventArgs e,
      string text, CharacterRange[] charRanges)
    {
      string cellText;
      string hiS;
      Rectangle textRect;
      bool wordWrap;
      Region oldClip;
      int outOfBounds = 0;
      //CharacterRange[] charRanges;
      Rectangle paintRect = e.CellContentRect;

      cellText = GetDisplayText(e.PropAxisBar, e.ListItemBar);
      hiS = text;
      if (string.IsNullOrEmpty(hiS) == true) return;

      //if (!Grid.SearchBox.CheckTextHit(e.Column, cellText, Grid.SearchBox.SearchingText)) return;

      //charRanges = Grid.SearchBox.GetHitRanges(e.Column, e.Row, cellText);

      textRect = EhLibUtils.TrimPadding(e.CellContentRect, e.ParentCellPaintArgs.Padding);

      wordWrap = CheckWordWrap(e.PropAxisBar, paintRect);

      Rectangle[] stringRegions = EhLibUtils.MeasureCharacterRanges(e.Graphics, cellText, Font,
        textRect, HorzAlign, VertAlign, wordWrap, charRanges);
      oldClip = e.Graphics.Clip;
      e.Graphics.SetClip(paintRect, CombineMode.Intersect);

      for (int i = 0; i < stringRegions.Length; i++)
      {
        Rectangle regRect = stringRegions[i];

        if (textRect.IntersectsWith(regRect))
        {
          e.Graphics.FillRectangle(new SolidBrush(Color.Yellow), regRect);

          string drawText = cellText.Substring(charRanges[i].First, charRanges[i].Length);

          EhLibUtils.DrawText(e.Graphics, drawText, Font, regRect, ForeColor, HorizontalAlignment.Left, VerticalAlignment.Top, TextFormatFlagsEh.None);
        }
        else
        {
          outOfBounds = outOfBounds + 1;
        }
      }

      if (outOfBounds > 0)
      {
        string outOfBoundsStr = outOfBounds.ToString();
        Font ofbFont = new Font(Font.FontFamily, 6);
        Size ofbSize = EhLibUtils.MeasureText(e.Graphics, outOfBoundsStr, ofbFont, new Size(1, 1), CellTextWrapMode.NoWrap);
        Rectangle ofbRect = new Rectangle(textRect.Right - ofbSize.Width - 2, textRect.Top, ofbSize.Width + 2, ofbSize.Height + 2);

        e.Graphics.FillRectangle(new SolidBrush(Color.Yellow), ofbRect);
        EhLibUtils.DrawText(e.Graphics, outOfBoundsStr, ofbFont, ofbRect, ForeColor, HorizontalAlignment.Center, VerticalAlignment.Center, TextFormatFlagsEh.None);
      }

      e.Graphics.Clip = oldClip;
    }

    //protected internal override void PrintCell(BaseGridControl grid, PrintServiceEventArgs e,
    //  Rectangle paintRect,
    //  int colIndex, int rowIndex,
    //  int areaColIndex, int areaRowIndex)
    //{
    //  Font drawFont;
    //  Rectangle textRect;
    //  Color fForeColor = Color.Black;
    //  bool wordWrap;
    //  //DataGridColumn column = Grid.VisibleColumns[dataColIndex];

    //  PropertyAxisBar propAxisBar;
    //  DataAxisGridListItemBar listItemBar;
    //  DataAxisGrid axisGrid = grid as DataAxisGrid;
    //  AxisObjectsByDataColRowIndex(axisGrid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar);

    //  string text = GetDisplayText(propAxisBar, listItemBar);
    //  if (text != null)
    //  {
    //    drawFont = Font;
    //    TextFormatFlagsEh flags = TextFormatFlagsEh.None;
    //    textRect = EhLibUtils.TrimPadding(paintRect, Padding);

    //    wordWrap = CheckWordWrap(propAxisBar, textRect);
    //    if (wordWrap)
    //      flags = flags | TextFormatFlagsEh.WordBreak;

    //    e.DrawText(text, drawFont, textRect, fForeColor, HorzAlign, VertAlign, flags);
    //    //EhLibUtils.DrawText(e.Graphics, text, drawFont, textRect, fForeColor, HorzAlign, VertAlign, flags, UsedGraphicEngine.WinFormsGDIPlus);
    //  }
    //}

    public override bool IsCharToEnterEditMode(KeyPressEventArgs e)
    {
      UnicodeCategory uc = char.GetUnicodeCategory(e.KeyChar);
      if (uc != UnicodeCategory.Control)
        return true;

      return base.IsCharToEnterEditMode(e);
    }

    protected internal override void OnEditorOccupy(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
      Rectangle cellRect;
      bool wordWrap;
      DataAxisGridTextBoxEditControl editor = (DataAxisGridTextBoxEditControl)e.Editor;
      //DataAxisGridDataCellEditorParamsNeededEventArgs de = editorParams as DataAxisGridDataCellEditorParamsNeededEventArgs;

      cellRect = e.Grid.CellRect(e.ColIndex, e.RowIndex, true);

      wordWrap = CheckWordWrap(e.PropAxisBar, cellRect);

      editor.SetEditButton(EditButton);
      foreach (var ei in InEditControls)
        editor.InEditControls.Add(ei);
      editor.EditorEditValue = e.Value;
      if (e != null)
        editor.Font = e.EditorParams.Font;
      editor.ReadOnly = e.EditorParams.ReadOnly;
      editor.PrepareEditorForEdit(e.SelectAll);
      editor.Padding = e.EditorParams.Padding;
      editor.TextAlign = HorzAlign;
      editor.WordWrap = wordWrap;
      editor.Multiline = editor.WordWrap;
      editor.MaxLength = e.PropAxisBar.MaxLength;

      editor.AutoCompleting.Active = AutoCompleting.Active;
      editor.AutoCompleting.DataSourceParams.StringCollection.Clear();
      editor.AutoCompleting.DataSourceParams.StringCollection.AddRange(AutoCompleting.DataSourceParams.StringCollection);
      editor.AutoCompleting.DataSourceParams.DataSource = AutoCompleting.DataSourceParams.DataSource;
      editor.AutoCompleting.DataSourceParams.DataPropertyName = AutoCompleting.DataSourceParams.DataPropertyName;
      editor.AutoCompleting.DataSourceParams.SourceType = AutoCompleting.DataSourceParams.SourceType;
      editor.AutoCompleting.Shortcut = AutoCompleting.Shortcut;
      editor.AutoCompleting.ShowListOnClickWhenEmpty = AutoCompleting.ShowListOnClickWhenEmpty;
      editor.AutoCompleting.Match = AutoCompleting.Match;
      editor.AutoCompleting.DropDownListWidth = AutoCompleting.DropDownListWidth;
    }

    protected override void OnEditorRelease(DataAxisGridDataCellEditorReleaseEventArgs e)
    {
      DataAxisGridTextBoxEditControl editor = (DataAxisGridTextBoxEditControl)e.Editor;
      editor.SetEditButton(null);
      editor.InEditControls.Clear();

      //editor.AutoCompleting
      editor.AutoCompleting.Active = false;
      editor.AutoCompleting.DataSourceParams.StringCollection.Clear();
      editor.AutoCompleting.DataSourceParams.DataSource = null;
      editor.AutoCompleting.DataSourceParams.DataPropertyName = String.Empty;
      editor.AutoCompleting.DataSourceParams.SourceType = TextAutoCompletingSourceType.StringCollection;
      editor.AutoCompleting.Shortcut = Shortcut.AltDownArrow;
      editor.AutoCompleting.ShowListOnClickWhenEmpty = true;
      editor.AutoCompleting.Match = TextAutoCompletingMatching.StartOfItem;
      AutoCompleting.DropDownListWidth = editor.AutoCompleting.DropDownListWidth;
      editor.AutoCompleting.DropDownListWidth = 0;
    }

    //public override void OccupyEditControl(Control cellEditControl, bool selectAll, BaseGridCellEditorParamsEventArgs editorParams)
    //{
    //  Rectangle cellRect;
    //  Rectangle textRect;
    //  //int colIndex, rowIndex;
    //  bool wordWrap;
    //  DataAxisGridTextBoxEditControl editor = (DataAxisGridTextBoxEditControl)cellEditControl;

    //  //AreaCellPosToGridCellPos(editorParams.AreaColIndex, editorParams.AreaRowIndex, out colIndex, out rowIndex);
    //  cellRect = Grid.CellRect(editorParams.ColIndex, editorParams.RowIndex, true);

    //  textRect = EhLibUtils.TrimPadding(cellRect, Padding);
    //  wordWrap = CheckWordWrap(cellRect);

    //  editor.EditorEditValue = GetDisplayText(editorParams.AreaColIndex, editorParams.AreaRowIndex);
    //  editor.Font = Font;
    //  editor.ReadOnly = editorParams.ReadOnly;
    //  editor.PrepareEditorForEdit(selectAll);
    //  editor.Padding = Padding;
    //  editor.TextAlign = HorzAlign;
    //  editor.WordWrap = wordWrap;
    //  editor.Multiline = editor.WordWrap;
    //}

    public virtual string GetCellNonfitToolTipText(BaseGridCellEventArgs e)
    {
      CellTextWrapMode wrapMode;
      SizeF sf;
      Graphics g = EhLibUtils.DisplayGraphicsCash;
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = e.Grid as DataAxisGrid;
      AxisObjectsByDataColRowIndex(axisGrid, e.AreaColIndex, e.AreaRowIndex, out propAxisBar, out listItemBar);

      string cellText = GetDisplayText(propAxisBar, listItemBar);

      DataAxisGridDataCellFormatParamsNeededEventArgs fpe = CreateProcessFormatParams(axisGrid, propAxisBar, listItemBar);

      Rectangle clientRect = GetCellClientRect(propAxisBar, listItemBar, e.CellRect);
      Rectangle contentRect = CalcContentRect(clientRect);
      Rectangle textRect = EhLibUtils.TrimPadding(contentRect, fpe.Padding);

      bool wordWrap = CheckWordWrap(propAxisBar, textRect);
      if (wordWrap)
        wrapMode = CellTextWrapMode.WordWrap;
      else
        wrapMode = CellTextWrapMode.NoWrap;

      sf = EhLibUtils.MeasureText(g, cellText, fpe.Font, textRect.Size, wrapMode);
      //sf = g.MeasureString(cellText, Grid.Font, new PointF(0, 0), StringFormat.GenericTypographic);

      if (sf.Width > textRect.Width)
        return cellText;
      else
        return "";
    }

    protected internal override void OnMouseEnter(DataAxisGridDataCellEnterEventArgs e)
    {
      base.OnMouseEnter(e);

      if (e.Grid.IsShowDataCellsNonfitTooltips())
      {
        string cellText = GetCellNonfitToolTipText(e);

        if (!string.IsNullOrEmpty(cellText))
        {
          DataAxisGrid axisGrid = e.Grid as DataAxisGrid;
          axisGrid.ShowCellNonFitToolTip(cellText, this, e);
        }
      }

      CalcInCellLinkBounds(e.Grid, e.ColIndex, e.RowIndex, e.AreaColIndex, e.AreaRowIndex, 
        e.PropAxisBar, e.ListItemBar, e.CellRect, out this.inCellLinkBounds);
    }

    protected internal override void OnMouseLeave(DataAxisGridDataCellLeaveEventArgs e)
    {
      base.OnMouseLeave(e);
      DataAxisGrid axisGrid = e.Grid as DataAxisGrid;
      axisGrid.HideCellNonFitToolTip();
      inCellLinkBounds = Rectangle.Empty;
      if (linkCellIndex.X >= 0 || linkCellIndex.Y >= 0)
      {
        linkCellIndex = new GridCoord(-1, -1);
        e.Grid.InvalidateRow(e.RowIndex);
      }
    }

    protected internal override void OnMouseMove(DataAxisGridDataCellMouseEventArgs e)
    {
      base.OnMouseMove(e);
      Point inCellPos = new Point(e.InCellX, e.InCellY);

      bool oldMouseInCellLinkBounds = (linkCellIndex.X >= 0 || linkCellIndex.Y >= 0);
      bool newMouseInCellLinkBounds = inCellLinkBounds.Contains(inCellPos);

      if (oldMouseInCellLinkBounds != newMouseInCellLinkBounds)
      {
        if (newMouseInCellLinkBounds)
          linkCellIndex = new GridCoord(e.ColIndex, e.RowIndex);
        else
          linkCellIndex = new GridCoord(-1, -1);
        e.Grid.InvalidateRow(e.RowIndex);
      }
    }

    protected internal override void OnMouseDown(DataAxisGridDataCellMouseEventArgs e)
    {
      DataAxisGrid axisGrid = e.Grid as DataAxisGrid;
      if (linkCellIndex == new GridCoord(e.ColIndex, e.RowIndex) && !axisGrid.EditorBanned)
      {
        axisGrid.EditorBanned = true;
        base.OnMouseDown(e);
        axisGrid.EditorBanned = false;
      }
      else
        base.OnMouseDown(e);
    }

    protected internal override void OnMouseClick(DataAxisGridDataCellMouseEventArgs e)
    {
      base.OnMouseClick(e);
      if (linkCellIndex == new GridCoord(e.ColIndex, e.RowIndex))
      {
        PropertyAxisBar propAxisBar;
        DataAxisGridListItemBar listItemBar;
        DataAxisGrid axisGrid = e.Grid as DataAxisGrid;
        AxisObjectsByDataColRowIndex(axisGrid, e.AreaColIndex, e.AreaRowIndex, out propAxisBar, out listItemBar);

        DataAxisGridDataCellEventArgs de = propAxisBar.CreateDataCellEventArgs(axisGrid, e.ColIndex, e.RowIndex,
          e.AreaColIndex, e.AreaRowIndex, e.CellRect, propAxisBar, listItemBar, this);
        OnContentClick(de);
      }
    }

    //private void OnLinkClick(DataGridDataCellEventArgs de)
    //{
    //}

    protected internal override void OnQueryCursor(BaseGridCellQueryCursorEventArgs e)
    {
      base.OnQueryCursor(e);
      if (linkCellIndex.X == e.ColIndex && linkCellIndex.Y == e.RowIndex)
        e.Cursor = Cursors.Hand;
    }

    public virtual int GetOneLineHeight(PropertyAxisBar propAxisBar)
    {
      return CalcDefaultRowHeight(propAxisBar);
    }

    protected internal override bool CheckWordWrap(PropertyAxisBar propAxisBar, Rectangle paintRect)
    {
      bool wordWrap = false;
      int oneLineHeight;
      if (WrapMode == CellTextWrapMode.Auto)
      {
        oneLineHeight = GetOneLineHeight(propAxisBar);
        if (paintRect.Height > oneLineHeight)
          wordWrap = true;
      }
      else if (WrapMode == CellTextWrapMode.WordWrap)
      {
        wordWrap = true;
      }
      return wordWrap;
    }

    protected internal override int CalcCellHeight(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, int cellWidth)
    {
      int th, result;
      Size inSize, outSize;

      string text = GetDisplayText(propAxisBar, listItemBar);
      Padding padding = GetPadding(propAxisBar);
      Font font = GetFont(propAxisBar);
      DataAxisGridDataCellFormatParamsNeededEventArgs fpe = CreateProcessFormatParams(propAxisBar.Grid, propAxisBar, listItemBar);

      result = base.CalcCellHeight(propAxisBar, listItemBar, cellWidth);

      if (HeightOptions.GetAutoExpand(propAxisBar) && HeightOptions.Unit == GridRowHeightUnit.TextLine)
      {
        if ((WrapMode == CellTextWrapMode.Auto) ||
            (WrapMode == CellTextWrapMode.WordWrap))
        {
          inSize = new Size(cellWidth - fpe.Padding.Left - fpe.Padding.Right, CalcDefaultRowHeight(propAxisBar));
          outSize = EhLibUtils.MeasureText(EhLibUtils.DisplayGraphicsCash, text, font, inSize, CellTextWrapMode.WordWrap);
        }
        else
        {
          outSize = EhLibUtils.MeasureText(EhLibUtils.DisplayGraphicsCash, text, font);
        }

        th = outSize.Height + fpe.Padding.Top + fpe.Padding.Bottom;
        if (th > result)
          result = th;
      }

      return result;
    }

    protected virtual void CalcInCellLinkBounds(DataAxisGrid grid, int colIndex, int rowIndex, int areaColIndex, int areaRowIndex, 
      PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar,
      Rectangle cellRect, out Rectangle inCellLinkBounds)
    {
      //Rectangle contentRect = cellRect;
      Rectangle textRect;
      Size textSize;
      string displayText;
      Padding padding = GetPadding(propAxisBar);

      inCellLinkBounds = Rectangle.Empty;
      if (!CellDataIsLink) return;

      Rectangle customRect = GetCellCustomRect(propAxisBar, listItemBar, cellRect);
      Rectangle clientRect = GetCellClientRect(propAxisBar, listItemBar, customRect);
      Rectangle contentRect = CalcContentRect(clientRect);

      Rectangle textAreaRect = EhLibUtils.TrimPadding(contentRect, padding);

      displayText = GetDisplayText(propAxisBar, listItemBar);
      if (string.IsNullOrEmpty(displayText)) return;

      DataAxisGridDataCellFormatParamsNeededEventArgs fe = CreateFormatParamsNeededEventArgs(grid, propAxisBar, listItemBar);
      ProcessFormatParamsNeeded(fe);

      textSize = EhLibUtils.MeasureText(EhLibUtils.DisplayGraphicsCash, displayText, fe.Font);
      textRect = new Rectangle(Point.Empty, textSize);

      if (textRect.Width > textAreaRect.Width)
        textRect.Width = textAreaRect.Width;
      if (textRect.Height > textAreaRect.Height)
        textRect.Height = textAreaRect.Height;

      if (HorzAlign == HorizontalAlignment.Left)
        textRect.X = textAreaRect.X;
      else if (HorzAlign == HorizontalAlignment.Right)
        textRect.X = textAreaRect.Right - textRect.Width;
      else // HorizontalAlignment.Center
        textRect.X = textAreaRect.X + (textAreaRect.Width + textRect.Width) / 2;

      if (VertAlign == VerticalAlignment.Top)
        textRect.Y = textAreaRect.Y;
      else if (VertAlign == VerticalAlignment.Bottom)
        textRect.Y = textAreaRect.Bottom - textRect.Height;
      else // VerticalAlignment.Center
        textRect.Y = textAreaRect.Y + (textAreaRect.Height + textRect.Height) / 2;

      inCellLinkBounds = textRect;
      inCellLinkBounds.Offset(-cellRect.X, -cellRect.Y);
    }

    protected internal override void OnDisplayValueNeeded(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      e.DisplayValue = ValueToDisplayValue(e.Value);
    }

    public virtual object ValueToDisplayValue(object value)
    {
      Type dataType;

      if (value != null)
        dataType = value.GetType();
      else
        dataType = null;

      TypeConverter srcConverter = null;
      TypeConverter targetConverter = EhLibUtils.GetCachedStringConverter();
      if (dataType != null)
      {
        if (dataType == typeof(string))
          srcConverter = targetConverter;
        else
          srcConverter = TypeDescriptor.GetConverter(dataType);
      }
      object result = EhLibManager.DefaultEhLibManager.ValueConverter.FormatValue(
        value, typeof(string), srcConverter, targetConverter, FormatString, null, "", null);
      return result.ToString();
    }

    protected override void OnEditValueNeeded(DataAxisGridDataCellEditValueNeededEventArgs e)
    {
      e.EditValue = ValueToDisplayValue(e.Value);
    }

    public override string GetTypeNameAbbr()
    {
      return "Txt";
    }
    #endregion
  }

  [ToolboxItem(false)]
  [System.ComponentModel.DesignerCategory("Code")]
  public class DataAxisGridTextBoxEditControl : TextBoxEh, IDataAxisGridCellInPlaceEditor
  {
    private DataAxisGrid ownerGrid;
    private int rowIndex;
    private bool valueChanged;
    private BaseDataCellManager cellManager;

    public DataAxisGridTextBoxEditControl()
    {
      this.TabStop = false;
      this.Border.Style = ControlBorderStyle.None;
      InitData();
    }

    private void InitData()
    {
      this.AutoSize = false;
    }

    public object EditorEditValue
    {
      get { return Text; }
      set
      {
        this.Text = (string)value;
        this.valueChanged = false;
      }
    }

    public DataAxisGrid EditorOwnerGrid
    {
      get { return this.ownerGrid; }
      set { this.ownerGrid = value; }
    }

    public int EditorTableRowIndex
    {
      get { return this.rowIndex; }
      set { this.rowIndex = value; }
    }

    public bool EditorValueChanged
    {
      get { return this.valueChanged; }
      set { this.valueChanged = value; }
    }

    public BaseDataCellManager CellManager
    {
      get { return cellManager; }
      set { cellManager = value; }
    }

    public DataAxisGridDataCellEditorOccupyEventArgs CellPosData
    {
      get;
      set;
    }

    public bool EditorWantsInputKey(Keys keyData, bool dataGridWantsInputKey)
    {
      switch (keyData & Keys.KeyCode)
      {
        case Keys.Right:
          if ((this.RightToLeft == RightToLeft.No && !(this.SelectionLength == 0 && this.SelectionStart == this.Text.Length)) ||
              (this.RightToLeft == RightToLeft.Yes && !(this.SelectionLength == 0 && this.SelectionStart == 0)))
          {
            return true;
          }
          break;

        case Keys.Left:
          if ((this.RightToLeft == RightToLeft.No && !(this.SelectionLength == 0 && this.SelectionStart == 0)) ||
              (this.RightToLeft == RightToLeft.Yes && !(this.SelectionLength == 0 && this.SelectionStart == this.Text.Length)))
          {
            return true;
          }
          break;

        case Keys.Down:
          int end = this.SelectionStart + this.SelectionLength;
          if (this.Text.IndexOf("\r\n", end, StringComparison.Ordinal) != -1)
          {
            return true;
          }
          break;

        case Keys.Up:
          if (!(this.Text.IndexOf("\r\n", StringComparison.Ordinal) < 0 ||
                this.SelectionStart + this.SelectionLength < this.Text.IndexOf("\r\n", StringComparison.Ordinal)))
          {
            return true;
          }
          break;

        case Keys.Home:
        case Keys.End:
          if (this.SelectionLength != this.Text.Length)
          {
            return true;
          }
          break;

        case Keys.Prior:
        case Keys.Next:
          if (this.valueChanged)
          {
            return true;
          }
          break;

        case Keys.Delete:
          if (this.SelectionLength > 0 ||
              this.SelectionStart < this.Text.Length)
          {
            return true;
          }
          break;

        case Keys.Enter:
          if (CompletingManager.PopUpListBoxVisible)
          {
            return true;
          }
          else if ((keyData & (Keys.Control | Keys.Shift | Keys.Alt)) == Keys.Shift && this.Multiline && this.AcceptsReturn)
          {
            return true;
          }
          break;

        case Keys.Escape:
          if (CompletingManager.PopUpListBoxVisible)
          {
            return true;
          }
          break;
      }
      return !dataGridWantsInputKey;
    }

    public void PrepareEditorForEdit(bool selectAll)
    {
      if (selectAll)
        SelectAll();
      else
        this.SelectionStart = this.Text.Length;
    }

    protected override void OnTextChanged(EventArgs e)
    {
      base.OnTextChanged(e);
      this.valueChanged = true;
      ownerGrid.EditorTextChanged(e);
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
      var ke = new DataAxisGridEditorKeyEventArgs(
        ownerGrid, CellPosData.PropAxisBar, CellPosData.ListItemBar, this, CellManager, e);
      CellManager.OnEditorKeyDown(ke);
      if (ke.Handled)
        e.Handled = true;
      else
        base.OnKeyDown(e);
    }

    protected override TextAutoCompletingManager CreateCompletingManager()
    {
      return new DataAxisGridTextBoxAutoCompletingManager();
    }

  }

  public class DataAxisGridTextBoxAutoCompletingManager : TextAutoCompletingManager
  {
    public DataAxisGridTextBoxAutoCompletingManager()
    {

    }

    protected internal override void GetCompletingDataSourceInfo(TextAutoCompleting autoCompletingObj, Control control, string dataPropertyName, out object dataSource, out string propName)
    {
      TextAutoCompletingSource srcParams = autoCompletingObj.DataSourceParams;

      if (srcParams.SourceType == TextAutoCompletingSourceType.BindDataSource)
      {
        DataAxisGridTextBoxEditControl editControl = control as DataAxisGridTextBoxEditControl;

        dataSource = editControl.CellPosData.PropAxisBar.GetEditUniqueValues();
        propName = null;
        srcParams.ResetDataSourceChangedState();
        //srcParams.CurDataSource = dataSource;
      }
      else
      {
        base.GetCompletingDataSourceInfo(autoCompletingObj, control, dataPropertyName, out dataSource, out propName);
      }
    }

  }
}
