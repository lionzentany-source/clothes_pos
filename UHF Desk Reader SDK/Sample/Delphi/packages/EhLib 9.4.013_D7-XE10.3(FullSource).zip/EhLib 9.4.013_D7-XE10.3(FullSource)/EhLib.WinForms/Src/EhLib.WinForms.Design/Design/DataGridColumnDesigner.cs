﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Windows.Forms;

namespace EhLib.WinForms.Design
{

  public class DataGridBaseColumnDesigner : ComponentDesigner
  {

    public override void Initialize(IComponent component)
    {
      base.Initialize(component);

      IDesignerHost host = (IDesignerHost)GetService(typeof(IDesignerHost));
      if (host != null)
      {
        host.LoadComplete += Host_LoadComplete;
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        IDesignerHost host = (IDesignerHost)GetService(typeof(IDesignerHost));
        if (host != null)
        {
          host.LoadComplete -= Host_LoadComplete;
        }
      }

      base.Dispose(disposing);
    }
    #region Properties
    public override DesignerVerbCollection Verbs
    {
      get
      {
        return CreateDesignVerbs();
      }
    }

    public DataGridColumn Column
    {
      get { return Component as DataGridColumn; }
    }

    public DataGridSuperTitle SuperTitle
    {
      get { return Component as DataGridSuperTitle; }
    }

    public DataGridEh Grid
    {
      get
      {
        if (Column != null)
          return Column.Grid;
        else if (SuperTitle != null)
          return SuperTitle.Grid;
        else
          return null;
      }
    }

    protected override IComponent ParentComponent 
    { 
      get { return Grid; } 
    }
    #endregion 

    #region Methods
    private void Host_LoadComplete(object sender, EventArgs e)
    {
      if (Column != null && Column.Grid == null)
      {
        //MessageBox.Show("Column " + Column.Name + " is not assigned to any DataGridEh");
        DialogResult result = MessageBox.Show("Column " + Column.Name + " is not assigned to any DataGridEh." + 
                                              Environment.NewLine + Environment.NewLine +
                                              "Do you want to delete the Column: " + Column.Name + " ?",
                        "Unbound object detected",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);

        if (result == DialogResult.Yes)
          Component.Dispose();
      }
    }

    protected void CreateMoveToSuperTitleList(DesignerVerbCollection verbs)
    {
      IMultiTitleNodeProvider item = Component as IMultiTitleNodeProvider;
      DataGridTitleNode thisNode = item.GetNode();
      DesignerVerb sbvVerb;

      if (thisNode.Parent.Items.Count == 1) return;

      if (thisNode.Parent != Grid.Title.MultiTitle.Root)
      {
        sbvVerb = new DesignerVerb("Move To MultiTitle Root", MoveToMultiTitleRoot);
        verbs.Add(sbvVerb);
      }

      DataGridTitleNode loopNode = Grid.Title.MultiTitle.TitleTree.GetFirst();
      while (loopNode != null)
      {
        if (loopNode.NodeType == DataGridTitleNodeType.SuperTitle)
        {
          DataGridTitleNode[] upChain = loopNode.GetUpChain();
          if (thisNode.Parent != loopNode && 
              thisNode != loopNode &&
              Array.IndexOf(upChain, thisNode) < 0)
          {
            sbvVerb = new SuperTitleDesignerVerbEh("Move under \"" + loopNode.SuperTitle.Text + "\"", MoveToSuperTitleHandler, loopNode.SuperTitle);
            verbs.Add(sbvVerb);
          }
        }
        loopNode = Grid.Title.MultiTitle.TitleTree.GetNext(loopNode);
      }
    }

    protected virtual DesignerVerbCollection CreateDesignVerbs()
    {
      return null;
    }


    protected void MoveToMultiTitleRoot(object sender, EventArgs e)
    {
      IMultiTitleNodeProvider item = Component as IMultiTitleNodeProvider;

      DataGridTitleNode node = item.GetNode();
      DataGridTitleNode baseNode = node;
      while (baseNode.Parent != Grid.Title.MultiTitle.Root)
        baseNode = baseNode.Parent;

      Grid.Title.MultiTitle.TitleTree.BeginUpdate();
      Grid.Title.MultiTitle.Root.Items.MoveIn(baseNode.Index, item);
      Grid.Title.MultiTitle.TitleTree.EndUpdate();

      IComponentChangeService chService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
      chService.OnComponentChanged(this, null, null, null);
    }

    protected void MoveToSuperTitleHandler(object sender, EventArgs e)
    {
      DataGridSuperTitle superTitle = (sender as SuperTitleDesignerVerbEh).SuperTitle;
      IMultiTitleNodeProvider item = Component as IMultiTitleNodeProvider;

      Grid.Title.MultiTitle.TitleTree.BeginUpdate();
      superTitle.Subtitles.MoveIn(superTitle.Subtitles.Count, item);
      Grid.Title.MultiTitle.TitleTree.EndUpdate();

      IComponentChangeService chService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
      chService.OnComponentChanged(this, null, null, null);
    }

    protected void AddSuperTitleHandler(object sender, EventArgs e)
    {

      IMultiTitleNodeProvider firstItem = (IMultiTitleNodeProvider)Component;

      string stTitleText = "SuperTitle";
      DialogResult result = EhLibUtils.InputBox("Name of title", "Enter text of title", ref stTitleText);
      if (result != DialogResult.OK) return;

      IDesignerHost host = (IDesignerHost)GetService(typeof(IDesignerHost));
      DataGridSuperTitle st = (DataGridSuperTitle)host.CreateComponent(typeof(DataGridSuperTitle));
      st.Text = stTitleText;

      DataGridTitleNode node = firstItem.GetNode();

      Grid.Title.MultiTitle.BeginUpdate();
      int Index = node.Index;
      node.Parent.Subtitles.Insert(Index, st);

      st.Subtitles.MoveIn(st.Subtitles.Count, firstItem);

      Grid.Title.MultiTitle.EndUpdate();

      IComponentChangeService chService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
      chService.OnComponentChanged(this, null, null, null);
    }
    #endregion 
  }

  //class GradientLabelVerbCollection : DesignerVerbCollection
  //{
  //  //GradientLabel glabel;
  //  private IComponent component;

  //  public GradientLabelVerbCollection(IComponent component)
  //  {
  //    //glabel = component as GradientLabel;
  //    this.component = component;

  //    //Add(new DesignerVerb("Перевернуть &цвета", OnInvertColors));
  //    Add(new DesignerVerb("Add SuperTitle", AddSuperTitleHandler));

  //    //  // Add SuperTitle Verb
  //    //  if (addSuperTitleVerb == null)
  //    //    addSuperTitleVerb = new DesignerVerb("Add SuperTitle", AddSuperTitleHandler);
  //    //  addSuperTitleVerb.Visible = true;
  //    //  addSuperTitleVerb.Enabled = allSelIsMultiTitleProvider && Grid.Title.MultiTitle.Active;
  //    //  addSuperTitleVerb.Supported = true;
  //    //  mcs.RemoveVerb(addSuperTitleVerb);
  //    //  mcs.AddVerb(addSuperTitleVerb);

  //  }

  //  private void AddSuperTitleHandler(object sender, EventArgs e)
  //  {

  //    IMultiTitleNodeProvider firstItem = (IMultiTitleNodeProvider)component;

  //    string stTitleText = "SuperTitle";
  //    DialogResult result = EhLibUtils.InputBox("Name of title", "Enter text of title", ref stTitleText);
  //    if (result != DialogResult.OK) return;

  //    IDesignerHost host = (IDesignerHost)component.GetService(typeof(IDesignerHost));
  //    DataGridSuperTitle st = (DataGridSuperTitle)host.CreateComponent(typeof(DataGridSuperTitle));
  //    st.Text = stTitleText;
  //    //DataGridSuperTitle st = new DataGridSuperTitle()
  //    //{
  //    //  Text = stTitleText
  //    //};

  //    DataGridTitleNode node = firstItem.GetNode();

  //    Grid.Title.MultiTitle.BeginUpdate();
  //    int Index = node.Index;
  //    node.Parent.Subtitles.Insert(Index, st);

  //    //selList.Reverse();

  //    foreach (object o in selList)
  //    {
  //      st.Subtitles.MoveIn(st.Subtitles.Count, (IMultiTitleNodeProvider)o);
  //    }

  //    Grid.Title.MultiTitle.EndUpdate();

  //    IComponentChangeService chService = (IComponentChangeService)GetService(typeof(IComponentChangeService));
  //    chService.OnComponentChanged(this, null, null, null);
  //  }

  //  //private void OnInvertColors(object sender, System.EventArgs e)
  //  //{
  //  //}

  //}

  public class DataGridColumnDesigner : DataGridBaseColumnDesigner
  {
    internal INestedContainer nestedContainer;

    public override void Initialize(IComponent component)
    {
      base.Initialize(component);

      DataGridColumn col = component as DataGridColumn;
      Debug.Assert(col != null, "Error: DataGridBaseColumnDesigner component is not DataGridColumn");

      nestedContainer = (INestedContainer)GetService(typeof(INestedContainer));
      if (nestedContainer != null)
      {
        nestedContainer.Add(col.Title, "Title");
        nestedContainer.Add(col.EditButton, "EditButton");
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        if (nestedContainer != null) nestedContainer.Dispose();
      }

      base.Dispose(disposing);
    }

    protected override DesignerVerbCollection CreateDesignVerbs()
    {
      DesignerVerbCollection verbs;
      verbs = new DesignerVerbCollection();

      if (Grid != null && Grid.Title.MultiTitle.Active)
      {
        verbs.Add(new DesignerVerb("Add SuperTitle", AddSuperTitleHandler));
        CreateMoveToSuperTitleList(verbs);
      }

      return verbs;
    }
  }

  public class DataGridSuperTitleDesigner : DataGridBaseColumnDesigner
  {

    protected override DesignerVerbCollection CreateDesignVerbs()
    {
      DesignerVerbCollection verbs;
      verbs = new DesignerVerbCollection();

      if (Grid != null && Grid.Title.MultiTitle.Active)
      {
        verbs.Add(new DesignerVerb("Delete SuperTitle", DeleteSuperTitleHandler));
        verbs.Add(new DesignerVerb("Add SuperTitle", AddSuperTitleHandler));
        CreateMoveToSuperTitleList(verbs);
      }

      return verbs;
    }

    private void DeleteSuperTitleHandler(object sender, EventArgs e)
    {
      Component.Dispose();
    }
  }

  public class DesignerVerbEh : DesignerVerb
  {
    public DesignerVerbEh(string text, EventHandler handler, bool enabled) : base(text, handler)
    {
      Enabled = enabled;
    }

    public DesignerVerbEh(string text, EventHandler handler) : base(text, handler)
    {
    }

    public DesignerVerbEh(string text, EventHandler handler, CommandID startCommandID) : base(text, handler, startCommandID)
    {
    }
  }

  public class SuperTitleDesignerVerbEh : DesignerVerb
  {
    private readonly DataGridSuperTitle superTitle;

    public SuperTitleDesignerVerbEh(string text, EventHandler handler, DataGridSuperTitle superTitle) : base(text, handler)
    {
      this.superTitle = superTitle;
    }

    public DataGridSuperTitle SuperTitle
    {
      get { return superTitle; }
    }
  }

}
