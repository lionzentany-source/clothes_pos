﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of data cell manager that a DateTime picker user interface (UI). 
  /// </summary>
  //[DataCellDesignTimeVisible(true)]
  //[ToolboxItem(true)]
  public class DateTimeDataCellManager : BaseDataCellManager
  {

    #region privates
    private Rectangle inCellLinkBounds;
    private GridCoord linkCellIndex = new GridCoord(-1, -1);

    private string dateFormatString = "d";
    private string timeFormatString = "t";
    private bool hideTimeWhenZero = true;
    private string dateTimePartSeparator = " ";
    #endregion

    public DateTimeDataCellManager()
    {
    }

    #region properties
    [DefaultValue("d")]
    public string DateFormatString
    {
      get
      {
        return dateFormatString;
      }
      set
      {
        if (value != dateFormatString)
        {
          dateFormatString = value;
          if (BoundGrid != null)
            BoundGrid.Invalidate();
        }
      }
    }

    [DefaultValue("t")]
    public string TimeFormatString
    {
      get
      {
        return timeFormatString;
      }
      set
      {
        if (value != timeFormatString)
        {
          timeFormatString = value;
          if (BoundGrid != null)
            BoundGrid.Invalidate();
        }
      }
    }

    [DefaultValue(true)]
    public bool HideTimeWhenZero
    {
      get
      {
        return hideTimeWhenZero;
      }
      set
      {
        if (value != hideTimeWhenZero)
        {
          hideTimeWhenZero = value;
          if (BoundGrid != null)
            BoundGrid.Invalidate();
        }
      }
    }

    [DefaultValue(" ")]
    public string DateTimePartSeparator
    {
      get
      {
        return dateTimePartSeparator;
      }
      set
      {
        if (value != dateTimePartSeparator)
        {
          dateTimePartSeparator = value;
          if (BoundGrid != null)
            BoundGrid.Invalidate();
        }
      }
    }

    protected override Type DefaultEditorType
    {
      get
      {
        return typeof(DataAxisGridDateTimeBoxEditControl);
      }
    }
    #endregion

    #region methods
    protected override void PaintBackground(DataAxisGridDataCellPaintEventArgs e)
    {
      base.PaintBackground(e);
    }

    protected internal override void OnPaintContent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      Rectangle textRect;
      Color foreColor = e.ParentCellPaintArgs.ForePaintColor;
      Font drawFont = e.ParentCellPaintArgs.Font;
      HorizontalAlignment horzAlign = e.ParentCellPaintArgs.HorzAlign;
      VerticalAlignment vertAlign = e.ParentCellPaintArgs.VertAlign;

      string text = GetDisplayText(e.PropAxisBar, e.ListItemBar);
      if (text != null)
      {
        textRect = EhLibUtils.TrimPadding(e.CellContentRect, e.ParentCellPaintArgs.Padding);

        if (linkCellIndex.X == e.ParentCellPaintArgs.ColIndex &&
            linkCellIndex.Y == e.ParentCellPaintArgs.RowIndex)
        {
          drawFont = new Font(Font, FontStyle.Underline);
        }

        e.Grid.PaintingDrawText(e.GraphicsContext, text, drawFont, textRect, foreColor, horzAlign, vertAlign, false);
      }

      CharacterRange[] charRanges;
      string searchingText = e.Grid.GetHighlightSearchingData(e.PropAxisBar, e.ListItemBar, text, out charRanges);
      if (!String.IsNullOrEmpty(searchingText))
      {
        PaintHighlightedText(e, searchingText, charRanges);
      }
    }

    protected internal virtual void PaintHighlightedText(DataAxisGridDataCellContentPaintEventArgs e, string text, CharacterRange[] charRanges)
    {
      string cellText;
      string hiS;
      Rectangle textRect;
      Region oldClip;
      int outOfBounds = 0;
      Rectangle paintRect = e.CellContentRect;

      cellText = GetDisplayText(e.PropAxisBar, e.ListItemBar);
      hiS = text;
      if (string.IsNullOrEmpty(hiS) == true) return;

      textRect = EhLibUtils.TrimPadding(e.CellContentRect, e.ParentCellPaintArgs.Padding);

      Rectangle[] stringRegions = EhLibUtils.MeasureCharacterRanges(e.Graphics, cellText, Font,
        textRect, HorzAlign, VertAlign, false, charRanges);
      oldClip = e.Graphics.Clip;
      e.Graphics.SetClip(paintRect, CombineMode.Intersect);

      for (int i = 0; i < stringRegions.Length; i++)
      {
        Rectangle regRect = stringRegions[i];

        if (textRect.IntersectsWith(regRect))
        {
          e.Graphics.FillRectangle(new SolidBrush(Color.Yellow), regRect);

          string drawText = cellText.Substring(charRanges[i].First, charRanges[i].Length);

          EhLibUtils.DrawText(e.Graphics, drawText, Font, regRect, ForeColor, HorizontalAlignment.Left, VerticalAlignment.Top, TextFormatFlagsEh.None);
        }
        else
        {
          outOfBounds = outOfBounds + 1;
        }
      }

      if (outOfBounds > 0)
      {
        string outOfBoundsStr = outOfBounds.ToString();
        Font ofbFont = new Font(Font.FontFamily, 6);
        Size ofbSize = EhLibUtils.MeasureText(e.Graphics, outOfBoundsStr, ofbFont, new Size(1, 1), CellTextWrapMode.NoWrap);
        Rectangle ofbRect = new Rectangle(textRect.Right - ofbSize.Width - 2, textRect.Top, ofbSize.Width + 2, ofbSize.Height + 2);

        e.Graphics.FillRectangle(new SolidBrush(Color.Yellow), ofbRect);
        EhLibUtils.DrawText(e.Graphics, outOfBoundsStr, ofbFont, ofbRect, ForeColor, HorizontalAlignment.Center, VerticalAlignment.Center, TextFormatFlagsEh.None);
      }

      e.Graphics.Clip = oldClip;
    }

    //protected internal override void PrintCell(BaseGridControl grid, PrintServiceEventArgs e,
    //  Rectangle paintRect,
    //  int colIndex, int rowIndex,
    //  int areaColIndex, int areaRowIndex)
    //{
    //  Font drawFont;
    //  Rectangle textRect;
    //  Color fForeColor = Color.Black;

    //  string text = GetDisplayText(grid, areaColIndex, areaRowIndex);
    //  if (text != null)
    //  {
    //    drawFont = Font;
    //    TextFormatFlagsEh flags = TextFormatFlagsEh.None;
    //    textRect = EhLibUtils.TrimPadding(paintRect, Padding);

    //    e.DrawText(text, drawFont, textRect, fForeColor, HorzAlign, VertAlign, flags);
    //  }
    //}

    public override bool IsCharToEnterEditMode(KeyPressEventArgs e)
    {
      UnicodeCategory uc = char.GetUnicodeCategory(e.KeyChar);
      if (uc != UnicodeCategory.Control)
        return true;

      return base.IsCharToEnterEditMode(e);
    }

    protected internal override void OnEditorOccupy(DataAxisGridDataCellEditorOccupyEventArgs e)
    {
      DataAxisGridDateTimeBoxEditControl editor = (DataAxisGridDateTimeBoxEditControl)e.Editor;

      if (e.Value is DateTime)
        editor.EditorEditValue = (DateTime)e.Value;
      else
        editor.EditorEditValue = null;

      editor.SetEditButton(EditButton);
      editor.Font = e.EditorParams.Font;
      editor.ReadOnly = e.EditorParams.ReadOnly;
      editor.PrepareEditorForEdit(e.SelectAll);
      editor.Padding = GetPadding(e.PropAxisBar);
      editor.HorzAlign = GetHorzAlign(e.PropAxisBar);
      editor.DateFormatString = DateFormatString;
      editor.TimeFormatString = TimeFormatString;
      editor.DateTimePartSeparator = DateTimePartSeparator;
    }

    protected override void OnEditorRelease(DataAxisGridDataCellEditorReleaseEventArgs e)
    {
      DataAxisGridDateTimeBoxEditControl editor = (DataAxisGridDateTimeBoxEditControl)e.Editor;
      editor.SetEditButton(null);
    }

    public virtual string GetCellNonfitToolTipText(BaseGridCellEventArgs e)
    {
      SizeF sf;
      Graphics g = EhLibUtils.DisplayGraphicsCash;
      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      DataAxisGrid axisGrid = e.Grid as DataAxisGrid;

      AxisObjectsByDataColRowIndex(axisGrid, e.AreaColIndex, e.AreaRowIndex, out propAxisBar, out listItemBar);

      string cellText = GetDisplayText(propAxisBar, listItemBar);
      Rectangle textRect = e.CellRect;

      textRect = EhLibUtils.TrimPadding(textRect, GetPadding(propAxisBar));

      sf = EhLibUtils.MeasureText(g, cellText, e.Grid.Font, textRect.Size, CellTextWrapMode.NoWrap);

      if (sf.Width > e.CellRect.Width)
        return cellText;
      else
        return "";
    }

    protected internal override void OnDisplayValueNeeded(DataAxisGridDataCellDisplayValueNeededEventArgs e)
    {
      Type dataType;

      if (e.PropAxisBar != null)
        dataType = e.PropAxisBar.DataType;
      else
        dataType = null;

      if (!EhLibUtils.DBValueEqual(e.Value, null) && dataType.IsAssignableFrom(typeof(DateTime)))
      {
        DateTime dtValue = Convert.ToDateTime(e.Value);
        string result = "";
        if (!String.IsNullOrEmpty(DateFormatString))
          result = dtValue.ToString(DateFormatString);
        if (!String.IsNullOrEmpty(TimeFormatString) &&
            (!HideTimeWhenZero || (HideTimeWhenZero && dtValue.TimeOfDay.Ticks != 0))
           )
        {
          result = result + DateTimePartSeparator;
          result = result + dtValue.ToString(TimeFormatString);
        }
        e.DisplayValue = result;
      }
      else
      {
        base.OnDisplayValueNeeded(e);
      }
    }

    protected internal override void OnMouseEnter(DataAxisGridDataCellEnterEventArgs e)
    {

      base.OnMouseEnter(e);

      DataAxisGrid axisGrid = e.Grid as DataAxisGrid;

      if (e.Grid.IsShowDataCellsNonfitTooltips())
      {
        string cellText = GetCellNonfitToolTipText(e);

        if (!string.IsNullOrEmpty(cellText))
        {
          axisGrid.ShowCellNonFitToolTip(cellText, this, e);
        }
      }

      PropertyAxisBar propAxisBar;
      DataAxisGridListItemBar listItemBar;
      AxisObjectsByDataColRowIndex(axisGrid, e.AreaColIndex, e.AreaRowIndex, out propAxisBar, out listItemBar);
    }

    protected internal override void OnMouseLeave(BaseGridCellLeaveEventArgs e)
    {
      base.OnMouseLeave(e);
      (e.Grid as DataAxisGrid).HideCellNonFitToolTip();
      inCellLinkBounds = Rectangle.Empty;
      if (linkCellIndex.X >= 0 || linkCellIndex.Y >= 0)
      {
        linkCellIndex = new GridCoord(-1, -1);
        e.Grid.InvalidateRow(e.RowIndex);
      }
    }

    protected internal override void OnMouseMove(BaseGridCellMouseEventArgs e)
    {
      base.OnMouseMove(e);
      Point inCellPos = new Point(e.InCellX, e.InCellY);

      bool oldMouseInCellLinkBounds = (linkCellIndex.X >= 0 || linkCellIndex.Y >= 0);
      bool newMouseInCellLinkBounds = inCellLinkBounds.Contains(inCellPos);

      if (oldMouseInCellLinkBounds != newMouseInCellLinkBounds)
      {
        if (newMouseInCellLinkBounds)
          linkCellIndex = new GridCoord(e.ColIndex, e.RowIndex);
        else
          linkCellIndex = new GridCoord(-1, -1);
        e.Grid.InvalidateRow(e.RowIndex);
      }
    }

    protected internal override void OnMouseDown(DataAxisGridDataCellMouseEventArgs e)
    {
      if (linkCellIndex == new GridCoord(e.ColIndex, e.RowIndex) && !e.Grid.EditorBanned)
      {
        e.Grid.EditorBanned = true;
        base.OnMouseDown(e);
        e.Grid.EditorBanned = false;
      }
      else
        base.OnMouseDown(e);
    }

    protected internal override void OnMouseClick(BaseGridCellMouseEventArgs e)
    {
      base.OnMouseClick(e);
      if (linkCellIndex == new GridCoord(e.ColIndex, e.RowIndex))
      {
        PropertyAxisBar propAxisBar;
        DataAxisGridListItemBar listItemBar;
        DataAxisGrid axisGrid = e.Grid as DataAxisGrid;

        AxisObjectsByDataColRowIndex(axisGrid, e.AreaColIndex, e.AreaRowIndex, out propAxisBar, out listItemBar);

        DataAxisGridDataCellEventArgs de = propAxisBar.CreateDataCellEventArgs(axisGrid, e.ColIndex, e.RowIndex,
          e.AreaColIndex, e.AreaRowIndex, e.CellRect, propAxisBar, listItemBar, this);
        OnContentClick(de);
      }
    }

    protected internal override void OnQueryCursor(BaseGridCellQueryCursorEventArgs e)
    {
      base.OnQueryCursor(e);
      if (linkCellIndex.X == e.ColIndex && linkCellIndex.Y == e.RowIndex)
        e.Cursor = Cursors.Hand;
    }

    //public virtual int GetOneLineHeight()
    //{
    //  return CalcDefaultRowHeight();
    //}

    protected internal override int CalcCellHeight(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, int cellWidth)
    {
      int th, result;
      Size outSize;

      string text = GetDisplayText(propAxisBar, listItemBar);
      Padding padding = GetPadding(propAxisBar);

      result = base.CalcCellHeight(propAxisBar, listItemBar, cellWidth);

      if (HeightOptions.GetAutoExpand(propAxisBar) && HeightOptions.Unit == GridRowHeightUnit.TextLine)
      {
        outSize = EhLibUtils.MeasureText(EhLibUtils.DisplayGraphicsCash, text, GetFont(propAxisBar));

        th = outSize.Height + padding.Top + padding.Bottom;
        if (th > result)
          result = th;
      }

      return result;
    }

    protected override bool EditButtonDefaultVisible()
    {
      return true;
    }

    public override string GetTypeNameAbbr()
    {
      return "DtTm";
    }
    #endregion
  }

  [ToolboxItem(false)]
  [System.ComponentModel.DesignerCategory("Code")]
  public class DataAxisGridDateTimeBoxEditControl : DateTimeBoxEh, IDataAxisGridCellInPlaceEditor
  {
    private DataAxisGrid ownerGrid;
    private int rowIndex;
    private bool valueChanged;
    private BaseDataCellManager cellManager;

    public DataAxisGridDateTimeBoxEditControl()
    {
      this.TabStop = false;
      this.Border.Style = ControlBorderStyle.None;
      InitData();
    }

    private void InitData()
    {
      this.AutoSize = false;
    }

    public object EditorEditValue
    {
      get { return Value; }
      set
      {
        this.Value = (value as Nullable<DateTime>);
        this.valueChanged = false;
      }
    }

    public DataAxisGrid EditorOwnerGrid
    {
      get { return this.ownerGrid; }
      set { this.ownerGrid = value; }
    }

    public int EditorTableRowIndex
    {
      get { return this.rowIndex; }
      set { this.rowIndex = value; }
    }

    public bool EditorValueChanged
    {
      get
      {
        Validate();
        return this.valueChanged;
      }
      set
      {
        this.valueChanged = value;
      }
    }

    public BaseDataCellManager CellManager
    {
      get { return cellManager; }
      set { cellManager = value; }
    }

    public DataAxisGridDataCellEditorOccupyEventArgs CellPosData
    {
      get;
      set;
    }

    public bool EditorWantsInputKey(Keys keyData, bool dataGridWantsInputKey)
    {
      switch (keyData & Keys.KeyCode)
      {
        case Keys.Right:
            return true;

        case Keys.Left:
            return true;

        case Keys.Down:
            return true;

        case Keys.Up:
            return true;

        case Keys.Home:
        case Keys.End:
            return true;

        case Keys.Prior:
        case Keys.Next:
            return true;

        case Keys.Delete:
            return true;
      }
      return !dataGridWantsInputKey;
    }

    public void PrepareEditorForEdit(bool selectAll)
    {
      if (selectAll)
        SelectAll();
      else
        SelectedPatternItemIndex = 0;
    }

    protected override void OnValueChanged(EventArgs e)
    {
      base.OnTextChanged(e);
      this.valueChanged = true;
      ownerGrid.EditorTextChanged(e);
    }

    protected override void OnEditItemDisplayTextChanged(EventArgs e)
    {
      base.OnEditItemDisplayTextChanged(e);
      if (Focused)
      {
        this.valueChanged = true;
        ownerGrid.EditorTextChanged(e);
      }
    }
  }

  public interface IDateTimeDataCellManager
  {
    string DateFormatString { get; }
    string TimeFormatString { get; }
    bool HideTimeWhenZero { get; }
    string DateTimePartSeparator { get; }
  }

}
