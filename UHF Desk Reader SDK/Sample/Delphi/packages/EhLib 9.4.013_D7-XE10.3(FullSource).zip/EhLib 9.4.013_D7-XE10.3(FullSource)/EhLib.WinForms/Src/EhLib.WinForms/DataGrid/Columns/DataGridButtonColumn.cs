﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of column in a DataGridEh control that displays a check box user interface (UI).
  /// </summary>
  [DataGridColumnDesignTimeVisible(true)]
  public class DataGridButtonColumn : DataGridColumn
  {
    #region privates
    #endregion

    public DataGridButtonColumn()
    {
    }

    #region properties
    [Browsable(false)]
    public new ButtonDataCellManager DataCell
    {
      get { return (ButtonDataCellManager)base.InternalCellManager; }
    }

    [DefaultValue(FlatStyle.Standard) ]
    public FlatStyle FlatStyle
    {
      get { return DataCell.FlatStyle; }
      set { DataCell.FlatStyle = value; }
    }

    public string Text
    {
      get { return DataCell.Text; }
      set { DataCell.Text = value; }
    }

    [ DefaultValue(false) ]
    public bool UseColumnTextForButtonValue
    {
      get { return DataCell.UseColumnTextForButtonValue; }
      set { DataCell.UseColumnTextForButtonValue = value; }
    }
    #endregion

    #region methods
    protected override BaseDataCellManager CreateTemplateCell()
    {
      return new ButtonDataCellManager();
    }

    protected internal override void PaintCellBackground(
      BaseDataCellManager cellMan, DataAxisGridDataCellPaintEventArgs e)
    {
      Color baseColor;
      int alpha;

      if ((Grid.Focused) &&
          (Grid.Selection.SelectionType == GridSelectionType.None) &&
          ((BasePaintCellStates.Current & e.State) != 0))
      {
        using (
          SolidBrush fillBrush = new SolidBrush(Grid.BackColor))
        {
          e.Graphics.FillRectangle(fillBrush, e.CellRect);
        }

        if (Grid.Selection.RowHighlight)
        {
          baseColor = SystemColors.Highlight;
          alpha = 255 / 4;
          using (
            SolidBrush fillBrush = new SolidBrush(Color.FromArgb(alpha, baseColor)))
          {
            e.Graphics.FillRectangle(fillBrush, e.CellRect);
          }
        }
      }
      else
      {
        base.PaintCellBackground(cellMan, e);
      }
    }
    #endregion
  }

  //[DataGridDataCellDesignTimeVisible(true)]
  //public class DataGridButtonDataCellManager : DataGridBaseDataCellManager, IButtonDataCellManager
  //{

  //  #region internal

  //  private FlatStyle flatStyle = FlatStyle.Standard;
  //  private string text;
  //  private bool useColumnTextForButtonValue;
  //  private bool buttonPaddingStored;
  //  private Padding buttonPadding = new Padding(0);
  //  private Padding defaultButtonPadding = new Padding(2, 3, 2, 3);
  //  private ButtonDataCellWorker cellWorker;
  //  //protected bool downState = false;
  //  #endregion

  //  public DataGridButtonDataCellManager()
  //  {
  //    cellWorker = new ButtonDataCellWorker(this);
  //  }

  //  #region properties
  //  [DefaultValue(FlatStyle.Standard)]
  //  public FlatStyle FlatStyle
  //  {
  //    get
  //    {
  //      return this.flatStyle;
  //    }
  //    set
  //    {
  //      if (this.flatStyle != value)
  //      {
  //        flatStyle = value;
  //        if (Grid != null)
  //          Grid.InvalidateGrid();
  //      }
  //    }
  //  }

  //  public string Text
  //  {
  //    get
  //    {
  //      return this.text;
  //    }
  //    set
  //    {
  //      if (value != this.text)
  //      {
  //        this.text = value;
  //        if (Grid != null)
  //          Grid.InvalidateGrid();
  //      }
  //    }
  //  }

  //  [DefaultValue(false)]
  //  public bool UseColumnTextForButtonValue
  //  {
  //    get
  //    {
  //      return this.useColumnTextForButtonValue;
  //    }
  //    set
  //    {
  //      if (this.useColumnTextForButtonValue != value)
  //      {
  //        this.useColumnTextForButtonValue = value;
  //        if (Grid != null)
  //          Grid.InvalidateGrid();
  //      }
  //    }
  //  }
  //  #endregion

  //  #region runtime properties
  //  [Browsable(false)]
  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new bool DownState
  //  {
  //    get
  //    {
  //      return cellWorker.DownState;
  //    }
  //    set
  //    {
  //      if (value != cellWorker.DownState)
  //      {
  //        cellWorker.DownState = value;
  //        if (Grid != null)
  //          Grid.InvalidateGrid();
  //      }
  //    }
  //  }

  //  public Padding ButtonPadding
  //  {
  //    get
  //    {
  //      if (buttonPaddingStored)
  //        return buttonPadding;
  //      else
  //        return DefaultButtonPadding();
  //    }
  //    set
  //    {
  //      buttonPadding = value;
  //      buttonPaddingStored = true;
  //      ButtonPaddingChanged();
  //    }
  //  }

  //  #endregion

  //  #region methods
  //  //ButtonPadding
  //  public virtual void ButtonPaddingChanged()
  //  {
  //    if (Grid != null)
  //      Grid.UpdateBaseFixedBands();
  //  }

  //  public virtual Padding DefaultButtonPadding()
  //  {
  //    if (Grid != null)
  //      return defaultButtonPadding;
  //    else
  //      return Padding.Empty;
  //  }

  //  public virtual bool ShouldSerializeButtonPadding()
  //  {
  //    return (buttonPaddingStored == true);
  //  }

  //  public virtual void ResetButtonPadding()
  //  {
  //    buttonPaddingStored = false;
  //    ButtonPaddingChanged();
  //  }

  //  //Other
  //  public override Padding DefaultPadding()
  //  {
  //    if (Grid != null)
  //      return GetPaddingForSidePadding(Grid.GetDataCellSidePadding());
  //    else
  //      return Padding.Empty;
  //  }

  //  protected Padding GetPaddingForSidePadding(Padding sidePadding)
  //  {
  //    return cellWorker.GetPaddingForSidePadding(sidePadding);
  //  }

  //  public override string GetDisplayText(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    if (UseColumnTextForButtonValue)
  //      return Text;
  //    else
  //      return base.GetDisplayText(propAxisBar, listItemBar);
  //  }

  //  protected override void PaintForeground(DataAxisGridDataCellPaintEventArgs e)
  //  {
  //    cellWorker.PaintForeground(e);
  //  }

  //  protected internal override void OnKeyDown(KeyEventArgs e)
  //  {
  //    cellWorker.OnKeyDown(e);
  //  }

  //  protected internal override void OnKeyUp(KeyEventArgs e)
  //  {
  //    cellWorker.OnKeyUp(e);
  //  }

  //  protected internal override void OnMouseDown(DataAxisGridDataCellMouseEventArgs e)
  //  {
  //    base.OnMouseDown(e);
  //    cellWorker.OnMouseDown(e);
  //  }

  //  protected internal override void OnMouseMove(DataAxisGridDataCellMouseEventArgs e)
  //  {
  //    base.OnMouseMove(e);
  //    cellWorker.OnMouseMove(e);
  //  }

  //  protected internal override void OnMouseUp(DataAxisGridDataCellMouseEventArgs e)
  //  {
  //    cellWorker.OnMouseUp(e);
  //    base.OnMouseUp(e);
  //  }

  //  protected internal override void OnMouseEnter(DataAxisGridDataCellEnterEventArgs e)
  //  {
  //    Grid.InvalidateCell(e.ColIndex, e.RowIndex);
  //    base.OnMouseEnter(e);
  //  }

  //  protected internal override void OnMouseLeave(DataAxisGridDataCellLeaveEventArgs e)
  //  {
  //    Grid.InvalidateCell(e.ColIndex, e.RowIndex);
  //    base.OnMouseLeave(e);
  //    cellWorker.OnMouseLeave(e);
  //  }

  //  protected internal override int CalcDefaultRowHeight()
  //  {
  //    return cellWorker.CalcDefaultRowHeight();
  //  }

  //  protected internal override int CalcCellHeight(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, int cellWidth)
  //  {
  //    return cellWorker.CalcCellHeight(propAxisBar, listItemBar, cellWidth);
  //  }

  //  #endregion

  //}

}
