﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Collections.ObjectModel;

namespace EhLib.WinForms
{
  public partial class BaseCustomizePropBarsDialog : Form
  {
    
    private readonly Collection<CustomizePropBarsDialogPropDataRow> propsTable;// = new List<AxisGridPropDataRow>();
    private readonly Collection<CustomizePropBarsDialogPropDataRow> dataViewVisibleProps;// = new List<AxisGridPropDataRow>();
    private readonly Collection<CustomizePropBarsDialogPropDataRow> dataViewHiddenProps;// = new List<AxisGridPropDataRow>();

    //private DataTable propsTable;
    //private DataView dataViewVisibleProps = new DataView();
    //private DataView dataViewHiddenProps = new DataView();
    private DataAxisGrid dataGrid;

    //protected int refColumnColIndex;
    //protected int visibleStateColIndex;
    //protected int nameColIndex;

    public BaseCustomizePropBarsDialog()
    {
      InitializeComponent();

      propsTable = CreateTable();
      dataViewVisibleProps = CreateDataViewVisiblePropsList();
      dataViewHiddenProps = CreateDataViewHiddenPropsList();
    }

    public DataAxisGrid DataGrid { get { return dataGrid; } }
    public DataGridEh HiddenPropBarsGrid { get { return hiddenPropBarsGrid; } }
    public DataGridEh VisiblePropBarsGrid { get { return visiblePropBarsGrid; } }
    public DataGridTextColumn VisGridNameColumn { get { return visGridNameColumn; } }
    public DataGridTextColumn HidGridNameColumn { get { return hidGridNameColumn; } }
    public Collection<CustomizePropBarsDialogPropDataRow> PropsTable { get { return propsTable; } }
    public Collection<CustomizePropBarsDialogPropDataRow> DataViewVisibleProps { get { return dataViewVisibleProps; } }
    public Collection<CustomizePropBarsDialogPropDataRow> DataViewHiddenProps { get { return dataViewHiddenProps; } }

    //public DataView DataViewVisibleProps { get { return dataViewVisibleProps; } }
    //public DataView DataViewHiddenProps { get { return dataViewHiddenProps; } }

    //public DataTable PropsTable { get { return propsTable; } }

    public static bool ShowCustomizePropBarsDialog(DataAxisGrid grid)
    {
      BaseCustomizePropBarsDialog dialog = new BaseCustomizePropBarsDialog();
      return dialog.ShowDialog(grid);
    }

    protected virtual Collection<CustomizePropBarsDialogPropDataRow> CreateTable()
    {
      return new Collection<CustomizePropBarsDialogPropDataRow>();
    }

    protected virtual Collection<CustomizePropBarsDialogPropDataRow> CreateDataViewVisiblePropsList()
    {
      return new Collection<CustomizePropBarsDialogPropDataRow>();
    }

    protected virtual Collection<CustomizePropBarsDialogPropDataRow> CreateDataViewHiddenPropsList()
    {
      return new Collection<CustomizePropBarsDialogPropDataRow>();
    }

    public new virtual bool ShowDialog(DataAxisGrid grid)
    {
      dataGrid = grid;
      InitData();

      if (ShowDialog() == DialogResult.OK)
      {
        WriteGridBarsData();
        return true;
      }
      else
      {
        return false;
      }
    }

    protected virtual void WriteGridBarsData()
    {
      DataGrid.PropBars.BeginUpdate();
      try
      {
        int i = 0;
        foreach (CustomizePropBarsDialogPropDataRow propBarDataRow in propsTable)
        {
          PropertyAxisBar propBar = propBarDataRow.PropBar;
          WritePropBarFromPropBarDataRow(propBar, propBarDataRow, i);
          i++;
        }
      }
      finally
      {
        DataGrid.PropBars.EndUpdate();
      }
    }

    protected virtual void WritePropBarFromPropBarDataRow(PropertyAxisBar propBar, CustomizePropBarsDialogPropDataRow propBarDataRow, int index)
    {
      propBar.Visible = propBarDataRow.VisibleState;
      propBar.DisplayIndex = index;
    }

    protected virtual void InitData()
    {
      ReadPropBars();

      //dataViewVisibleProps.Table = propsTable;
      //dataViewVisibleProps.RowFilter = "VisibleState = true";
      //visiblePropBarsGrid.DataSource = dataViewVisibleProps;
      bsVisiblePropBars.DataSource = dataViewVisibleProps;

      //dataViewHiddenProps.Table = propsTable;
      //dataViewHiddenProps.RowFilter = "VisibleState <> true";
      //HiddenPropBarsGrid.DataSource = dataViewHiddenProps;
      bsHiddenPropBars.DataSource = dataViewHiddenProps;

      bSetWidth.Visible = false;
    }

    protected virtual void ReadPropBars()
    {
      foreach (PropertyAxisBar propBar in DataGrid.ViewOrderedPropBars)
      {
        CustomizePropBarsDialogPropDataRow dataTow = CreateNewPropsDataRow(propBar);
        InitNewPropDataRow(dataTow, propBar);
        propsTable.Add(dataTow);
      }
      RefreshScreenLists();
    }

    protected virtual CustomizePropBarsDialogPropDataRow CreateNewPropsDataRow(PropertyAxisBar propBar)
    {
      return new CustomizePropBarsDialogPropDataRow();
    }

    protected virtual void InitNewPropDataRow(CustomizePropBarsDialogPropDataRow dataRow, PropertyAxisBar propBar)
    {
      dataRow.PropBar = propBar;
      dataRow.VisibleState = propBar.Visible;
      dataRow.Name = propBar.Title.Text;
    }

    private void HideSelected_Click(object sender, EventArgs e)
    {
      HideSelectedPropBars();
    }

    private void ShowSelected_Click(object sender, EventArgs e)
    {
      ShowSelectedPropBars();
    }

    private void VisGridNameColumn_DataCellMouseDoubleClick(object sender, DataGridDataCellMouseEventArgs e)
    {
      HideSelectedPropBars();
    }

    private void HidGridNameColumn_DataCellMouseDoubleClick(object sender, DataGridDataCellMouseEventArgs e)
    {
      ShowSelectedPropBars();
    }

    private void MoveUp_Click(object sender, EventArgs e)
    {
      MovePropBarsUpDown(true);
    }

    private void MoveDown_Click(object sender, EventArgs e)
    {
      MovePropBarsUpDown(false);
    }

    protected virtual void MovePropBarsUpDown(bool isMoveUp)
    {
      if (visiblePropBarsGrid.VisibleRows.Count == 0) return;

      List<CustomizePropBarsDialogPropDataRow> listForHide = new List<CustomizePropBarsDialogPropDataRow>();
      List<PropertyAxisBar> movedPropBars = new List<PropertyAxisBar>();
      int firstSelGridIndex = -1;
      int lastSelGridIndex = -1;
      int moveToDataRowIndex;
      CustomizePropBarsDialogPropDataRow firstSel = null;
      CustomizePropBarsDialogPropDataRow baseDataRow;

      foreach (DataGridRow row in visiblePropBarsGrid.VisibleRows)
      {
        if (row.Selected)
        {
          listForHide.Add(row.SourceItem as CustomizePropBarsDialogPropDataRow);
          if (firstSelGridIndex == -1)
          {
            firstSelGridIndex = row.VisibleIndex;
            firstSel = row.SourceItem as CustomizePropBarsDialogPropDataRow;
          }
          lastSelGridIndex = row.VisibleIndex;
        }
      }

      if (listForHide.Count == 0)
      {
        DataGridRow gridRow = visiblePropBarsGrid.CurrentRow;
        firstSel = gridRow.SourceItem as CustomizePropBarsDialogPropDataRow;
        listForHide.Add(firstSel);
        firstSelGridIndex = gridRow.VisibleIndex;
        lastSelGridIndex = gridRow.VisibleIndex;
        
      }

      foreach (CustomizePropBarsDialogPropDataRow rowView in listForHide)
      {
        propsTable.Remove(rowView);
      }

      if (isMoveUp)
      {
        if (firstSelGridIndex > 0) firstSelGridIndex = firstSelGridIndex - 1;
        baseDataRow = visiblePropBarsGrid.VisibleRows[firstSelGridIndex].SourceItem as CustomizePropBarsDialogPropDataRow;
      }
      else
      {
        if (lastSelGridIndex < visiblePropBarsGrid.VisibleRows.Count-1) lastSelGridIndex = lastSelGridIndex + 1;
        baseDataRow = visiblePropBarsGrid.VisibleRows[lastSelGridIndex].SourceItem as CustomizePropBarsDialogPropDataRow;
      }

      moveToDataRowIndex = propsTable.IndexOf(baseDataRow);

      if (isMoveUp)
      {
        if (moveToDataRowIndex == -1) moveToDataRowIndex = 0;
      }
      else
      {
        if (moveToDataRowIndex == -1 || moveToDataRowIndex == propsTable.Count-1)
          moveToDataRowIndex = propsTable.Count;
        else
          moveToDataRowIndex = moveToDataRowIndex + 1;
      }

      listForHide.Reverse();

      foreach (CustomizePropBarsDialogPropDataRow row in listForHide)
      {
        propsTable.Insert(moveToDataRowIndex, row);
        movedPropBars.Add(row.PropBar);
      }

      RefreshScreenLists();

      int i = 0;
      foreach (DataGridRow row in visiblePropBarsGrid.VisibleRows)
      {
        if ((row.SourceItem as CustomizePropBarsDialogPropDataRow) == firstSel)
        {
          visiblePropBarsGrid.CurrentRowIndex = i;
          break;
        }
        i++;
      }

      foreach (DataGridRow row in visiblePropBarsGrid.VisibleRows)
      {
        CustomizePropBarsDialogPropDataRow dataRow = (row.SourceItem as CustomizePropBarsDialogPropDataRow);
        PropertyAxisBar propBar = dataRow.PropBar;
        if (movedPropBars.IndexOf(propBar) >= 0)
          row.Selected = true;
      }

    }

    protected virtual void HideSelectedPropBars()
    {
      List<CustomizePropBarsDialogPropDataRow> listForHide = new List<CustomizePropBarsDialogPropDataRow>();

      foreach (DataGridRow row in visiblePropBarsGrid.Rows)
      {
        if (row.Selected)
          listForHide.Add(row.SourceItem as CustomizePropBarsDialogPropDataRow);
      }

      if (listForHide.Count == 0 && visiblePropBarsGrid.VisibleRows.Count > 0)
        listForHide.Add(visiblePropBarsGrid.CurrentRow.SourceItem as CustomizePropBarsDialogPropDataRow);

      foreach (CustomizePropBarsDialogPropDataRow rowView in listForHide)
      {
        rowView.VisibleState = false;
      }

      RefreshScreenLists();
    }

    protected virtual void ShowSelectedPropBars()
    {
      List<CustomizePropBarsDialogPropDataRow> listForShow = new List<CustomizePropBarsDialogPropDataRow>();

      foreach (DataGridRow row in hiddenPropBarsGrid.Rows)
      {
        if (row.Selected)
          listForShow.Add(row.SourceItem as CustomizePropBarsDialogPropDataRow);
      }

      if (listForShow.Count == 0 && hiddenPropBarsGrid.VisibleRows.Count > 0)
        listForShow.Add(hiddenPropBarsGrid.CurrentRow.SourceItem as CustomizePropBarsDialogPropDataRow);

      foreach (CustomizePropBarsDialogPropDataRow rowView in listForShow)
      {
        rowView.VisibleState = true;
      }

      RefreshScreenLists();
    }

    protected virtual void SetWidth_Click(object sender, EventArgs e)
    {
    }

    protected virtual void RefreshScreenLists()
    {
      RefreshDataViewVisibleProps();
      RefreshDataViewHiddenProps();
    }

    protected virtual void RefreshDataViewVisibleProps()
    {
      dataViewVisibleProps.Clear();

      foreach (CustomizePropBarsDialogPropDataRow propBarDataRow in propsTable)
      {
        if (IsPropRowInVisibleList(propBarDataRow))
          dataViewVisibleProps.Add(propBarDataRow);
      }

      int oldPos = bsVisiblePropBars.Position;
      bsVisiblePropBars.ResetBindings(false);
      bsVisiblePropBars.Position = Math.Min(oldPos, bsVisiblePropBars.Count - 1);
    }

    protected virtual bool IsPropRowInVisibleList(CustomizePropBarsDialogPropDataRow propBarDataRow)
    {
      return propBarDataRow.VisibleState;
    }

    protected virtual void RefreshDataViewHiddenProps()
    {
      DataViewHiddenProps.Clear();

      foreach (CustomizePropBarsDialogPropDataRow propBarDataRow in propsTable)
      {
        if (IsPropRowInHiddenList(propBarDataRow))
          DataViewHiddenProps.Add(propBarDataRow);
      }

      int oldPos = bsHiddenPropBars.Position;
      bsHiddenPropBars.ResetBindings(false);
      bsHiddenPropBars.Position = Math.Min(oldPos, bsHiddenPropBars.Count-1);
    }

    protected virtual bool IsPropRowInHiddenList(CustomizePropBarsDialogPropDataRow propBarDataRow)
    {
      return !propBarDataRow.VisibleState;
    }

  }

  public class DynaTypedList<T> : Collection<T>, ITypedList
  {
    private readonly Type itemType;

    public DynaTypedList(Type itemType)
    {
      this.itemType = itemType;
    }

    public PropertyDescriptorCollection GetItemProperties(PropertyDescriptor[] listAccessors)
    {
      if (listAccessors == null)
        return TypeDescriptor.GetProperties(itemType);
      else
        return null;
    }

    public string GetListName(PropertyDescriptor[] listAccessors)
    {
      return "";
    }
  }

  [Obfuscation(Feature = "renaming", Exclude = true, ApplyToMembers = false)]
  public class CustomizePropBarsDialogPropDataRow
  {
    public PropertyAxisBar PropBar { get; set; }
    public bool VisibleState { get; set; }
    public string Name { get; set; }
  }

}
