﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2019 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{
  public interface ICheckBoxDataCellHolder
  {
    CheckState OnGetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, out bool handled);
  }

  /// <summary>
  /// Defines a type of data cell manager that displays a check box user interface (UI).
  /// </summary>
  //[DataCellDesignTimeVisible(true)]
  //[ToolboxItem(true)]
  [DataCellDesignTimeVisible(true)]
  public class CheckBoxDataCellManager : ButtonBaseDataCellManager
  {

    #region >private consts
    private static readonly object EventKeyQueryCheckboxState = new object();
    #endregion <private consts

    #region >privates
    private static readonly Type CheckStateType = typeof(CheckState);
    private static readonly Type BooleanType = typeof(bool);

    bool threeState;
    object trueValue;
    object falseValue;
    object indeterminateValue;
    private FlatStyle flatStyle;
    #endregion <privates

    public CheckBoxDataCellManager()
    {
      flatStyle = FlatStyle.Standard;
    }

    #region >properties
    [DefaultValue(false)]
    public bool ThreeState
    {
      get
      {
        return this.threeState;
      }
      set
      {
        if (this.threeState != value)
        {
          this.threeState = value;
          if (BoundGrid != null)
            BoundGrid.InvalidateGrid();
        }
      }
    }

    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object TrueValue
    {
      get
      {
        return this.trueValue;
      }
      set
      {
        if (this.trueValue != value)
        {
          this.trueValue = value;
          if (BoundGrid != null)
            BoundGrid.InvalidateGrid();
        }
      }
    }

    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object FalseValue
    {
      get
      {
        return this.falseValue;
      }
      set
      {
        if (this.falseValue != value)
        {
          this.falseValue = value;
          if (BoundGrid != null)
            BoundGrid.InvalidateGrid();
        }
      }
    }

    [DefaultValue(null)]
    [TypeConverter(typeof(StringConverter))]
    public object IndeterminateValue
    {
      get
      {
        return this.indeterminateValue;
      }
      set
      {
        if (this.indeterminateValue != value)
        {
          this.indeterminateValue = value;
          if (BoundGrid != null)
            BoundGrid.InvalidateGrid();
        }
      }
    }

    [DefaultValue(FlatStyle.Standard)]
    public FlatStyle FlatStyle
    {
      get
      {
        return this.flatStyle;
      }
      set
      {
        if (this.flatStyle != value)
        {
          flatStyle = value;
          if (BoundGrid != null)
            BoundGrid.InvalidateGrid();
        }
      }
    }
    #endregion <properties

    #region >events
    public event EventHandler<DataGridCheckBoxColumnQueryCheckStateEventArgs> QueryCheckState
    {
      add
      {
        this.Events.AddHandler(EventKeyQueryCheckboxState, value);
      }
      remove
      {
        this.Events.RemoveHandler(EventKeyQueryCheckboxState, value);
      }
    }
    #endregion <events

    #region >methods
    public virtual CheckState DefaultGetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      CheckState result;
      if (propAxisBar != null && listItemBar != null)
      {
        object value = propAxisBar.GetListItemBarValue(listItemBar);
        result = GetCheckStateFromValue(value);
      }
      else
      {
        result = CheckState.Indeterminate;
      }
      return result;
    }

    protected internal virtual CheckState OnGetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      DataAxisGridCheckBoxQueryDataCellCheckStateEventArgs e = null;
      var eh = this.Events[EventKeyQueryCheckboxState] as EventHandler<DataAxisGridCheckBoxQueryDataCellCheckStateEventArgs>;
      if (eh != null /*&& !this.IsDisposed*/)
      {
        e = new DataAxisGridCheckBoxQueryDataCellCheckStateEventArgs(listItemBar);
        eh(this, e);
      }

      if ((e != null) && e.Handled)
        return e.CheckState;
      else
      {
        bool handled = false;
        CheckState result = CheckState.Indeterminate;

        var holder = propAxisBar as ICheckBoxDataCellHolder;
        if (holder != null)
          result = holder.OnGetCheckState(propAxisBar, listItemBar, out handled);

        if (!handled)
          result = DefaultGetCheckState(propAxisBar, listItemBar);

        return result;
      }
    }

    public CheckBoxState GetCheckBoxState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      CheckBoxState result;

      CheckState chState = OnGetCheckState(propAxisBar, listItemBar);

      if (chState == CheckState.Checked)
        result = CheckBoxState.CheckedNormal;
      else if (chState == CheckState.Unchecked)
        result = CheckBoxState.UncheckedNormal;
      else
        result = CheckBoxState.MixedNormal;

      return result;
    }

    public CheckState GetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      return OnGetCheckState(propAxisBar, listItemBar);
    }

    public CheckState GetCheckStateFromValue(object value)
    {
      CheckState result;

      if (value == null)
        result = CheckState.Indeterminate;
      else if (TrueValue != null && value.Equals(TrueValue))
        result = CheckState.Checked;
      else if (FalseValue != null && value.Equals(FalseValue))
        result = CheckState.Unchecked;
      else if (IndeterminateValue != null && value.Equals(IndeterminateValue))
        result = CheckState.Indeterminate;
      else if (value.Equals(true))
        result = CheckState.Checked;
      else if (value.Equals(false))
        result = CheckState.Unchecked;
      else
        result = CheckState.Indeterminate;

      return result;
    }

    public void SetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, CheckState checkState)
    {
      object value = GetDataValueFromCheckState(propAxisBar, listItemBar, checkState);
      propAxisBar.Grid.SetDataValue(propAxisBar, value);
    }

    public void InteractiveSetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, CheckState checkState)
    {
      object value = GetDataValueFromCheckState(propAxisBar, listItemBar, checkState);
      propAxisBar.Grid.InteractiveSetDataValue(propAxisBar, value);
    }

    public object GetDataValueFromCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, CheckState checkState)
    {
      object result = null;

      switch (checkState)
      {
        case CheckState.Unchecked:
          {
            if (FalseValue != null)
            {
              result = FalseValue;
            }
            else
            {
              if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(BooleanType))
                result = false;
              else if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(CheckStateType))
                result = CheckState.Unchecked;
            }
            break;
          }
        case CheckState.Checked:
          {
            if (TrueValue != null)
            {
              result = TrueValue;
            }
            else
            {
              if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(BooleanType))
                //EhLibUtils.DoNothing(); 
                result = true;
              else if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(CheckStateType))
                result = CheckState.Checked;
            }
            break;
          }
        case CheckState.Indeterminate:
          {
            if (IndeterminateValue != null)
            {
              result = IndeterminateValue;
            }
            else
            {
              if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(BooleanType))
                //EhLibUtils.DoNothing();
                result = null;
              else if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(CheckStateType))
                result = CheckState.Indeterminate;
            }
            break;
          }
      }
      return result;
    }

    public CheckState NextCheckState(CheckState cs)
    {
      if (ThreeState)
      {
        switch (cs)
        {
          case CheckState.Unchecked:
            {
              return CheckState.Checked;
            }
          case CheckState.Checked:
            {
              return CheckState.Indeterminate;
            }
          case CheckState.Indeterminate:
            {
              return CheckState.Unchecked;
            }
          default:
            {
              return CheckState.Unchecked;
            }
        }
      }
      else
      {
        switch (cs)
        {
          case CheckState.Unchecked:
            {
              return CheckState.Checked;
            }
          case CheckState.Checked:
            {
              return CheckState.Unchecked;
            }
          default:
            {
              return CheckState.Unchecked;
            }
        }
      }
    }

    public override void Toggle(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      CheckState cbState = GetCheckState(propAxisBar, listItemBar);
      cbState = NextCheckState(cbState);
      SetCheckState(propAxisBar, listItemBar, cbState);
    }

    public override void InteractiveToggle(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      CheckState cbState = GetCheckState(propAxisBar, listItemBar);
      cbState = NextCheckState(cbState);
      InteractiveSetCheckState(propAxisBar, listItemBar, cbState);
    }

    protected internal override void OnPaintContent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      Rectangle chRect = new Rectangle();
      bool isHot = false;
      bool isDown = false;
      GridCoord mouseHolderCellCoord = e.Grid.MouseHolderCellCoord;
      CheckBoxState cbState = GetCheckBoxState(e.PropAxisBar, e.ListItemBar);

      //AreaCellPosToGridCellPos(e.AreaColIndex, e.AreaRowIndex, out gridColIndex, out gridRowIndex);

      if (DownState && (e.Grid.CurrentDataRowIndex == e.DataRowIndex))
      {
        isDown = true;
      }
      else if (!DownState &&
                mouseHolderCellCoord.X == e.ColIndex &&
                mouseHolderCellCoord.Y == e.RowIndex
                )
      {
        isHot = true;
      }

      cbState = EhLibUtilsInternal.FixCheckBoxStateByState(cbState, isHot, isDown, true);

      ////
      //Size cbSize = CheckBoxRenderer.GetGlyphSize(e.Graphics, cbState);
      //chRect.Size = cbSize;
      //chRect = EhLibUtils.RectCenter(chRect, e.CellContentRect);
      //CheckBoxRenderer.DrawCheckBox(e.Graphics, chRect.Location, cbState);

      ////
      //Bitmap cdImage = EhLibUtils.GetCheckboxBitmap(cbState);
      //Size cbSize = CheckBoxRenderer.GetGlyphSize(e.Graphics, cbState);
      //chRect.Size = cbSize;
      //chRect = EhLibUtils.RectCenter(chRect, e.CellContentRect);

      //e.Graphics.DrawImage(cdImage, chRect);

      ////
      EhLibCheckBoxRenderer cbRenderer = EhLibRenderManager.DefaultEhLibRenderManager.CheckBoxRenderer;

      Size cbSize = cbRenderer.GetGlyphSize(e.Graphics, cbState);
      chRect = EhLibUtils.RectCenter(chRect, e.CellContentRect);
      cbRenderer.DrawCheckBox(e.Graphics, chRect, cbState);
    }

    public override string GetTypeNameAbbr()
    {
      return "ChBx";
    }
    #endregion <methods
  }

  //public class InternalCheckBoxDataCellManager : CheckBoxDataCellManager
  //{
  //  //Checkbox
  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new bool ThreeState
  //  {
  //    get { return base.ThreeState; }
  //    set { base.ThreeState = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new object TrueValue
  //  {
  //    get { return base.TrueValue; }
  //    set { base.TrueValue = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new object FalseValue
  //  {
  //    get { return base.FalseValue; }
  //    set { base.FalseValue = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new object IndeterminateValue
  //  {
  //    get { return base.FalseValue; }
  //    set { base.FalseValue = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new FlatStyle FlatStyle
  //  {
  //    get { return base.FlatStyle; }
  //    set { base.FlatStyle = value; }
  //  }

  //  //base
  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new EditButton EditButton
  //  {
  //    get { return base.EditButton; }
  //    set { base.EditButton = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new EditItemControlsCollection InEditControls
  //  {
  //    get { return base.InEditControls; }
  //    //set { base.InEditControls = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new bool AllowShowEditor
  //  {
  //    get { return base.AllowShowEditor; }
  //    set { base.AllowShowEditor = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new Padding Padding
  //  {
  //    get { return base.Padding; }
  //    set { base.Padding = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new HorizontalAlignment HorzAlign
  //  {
  //    get { return base.HorzAlign; }
  //    set { base.HorzAlign = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new VerticalAlignment VertAlign
  //  {
  //    get { return base.VertAlign; }
  //    set { base.VertAlign = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new virtual ContextMenuStrip ContextMenuStrip
  //  {
  //    get { return base.ContextMenuStrip; }
  //    set { base.ContextMenuStrip = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new Color BackColor
  //  {
  //    get { return base.BackColor; }
  //    set { base.BackColor = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new Color ForeColor
  //  {
  //    get { return base.ForeColor; }
  //    set { base.ForeColor = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new Font Font
  //  {
  //    get { return base.Font; }
  //    set { base.Font = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new virtual bool ReadOnly
  //  {
  //    get { return base.ReadOnly; }
  //    set { base.ReadOnly = value; }
  //  }

  //  [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
  //  public new GridDataRowHeightOptions HeightOptions
  //  {
  //    get { return base.HeightOptions; }
  //    //set { base.HeightOptions = value; }
  //  }

  //}

  //public class CheckBoxDataCellWorker : ButtonBaseCellWorker
  //{

  //  #region private consts
  //  #endregion private consts

  //  #region privates
  //  private static readonly Type CheckStateType = typeof(CheckState);
  //  private static readonly Type BooleanType = typeof(bool);

  //  bool threeState;
  //  object trueValue;
  //  object falseValue;
  //  object indeterminateValue;
  //  private FlatStyle flatStyle;
  //  #endregion privates

  //  public CheckBoxDataCellWorker(BaseDataCellManager cellManager) : base(cellManager)
  //  {
  //  }

  //  #region properties
  //  [DefaultValue(false)]
  //  public bool ThreeState
  //  {
  //    get
  //    {
  //      return this.threeState;
  //    }
  //    set
  //    {
  //      if (this.threeState != value)
  //      {
  //        this.threeState = value;
  //        if (CellManager.Grid != null)
  //          CellManager.Grid.InvalidateGrid();
  //      }
  //    }
  //  }

  //  [DefaultValue(null)]
  //  [TypeConverter(typeof(StringConverter))]
  //  public object TrueValue
  //  {
  //    get
  //    {
  //      return this.trueValue;
  //    }
  //    set
  //    {
  //      if (this.trueValue != value)
  //      {
  //        this.trueValue = value;
  //        if (CellManager.Grid != null)
  //          CellManager.Grid.InvalidateGrid();
  //      }
  //    }
  //  }

  //  [DefaultValue(null)]
  //  [TypeConverter(typeof(StringConverter))]
  //  public object FalseValue
  //  {
  //    get
  //    {
  //      return this.falseValue;
  //    }
  //    set
  //    {
  //      if (this.falseValue != value)
  //      {
  //        this.falseValue = value;
  //        if (CellManager.Grid != null)
  //          CellManager.Grid.InvalidateGrid();
  //      }
  //    }
  //  }

  //  [DefaultValue(null)]
  //  [TypeConverter(typeof(StringConverter))]
  //  public object IndeterminateValue
  //  {
  //    get
  //    {
  //      return this.indeterminateValue;
  //    }
  //    set
  //    {
  //      if (this.indeterminateValue != value)
  //      {
  //        this.indeterminateValue = value;
  //        if (CellManager.Grid != null)
  //          CellManager.Grid.InvalidateGrid();
  //      }
  //    }
  //  }

  //  [DefaultValue(FlatStyle.Standard)]
  //  public FlatStyle FlatStyle
  //  {
  //    get
  //    {
  //      return this.flatStyle;
  //    }
  //    set
  //    {
  //      if (this.flatStyle != value)
  //      {
  //        flatStyle = value;
  //        if (CellManager.Grid != null)
  //          CellManager.Grid.InvalidateGrid();
  //      }
  //    }
  //  }
  //  #endregion 

  //  #region Methods
  //  public virtual CheckState DefaultGetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    CheckState result;
  //    if (propAxisBar != null && listItemBar != null)
  //    {
  //      object value = propAxisBar.GetListItemBarValue(listItemBar);
  //      result = GetCheckStateFromValue(value);
  //    }
  //    else
  //    {
  //      result = CheckState.Indeterminate;
  //    }
  //    return result;
  //  }

  //  public virtual CheckState OnGetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    //DataAxisGridCheckBoxQueryDataCellCheckStateEventArgs e = null;
  //    //var eh = this.Events[EventKeyQueryCheckboxState] as EventHandler<DataAxisGridCheckBoxQueryDataCellCheckStateEventArgs>;
  //    //if (eh != null /*&& !this.IsDisposed*/)
  //    //{
  //    //  e = new DataAxisGridCheckBoxQueryDataCellCheckStateEventArgs(listItemBar);
  //    //  eh(this, e);
  //    //}

  //    //if ((e != null) && e.Handled)
  //    //  return e.CheckState;
  //    //else
  //    {
  //      bool handled = false;
  //      CheckState result = CheckState.Indeterminate;

  //      var holder = propAxisBar as ICheckBoxDataCellHolder;
  //      if (holder != null)
  //        result = holder.OnGetCheckState(propAxisBar, listItemBar, out handled);

  //      if (!handled)
  //        result = DefaultGetCheckState(propAxisBar, listItemBar);

  //      return result;
  //    }
  //  }

  //  public CheckBoxState GetCheckBoxStateByCheckState(CheckState checkState)
  //  {
  //    if (checkState == CheckState.Checked)
  //      return CheckBoxState.CheckedNormal;
  //    else if (checkState == CheckState.Unchecked)
  //      return CheckBoxState.UncheckedNormal;
  //    else
  //      return CheckBoxState.MixedNormal;
  //  }

  //  public CheckBoxState GetCheckBoxState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    CheckState chState = OnGetCheckState(propAxisBar, listItemBar);

  //    return GetCheckBoxStateByCheckState(chState);
  //  }

  //  public CheckState GetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    return OnGetCheckState(propAxisBar, listItemBar);
  //  }

  //  public CheckState GetCheckStateFromValue(object value)
  //  {
  //    CheckState result;

  //    if (value == null)
  //      result = CheckState.Indeterminate;
  //    else if (TrueValue != null && value.Equals(TrueValue))
  //      result = CheckState.Checked;
  //    else if (FalseValue != null && value.Equals(FalseValue))
  //      result = CheckState.Unchecked;
  //    else if (IndeterminateValue != null && value.Equals(IndeterminateValue))
  //      result = CheckState.Indeterminate;
  //    else if (value.Equals(true))
  //      result = CheckState.Checked;
  //    else if (value.Equals(false))
  //      result = CheckState.Unchecked;
  //    else
  //      result = CheckState.Indeterminate;

  //    return result;
  //  }

  //  public void SetCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, CheckState checkState)
  //  {
  //    object value = GetDataValueFromCheckState(propAxisBar, listItemBar, checkState);
  //    CellManager.Grid.SetDataValue(propAxisBar, value);
  //  }

  //  public object GetDataValueFromCheckState(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, CheckState checkState)
  //  {
  //    object result;

  //    switch (checkState)
  //    {
  //      case CheckState.Unchecked:
  //        {
  //          if (FalseValue != null)
  //          {
  //            result = FalseValue;
  //          }
  //          else
  //          {
  //            if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(BooleanType))
  //              result = false;
  //            else if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(CheckStateType))
  //              result = CheckState.Unchecked;
  //            else
  //              result = null;
  //          }
  //          break;
  //        }
  //      case CheckState.Checked:
  //        {
  //          if (TrueValue != null)
  //          {
  //            result = TrueValue;
  //          }
  //          else
  //          {
  //            if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(BooleanType))
  //              //EhLibUtils.DoNothing(); 
  //              result = true;
  //            else if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(CheckStateType))
  //              result = CheckState.Checked;
  //            else
  //              result = null;
  //          }
  //          break;
  //        }
  //      case CheckState.Indeterminate:
  //        {
  //          if (IndeterminateValue != null)
  //          {
  //            result = IndeterminateValue;
  //          }
  //          else
  //          {
  //            if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(BooleanType))
  //              //EhLibUtils.DoNothing();
  //              result = null;
  //            else if (propAxisBar.DataType != null && propAxisBar.DataType.IsAssignableFrom(CheckStateType))
  //              result = CheckState.Indeterminate;
  //            else
  //              result = null;
  //          }
  //          break;
  //        }
  //      default:
  //        result = null;
  //        break;
  //    }

  //    return result;
  //  }

  //  public CheckState NextCheckState(CheckState cs)
  //  {
  //    if (ThreeState)
  //    {
  //      switch (cs)
  //      {
  //        case CheckState.Unchecked:
  //          {
  //            return CheckState.Checked;
  //          }
  //        case CheckState.Checked:
  //          {
  //            return CheckState.Indeterminate;
  //          }
  //        case CheckState.Indeterminate:
  //          {
  //            return CheckState.Unchecked;
  //          }
  //        default:
  //          {
  //            return CheckState.Unchecked;
  //          }
  //      }
  //    }
  //    else
  //    {
  //      switch (cs)
  //      {
  //        case CheckState.Unchecked:
  //          {
  //            return CheckState.Checked;
  //          }
  //        case CheckState.Checked:
  //          {
  //            return CheckState.Unchecked;
  //          }
  //        default:
  //          {
  //            return CheckState.Unchecked;
  //          }
  //      }
  //    }
  //  }

  //  public override void Toggle(int dataColIndex, int dataRowIndex)
  //  {
  //    PropertyAxisBar propAxisBar;
  //    DataAxisGridListItemBar listItemBar;
  //    CellManager.AxisObjectsByDataColRowIndex(dataColIndex, dataRowIndex, out propAxisBar, out listItemBar);

  //    CheckState cbState = GetCheckState(propAxisBar, listItemBar);
  //    cbState = NextCheckState(cbState);
  //    SetCheckState(propAxisBar, listItemBar, cbState);
  //  }

  //  public virtual void PaintContent(DataAxisGridDataCellContentPaintEventArgs e)
  //  {
  //    Rectangle chRect = new Rectangle();
  //    bool isHot = false;
  //    bool isDown = false;
  //    //int gridColIndex;
  //    //int gridRowIndex;
  //    GridCoord mouseHolderCellCoord = CellManager.Grid.MouseHolderCellCoord;

  //    CheckBoxState cbState = GetCheckBoxState(e.PropAxisBar, e.ListItemBar);
  //    Size cbSize = CheckBoxRenderer.GetGlyphSize(e.Graphics, cbState);
  //    chRect.Size = cbSize;
  //    chRect = EhLibUtils.RectCenter(chRect, e.CellContentRect);

  //    //AreaCellPosToGridCellPos(e.AreaColIndex, e.AreaRowIndex, out gridColIndex, out gridRowIndex);

  //    if (DownState && (CellManager.Grid.CurrentDataRowIndex == e.DataRowIndex))
  //    {
  //      isDown = true;
  //    }
  //    else if (!DownState &&
  //              mouseHolderCellCoord.X == e.ColIndex &&
  //              mouseHolderCellCoord.Y == e.RowIndex
  //              )
  //    {
  //      isHot = true;
  //    }

  //    cbState = EhLibUtilsInternal.FixCheckBoxStateByState(cbState, isHot, isDown, true);

  //    CheckBoxRenderer.DrawCheckBox(e.Graphics, chRect.Location, cbState);
  //  }

  //  #endregion Methods
  //}

}
