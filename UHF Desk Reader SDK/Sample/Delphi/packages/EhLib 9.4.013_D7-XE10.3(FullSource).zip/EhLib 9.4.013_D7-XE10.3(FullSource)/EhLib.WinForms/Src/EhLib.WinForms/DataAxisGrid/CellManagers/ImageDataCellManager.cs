﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Drawing.Drawing2D;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of data cell manager that  displays a graphic.
  /// </summary>
  //[DataCellDesignTimeVisible(true)]
  //[ToolboxItem(true)]
  public class ImageDataCellManager : BaseDataCellManager
  {
    #region> privates
    private static readonly Type ImageType = typeof(System.Drawing.Image);
    private PictureSizeMode imageLayout = PictureSizeMode.Fit;
    private double scale = 1.0f;
    private Image toolTipImage;
    private DataAxisGrid toolTipImageGrid;
    #endregion

    public ImageDataCellManager()
    {
    }

    #region> properties
    [DefaultValue(PictureSizeMode.Fit)]
    public PictureSizeMode SizeMode
    {
      get { return imageLayout; }
      set
      {
        if (this.imageLayout != value)
        {
          imageLayout = value;
          BoundGrid.InvalidateGrid();
        }
      }
    }

    [DefaultValue(1.0)]
    public double Scale
    {
      get
      {
        return scale;
      }

      set
      {
        if (scale != value)
        {
          scale = value;
          ScaleChanged();
        }
      }
    }

    #endregion

    #region> methods
    private Image GetCellValueAsImage(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
    {
      object objValue;
      TypeConverter converter;

      if (propAxisBar != null && listItemBar != null)
      {
        objValue = propAxisBar.GetListItemBarValue(listItemBar);
        if (objValue == null)
          return null;
        else if (objValue is Image)
          return (objValue as Image);
        else
        {
          converter = TypeDescriptor.GetConverter(ImageType);
          if (converter.CanConvertFrom(objValue.GetType()) == true)
            return (Image)converter.ConvertFrom(objValue);
          else
            return null;
        }
      }
      else
        return null;
    }

    protected internal override void OnPaintContent(DataAxisGridDataCellContentPaintEventArgs e)
    {
      Image img = null;

      if (e.PropAxisBar == null) return;

      Rectangle cellDrawRect = EhLibUtils.TrimPadding(e.CellContentRect, e.ParentCellPaintArgs.Padding);

      //ImageAttributes attr = new ImageAttributes();
      try
      {
        img = GetCellValueAsImage(e.PropAxisBar, e.ListItemBar);
      }
      catch (Exception expn)
      {
        if (EhLibUtils.IsCriticalException(expn))
        {
          throw;
        }
        else
        {
          string s = "Error: " + expn.Message;
          Rectangle textRect = EhLibUtils.TrimPadding(cellDrawRect, e.ParentCellPaintArgs.Padding);
          e.Grid.PaintingDrawText(e.GraphicsContext, s, Font, textRect, ForeColor, HorizontalAlignment.Left, VerticalAlignment.Top, false);
        }
      }

      if (img == null) return;

      PaintImage(e.Grid, img, e.Graphics, cellDrawRect);
    }

    public void PaintImage(DataAxisGrid grid, Image img, Graphics graphics, Rectangle cellDrawRect)
    {
      bool sizeFites;
      Rectangle imageDrawRect = Rectangle.Empty;
      int nw, nh;
      double xyaspect;

      Size imageSize = img.Size;
      imageSize.Width = (int)Math.Round(imageSize.Width * Scale);
      imageSize.Height = (int)Math.Round(imageSize.Height * Scale);

      if (cellDrawRect.Width >= imageSize.Width &&
          cellDrawRect.Height >= imageSize.Height)
        sizeFites = true;
      else
        sizeFites = false;

      if (SizeMode == PictureSizeMode.Stretch)
      {
        imageDrawRect = cellDrawRect;
      }
      else if ((SizeMode == PictureSizeMode.Normal) ||
               (sizeFites && SizeMode == PictureSizeMode.Fit))
      {
        imageDrawRect.Width = imageSize.Width;
        imageDrawRect.Height = imageSize.Height;
        imageDrawRect.X = cellDrawRect.X + (cellDrawRect.Width - imageSize.Width) / 2;
        imageDrawRect.Y = cellDrawRect.Y + (cellDrawRect.Height - imageSize.Height) / 2;
      }
      else // (SizeMode == PictureSizeMode.Fit) || PictureSizeMode.Zoom
      {
        if ((imageSize.Width > 0) && (imageSize.Height > 0))
        {
          xyaspect = (double)imageSize.Width / imageSize.Height;
          nw = cellDrawRect.Width;
          nh = (int)(cellDrawRect.Width / xyaspect);
          if (nh > cellDrawRect.Height)
          {
            nh = cellDrawRect.Height;
            nw = (int)(cellDrawRect.Height * xyaspect);
          }
          imageDrawRect.Width = nw;
          imageDrawRect.Height = nh;
          imageDrawRect = EhLibUtils.RectCenter(imageDrawRect, cellDrawRect);
        }
      }

      Region oldClip = grid.PaintingSetClip(graphics, cellDrawRect, CombineMode.Intersect);
      graphics.DrawImage(img, imageDrawRect, 0, 0, img.Width, img.Height, GraphicsUnit.Pixel);
      grid.PaintingSetClip(graphics, oldClip, CombineMode.Replace);
    }

    protected internal override int CalcCellHeight(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, int cellWidth)
    {
      int th = CalcDefaultRowHeight(propAxisBar);
      Padding padding = GetPadding(propAxisBar);

      if (!HeightOptions.GetAutoExpand(propAxisBar))
        return base.CalcCellHeight(propAxisBar, listItemBar, cellWidth);

      Image img;

      try
      {
        img = GetCellValueAsImage(propAxisBar, listItemBar);
        if (img != null)
        {
          double widthFactor = 1;
          if (cellWidth < img.Width && img.Width > 0)
            widthFactor = (double)cellWidth / img.Width;
          th = (int)Math.Round(img.Height * Scale * widthFactor) + padding.Top + padding.Bottom;
        }
      }
      catch (Exception expn)
      {
        if (EhLibUtils.IsCriticalException(expn))
        {
          throw;
        }
      }

      return th;
    }

    protected virtual void ScaleChanged()
    {
      if (BoundGrid != null)
        BoundGrid.RowHeightAffectPropertyChanged();
    }

    //protected internal override void PrintCell(BaseGridControl grid, PrintServiceEventArgs e, 
    //  Rectangle paintRect,
    //  int colIndex, int rowIndex,
    //  int areaColIndex, int areaRowIndex)
    //{
    //  PropertyAxisBar propAxisBar;
    //  DataAxisGridListItemBar listItemBar;
    //  DataAxisGridListAxisItemViewState listAxisItemViewState;
    //  DataAxisGrid axisGrid = grid as DataAxisGrid;

    //  AxisObjectsByDataColRowIndex(axisGrid, areaColIndex, areaRowIndex, out propAxisBar, out listItemBar, out listAxisItemViewState);

    //  var fe = new DataAxisGridDataCellFormatParamsNeededEventArgs(axisGrid, propAxisBar, listItemBar, this);
    //  ProcessFormatParamsNeeded(fe);

    //  DataAxisGridDataCellPaintEventArgs paintEventArgs = new DataAxisGridDataCellPaintEventArgs(axisGrid, null, e, -1, -1,
    //    paintRect, paintRect, 0, areaColIndex, areaRowIndex, new Point(-1, -1), propAxisBar, listItemBar, listAxisItemViewState, fe);
    //  //DataAxisGridDataCellPaintEventArgs paintEventArgs = new DataAxisGridDataCellPaintEventArgs(null, e.Graphics, -1, -1,
    //  //  paintRect, 0, areaColIndex, areaRowIndex, new Point(-1, -1), propAxisBar, listItemBar, listAxisItemViewState);

    //  PaintForeground(paintEventArgs);
    //}

    protected internal override void OnMouseEnter(DataAxisGridDataCellEnterEventArgs e)
    {
      base.OnMouseEnter(e);

      if (e.Grid.IsShowDataCellsNonfitTooltips())
      {
        toolTipImage = GetCellNonfitToolTipText(e);
        toolTipImageGrid = e.Grid;

        if (toolTipImage != null)
        {
          toolTipImageGrid.ShowCellNonFitToolTip(ToolTipPopupEventHandler, ToolTipDrawEventHandler, e);
        }
      }
    }

    protected virtual void ToolTipPopupEventHandler(object sender, PopupEventArgs e)
    {
      if (toolTipImage != null)
        e.ToolTipSize = toolTipImage.Size;
    }

    protected virtual void ToolTipDrawEventHandler(object sender, DrawToolTipEventArgs e)
    {
      e.DrawBorder();
      e.DrawBackground();
      Rectangle imageDrawRect = e.Bounds;
      imageDrawRect = EhLibUtils.ChangeRectangle(imageDrawRect, 1, 1, -2, -2);
      PaintImage(toolTipImageGrid, toolTipImage, e.Graphics, imageDrawRect);
    }

    public virtual Image GetCellNonfitToolTipText(DataAxisGridDataCellEnterEventArgs e)
    {

      if (e.Grid.IsShowDataCellsNonfitTooltips())
      {
        Rectangle cellRect = e.Grid.CellRect(e.ColIndex, e.RowIndex);

        PropertyAxisBar propAxisBar;
        DataAxisGridListItemBar listItemBar;
        AxisObjectsByDataColRowIndex(e.Grid as DataAxisGrid, e.AreaColIndex, e.AreaRowIndex, out propAxisBar, out listItemBar);
        if (listItemBar == null) return null;

        object value = GetCellValueAsImage(propAxisBar, listItemBar);
        Image image = value as Image;
        if (image != null)
        {
          if (image.Size.Height > cellRect.Size.Height ||
              image.Size.Width > cellRect.Size.Width
          )
            return image;
        }
      }

      return null;
    }

    public override string GetTypeNameAbbr()
    {
      return "Img";
    }
    #endregion
  }
}
