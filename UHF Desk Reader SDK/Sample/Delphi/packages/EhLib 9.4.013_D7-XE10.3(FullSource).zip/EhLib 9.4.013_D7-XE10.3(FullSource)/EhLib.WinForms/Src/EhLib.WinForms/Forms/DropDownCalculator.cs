﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  public partial class DropDownCalculator : DropDownForm
  {
    public DropDownCalculator()
    {
      InitializeComponent();

      FormElements = 0;
      DropDownBorder = false;
      ClientSize = calculatorControl1.Size;
    }

    public decimal Value
    {
      get
      {
        return calculatorControl1.Value;
      }

      set
      {
        calculatorControl1.Value = value;
      }  
    }

    public bool ReadOnly
    {
      get
      {
        return calculatorControl1.ReadOnly;
      }

      set
      {
        calculatorControl1.ReadOnly = value;
      }  
    }

    private void calculatorControl1_OkButtonPressed(object sender, EventArgs e)
    {
      DialogResult = DialogResult.OK;
      Close();
    }

    private void DropDownCalculator_KeyDown(object sender, KeyEventArgs e)
    {
      if (e.KeyData == Keys.Escape)
      {
        DialogResult = DialogResult.Cancel;
        Close();
      }
    }
  }
}
