﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  public enum InEditButtonStyleKind
  {
    SysDropDown, AltDropDown, UpSign, DownSign, LeftSign, RightSign, EndEllipsis//, Push, Custom
  }

  /// <summary>
  /// Item of edit control that looks like a button with gliph.
  /// </summary>
  [ToolboxItem(false)]
  [ToolboxBitmap(typeof(EditButton), "ToolboxBitmaps.EhLib_EditButton.bmp")]
  public class EditButton : EditItem
  {

    #region private consts
    private static readonly object EventKeyPaint = new object();
    private static readonly object EventKeyDown = new object();
    private static readonly object EventKeyClick = new object();
    #endregion private consts

    #region fields
    private InEditButtonStyleKind styleKind = InEditButtonStyleKind.SysDropDown;
    #endregion fields

    #region constructor
    public EditButton()
    {
      Shortcut = Shortcut.AltDownArrow;
    }
    #endregion constructor

    #region design-time properties
    [DefaultValue(InEditButtonStyleKind.SysDropDown)]
    public InEditButtonStyleKind StyleKind
    {
      get
      {
        return styleKind;
      }
      set
      {
        if (value != styleKind)
        {
          styleKind = value;
          NotifyEditItemChanged();
        }
      }
    }

    [DefaultValue(Shortcut.AltDownArrow)]
    public Shortcut Shortcut { get; set; }

    #endregion

    #region run-time properties
    //[Browsable(false)]
    //[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    //public override ISite Site
    //{
    //  get { return EditControl.Site; }
    //}

    public override bool SupportInControlBorderMerging
    {
      get
      {
        if ((StyleKind == InEditButtonStyleKind.SysDropDown) &&
            Application.RenderWithVisualStyles &&
            Environment.OSVersion.Version.Major >= 6
           )
          return true;
        else
          return false;
      }
    }
    #endregion

    #region events
    public event EventHandler<DownEventArgs> Down
    {
      add
      {
        Events.AddHandler(EventKeyDown, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDown, value);
      }
    }

    public event EventHandler<InEditControlClickEventArgs> Click
    {
      add
      {
        Events.AddHandler(EventKeyClick, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyClick, value);
      }
    }

    public event EventHandler<EditItemContextPaintEventArgs> Paint
    {
      add
      {
        Events.AddHandler(EventKeyPaint, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyPaint, value);
      }
    }

    #endregion

    #region methods
    protected override EditItemControl CreateInEditWinControl()
    {
      return new EditButtonControl(this);
    }

    public override bool IntegratedInBorder()
    {
      if ((StyleKind == InEditButtonStyleKind.SysDropDown) &&
          ComboBoxRenderer.DropDownButtonAlignSupported(DropDownButtonAlign.Right))
        return true;
      else
        return false;
    }

    public override bool IsDropDown()
    {
      if (StyleKind == InEditButtonStyleKind.SysDropDown ||
          StyleKind == InEditButtonStyleKind.AltDropDown)
        return true;
      else
        return false;
    }

    protected internal override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
      if ((int)keyData == (int)Shortcut)
      {
        DownEventArgs e = new DownEventArgs(false, 0);
        ProcessDown(e); 
        if (e.Handled)
          return true; 
        else
          return false;
      }
      else
      {
        return false;
      }
    }

    internal void ConnectToEditor(BaseEditBoxEh editor)
    {
      if (EditControl != null)
        throw new ArgumentException("Edit item already connected to the EditBox");

      InEditWinControl.Parent = editor;
      EditControl = editor;
    }

    internal void DisconnectFromEditor()
    {
      InEditWinControl.Parent = null;
      EditControl = null;
    }

    protected override void HandlePaintEvent(EditItemContextPaintEventArgs e)
    {
      var eh = Events[EventKeyPaint] as EventHandler<EditItemContextPaintEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected internal override void OnPaintBackground(EditItemContextPaintEventArgs e)
    {
      PushButtonState state = EhLibUtils.GetPushButtonState(e.Hot, e.Pressed && e.Hot, e.Disabled);
      EhLibRenderManager.DefaultEhLibRenderManager.EditBoxEditButtonPainter.
        DrawButtonBackground(e.GraphicsContext, e.ClientRect, state, StyleKind);
    }

    protected internal override void OnPaintForeground(EditItemContextPaintEventArgs e)
    {
      bool themed = Application.RenderWithVisualStyles;
      Rectangle btnRect = e.ClientRect;

      if (themed && StyleKind != InEditButtonStyleKind.SysDropDown)
        btnRect.Inflate(1, 1);

      if (StyleKind == InEditButtonStyleKind.SysDropDown)
      {
      }
      else
      {
        PushButtonState state = EhLibUtils.GetPushButtonState(e.Hot, e.Pressed && e.Hot, e.Disabled);

        //if (StyleKind == InEditButtonStyleKind.AltDropDown)
        //  EhLibDrawStyle.DefaultToolElementsDrawStyle.DrawDropDownButtonSign(e.Graphics, btnRect, state);
        //else if (StyleKind == InEditButtonStyleKind.EndEllipsis)
        //  EhLibDrawStyle.DefaultToolElementsDrawStyle.DrawEllipsisButtonSign(e.Graphics, btnRect, state);

        if (StyleKind == InEditButtonStyleKind.AltDropDown)
          EhLibRenderManager.DefaultEhLibRenderManager.ToolElementsDrawStyle.DrawDropDownButtonSign(e.Graphics, btnRect, state);
        else if (StyleKind == InEditButtonStyleKind.UpSign)
          EhLibRenderManager.DefaultEhLibRenderManager.ToolElementsDrawStyle.DrawUpSignButtonSign(e.Graphics, btnRect, state);
        else if (StyleKind == InEditButtonStyleKind.DownSign)
          EhLibRenderManager.DefaultEhLibRenderManager.ToolElementsDrawStyle.DrawDownSignButtonSign(e.Graphics, btnRect, state);
        else if (StyleKind == InEditButtonStyleKind.LeftSign)
          EhLibRenderManager.DefaultEhLibRenderManager.ToolElementsDrawStyle.DrawLeftSignButtonSign(e.Graphics, btnRect, state);
        else if (StyleKind == InEditButtonStyleKind.RightSign)
          EhLibRenderManager.DefaultEhLibRenderManager.ToolElementsDrawStyle.DrawRightSignButtonSign(e.Graphics, btnRect, state);
        else if (StyleKind == InEditButtonStyleKind.EndEllipsis)
          EhLibRenderManager.DefaultEhLibRenderManager.ToolElementsDrawStyle.DrawEllipsisButtonSign(e.Graphics, btnRect, state);
      }
    }

    public override void DefaultHandleDownAction(DownEventArgs e)
    {
      if (e.Handled) return;
      if (DefaultAction)
        EditControl.HandleInEditControlDownAction(this, e);
    }

    protected override void HandleDownEvent(DownEventArgs e)
    {
      var eh = Events[EventKeyDown] as EventHandler<DownEventArgs>;
      if (eh != null)
        eh(this, e);
    }

    protected override void HandleClickEvent(InEditControlClickEventArgs e)
    {
      var eh = Events[EventKeyClick] as EventHandler<InEditControlClickEventArgs>;
      if (eh != null)
        eh(this, e);
    }
    #endregion
  }

  [DesignTimeVisible(false)]
  [ToolboxItem(false)]
  public class EditButtonControl : EditItemControl
  {
    //private bool pushed;
    //private bool captured = false;
    //private bool mouseOver;

    #region constructor
    public EditButtonControl(EditItem editItem) : base(editItem)
    {
      //SetStyle(ControlStyles.Opaque, false);
    }
    #endregion constructor

    #region properties
    protected internal EditButton InEditButton
    {
      get { return (EditButton)EditItem; }
    }
    #endregion properties

    //protected override void OnPaint(PaintEventArgs e)
    //{
    //  bool themed = Application.RenderWithVisualStyles;
    //  Rectangle btnRect = ClientRectangle;

    //  //e.Graphics.FillRectangle(new SolidBrush(Color.Red), ClientRectangle);

    //  if ((themed) && (InEditButton.StyleKind != InEditButtonStyleKind.SysDropDown))
    //      btnRect.Inflate(1, 1);

    //  //ButtonRenderer.DrawButton(e.Graphics, btnRect, PushButtonState.Normal);
    //  if (InEditButton.StyleKind == InEditButtonStyleKind.SysDropDown)
    //  {
    //    ComboBoxState state = ComboBoxRenderer.GetButtonState(mouseOver, pushed && mouseOver, !Enabled);
    //    DropDownButtonAlign buttonAlign;
    //    if (InControlBorderMerging && 
    //       (ComboBoxRenderer.DropDownButtonAlignSupported(DropDownButtonAlign.Right)))
    //      buttonAlign = DropDownButtonAlign.Right;
    //    else
    //      buttonAlign = DropDownButtonAlign.Neutral;

    //    ComboBoxRenderer.DrawDropDownButton(e.Graphics, btnRect, state, buttonAlign, this);
    //  }
    //  else
    //  {
    //    //AltDropDown, EndElipsis, Push, Custom
    //    PushButtonState state = EhLibUtils.GetPushButtonState(mouseOver, pushed && mouseOver, !Enabled);
    //    ButtonRenderer.DrawButton(e.Graphics, btnRect, state);
    //    if (InEditButton.StyleKind == InEditButtonStyleKind.AltDropDown)
    //      EhLibDrawStyle.DefaultToolElementsDrawStyle.DrawDropDownButtonSign(e.Graphics, btnRect, state);
    //    else if (InEditButton.StyleKind == InEditButtonStyleKind.UpSign)
    //      EhLibDrawStyle.DefaultToolElementsDrawStyle.DrawUpSignButtonSign(e.Graphics, btnRect, state);
    //    else if (InEditButton.StyleKind == InEditButtonStyleKind.DownSign)
    //      EhLibDrawStyle.DefaultToolElementsDrawStyle.DrawDownSignButtonSign(e.Graphics, btnRect, state);
    //    else if (InEditButton.StyleKind == InEditButtonStyleKind.LeftSign)
    //      EhLibDrawStyle.DefaultToolElementsDrawStyle.DrawLeftSignButtonSign(e.Graphics, btnRect, state);
    //    else if (InEditButton.StyleKind == InEditButtonStyleKind.RightSign)
    //      EhLibDrawStyle.DefaultToolElementsDrawStyle.DrawRightSignButtonSign(e.Graphics, btnRect, state);
    //    else if (InEditButton.StyleKind == InEditButtonStyleKind.EndEllipsis)
    //      EhLibDrawStyle.DefaultToolElementsDrawStyle.DrawEllipsisButtonSign(e.Graphics, btnRect, state);
    //  }
    //  //e.Graphics.DrawRectangle(new Pen(Color.Red), ClientRectangle);
    //  if (Focused)
    //    e.Graphics.DrawString("f", Font, new SolidBrush(ForeColor), btnRect.Location);
    //}

    //protected override void OnMouseDown(MouseEventArgs e)
    //{
    //  base.OnMouseDown(e);
    //  if (!InEditButton.EditControl.Focused)
    //    InEditButton.EditControl.Focus();
    //  //this.parent.FocusInternal();

    //  if (/*!parent.ValidationCancelled &&*/ e.Button == MouseButtons.Left)
    //  {
    //    pushed = true;
    //    //captured = true;
    //    mouseOver = true;
    //    Capture = true;
    //    Invalidate();
    //  }

    //  DownEventArgs dea = InEditButton.CreateDownEventArgs();
        
    //  //InEditButton.ProcessDown(dea);
    //}

    //protected override void OnMouseMove(MouseEventArgs e)
    //{
    //  base.OnMouseMove(e);
    //  if (Capture)
    //  {
    //    Rectangle bounds = ClientRectangle;
    //    if (bounds.Contains(e.X, e.Y) && !mouseOver)
    //    {
    //      mouseOver = true;
    //      Invalidate();
    //    }
    //    else if (!bounds.Contains(e.X, e.Y) && mouseOver)
    //    {
    //      mouseOver = false;
    //      Invalidate();
    //    }
    //  }
    //}

    //protected override void OnMouseUp(MouseEventArgs e)
    //{
    //  base.OnMouseUp(e);
    //  if (/*!Parent.ValidationCancelled && */e.Button == MouseButtons.Left)
    //  {
    //    pushed = false;
    //    //captured = false;
    //    Capture = false;
    //    Invalidate();
    //  }
    //}

    //protected override void OnMouseEnter(EventArgs e)
    //{
    //  base.OnMouseEnter(e);
    //  if (!Capture)
    //    mouseOver = true;
    //  Invalidate();
    //}

    //protected override void OnMouseLeave(EventArgs e)
    //{
    //  base.OnMouseLeave(e);
    //  if (!Capture)
    //    mouseOver = false;
    //  Invalidate();
    //}

    //protected override void OnClick(EventArgs e)
    //{
    //  base.OnClick(e);
    //  InEditButton.ProcessClick(new ClickEventArgs());
    //}

  }

}
