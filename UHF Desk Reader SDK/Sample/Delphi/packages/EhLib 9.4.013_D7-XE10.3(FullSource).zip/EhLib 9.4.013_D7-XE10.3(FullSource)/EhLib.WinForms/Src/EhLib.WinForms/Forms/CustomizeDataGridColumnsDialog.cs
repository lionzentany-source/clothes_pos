﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace EhLib.WinForms
{
  public partial class CustomizeDataGridColumnsDialog : BaseCustomizePropBarsDialog
  {

    #region internal types
    public enum SetVisibleState { Show, Hide };
    #endregion

    #region privates
    private readonly DataGridTextColumn visGridWidthColumn = new DataGridTextColumn();
    private readonly TreeListGeneric<CustomizeDataGridColumnDialogTreeNode> multiTitleSetupTreeList = new TreeListGeneric<CustomizeDataGridColumnDialogTreeNode>();
    #endregion

    #region constructor
    public CustomizeDataGridColumnsDialog()
    {
      InitializeComponent();


      this.VisGridNameColumn.DataCellClientAreaNeeded += VisGridNameColumn_DataCellClientAreaNeeded;
      this.VisGridNameColumn.DataCellCustomAreaPaint += VisGridNameColumn_DataCellPaintCustomArea;

      this.HidGridNameColumn.DataCellClientAreaNeeded += VisGridNameColumn_DataCellClientAreaNeeded;
      this.HidGridNameColumn.DataCellCustomAreaPaint += VisGridNameColumn_DataCellPaintCustomArea;

      this.visGridWidthColumn.DataPropertyName = "Width";
      this.visGridWidthColumn.FillWeight = 69F;
      this.visGridWidthColumn.Name = "dataGridTextColumn5";
      this.visGridWidthColumn.Title.Text = "Width";
      this.visGridWidthColumn.Title.ToolTipText = null;
      this.visGridWidthColumn.Width = 69;
      VisiblePropBarsGrid.StaticColumns.AddRange(new PropertyAxisBar[] {
            this.visGridWidthColumn});

    }
    #endregion

    #region properties
    public new DataGridEh DataGrid { get { return (DataGridEh)base.DataGrid; } }
    #endregion

    #region methods
    public static bool ShowCustomizeColumnsDialog(DataGridEh grid)
    {
      CustomizeDataGridColumnsDialog dialog = new CustomizeDataGridColumnsDialog();
      return dialog.ShowDialog(grid);
    }

    protected override Collection<CustomizePropBarsDialogPropDataRow> CreateDataViewVisiblePropsList()
    {
      return new DynaTypedList<CustomizePropBarsDialogPropDataRow>(typeof(CustomizeDataGridColumnDialogDataRow));
    }

    protected override Collection<CustomizePropBarsDialogPropDataRow> CreateDataViewHiddenPropsList()
    {
      return new DynaTypedList<CustomizePropBarsDialogPropDataRow>(typeof(CustomizeDataGridColumnDialogDataRow));
    }

    protected override void InitData()
    {
      base.InitData();
      bSetWidth.Visible = true;
      InitCultureData();
      //if (DataGrid.Title.MultiTitle.Active)
      //  DataViewHidenProps.RowFilter = "HidenState = true";
    }

    protected virtual void InitCultureData()
    {
      Text = Properties.Resources.CustomizeColumnsDialog_Text;
      label1.Text = Properties.Resources.CustomizeColumnsDialog_VisibleColumns;
      label2.Text = Properties.Resources.CustomizeColumnsDialog_HiddenColumns;
      VisGridNameColumn.Title.Text = Properties.Resources.CustomizeColumnsDialog_ColumnNameCaption;
      HidGridNameColumn.Title.Text = Properties.Resources.CustomizeColumnsDialog_ColumnNameCaption;
      bOk.Text = Properties.Resources.OkButtonCaption;
      bCancel.Text = Properties.Resources.CancelButtonCaption;
      visGridWidthColumn.Title.Text = Properties.Resources.CustomizeColumnsDialog_ColumnWidthCaption;
    }

    protected override void WriteGridBarsData()
    {
      if (DataGrid.Title.MultiTitle.Active)
      {
        DataGrid.Columns.BeginUpdate();
        DataGrid.Title.MultiTitle.BeginUpdate();
        try
        {
          int i = 0;
          foreach (CustomizePropBarsDialogPropDataRow propBarDataRow in PropsTable)
          {
            CustomizeDataGridColumnDialogDataRow colRow = propBarDataRow as CustomizeDataGridColumnDialogDataRow;
            DataGridTitleNode node = colRow.TitleNode;
            WriteTitleNodeFromTitleNodeDataRow(node, colRow, i);
            i++;
          }

          DataGridMultiTitleTreeList titleTree = DataGrid.Title.MultiTitle.TitleTree;
          WriteNodeOrders(titleTree.Root, multiTitleSetupTreeList.Root);
        }
        finally
        {
          DataGrid.Title.MultiTitle.EndUpdate();
          DataGrid.Columns.EndUpdate();
        }
      }
      else
      {
        base.WriteGridBarsData();
      }
    }

    protected virtual void WriteNodeOrders(DataGridTitleNode titleNode, CustomizeDataGridColumnDialogTreeNode setupNode)
    {
      List<DataGridTitleNode> titleNodesOrders = new List<DataGridTitleNode>();

      foreach(CustomizeDataGridColumnDialogTreeNode setupChildNode in setupNode.Items)
      {
        WriteNodeOrders(setupChildNode.DataRow.TitleNode, setupChildNode);
        titleNodesOrders.Add(setupChildNode.DataRow.TitleNode);
      }

      titleNode.SetItemsOrder(titleNodesOrders);
    }

    protected virtual void WriteTitleNodeFromTitleNodeDataRow(DataGridTitleNode node, CustomizeDataGridColumnDialogDataRow propBarDataRow, int index)
    {
      if (node.NodeType == DataGridTitleNodeType.SuperTitle)
      {
        node.SuperTitle.Visible = propBarDataRow.VisibleState;
      }
      else
      {
        node.ColumnTitle.Column.Visible = propBarDataRow.VisibleState;
        //propBar.DisplayIndex = index;
        Debug.Assert(propBarDataRow.Width != null, "propBarDataRow.Width != null");
        node.ColumnTitle.Column.Width = propBarDataRow.Width.Value;
      }
    }

    protected override void WritePropBarFromPropBarDataRow(PropertyAxisBar propBar, CustomizePropBarsDialogPropDataRow propBarDataRow, int index)
    {
      base.WritePropBarFromPropBarDataRow(propBar, propBarDataRow, index);
      (propBar as DataGridColumn).Width = (propBarDataRow as CustomizeDataGridColumnDialogDataRow).Width.Value;
    }

    protected override CustomizePropBarsDialogPropDataRow CreateNewPropsDataRow(PropertyAxisBar propBar)
    {
      return new CustomizeDataGridColumnDialogDataRow();
    }

    protected override void InitNewPropDataRow(CustomizePropBarsDialogPropDataRow dataRow, PropertyAxisBar propBar)
    {
      base.InitNewPropDataRow(dataRow, propBar);

      CustomizeDataGridColumnDialogDataRow colDataRow = dataRow as CustomizeDataGridColumnDialogDataRow;
      DataGridColumn col = propBar as DataGridColumn;

      colDataRow.Width = col.Width;
    }

    protected override void ReadPropBars()
    {
      if (DataGrid.Title.MultiTitle.Active)
      {
        DataGridMultiTitleTreeList titleTree = DataGrid.Title.MultiTitle.TitleTree;

        ReadMultiTitleNode(titleTree.Root, multiTitleSetupTreeList.Root);
        SetupTreeListToFlatPropsTable();

        foreach (CustomizePropBarsDialogPropDataRow axisRow in PropsTable)
        {
          CustomizeDataGridColumnDialogDataRow row = axisRow as CustomizeDataGridColumnDialogDataRow;
          Debug.Assert(row != null, "row != null");
          bool visibleState = row.VisibleState;
          if (!visibleState)
            CheckSetStateParent(row.TitleNode, SetVisibleState.Hide);
        }

        RefreshScreenLists();
      }
      else
      {
        base.ReadPropBars();
      }
    }

    protected virtual void ReadMultiTitleNode(DataGridTitleNode titleNode, CustomizeDataGridColumnDialogTreeNode colSetupNode)
    {
      foreach (DataGridTitleNode childTitleNode in titleNode.Items)
      {
        CustomizeDataGridColumnDialogTreeNode colSetupChildNode = new CustomizeDataGridColumnDialogTreeNode();

        InitPropsMultiTitleTableRow(colSetupChildNode.DataRow, childTitleNode, colSetupChildNode);
        colSetupNode.Items.Add(colSetupChildNode);

        if (childTitleNode.Items.Count > 0)
          ReadMultiTitleNode(childTitleNode, colSetupChildNode);
      }
    }

    protected virtual void SetupTreeListToFlatPropsTable()
    {
      PropsTable.Clear();

      CustomizeDataGridColumnDialogTreeNode node = multiTitleSetupTreeList.GetFirst();
      while (node != null)
      {
        PropsTable.Add(node.DataRow);
        node = multiTitleSetupTreeList.GetNext(node);
      }

      SetSetupTreeListItemsVisibleState();
    }

    private void SetSetupTreeListItemsVisibleState()
    {
      CustomizeDataGridColumnDialogTreeNode node = multiTitleSetupTreeList.GetFirst();
      while (node != null)
      {
        node.Visible = GetColumnSetupNodeVisibleState(node);
        node = multiTitleSetupTreeList.GetNext(node);
      }
    }

    private bool GetColumnSetupNodeVisibleState(CustomizeDataGridColumnDialogTreeNode node)
    {
      bool result = node.DataRow.VisibleState;
      if (node.Parent != null && node.Parent != node.TreeList.Root)
        result = result && GetColumnSetupNodeVisibleState(node.Parent);
      return result;
    }

    protected virtual void InitPropsMultiTitleTableRow(CustomizeDataGridColumnDialogDataRow row, DataGridTitleNode titleNode, CustomizeDataGridColumnDialogTreeNode setupNode)
    {
      if (titleNode.NodeType == DataGridTitleNodeType.ColumnTitle)
      {
        DataGridColumn col = titleNode.ColumnTitle.Column;

        row.PropBar = col;
        row.VisibleState = col.Visible;
        row.Name = col.Title.Text;
        row.Width = col.Width;
        row.TitleNode = titleNode;
        row.HiddenState = !col.Visible;
        row.SetupNode = setupNode;
      }
      else
      {
        DataGridSuperTitle superTitle = titleNode.SuperTitle;

        row.PropBar = null;
        row.VisibleState = superTitle.Visible;
        row.Name = superTitle.Text;
        row.Width = null;
        row.TitleNode = titleNode;
        row.HiddenState = !superTitle.Visible;
        row.SetupNode = setupNode;
      }
    }

    protected override void HideSelectedPropBars()
    {
      if (DataGrid.Title.MultiTitle.Active)
        SetMultiTileColumnVisibleState(SetVisibleState.Hide);
      else
        base.HideSelectedPropBars();
    }

    protected override bool IsPropRowInHiddenList(CustomizePropBarsDialogPropDataRow propBarDataRow)
    {
      if (DataGrid.Title.MultiTitle.Active)
        return (propBarDataRow as CustomizeDataGridColumnDialogDataRow).HiddenState;
      else
        return base.IsPropRowInHiddenList(propBarDataRow);
    }

    protected override void ShowSelectedPropBars()
    {
      if (DataGrid.Title.MultiTitle.Active)
        SetMultiTileColumnVisibleState(SetVisibleState.Show);
      else
        base.ShowSelectedPropBars();
    }

    protected virtual void SetMultiTileColumnVisibleState(SetVisibleState setState)
    {
      DataGridEh stateGrid;
      if (setState == SetVisibleState.Hide)
        stateGrid = VisiblePropBarsGrid;
      else
        stateGrid = HiddenPropBarsGrid;

      if (stateGrid.CurrentRow == null) return;

      CustomizeDataGridColumnDialogDataRow curRow = (stateGrid.CurrentRow.SourceItem as CustomizeDataGridColumnDialogDataRow);
      DataGridTitleNode curNode = curRow.TitleNode;

      List<CustomizeDataGridColumnDialogDataRow> listForChangeState = new List<CustomizeDataGridColumnDialogDataRow>();
      listForChangeState.Add(curRow);

      if (curNode.NodeType == DataGridTitleNodeType.SuperTitle)
      {
        GetChildList(curNode, listForChangeState, true);
      }

      foreach (CustomizeDataGridColumnDialogDataRow row in listForChangeState)
      {
        if (setState == SetVisibleState.Hide)
        {
          row.VisibleState = false;
          row.HiddenState = true;
        }
        else
        {
          row.VisibleState = true;
          row.HiddenState = false;
        }
      }

      CheckSetStateParent(curNode, setState);
      SetSetupTreeListItemsVisibleState();
      RefreshScreenLists();
    }

    private void CheckSetStateParent(DataGridTitleNode node, SetVisibleState setState)
    {
      if (node.Parent != node.TreeList.Root && node.Parent != null)
      {
        SetVisibleState getState;
        CustomizeDataGridColumnDialogDataRow parentRow = GetDataRowByNode(node.Parent);
        //parentRow.BeginEdit();

        if (setState == SetVisibleState.Hide)
        {
          parentRow.HiddenState = true;
          getState = SetVisibleState.Show;
        }
        else
        {
          parentRow.VisibleState = true;
          getState = SetVisibleState.Hide;
        }

        int visibleChildren = GetStatedChildren(node.Parent, getState);
        if (visibleChildren == 0)
        {
          if (setState == SetVisibleState.Hide)
            parentRow.VisibleState = false;
          else
            parentRow.HiddenState = false;
        }

        //parentRow.EndEdit();

        CheckSetStateParent(node.Parent, setState);
      }
    }

    private int GetStatedChildren(DataGridTitleNode parent, SetVisibleState getState)
    {
      int result = 0;
      foreach (DataGridTitleNode childNode in parent.Items)
      {
        CustomizeDataGridColumnDialogDataRow childRow = GetDataRowByNode(childNode);
        if (getState == SetVisibleState.Show)
        {
          if (childRow.VisibleState == true)
            result = result + 1;
        }
        else
        {
          if (childRow.HiddenState == true)
            result = result + 1;
        }
      }
      return result;
    }

    private void GetChildList(DataGridTitleNode node, List<CustomizeDataGridColumnDialogDataRow> rowsList, bool childRecursion)
    {
      foreach (DataGridTitleNode childNode in node.Items)
      {
        CustomizeDataGridColumnDialogDataRow childRow = GetDataRowByNode(childNode);
        rowsList.Add(childRow);

        if (childRecursion && (childNode.NodeType == DataGridTitleNodeType.SuperTitle))
        {
          GetChildList(childRow.TitleNode, rowsList, childRecursion);
        }
      }
    }

    private CustomizeDataGridColumnDialogDataRow GetDataRowByNode(DataGridTitleNode childNode)
    {
      foreach (CustomizePropBarsDialogPropDataRow axisRow in PropsTable)
      {
        CustomizeDataGridColumnDialogDataRow row = axisRow as CustomizeDataGridColumnDialogDataRow;
        Debug.Assert(row != null, "row != null");
        DataGridTitleNode node = row.TitleNode;
        if (node == childNode)
          return row;
      }
      return null;
    }

    protected override void MovePropBarsUpDown(bool isMoveUp)
    {
      if (DataGrid.Title.MultiTitle.Active)
      {
        if (VisiblePropBarsGrid.VisibleRows.Count == 0) return;

        DataGridRow gridRow = VisiblePropBarsGrid.CurrentRow;
        CustomizeDataGridColumnDialogDataRow dataRow = gridRow.SourceItem as CustomizeDataGridColumnDialogDataRow;
        CustomizeDataGridColumnDialogTreeNode setupNode = dataRow.SetupNode;
        int setupNodeVisibleIndex = setupNode.VisibleIndex;
        CustomizeDataGridColumnDialogTreeNode parentSetupNode = dataRow.SetupNode.Parent;

        List<CustomizeDataGridColumnDialogTreeNode> orderdList = new List<CustomizeDataGridColumnDialogTreeNode>();

        foreach (CustomizeDataGridColumnDialogTreeNode node in parentSetupNode.Items)
          orderdList.Add(node);

        if (isMoveUp)
        {
          if (setupNodeVisibleIndex == 0) return;
          setupNodeVisibleIndex--;
          int modeToNodeIndex = parentSetupNode.VisibleItems[setupNodeVisibleIndex].Index;
          orderdList.Remove(setupNode);
          orderdList.Insert(modeToNodeIndex, setupNode);
          //VisiblePropBarsGrid.CurrentRowIndex = VisiblePropBarsGrid.CurrentRowIndex - 1;
        }
        else
        {
          if (setupNodeVisibleIndex == parentSetupNode.VisibleItems.Count - 1) return;
          setupNodeVisibleIndex++;
          int modeToNodeIndex = parentSetupNode.VisibleItems[setupNodeVisibleIndex].Index;
          orderdList.Remove(setupNode);
          orderdList.Insert(modeToNodeIndex, setupNode);
          //VisiblePropBarsGrid.CurrentRowIndex = VisiblePropBarsGrid.CurrentRowIndex + 1;
        }

        dataRow.SetupNode.Parent.SetItemsOrder(orderdList);

        SetupTreeListToFlatPropsTable();
        RefreshScreenLists();

        VisiblePropBarsGrid.CurrentRowIndex = VisiblePropBarsGridIndexOfSetupNode(setupNode);
      }
      else
      {
        base.MovePropBarsUpDown(isMoveUp);
      }
    }

    private int VisiblePropBarsGridIndexOfSetupNode(CustomizeDataGridColumnDialogTreeNode setupNode)
    {
      int i = 0;
      foreach (DataGridRow gridRow in VisiblePropBarsGrid.VisibleRows)
      {
        CustomizeDataGridColumnDialogDataRow dataRow = gridRow.SourceItem as CustomizeDataGridColumnDialogDataRow;
        if (dataRow.SetupNode == setupNode)
          return i;
        i++;
      }
      return -1;
    }

    protected override void SetWidth_Click(object sender, EventArgs e)
    {
      List<CustomizeDataGridColumnDialogDataRow> listForWidth = new List<CustomizeDataGridColumnDialogDataRow>();

      foreach (DataGridRow row in VisiblePropBarsGrid.Rows)
      {
        if (row.Selected)
          listForWidth.Add(row.SourceItem as CustomizeDataGridColumnDialogDataRow);
      }

      if (listForWidth.Count == 0 && VisiblePropBarsGrid.VisibleRows.Count > 0)
        listForWidth.Add(VisiblePropBarsGrid.CurrentRow.SourceItem as CustomizeDataGridColumnDialogDataRow);

      if (listForWidth.Count == 0) return;

      string colWidthStr = listForWidth[0].Width.ToString();

      if (EhLibUtils.InputBox("Set columns width", "Width", ref colWidthStr) != DialogResult.OK) return;

      int newColWidth;
      if (!int.TryParse(colWidthStr, out newColWidth))
      {
        MessageBox.Show(@"The input text is not a number", @"Error", System.Windows.Forms.MessageBoxButtons.OK, MessageBoxIcon.Error);
        return;
      }

      foreach (CustomizeDataGridColumnDialogDataRow rowView in listForWidth)
      {
        if (DataGrid.Title.MultiTitle.Active == false
              ||
            (DataGrid.Title.MultiTitle.Active == true &&
             (rowView.TitleNode.NodeType == DataGridTitleNodeType.ColumnTitle))
           )
        {
          rowView.Width = newColWidth;
        }
      }

      RefreshScreenLists();
    }

    private void VisGridNameColumn_DataCellClientAreaNeeded(object sender, DataGridDataCellClientAreaNeededEventArgs e)
    {
      if (e.Row == null) return;
      int custAreaWidth = 0;
      if (DataGrid.Title.MultiTitle.Active)
      {
        CustomizeDataGridColumnDialogDataRow row = e.Row.SourceItem as CustomizeDataGridColumnDialogDataRow;
        DataGridTitleNode node = row.TitleNode;
        custAreaWidth = e.CellArgs.CellRect.Height * node.Level;
      }
      e.CellArgs.CellClientRect = EhLibUtils.ChangeRectangle(e.CellArgs.CellRect, custAreaWidth, 0, -custAreaWidth, 0);
    }

    private void VisGridNameColumn_DataCellPaintCustomArea(object sender, DataGridDataCellPaintEventArgs e)
    {
      if (!DataGrid.Title.MultiTitle.Active) return;
      if (e.Row == null) return;

      Rectangle drawRect = e.CellArgs.ClientRect;
      drawRect.X = e.CellArgs.CellRect.X;
      drawRect.Width = e.CellArgs.ClientRect.X - e.CellArgs.CellRect.X;
      e.CellArgs.ClientRect = drawRect;
      e.PaintBackground(e);

      CustomizeDataGridColumnDialogDataRow row = e.Row.SourceItem as CustomizeDataGridColumnDialogDataRow;
      DataGridTitleNode node = row.TitleNode;

      if (node.NodeType == DataGridTitleNodeType.SuperTitle)
      {
        Rectangle btnRect = drawRect;
        btnRect.X = drawRect.Right - drawRect.Height;
        btnRect.Width = drawRect.Height;

        Bitmap bmp = Properties.Resources.ExpandedTriangle;

        Rectangle signRect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        signRect = EhLibUtils.RectCenter(signRect, btnRect);

        e.CellArgs.Graphics.DrawImage(bmp, signRect);
      }
    }
    #endregion

  }

  [Obfuscation(Feature = "renaming", Exclude = true, ApplyToMembers = false)]
  public class CustomizeDataGridColumnDialogDataRow : CustomizePropBarsDialogPropDataRow
  {
    public Nullable<int> Width { get; set; }
    public DataGridTitleNode TitleNode { get; set; }
    public bool HiddenState { get; set; }
    public DataGridColumn Column { get { return PropBar as DataGridColumn; } }
    public CustomizeDataGridColumnDialogTreeNode SetupNode { get; set; }
  }

  public class CustomizeDataGridColumnDialogTreeNode : BaseTreeNode
  {
    private readonly CustomizeDataGridColumnDialogDataRow dataRow;

    public CustomizeDataGridColumnDialogTreeNode()
    {
      dataRow = new CustomizeDataGridColumnDialogDataRow();
    }

    public CustomizeDataGridColumnDialogDataRow DataRow { get { return dataRow; } }

    public new CustomizeDataGridColumnDialogTreeNode Parent { get { return (CustomizeDataGridColumnDialogTreeNode)base.Parent; } }

    public override string ToString()
    {
      return DataRow.Name;
    }
  }

}
