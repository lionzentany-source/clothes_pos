﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Windows.Forms.VisualStyles;
using System.Diagnostics;
using System.ComponentModel.Design;

namespace EhLib.WinForms
{
  public class DataGridTitleCellPaintEventArgs : BaseGridCellPaintEventArgs
  {

    public DataGridTitleCellPaintEventArgs(DataAxisGrid grid, BaseGridCellManager cellManager, GraphicsContext gc, int colIndex, int rowIndex,
      Rectangle cellRect, Rectangle cellAreaRect, BasePaintCellStates state, int areaColIndex, int areaRowIndex, Point inCellMousePos, 
      DataGridColumn column)
      : base (grid, cellManager, gc, colIndex, rowIndex, cellRect, cellAreaRect, state, areaColIndex, areaRowIndex, inCellMousePos)
    {
      Column = column;
    }

    public DataGridColumn Column { get; internal set; }
    public new DataGridTitleCellMan CellManager
    {
      get { return (DataGridTitleCellMan)base.CellManager; }
    }

    public Rectangle ContentRect { get; internal set; }
    public TextFormatFlags AlignFlags { get; set; }
    public Color BackColor { get; set; }
    public bool EndEllipsis { get; set; }
    public Font Font { get; set; }
    public Color ForeColor { get; set; }
    public Padding Padding { get; set; }
    public TextOrientation TextOrientation { get; set; }
    public CellTextWrapMode WrapMode { get; set; }

    public virtual void Paint(DataGridTitleCellPaintEventArgs e)
    {
      CellManager.OnPaint(e);
    }

    public virtual void PaintBackground(DataGridTitleCellPaintEventArgs e)
    {
      CellManager.OnPaintBackground(e);
    }

    public virtual void PaintForeground(DataGridTitleCellPaintEventArgs e)
    {
      CellManager.OnPaintForeground(e);
    }
  }

  //public class DataGridTitleCellCustomAreaMeasuresNeededEventArgs : EventArgs
  //{
  //  private readonly CellCustomAreaMeasures areaMeasures;
  //  private readonly DataGridColumnTitle columnTitle;

  //  public DataGridTitleCellCustomAreaMeasuresNeededEventArgs(
  //    CellCustomAreaMeasures areaMeasures, DataGridColumnTitle columnTitle)
  //  {
  //    this.areaMeasures = areaMeasures;
  //    this.columnTitle = columnTitle;
  //  }

  //  public CellCustomAreaMeasures AreaMeasures
  //  {
  //    get { return areaMeasures; }
  //  }

  //  public DataGridColumnTitle ColumnTitle
  //  {
  //    get { return this.columnTitle; }
  //  }
  //}

  public class DataGridTitleCellContextMenuStripNeededEventArgs : BaseGridCellContextMenuStripNeededEventArgs
  {
    private readonly DataGridColumn column;

    public DataGridTitleCellContextMenuStripNeededEventArgs(
      BaseGridControl grid, BaseGridCellManager cellManager, 
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex,
      int inCellX, int inCellY, Rectangle cellRect, int mousePosX, int mousePosY,
      DataGridColumn column)
      : base(grid, cellManager, colIndex, rowIndex, areaColIndex, areaRowIndex, inCellX, inCellY, cellRect, mousePosX, mousePosY)

    {
      this.column = column;
    }

    public DataGridColumn Column
    {
      get { return this.column; }
    }

    public DataGridTitleCellMan CellMan
    {
      get { return (DataGridTitleCellMan)base.CellManager; }
    }

    public new virtual void SetContextMenuStrip(DataGridTitleCellContextMenuStripNeededEventArgs e)
    {
      e.CellMan.OnTitleContextMenuStripNeeded(e);
    }
  }

  public class DataGridTitleCellClientAreaNeededEventArgs : EventArgs
  {
    private readonly Rectangle cellRect;
    private readonly DataGridColumnTitle columnTitle;
    private Rectangle cellClientRect;

    public DataGridTitleCellClientAreaNeededEventArgs(
      DataGridColumnTitle columnTitle, Rectangle cellRect)
    {
      this.cellRect = cellRect;
      this.cellClientRect = cellRect;
      this.columnTitle = columnTitle;
    }

    public DataGridColumnTitle ColumnTitle
    {
      get { return this.columnTitle; }
    }

    public Rectangle CellRect
    {
      get { return cellRect; }
    }

    public Rectangle CellClientRect
    {
      get { return cellClientRect; }
      set { cellClientRect = value; }
    }
  }

  public class DataGridMultiTitleCellContextMenuStripNeededProvideEventArgs : BaseGridCellContextMenuStripNeededEventArgs
  {
    private readonly DataGridTitleCellContextMenuStripNeededEventArgs titleEventArgs;
    private readonly DataGridSuperTitleCellContextMenuStripNeededEventArgs superTitleEventArgs;

    public DataGridMultiTitleCellContextMenuStripNeededProvideEventArgs(
      BaseGridControl grid, BaseGridCellManager cellManager, 
      int colIndex, int rowIndex, int areaColIndex, int areaRowIndex,
      int inCellX, int inCellY, Rectangle cellRect, int mousePosX, int mousePosY,
      DataGridTitleCellContextMenuStripNeededEventArgs titleEventArgs,
      DataGridSuperTitleCellContextMenuStripNeededEventArgs superTitleEventArgs)
      : base(grid, cellManager, colIndex, rowIndex, areaColIndex, areaRowIndex, inCellX, inCellY, cellRect, mousePosX, mousePosY)

    {
      this.titleEventArgs = titleEventArgs;
      this.superTitleEventArgs = superTitleEventArgs;
    }

    public DataGridTitleCellContextMenuStripNeededEventArgs TitleEventArgs
    {
      get { return this.titleEventArgs; }
    }

    public DataGridSuperTitleCellContextMenuStripNeededEventArgs SuperTitleEventArgs
    {
      get { return this.superTitleEventArgs; }
    }
  }

  public class DataGridTitleCellOptimalHeightNeededEventArgs : HandledEventArgs
  {
    private readonly DataGridColumnTitle columnTitle;
    private readonly BaseGridCellManager cellMan;
    private int optimalHeight;

    public DataGridTitleCellOptimalHeightNeededEventArgs(
      DataGridColumnTitle columnTitle, BaseGridCellManager cellMan)
    {
      this.columnTitle = columnTitle;
      this.cellMan = cellMan;
    }

    public DataGridColumnTitle ColumnTitle
    {
      get { return this.columnTitle; }
    }

    public BaseGridCellManager CellMan
    {
      get { return cellMan; }
    }

    public int OptimalHeight
    {
      get { return optimalHeight; }
      set { optimalHeight = value; }
    }

    public virtual int CalcOptimalHeight(DataGridTitleCellOptimalHeightNeededEventArgs e)
    {
      DataGridTitleCellMan tcm = e.CellMan as DataGridTitleCellMan;
      if (tcm != null)
      {
        tcm.OnOptimalHeightNeeded(e);
        return e.OptimalHeight;
      }
      else
      {
        return 0;
      }
    }

  }

  //public class DataGridColumnTitleContextMenuStripNeededEventArgs : EventArgs
  //{
  //  private ContextMenuStrip contextMenuStrip;
  //  private readonly DataGridColumn column;
  //  private readonly DataGridColumnTitle columnTitle;
  //  private readonly DataGridSuperTitle superTitle;

  //  public DataGridColumnTitleContextMenuStripNeededEventArgs(DataGridColumn column,
  //    DataGridColumnTitle columnTitle, DataGridSuperTitle superTitle)
  //  {
  //    this.column = column;
  //    this.columnTitle = columnTitle;
  //    this.superTitle = superTitle;
  //  }

  //  internal DataGridColumnTitleContextMenuStripNeededEventArgs(
  //      DataGridColumn column, ContextMenuStrip contextMenuStrip,
  //      DataGridColumnTitle columnTitle, DataGridSuperTitle superTitle
  //      )
  //  {
  //    this.contextMenuStrip = contextMenuStrip;
  //    this.column = column;
  //    this.columnTitle = columnTitle;
  //    this.superTitle = superTitle;
  //  }

  //  public ContextMenuStrip ContextMenuStrip
  //  {
  //    get { return this.contextMenuStrip; }
  //    set { this.contextMenuStrip = value; }
  //  }

  //  public DataGridColumn Column
  //  {
  //    get { return this.column; }
  //  }

  //  public DataGridColumnTitle ColumnTitle
  //  {
  //    get { return this.columnTitle; }
  //  }

  //  public DataGridSuperTitle SuperTitle
  //  {
  //    get { return this.superTitle; }
  //  }
  //}

}