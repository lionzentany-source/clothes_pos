﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EhLib.WinForms.Design
{
  public class DataVertGridRowsEditor : DataAxisGridPropertyBarsEditor
  {
    public DataVertGridRowsEditor(Type type) : base(type)
    {
    }

    public override Type GetRootPropertyBarType()
    {
      return typeof(DataVertGridRow);
    }

    protected override int CompareColumnTypesSorting(Type x, Type y)
    {
      if (x == y)
        return 0;
      else if (x == typeof(DataVertGridTextRow))
        return -1;
      else if (y == typeof(DataVertGridTextRow))
        return 1;
      else
        return 0;
    }

    public override Type GetDataGridColumnDesignTimeVisibleAttribute()
    {
      return typeof(DataVertGridRowDesignTimeVisibleAttribute);
    }
  }
}
