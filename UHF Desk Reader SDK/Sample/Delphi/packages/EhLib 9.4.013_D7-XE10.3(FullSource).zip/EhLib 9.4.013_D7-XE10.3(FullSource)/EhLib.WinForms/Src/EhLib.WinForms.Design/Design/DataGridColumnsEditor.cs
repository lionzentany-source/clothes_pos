﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows.Forms;
using System.Drawing.Design;
using System.Globalization;

namespace EhLib.WinForms.Design
{
  public class DataGridColumnsEditor : DataAxisGridPropertyBarsEditor
  {
    public DataGridColumnsEditor(Type type) : base(type)
    {
    }

    public override Type GetRootPropertyBarType()
    {
      return typeof(DataGridColumn);
    }

    protected override int CompareColumnTypesSorting(Type x, Type y)
    {
      if (x == y)
        return 0;
      else if (x == typeof(DataGridTextColumn))
        return -1;
      else if (y == typeof(DataGridTextColumn))
        return 1;
      else
        return 0;
    }

    public override Type GetDataGridColumnDesignTimeVisibleAttribute()
    {
      return typeof(DataGridColumnDesignTimeVisibleAttribute);
    }

  }

}
