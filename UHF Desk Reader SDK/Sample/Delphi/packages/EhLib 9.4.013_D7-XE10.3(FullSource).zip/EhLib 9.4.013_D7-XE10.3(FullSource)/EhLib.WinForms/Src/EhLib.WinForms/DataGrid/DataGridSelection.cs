﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017-2018 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace EhLib.WinForms
{

  /// <summary>
  /// Type of current selection in grid.
  /// </summary>
  /// <remarks>
  /// This enumeration is used to get the <see cref="DataGridSelection.SelectionType"/> property value of a <see cref="DataGridEh"/> control.
  /// </remarks>
  public enum GridSelectionType
  {
    /// <summary>
    /// No area is selected in the grid.
    /// </summary>
    None,

    /// <summary>
    /// One or more rows are selected in the grid.
    /// </summary>
    Rows,

    /// <summary>
    /// One or more columns are selected in the grid.
    /// </summary>
    Columns,

    /// <summary>
    /// A rectangular area consisting of several cells is selected in the grid.
    /// </summary>
    CellsBox,

    /// <summary>
    /// The whole grid is seleced.
    /// </summary>
    All
  }

  /// <summary>
  /// Contains a specific type of selection when user select areas in the grid be mouse.
  /// </summary>
  public enum DataGridSelectionState
  {
    None, RowSelection, ColumnSelection, CellSelection,
  }

  public enum SelectionChangeOperationType 
  {
    ComplexChange, RowSelected, RowDeselected, ColumnSelected, ColumnDeselected
  }

  /// <summary> 
  /// Controls the selection of cells, records and columns in the DataGridEh.
  /// You can retrieve an instance of this class through the <see cref="DataGridEh.Selection"/> property.
  /// </summary>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class DataGridSelection : DataGridObject
  {

    #region privates
    private GridAllowedSelections allowedSelection;
    private bool rowHighlight = true;
    private bool rowSelect;
    private bool keepSelection;
    private bool alwaysShowSelection = true;
    private GridSelectionType selectionType = GridSelectionType.None;
    private DataGridSelectionState selectionState = DataGridSelectionState.None;
    private bool selectedStateIsSelected = true;
    private readonly List<bool> oldSelectedState;
    private bool selectedRowCountObsolete = true;
    private int selectedRowCount;

    protected internal int AnchorCol;
    protected internal int FreeEndCol;
    protected internal int AnchorDataRowIndex;
    protected internal int FreeEndDataRowIndex;
    protected internal GridCoord AnchorCell;
    protected internal GridCoord FreeEndCell;
    protected internal bool InternalKeepSelection = false;
    private int updateCount;
    #endregion privates

    public DataGridSelection(DataGridEh grid) : base(grid)
    {
      allowedSelection = new GridAllowedSelections(this);
      oldSelectedState = new List<bool>();
    }

    #region design-time properties

    /// <summary>
    /// Contains properties for customizing the allowed selections in the grid that user can perform. It can be rows, columns, and rectangular area.
    /// </summary>
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public GridAllowedSelections AllowedSelection
    {
      get
      {
        return allowedSelection;
      }
      set
      {
        allowedSelection = value;
      }
    }

    /// <summary>
    /// Gets or sets a value indicating whether the grid always selects and heighlight the entire row instead of a single cell.
    /// </summary>
    [DefaultValue(false)]
    public bool RowSelect
    {
      get
      {
        return rowSelect;
      }
      set
      {
        if (rowSelect != value)
        {
          rowSelect = value;
          Grid.RowSelectStateChanged();
        }
      }
    }

    /// <summary>
    /// Highlights the row that contains the current cell.
    /// </summary>
    [DefaultValue(true)]
    public bool RowHighlight
    {
      get
      {
        return rowHighlight;
      }
      set
      {
        if (rowHighlight != value)
        {
          rowHighlight = value;
          Grid.RowSelectStateChanged();
        }
      }
    }

    /// <summary>
    /// Doesn't clear the selection when user navigate throw the grid.
    /// </summary>
    [DefaultValue(false)]
    public bool KeepSelection
    {
      get
      {
        return keepSelection;
      }
      set
      {
        if (keepSelection != value)
        {
          keepSelection = value;
          Grid.RowSelectStateChanged();
        }
      }
    }

    /// <summary>
    /// Highlights the row that contains the current cell.
    /// </summary>
    [DefaultValue(true)]
    public bool AlwaysShowSelection
    {
      get
      {
        return alwaysShowSelection;
      }
      set
      {
        if (alwaysShowSelection != value)
        {
          alwaysShowSelection = value;
          Grid.RowSelectStateChanged();
        }
      }
    }

    #endregion design-time properties

    #region run-time properties

    /// <summary>
    /// Type of current selection in grid.
    /// </summary>
    [Browsable(false)]
    public GridSelectionType SelectionType
    {
      get { return selectionType; }
    }

    /// <summary>
    /// Contains a specific type of selection when user select areas in the grid be mouse.
    /// </summary>
    /// <remarks>
    /// This property contains a non-zero value when the user press the mouse button over the one of 
    /// the areas of the grid and moves the mouse to select multiple objects.
    /// </remarks>
    [Browsable(false)]
    public DataGridSelectionState SelectionState
    {
      get { return selectionState; }
    }

    /// <summary>
    /// Contains the coordinates of the selected area in the grid when the type of selection is a 
    /// rectangular area.
    /// </summary>
    [Browsable(false)]
    public GridRect SelectedBox
    {
      get
      {
        if (SelectionType == GridSelectionType.None)
        {
          return new GridRect(Grid.CurrentColumnIndex, Grid.CurrentRowIndex, Grid.CurrentColumnIndex, Grid.CurrentRowIndex);
        }
        else if (SelectionType == GridSelectionType.CellsBox)
        {
          GridRect rec;

          if (AnchorCell.X < FreeEndCell.X)
          {
            rec.Left = AnchorCell.X;
            rec.Right = FreeEndCell.X;
          }
          else
          {
            rec.Left = FreeEndCell.X;
            rec.Right = AnchorCell.X;
          }

          if (AnchorCell.Y < FreeEndCell.Y)
          {
            rec.Top = AnchorCell.Y;
            rec.Bottom = FreeEndCell.Y;
          }
          else
          {
            rec.Top = FreeEndCell.Y;
            rec.Bottom = AnchorCell.Y;
          }

          return rec;
        }
        else
        {
          return new GridRect(-1, -1, -1, -1);
        }
      }
    }

    /// <summary>
    /// Gets the collection of rows selected by the user.
    /// </summary>
    /// <value>
    /// A ReadOnlyCollection that contains the rows selected by the user.
    /// </value>
    /// <remarks>
    /// This property contains a read-only snapshot of the selection at the time it is referenced. 
    /// If you hold onto a copy of this collection, it may differ from the actual, subsequent DataGridEh 
    /// state in which the user may have changed the selection. 
    /// You should therefore not operate on a copy of the collection.
    /// </remarks>
    [Browsable(false)]
    public ReadOnlyCollection<DataGridRow> SelectedRows
    {
      get
      {
        List<DataGridRow> strc = new List<DataGridRow>();
        switch (this.SelectionType)
        {
          case GridSelectionType.None:
          case GridSelectionType.Columns:
          case GridSelectionType.CellsBox:
            break;

          case GridSelectionType.Rows:
            foreach (DataGridRow row in Grid.Rows)
            {
              if (row.Selected)
                strc.Add(row);
            }
            break;

          case GridSelectionType.All:
            foreach (DataGridRow row in Grid.VisibleRows)
              strc.Add(row);
            break;
        }
        return new ReadOnlyCollection<DataGridRow>(strc);
      }
    }

    /// <summary>
    /// Gets the collection of rows selected by the user.
    /// </summary>
    /// <value>
    /// A ReadOnlyCollection that contains the columns selected by the user.
    /// </value>
    /// <remarks>
    /// This property contains a read-only snapshot of the selection at the time it is referenced. 
    /// If you hold onto a copy of this collection, it may differ from the actual, subsequent DataGridEh 
    /// state in which the user may have changed the selection. 
    /// You should therefore not operate on a copy of the collection.
    /// </remarks>
    [Browsable(false)]
    public ReadOnlyCollection<DataGridColumn> SelectedColumns
    {
      get
      {
        List<DataGridColumn> strc = new List<DataGridColumn>();
        switch (this.SelectionType)
        {
          case GridSelectionType.None:
          case GridSelectionType.Rows:
          case GridSelectionType.CellsBox:
            break;
          case GridSelectionType.Columns:
          case GridSelectionType.All:
            foreach (DataGridColumn col in Grid.Columns)
            {
              if (col.Selected)
                strc.Add(col);
            }
            break;
        }
        return new ReadOnlyCollection<DataGridColumn>(strc);
      }
    }

    /// <summary>
    /// Gets the count of rows selected in the grid.
    /// </summary>
    [Browsable(false)]
    public int SelectedRowCount
    {
      get
      {
        if (selectedRowCountObsolete)
          UpdateSelectedRowCount();
        return selectedRowCount;
      }
    }

    /// <summary>
    /// Gets a value indicating whether selection of grid rows is allows.
    /// </summary>
    /// <remarks>
    /// In some cases, the grid temporarily prohibits the selection of rows, 
    /// since The grid is blocked from performing other operations.
    /// For example, when a user resizes a column with a mouse.
    /// </remarks>
    [Browsable(false)]
    public bool RowsSelectionIsAllowed
    {
      get
      {
        if (AllowedSelection.Rows &&
             (Grid.GridState == BaseGridState.Normal) &&
             (Grid.DataGridState == DataGridState.Normal)
        )
          return true;
        else
          return false;
      }
    }

    /// <summary>
    /// Gets a value indicating whether selection of grid columns is allows.
    /// </summary>
    [Browsable(false)]
    public bool ColumnsSelectionIsAllowed
    {
      get
      {
        if ((AllowedSelection.Columns) &&
            (RowSelect == false) &&
            (Grid.GridState == BaseGridState.Normal) &&
            (Grid.DataGridState == DataGridState.Normal)
        )
          return true;
        else
          return false;
      }
    }

    /// <summary>
    /// Gets a value indicating whether selection of cells is allows.
    /// </summary>
    [Browsable(false)]
    public bool CellsSelectionIsAllowed
    {
      get
      {
        if ((AllowedSelection.Cells) &&
            (RowSelect == false) &&
            (Grid.GridState == BaseGridState.Normal) &&
            (Grid.DataGridState == DataGridState.Normal)
        )
          return true;
        else
          return false;
      }
    }

    /// <summary>
    /// Gets a value indicating that selection performs some internal operations. So SelectionChanged event is not fired.
    /// </summary>
    [Browsable(false)]
    public bool Updating
    {
      get { return (updateCount > 0); }
    }
    #endregion run-time properties

    #region internal methods
    private void UpdateSelectedRowCount()
    {
      selectedRowCount = 0;

      foreach (DataGridRow irow in Grid.Rows)
      {
        if (irow.SelectedInternal)
          selectedRowCount = selectedRowCount + 1;
      }

      selectedRowCountObsolete = false;
    }

    internal bool CellIsSelected(int col, int row)
    {
      switch (SelectionType)
      {
        case GridSelectionType.All:
          {
            return true;
          }

        case GridSelectionType.CellsBox:
        case GridSelectionType.Rows:
        case GridSelectionType.Columns:
          {
            int areaColIndex;
            int areaRowIndex;

            BaseGridCellManager cell = Grid.CellManByColRow(col, row, out areaColIndex, out areaRowIndex);
            Debug.Assert(cell != null, "DataGridEh.PaintCell Cell = null");

            return cell.IsSelected(Grid, areaColIndex, areaRowIndex);
          }

        default:
          {
            return false;
          }
      }
    }

    internal void SetFreeEndCol(int newFreeEndCol)
    {
      if (newFreeEndCol > FreeEndCol)
      {
        for (int i = FreeEndCol; i <= newFreeEndCol; i++)
        {
          if (!((FreeEndCol > AnchorCol) && (i == FreeEndCol))
              && !((newFreeEndCol < AnchorCol) && (i == newFreeEndCol))
              && (i != AnchorCol)
             )
          {
            AddSelectedColumn(Grid.VisibleColumns[i], !Grid.VisibleColumns[i].Selected);
          }
        }
      }
      else if (newFreeEndCol < FreeEndCol)
      {
        for (int i = newFreeEndCol; i <= FreeEndCol; i++)
        {
          if (!((newFreeEndCol > AnchorCol) && (i == newFreeEndCol))
               && !((FreeEndCol < AnchorCol) && (i == FreeEndCol))
               && (i != AnchorCol)
             )
          {
            AddSelectedColumn(Grid.VisibleColumns[i], !Grid.VisibleColumns[i].Selected);
          }
        }
      }
      FreeEndCol = newFreeEndCol;
    }

    internal void InitAnchorCol(int anchorCol)
    {
      this.AnchorCol = anchorCol;
      this.FreeEndCol = anchorCol;
    }

    internal void InitAnchorRow(int anchorDataRowIndex, bool selectedStateIsSelected)
    {
      this.AnchorDataRowIndex = anchorDataRowIndex;
      this.FreeEndDataRowIndex = anchorDataRowIndex;
      this.selectionState = DataGridSelectionState.RowSelection;
      this.selectedStateIsSelected = selectedStateIsSelected;
    }

    internal void SetFreeEndRow(int newFreeEndRow)
    {
      int stepIndex;
      DataGridRow row;
      bool oldSelState;

      if (newFreeEndRow > FreeEndDataRowIndex)
      {
        BeginUpdate();
        try
        {
          stepIndex = Math.Min(AnchorDataRowIndex, newFreeEndRow);

          for (int i = FreeEndDataRowIndex; i < stepIndex; i++)
          {
            oldSelState = DeleteOldStateSelectedRow();
            row = Grid.VisibleRows[i];
            if (Grid.CanSelectRow(row))
              AddSelectedRow(row, oldSelState);
          }

          stepIndex = Math.Max(AnchorDataRowIndex + 1, FreeEndDataRowIndex + 1);

          for (int i = stepIndex; i <= newFreeEndRow; i++)
          {
            AddOldStateSelectedRow(Grid.VisibleRows[i].Selected);
            row = Grid.VisibleRows[i];
            if (Grid.CanSelectRow(row))
              AddSelectedRow(row, selectedStateIsSelected);
          }
        }
        finally
        {
          EndUpdate(true);
        }
      }
      else if (newFreeEndRow < FreeEndDataRowIndex)
      {
        BeginUpdate();
        try
        {
          stepIndex = Math.Max(AnchorDataRowIndex, newFreeEndRow);

          for (int i = FreeEndDataRowIndex; i > stepIndex; i--)
          {
            oldSelState = DeleteOldStateSelectedRow();
            row = Grid.VisibleRows[i];
            if (Grid.CanSelectRow(row))
              AddSelectedRow(Grid.VisibleRows[i], oldSelState);
          }

          stepIndex = Math.Min(AnchorDataRowIndex - 1, FreeEndDataRowIndex - 1);

          for (int i = stepIndex; i >= newFreeEndRow; i--)
          {
            AddOldStateSelectedRow(Grid.VisibleRows[i].Selected);
            row = Grid.VisibleRows[i];
            if (Grid.CanSelectRow(row))
              AddSelectedRow(row, selectedStateIsSelected);
          }
        }
        finally
        {
          EndUpdate(true);
        }

      }
      FreeEndDataRowIndex = newFreeEndRow;
    }

    internal void StartCellsRectSelection(GridCoord anchorCell, GridCoord freeEndCell)
    {
      Rectangle noScrollRect = Rectangle.Empty;

      if (SelectionType != GridSelectionType.CellsBox)
        Clear();
      //if (anchorCell == freeEndCell)
      //  Clear();
      //else
      {
        if (Grid.VisibleColumns.Count == 0 || Grid.VisibleRows.Count == 0) return;

        this.AnchorCell = anchorCell;
        //Debug.WriteLine("StartCellsRectSelection:" + FreeEndCell.ToString());
        this.FreeEndCell = freeEndCell;
        SetSelectionType(GridSelectionType.CellsBox);
        Grid.InvalidateGrid();

        noScrollRect.X = Grid.HorzAxis.FixedBoundary;
        noScrollRect.Width = Grid.HorzAxis.RollClientLen;
        noScrollRect.Y = Grid.VertAxis.FixedBoundary;
        noScrollRect.Height = Grid.VertAxis.RollClientLen;

        Grid.MoveNScrollService.Capture(Grid, noScrollRect, CellsBoxSelectServiceEventHandler, true, true);

      }
    }

    protected internal virtual void CellsBoxSelectServiceEventHandler(MoveAndScrollService service, MouseEventArgs e)
    {
      GridCoord cellHit;
      GridCoord newFreeEndCell = FreeEndCell;
      int newColIndex;
      int newRowIndex;

      //Debug.WriteLine("RowSelectServiceEventHandler-" + e.Y.ToString());
      cellHit = Grid.MouseCoord(e.X, e.Y);
      if (service.ClientRect.Contains(e.Location))
      {
        if ((cellHit.Y >= 0) && (cellHit.X >= 0))
        {
          newFreeEndCell = new GridCoord(Grid.RawToDataColumnIndex(cellHit.X), Grid.RawToDataRowIndex(cellHit.Y));
        }
      }

      if (e.X > service.ClientRect.Right)
      {
        Grid.SafeScrollData(Grid.HorzAxis.GetScrollStep(), 0);
        newColIndex = Grid.HorzAxis.RollLastVisCell + Grid.HorzAxis.FixedCellCount;
        newFreeEndCell.X = Grid.RawToDataColumnIndex(newColIndex);
      }
      else if (e.X < service.ClientRect.Left)
      {
        Grid.SafeScrollData(-Grid.HorzAxis.GetScrollStep(), 0);
        newColIndex = Grid.HorzAxis.RollStartVisCell + Grid.HorzAxis.FixedCellCount;
        newFreeEndCell.X = Grid.RawToDataColumnIndex(newColIndex);
      }
      else if (cellHit.X >= 0)
      {
        newFreeEndCell.X = Grid.RawToDataColumnIndex(cellHit.X);
      }

      if (e.Y > service.ClientRect.Bottom)
      {
        Grid.SafeScrollData(0, Grid.HorzAxis.GetScrollStep());
        newRowIndex = Grid.VertAxis.RollLastVisCell + Grid.VertAxis.FixedCellCount;
        newFreeEndCell.Y = Grid.RawToDataRowIndex(newRowIndex);
      }
      else if (e.Y < service.ClientRect.Top)
      {
        Grid.SafeScrollData(0, -Grid.HorzAxis.GetScrollStep());
        newRowIndex = Grid.VertAxis.RollStartVisCell + Grid.VertAxis.FixedCellCount;
        newFreeEndCell.Y = Grid.RawToDataRowIndex(newRowIndex);
      }
      else if (cellHit.Y >= 0)
      {
        newFreeEndCell.Y = Grid.RawToDataColumnIndex(cellHit.Y);
      }

      //Debug.WriteLine(newFreeEndCell);

      if (newFreeEndCell.Y >= Grid.VisibleRows.Count)
        newFreeEndCell.Y = Grid.VisibleRows.Count - 1;
      SetFreeEndCell(newFreeEndCell);
    }

    protected internal void SetFreeEndCell(GridCoord newFreeEndCell)
    {
      if (newFreeEndCell != FreeEndCell)
      {
        FreeEndCell = newFreeEndCell;
        OnSelectionChanged(SelectionChangeOperationType.ComplexChange, null);
      }
    }

    internal bool CellsRectContains(int areaColIndex, int areaRowIndex)
    {
      bool containsAreaCol;
      bool containsAreaRow;

      if (AnchorCell.X < FreeEndCell.X)
        containsAreaCol = (AnchorCell.X <= areaColIndex) && (areaColIndex <= FreeEndCell.X);
      else
        containsAreaCol = (AnchorCell.X >= areaColIndex) && (areaColIndex >= FreeEndCell.X);

      if (AnchorCell.Y < FreeEndCell.Y)
        containsAreaRow = (AnchorCell.Y <= areaRowIndex) && (areaRowIndex <= FreeEndCell.Y);
      else
        containsAreaRow = (AnchorCell.Y >= areaRowIndex) && (areaRowIndex >= FreeEndCell.Y);

      return containsAreaCol && containsAreaRow;
    }

    protected virtual void SetSelectionType(GridSelectionType newSelectionType)
    {
      if (selectionType != newSelectionType)
      {
        Clear();
        if (newSelectionType != GridSelectionType.None)
          Grid.HideEditor(true);
        selectionType = newSelectionType;
        OnSelectionChanged(SelectionChangeOperationType.ComplexChange, null); //Why was commented
      }
    }

    private void BeginUpdate()
    {
      updateCount = updateCount + 1;
    }

    private void EndUpdate(bool selectionChanged)
    {
      Debug.Assert(updateCount > 0);
      updateCount = updateCount - 1;
      if (!Updating)
      {
        if (selectionChanged)
          OnSelectionChanged(SelectionChangeOperationType.ComplexChange, null);
      }
    }

    private void OnSelectionChanged(SelectionChangeOperationType changeOpType, object changingObject)
    {
      if (!Updating)
      {
        Grid.OnSelectionChanged(new DataGridSelectionChangeOperationEventArgs(changeOpType, changingObject));
      }
    }
    #endregion internal methods

    #region public methods
    public void Clear()
    {
      if (SelectionType == GridSelectionType.None) return;

      switch (SelectionType)
      {
        case GridSelectionType.All:
          {
            break;
          }

        case GridSelectionType.CellsBox:
          {
            AnchorCell = new GridCoord(-1, -1);
            FreeEndCell = new GridCoord(-1, -1);
            break;
          }

        case GridSelectionType.Columns:
          {
            foreach (DataGridColumn col in Grid.Columns)
              col.SelectedInternal = false;
            break;
          }

        case GridSelectionType.Rows:
          {
            foreach (DataGridRow row in Grid.Rows)
              row.SelectedInternal = false;
            break;
          }
      }
      selectionType = GridSelectionType.None;
      selectedRowCountObsolete = true;
      OnSelectionChanged(SelectionChangeOperationType.ComplexChange, null);
    }

    public void CheckClear()
    {
      if (!KeepSelection && !InternalKeepSelection)
        Clear();
    }

    public void SetSelectedColumn(DataGridColumn column)
    {
      CheckClear();
      SetSelectionType(GridSelectionType.Columns);
      column.SelectedInternal = true;
      OnSelectionChanged(SelectionChangeOperationType.ColumnSelected, column);
    }

    public void AddSelectedColumn(DataGridColumn column, bool setToSelected)
    {
      if (setToSelected && (column.SelectedInternal == false))
      {
        if (SelectionType != GridSelectionType.Columns)
          Clear();
        SetSelectionType(GridSelectionType.Columns);
        column.SelectedInternal = true;
        OnSelectionChanged(SelectionChangeOperationType.ColumnSelected, column);
      }
      else if (!setToSelected && (column.SelectedInternal == true))
      {
        bool haveSelected = false;

        column.SelectedInternal = false;
        foreach (DataGridColumn col in Grid.Columns)
        {
          if (col.SelectedInternal)
          {
            haveSelected = true;
            break;
          }
        }
        if (!haveSelected)
          selectionType = GridSelectionType.None;
        OnSelectionChanged(SelectionChangeOperationType.ColumnDeselected, column);
      }
    }

    public void AddSelectedRow(DataGridRow row, bool setToSelected)
    {
      if (setToSelected && (row.SelectedInternal == false))
      {
        if (SelectionType != GridSelectionType.Rows)
          Clear();
        SetSelectionType(GridSelectionType.Rows);
        row.SelectedInternal = true;
        selectedRowCountObsolete = true;
        OnSelectionChanged(SelectionChangeOperationType.RowSelected, row);
      }
      else if (!setToSelected && (row.SelectedInternal == true))
      {
        bool haveSelected = false;

        row.SelectedInternal = false;
        foreach (DataGridRow irow in Grid.Rows)
        {
          if (irow.SelectedInternal)
          {
            haveSelected = true;
            break;
          }
        }
        if (!haveSelected)
          selectionType = GridSelectionType.None;
        selectedRowCountObsolete = true;
        OnSelectionChanged(SelectionChangeOperationType.RowDeselected, row);
      }
    }

    public void AddOldStateSelectedRow(bool isSelected)
    {
      oldSelectedState.Add(isSelected);
    }

    public bool DeleteOldStateSelectedRow()
    {
      bool result = oldSelectedState[oldSelectedState.Count - 1];
      oldSelectedState.RemoveAt(oldSelectedState.Count - 1);
      return result;
    }

    public void SetSelectedRow(DataGridRow row)
    {
      CheckClear();
      SetSelectionType(GridSelectionType.Rows);
      row.SelectedInternal = true;
      selectedRowCountObsolete = true;
      OnSelectionChanged(SelectionChangeOperationType.RowSelected, row);
    }

    public void SetSelectedFreeEndCell(GridCoord newFreeEndCell)
    {
      if (SelectionType != GridSelectionType.CellsBox)
      {
        Clear();
        AnchorCell = new GridCoord(Grid.CurrentDataColIndex, Grid.CurrentDataRowIndex);
      }
      if (AnchorCell == FreeEndCell)
        Clear();
      else
      {
        //this.AnchorCell = new GridCoord(Grid.dataColIndex, Grid.DataRow);
        SetSelectionType(GridSelectionType.CellsBox);
        this.FreeEndCell = newFreeEndCell;
        OnSelectionChanged(SelectionChangeOperationType.ComplexChange, null);
      }
    }

    public ReadOnlyCollection<DataGridColumn> GetSelectedColumns()
    {
      return SelectedColumns;
    }

    public void SetSelectedColumns(IEnumerable<DataGridColumn> selCols)
    {
      Clear();
      foreach (DataGridColumn col in selCols)
        col.Selected = true;
    }

    public void SetSelectedColumns(DataGridColumn[] selCols)
    {
      Clear();
      foreach (DataGridColumn col in selCols)
        col.Selected = true;
    }

    public void SelectAll()
    {
      if (SelectionType != GridSelectionType.All)
        Clear();
      SetSelectionType(GridSelectionType.All);
      OnSelectionChanged(SelectionChangeOperationType.ComplexChange, null);
    }

    public void SelectAllRows()
    {
      BeginUpdate();
      try
      {
        foreach (DataGridRow row in Grid.VisibleRows)
          row.Selected = true;
      }
      finally
      {
        EndUpdate(true);
      }
    }

    public void DeleteSelectedArea()
    {
      switch (SelectionType)
      {
        case GridSelectionType.All:
          {
            try
            {
              Grid.DataLink.CurrencyManager.List.Clear();
            }
            catch (Exception e)
            {
              if (EhLibUtils.IsCriticalException(e))
              {
                throw;
              }
              else
              {
                IList list = Grid.DataLink.CurrencyManager.List;
                while (list.Count > 0)
                {
                  list.RemoveAt(list.Count - 1);
                }
              }
            }
            break;
          }

        case GridSelectionType.CellsBox:
          {
            GridRect selBox = Grid.Selection.SelectedBox;

            for (int rowIndex = selBox.Top; rowIndex <= selBox.Bottom; rowIndex++)
            {
              object rowDesc = Grid.VisibleRows[rowIndex].SourceItem;

              for (int colIndex = selBox.Left; colIndex <= selBox.Right; colIndex++)
              {
                DataGridColumn col = Grid.VisibleColumns[colIndex];
                DeepPropertyDescriptor propDescr = col.PropDescr;
                if (propDescr != null)
                {
                  bool canReset;
                  var rowView = rowDesc as DataRowView;
                  if (rowView != null)
                    canReset = rowView.Row.Table.Columns[propDescr.ButtomPropDescr.Name].AllowDBNull;
                  else
                    canReset = propDescr.ButtomPropDescr.CanResetValue(rowDesc);
                  if (canReset)
                    propDescr.ButtomPropDescr.ResetValue(rowDesc);
                }
              }
            }

            break;
          }

        case GridSelectionType.Columns:
          {
            foreach (DataGridRow row in Grid.VisibleRows)
            {
              object rowDesc = row.SourceItem;
              foreach (DataGridColumn col in Grid.VisibleColumns)
              {
                DeepPropertyDescriptor propDescr = col.PropDescr;
                if (col.Selected && (propDescr != null))
                {
                  bool canReset;
                  var rowView = rowDesc as DataRowView;
                  if (rowView != null)
                    canReset = rowView.Row.Table.Columns[propDescr.ButtomPropDescr.Name].AllowDBNull;
                  else
                    canReset = propDescr.ButtomPropDescr.CanResetValue(rowDesc);
                  if (canReset)
                    propDescr.ButtomPropDescr.ResetValue(rowDesc);
                }
              }
            }
            break;
          }

        case GridSelectionType.Rows:
          {
            List<object> rowsDescForDel = new List<object>();
            IList list = Grid.DataLink.CurrencyManager.List;

            foreach (DataGridRow row in Grid.VisibleRows)
            {
              if (row.Selected)
                rowsDescForDel.Add(row.SourceItem);
            }

            foreach (object rowDesc in rowsDescForDel)
              list.Remove(rowDesc);

            break;
          }

        case GridSelectionType.None:
          {
            if (Grid.VisibleColumns.Count == 0 || Grid.CurrentRow == null)
              break;
            //object rowDesc = Grid.CurrentRow.SourceItem;
            DataGridColumn col = Grid.VisibleColumns[Grid.CurrentColumnIndex];
            Grid.SafePushValue(col, null);

            break;
          }
      }
    }

    public void StopSelectionState()
    {
      selectionState = DataGridSelectionState.None;
      AnchorDataRowIndex = -1;
      FreeEndDataRowIndex = -1;
      oldSelectedState.Clear();
    }
    #endregion public methods
  }

  /// <summary>
  /// Contains a list of logical properties indicating which selection operations are available in the grid.
  /// </summary>
  /// <remarks>
  /// You can retrieve an instance of this class through the <see cref="DataGridSelection.AllowedSelection"/> property.
  /// </remarks>
  [TypeConverter(typeof(ExpandableObjectConverter))]
  public class GridAllowedSelections
  {
    #region privates
    #endregion

    public GridAllowedSelections(DataGridSelection dataGridSelection)
    {
      this.DataGridSelection = dataGridSelection;
      Rows = true;
      Cells = true;
      Columns = true;
      All = true;
    }

    #region properties
    /// <summary>
    ///  Gets the DataGridSelection class associated with this object.
    /// </summary>
    [Browsable(false)]
    public DataGridSelection DataGridSelection { get; private set; }

    /// <summary>
    ///  Gets or sets a value indicating whether the user can select rows in the grid.
    /// </summary>
    [DefaultValue(true)]
    public bool Rows { get; set; }

    /// <summary>
    ///  Gets or sets a value indicating whether the user can select rectangular area of cells in the grid.
    /// </summary>
    [DefaultValue(true)]
    public bool Cells { get; set; }

    /// <summary>
    ///  Gets or sets a value indicating whether the user can select columns in the grid.
    /// </summary>
    [DefaultValue(true)]
    public bool Columns { get; set; }

    /// <summary>
    ///  Gets or sets a value indicating whether the user can select whole the grid.
    /// </summary>
    /// <remarks>
    /// Usually the user selects the entire grid by clicking on the upper left cell of the grid.
    /// </remarks>
    [DefaultValue(true)]
    public bool All { get; set; }
    #endregion

    public void SetAllowedSelections(bool rows, bool cells, bool columns, bool all)
    {
      Rows = rows;
      Cells = cells;
      Columns = columns;
      All = all;
    }
  }
}