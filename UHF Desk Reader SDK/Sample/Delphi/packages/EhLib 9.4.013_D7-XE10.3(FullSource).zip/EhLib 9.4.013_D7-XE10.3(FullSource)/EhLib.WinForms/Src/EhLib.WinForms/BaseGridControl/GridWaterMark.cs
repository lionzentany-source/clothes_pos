﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  static class GridWaterMark
  {
    internal static bool Visible { get; set; }

    static GridWaterMark()
    {
      Visible = false;
    }

    internal static void PaintWaterMark(Graphics g, Control control, Point point)
    {
      if (!Visible) return;
      // TODO: Postpone. 
    }

  }
}
