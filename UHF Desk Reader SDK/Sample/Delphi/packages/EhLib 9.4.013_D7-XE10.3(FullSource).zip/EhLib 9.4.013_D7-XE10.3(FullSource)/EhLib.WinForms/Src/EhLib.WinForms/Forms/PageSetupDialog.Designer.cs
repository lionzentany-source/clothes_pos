﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

namespace EhLib.WinForms
{
  partial class PageSetupDialog
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.bOk = new System.Windows.Forms.Button();
      this.bCancel = new System.Windows.Forms.Button();
      this.tcPageSetup = new System.Windows.Forms.TabControl();
      this.tpPage = new System.Windows.Forms.TabPage();
      this.panel1 = new System.Windows.Forms.Panel();
      this.rbLandscape = new System.Windows.Forms.RadioButton();
      this.rbPortrait = new System.Windows.Forms.RadioButton();
      this.pictureBox2 = new System.Windows.Forms.PictureBox();
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.lTall = new System.Windows.Forms.Label();
      this.lPagesWideBy = new System.Windows.Forms.Label();
      this.nudFitToTall = new System.Windows.Forms.NumericUpDown();
      this.nudFitToWide = new System.Windows.Forms.NumericUpDown();
      this.rbFitTo = new System.Windows.Forms.RadioButton();
      this.nudUpDownScale = new System.Windows.Forms.NumericUpDown();
      this.lPercentNormalSize = new System.Windows.Forms.Label();
      this.rbAdjustTo = new System.Windows.Forms.RadioButton();
      this.bevelControl2 = new EhLib.WinForms.BevelControl();
      this.lScaling = new System.Windows.Forms.Label();
      this.bevelControl1 = new EhLib.WinForms.BevelControl();
      this.lOrientation = new System.Windows.Forms.Label();
      this.tpMargins = new System.Windows.Forms.TabPage();
      this.lMarginsFooter = new System.Windows.Forms.Label();
      this.nudMarginsFooter = new System.Windows.Forms.NumericUpDown();
      this.lMarginsHeader = new System.Windows.Forms.Label();
      this.nudMarginsHeader = new System.Windows.Forms.NumericUpDown();
      this.lMarginsBottom = new System.Windows.Forms.Label();
      this.nudMarginsBottom = new System.Windows.Forms.NumericUpDown();
      this.lMarignsRight = new System.Windows.Forms.Label();
      this.nudMarginsRight = new System.Windows.Forms.NumericUpDown();
      this.lMarginsLeft = new System.Windows.Forms.Label();
      this.nudMarginsLeft = new System.Windows.Forms.NumericUpDown();
      this.lMarginsTop = new System.Windows.Forms.Label();
      this.nudMarginsTop = new System.Windows.Forms.NumericUpDown();
      this.pictureBox3 = new System.Windows.Forms.PictureBox();
      this.tpHeaderFooter = new System.Windows.Forms.TabPage();
      this.rtbPageFooterRight = new System.Windows.Forms.RichTextBox();
      this.bSetFont = new EhLib.WinForms.ButtonEh();
      this.rtbPageHeaderRight = new System.Windows.Forms.RichTextBox();
      this.lPageFooterRight = new System.Windows.Forms.Label();
      this.lPageFooterCenter = new System.Windows.Forms.Label();
      this.lPageFooterLeft = new System.Windows.Forms.Label();
      this.lPageHeaderRight = new System.Windows.Forms.Label();
      this.lPageHeaderCenter = new System.Windows.Forms.Label();
      this.lPageHeaderLeft = new System.Windows.Forms.Label();
      this.bInsertLongDate = new EhLib.WinForms.ButtonEh();
      this.bInsertTime = new EhLib.WinForms.ButtonEh();
      this.bInsertShortDate = new EhLib.WinForms.ButtonEh();
      this.bInsertDate = new EhLib.WinForms.ButtonEh();
      this.bInsertPages = new EhLib.WinForms.ButtonEh();
      this.bInsertPageNo = new EhLib.WinForms.ButtonEh();
      this.lPageFooter = new System.Windows.Forms.Label();
      this.lPageHeader = new System.Windows.Forms.Label();
      this.bevelControl4 = new EhLib.WinForms.BevelControl();
      this.bevelControl3 = new EhLib.WinForms.BevelControl();
      this.fontDialog1 = new System.Windows.Forms.FontDialog();
      this.rtbPageHeaderCenter = new System.Windows.Forms.RichTextBox();
      this.rtbPageHeaderLeft = new System.Windows.Forms.RichTextBox();
      this.rtbPageFooterCenter = new System.Windows.Forms.RichTextBox();
      this.rtbPageFooterLeft = new System.Windows.Forms.RichTextBox();
      this.tcPageSetup.SuspendLayout();
      this.tpPage.SuspendLayout();
      this.panel1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudFitToTall)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudFitToWide)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudUpDownScale)).BeginInit();
      this.tpMargins.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudMarginsFooter)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudMarginsHeader)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudMarginsBottom)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudMarginsRight)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudMarginsLeft)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudMarginsTop)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
      this.tpHeaderFooter.SuspendLayout();
      this.SuspendLayout();
      // 
      // bOk
      // 
      this.bOk.BackColor = System.Drawing.SystemColors.ButtonFace;
      this.bOk.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.bOk.Location = new System.Drawing.Point(460, 347);
      this.bOk.Name = "bOk";
      this.bOk.Size = new System.Drawing.Size(78, 22);
      this.bOk.TabIndex = 8;
      this.bOk.Text = "OK";
      this.bOk.UseVisualStyleBackColor = false;
      // 
      // bCancel
      // 
      this.bCancel.BackColor = System.Drawing.SystemColors.ButtonFace;
      this.bCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.bCancel.Location = new System.Drawing.Point(546, 347);
      this.bCancel.Name = "bCancel";
      this.bCancel.Size = new System.Drawing.Size(78, 22);
      this.bCancel.TabIndex = 9;
      this.bCancel.Text = "Cancel";
      this.bCancel.UseVisualStyleBackColor = false;
      // 
      // tcPageSetup
      // 
      this.tcPageSetup.Controls.Add(this.tpPage);
      this.tcPageSetup.Controls.Add(this.tpMargins);
      this.tcPageSetup.Controls.Add(this.tpHeaderFooter);
      this.tcPageSetup.Location = new System.Drawing.Point(7, 9);
      this.tcPageSetup.Name = "tcPageSetup";
      this.tcPageSetup.SelectedIndex = 0;
      this.tcPageSetup.Size = new System.Drawing.Size(619, 332);
      this.tcPageSetup.TabIndex = 10;
      // 
      // tpPage
      // 
      this.tpPage.Controls.Add(this.panel1);
      this.tpPage.Controls.Add(this.lTall);
      this.tpPage.Controls.Add(this.lPagesWideBy);
      this.tpPage.Controls.Add(this.nudFitToTall);
      this.tpPage.Controls.Add(this.nudFitToWide);
      this.tpPage.Controls.Add(this.rbFitTo);
      this.tpPage.Controls.Add(this.nudUpDownScale);
      this.tpPage.Controls.Add(this.lPercentNormalSize);
      this.tpPage.Controls.Add(this.rbAdjustTo);
      this.tpPage.Controls.Add(this.bevelControl2);
      this.tpPage.Controls.Add(this.lScaling);
      this.tpPage.Controls.Add(this.bevelControl1);
      this.tpPage.Controls.Add(this.lOrientation);
      this.tpPage.Location = new System.Drawing.Point(4, 22);
      this.tpPage.Name = "tpPage";
      this.tpPage.Padding = new System.Windows.Forms.Padding(3);
      this.tpPage.Size = new System.Drawing.Size(611, 306);
      this.tpPage.TabIndex = 0;
      this.tpPage.Text = "Page";
      this.tpPage.UseVisualStyleBackColor = true;
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.rbLandscape);
      this.panel1.Controls.Add(this.rbPortrait);
      this.panel1.Controls.Add(this.pictureBox2);
      this.panel1.Controls.Add(this.pictureBox1);
      this.panel1.Location = new System.Drawing.Point(19, 32);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(466, 87);
      this.panel1.TabIndex = 26;
      // 
      // rbLandscape
      // 
      this.rbLandscape.AutoSize = true;
      this.rbLandscape.Location = new System.Drawing.Point(259, 24);
      this.rbLandscape.Name = "rbLandscape";
      this.rbLandscape.Size = new System.Drawing.Size(78, 17);
      this.rbLandscape.TabIndex = 19;
      this.rbLandscape.Text = "Landscape";
      this.rbLandscape.UseVisualStyleBackColor = true;
      // 
      // rbPortrait
      // 
      this.rbPortrait.AutoSize = true;
      this.rbPortrait.Checked = true;
      this.rbPortrait.Location = new System.Drawing.Point(89, 24);
      this.rbPortrait.Name = "rbPortrait";
      this.rbPortrait.Size = new System.Drawing.Size(58, 17);
      this.rbPortrait.TabIndex = 18;
      this.rbPortrait.TabStop = true;
      this.rbPortrait.Text = "Portrait";
      this.rbPortrait.UseVisualStyleBackColor = true;
      // 
      // pictureBox2
      // 
      this.pictureBox2.Image = global::EhLib.WinForms.Properties.Resources.PageLandscape;
      this.pictureBox2.Location = new System.Drawing.Point(203, 21);
      this.pictureBox2.Name = "pictureBox2";
      this.pictureBox2.Size = new System.Drawing.Size(50, 50);
      this.pictureBox2.TabIndex = 17;
      this.pictureBox2.TabStop = false;
      // 
      // pictureBox1
      // 
      this.pictureBox1.Image = global::EhLib.WinForms.Properties.Resources.PagePortrait;
      this.pictureBox1.Location = new System.Drawing.Point(38, 16);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new System.Drawing.Size(50, 50);
      this.pictureBox1.TabIndex = 16;
      this.pictureBox1.TabStop = false;
      // 
      // lTall
      // 
      this.lTall.AutoSize = true;
      this.lTall.Location = new System.Drawing.Point(353, 212);
      this.lTall.Name = "lTall";
      this.lTall.Size = new System.Drawing.Size(20, 13);
      this.lTall.TabIndex = 25;
      this.lTall.Text = "tall";
      // 
      // lPagesWideBy
      // 
      this.lPagesWideBy.AutoSize = true;
      this.lPagesWideBy.Location = new System.Drawing.Point(204, 212);
      this.lPagesWideBy.Name = "lPagesWideBy";
      this.lPagesWideBy.Size = new System.Drawing.Size(81, 13);
      this.lPagesWideBy.TabIndex = 24;
      this.lPagesWideBy.Text = "page(s) wide by";
      // 
      // nudFitToTall
      // 
      this.nudFitToTall.Location = new System.Drawing.Point(292, 209);
      this.nudFitToTall.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
      this.nudFitToTall.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.nudFitToTall.Name = "nudFitToTall";
      this.nudFitToTall.Size = new System.Drawing.Size(56, 20);
      this.nudFitToTall.TabIndex = 23;
      this.nudFitToTall.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // nudFitToWide
      // 
      this.nudFitToWide.Location = new System.Drawing.Point(142, 209);
      this.nudFitToWide.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
      this.nudFitToWide.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.nudFitToWide.Name = "nudFitToWide";
      this.nudFitToWide.Size = new System.Drawing.Size(56, 20);
      this.nudFitToWide.TabIndex = 22;
      this.nudFitToWide.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // rbFitTo
      // 
      this.rbFitTo.AutoSize = true;
      this.rbFitTo.Location = new System.Drawing.Point(88, 210);
      this.rbFitTo.Name = "rbFitTo";
      this.rbFitTo.Size = new System.Drawing.Size(48, 17);
      this.rbFitTo.TabIndex = 21;
      this.rbFitTo.TabStop = true;
      this.rbFitTo.Text = "Fit to";
      this.rbFitTo.UseVisualStyleBackColor = true;
      // 
      // nudUpDownScale
      // 
      this.nudUpDownScale.Location = new System.Drawing.Point(160, 169);
      this.nudUpDownScale.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
      this.nudUpDownScale.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.nudUpDownScale.Name = "nudUpDownScale";
      this.nudUpDownScale.Size = new System.Drawing.Size(56, 20);
      this.nudUpDownScale.TabIndex = 20;
      this.nudUpDownScale.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // lPercentNormalSize
      // 
      this.lPercentNormalSize.AutoSize = true;
      this.lPercentNormalSize.Location = new System.Drawing.Point(224, 171);
      this.lPercentNormalSize.Name = "lPercentNormalSize";
      this.lPercentNormalSize.Size = new System.Drawing.Size(70, 13);
      this.lPercentNormalSize.TabIndex = 19;
      this.lPercentNormalSize.Text = "% normal size";
      // 
      // rbAdjustTo
      // 
      this.rbAdjustTo.AutoSize = true;
      this.rbAdjustTo.Location = new System.Drawing.Point(88, 171);
      this.rbAdjustTo.Name = "rbAdjustTo";
      this.rbAdjustTo.Size = new System.Drawing.Size(66, 17);
      this.rbAdjustTo.TabIndex = 18;
      this.rbAdjustTo.TabStop = true;
      this.rbAdjustTo.Text = "Adjust to";
      this.rbAdjustTo.UseVisualStyleBackColor = true;
      // 
      // bevelControl2
      // 
      this.bevelControl2.BevelStyle = EhLib.WinForms.BevelStyle.Lowered;
      this.bevelControl2.BevelType = EhLib.WinForms.BevelType.Box;
      this.bevelControl2.HighlightColor = System.Drawing.SystemColors.ButtonHighlight;
      this.bevelControl2.Location = new System.Drawing.Point(105, 133);
      this.bevelControl2.Name = "bevelControl2";
      this.bevelControl2.ShadowColor = System.Drawing.SystemColors.ButtonShadow;
      this.bevelControl2.Size = new System.Drawing.Size(490, 2);
      this.bevelControl2.TabIndex = 17;
      this.bevelControl2.Text = "bevelControl2";
      // 
      // lScaling
      // 
      this.lScaling.AutoSize = true;
      this.lScaling.Location = new System.Drawing.Point(16, 126);
      this.lScaling.Name = "lScaling";
      this.lScaling.Size = new System.Drawing.Size(42, 13);
      this.lScaling.TabIndex = 16;
      this.lScaling.Text = "Scaling";
      // 
      // bevelControl1
      // 
      this.bevelControl1.BevelStyle = EhLib.WinForms.BevelStyle.Lowered;
      this.bevelControl1.BevelType = EhLib.WinForms.BevelType.Box;
      this.bevelControl1.HighlightColor = System.Drawing.SystemColors.ButtonHighlight;
      this.bevelControl1.Location = new System.Drawing.Point(105, 23);
      this.bevelControl1.Name = "bevelControl1";
      this.bevelControl1.ShadowColor = System.Drawing.SystemColors.ButtonShadow;
      this.bevelControl1.Size = new System.Drawing.Size(490, 2);
      this.bevelControl1.TabIndex = 11;
      this.bevelControl1.Text = "bevelControl1";
      // 
      // lOrientation
      // 
      this.lOrientation.AutoSize = true;
      this.lOrientation.Location = new System.Drawing.Point(16, 16);
      this.lOrientation.Name = "lOrientation";
      this.lOrientation.Size = new System.Drawing.Size(58, 13);
      this.lOrientation.TabIndex = 0;
      this.lOrientation.Text = "Orientation";
      // 
      // tpMargins
      // 
      this.tpMargins.Controls.Add(this.lMarginsFooter);
      this.tpMargins.Controls.Add(this.nudMarginsFooter);
      this.tpMargins.Controls.Add(this.lMarginsHeader);
      this.tpMargins.Controls.Add(this.nudMarginsHeader);
      this.tpMargins.Controls.Add(this.lMarginsBottom);
      this.tpMargins.Controls.Add(this.nudMarginsBottom);
      this.tpMargins.Controls.Add(this.lMarignsRight);
      this.tpMargins.Controls.Add(this.nudMarginsRight);
      this.tpMargins.Controls.Add(this.lMarginsLeft);
      this.tpMargins.Controls.Add(this.nudMarginsLeft);
      this.tpMargins.Controls.Add(this.lMarginsTop);
      this.tpMargins.Controls.Add(this.nudMarginsTop);
      this.tpMargins.Controls.Add(this.pictureBox3);
      this.tpMargins.Location = new System.Drawing.Point(4, 22);
      this.tpMargins.Name = "tpMargins";
      this.tpMargins.Padding = new System.Windows.Forms.Padding(3);
      this.tpMargins.Size = new System.Drawing.Size(611, 306);
      this.tpMargins.TabIndex = 1;
      this.tpMargins.Text = "Margins";
      this.tpMargins.UseVisualStyleBackColor = true;
      // 
      // lMarginsFooter
      // 
      this.lMarginsFooter.AutoSize = true;
      this.lMarginsFooter.Location = new System.Drawing.Point(213, 197);
      this.lMarginsFooter.Name = "lMarginsFooter";
      this.lMarginsFooter.Size = new System.Drawing.Size(37, 13);
      this.lMarginsFooter.TabIndex = 32;
      this.lMarginsFooter.Text = "Footer";
      // 
      // nudMarginsFooter
      // 
      this.nudMarginsFooter.DecimalPlaces = 2;
      this.nudMarginsFooter.Location = new System.Drawing.Point(216, 213);
      this.nudMarginsFooter.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
      this.nudMarginsFooter.Name = "nudMarginsFooter";
      this.nudMarginsFooter.Size = new System.Drawing.Size(56, 20);
      this.nudMarginsFooter.TabIndex = 31;
      this.nudMarginsFooter.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // lMarginsHeader
      // 
      this.lMarginsHeader.AutoSize = true;
      this.lMarginsHeader.Location = new System.Drawing.Point(213, 9);
      this.lMarginsHeader.Name = "lMarginsHeader";
      this.lMarginsHeader.Size = new System.Drawing.Size(42, 13);
      this.lMarginsHeader.TabIndex = 30;
      this.lMarginsHeader.Text = "Header";
      // 
      // nudMarginsHeader
      // 
      this.nudMarginsHeader.DecimalPlaces = 2;
      this.nudMarginsHeader.Location = new System.Drawing.Point(216, 25);
      this.nudMarginsHeader.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
      this.nudMarginsHeader.Name = "nudMarginsHeader";
      this.nudMarginsHeader.Size = new System.Drawing.Size(56, 20);
      this.nudMarginsHeader.TabIndex = 29;
      this.nudMarginsHeader.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // lMarginsBottom
      // 
      this.lMarginsBottom.AutoSize = true;
      this.lMarginsBottom.Location = new System.Drawing.Point(120, 197);
      this.lMarginsBottom.Name = "lMarginsBottom";
      this.lMarginsBottom.Size = new System.Drawing.Size(26, 13);
      this.lMarginsBottom.TabIndex = 28;
      this.lMarginsBottom.Text = "Top";
      // 
      // nudMarginsBottom
      // 
      this.nudMarginsBottom.DecimalPlaces = 2;
      this.nudMarginsBottom.Location = new System.Drawing.Point(123, 213);
      this.nudMarginsBottom.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
      this.nudMarginsBottom.Name = "nudMarginsBottom";
      this.nudMarginsBottom.Size = new System.Drawing.Size(56, 20);
      this.nudMarginsBottom.TabIndex = 27;
      this.nudMarginsBottom.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // lMarignsRight
      // 
      this.lMarignsRight.AutoSize = true;
      this.lMarignsRight.Location = new System.Drawing.Point(213, 78);
      this.lMarignsRight.Name = "lMarignsRight";
      this.lMarignsRight.Size = new System.Drawing.Size(32, 13);
      this.lMarignsRight.TabIndex = 26;
      this.lMarignsRight.Text = "Right";
      // 
      // nudMarginsRight
      // 
      this.nudMarginsRight.DecimalPlaces = 2;
      this.nudMarginsRight.Location = new System.Drawing.Point(216, 94);
      this.nudMarginsRight.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
      this.nudMarginsRight.Name = "nudMarginsRight";
      this.nudMarginsRight.Size = new System.Drawing.Size(56, 20);
      this.nudMarginsRight.TabIndex = 25;
      this.nudMarginsRight.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // lMarginsLeft
      // 
      this.lMarginsLeft.AutoSize = true;
      this.lMarginsLeft.Location = new System.Drawing.Point(38, 78);
      this.lMarginsLeft.Name = "lMarginsLeft";
      this.lMarginsLeft.Size = new System.Drawing.Size(25, 13);
      this.lMarginsLeft.TabIndex = 24;
      this.lMarginsLeft.Text = "Left";
      // 
      // nudMarginsLeft
      // 
      this.nudMarginsLeft.DecimalPlaces = 2;
      this.nudMarginsLeft.Location = new System.Drawing.Point(41, 94);
      this.nudMarginsLeft.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
      this.nudMarginsLeft.Name = "nudMarginsLeft";
      this.nudMarginsLeft.Size = new System.Drawing.Size(56, 20);
      this.nudMarginsLeft.TabIndex = 23;
      this.nudMarginsLeft.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // lMarginsTop
      // 
      this.lMarginsTop.AutoSize = true;
      this.lMarginsTop.Location = new System.Drawing.Point(120, 9);
      this.lMarginsTop.Name = "lMarginsTop";
      this.lMarginsTop.Size = new System.Drawing.Size(26, 13);
      this.lMarginsTop.TabIndex = 22;
      this.lMarginsTop.Text = "Top";
      // 
      // nudMarginsTop
      // 
      this.nudMarginsTop.DecimalPlaces = 2;
      this.nudMarginsTop.Location = new System.Drawing.Point(123, 25);
      this.nudMarginsTop.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
      this.nudMarginsTop.Name = "nudMarginsTop";
      this.nudMarginsTop.Size = new System.Drawing.Size(56, 20);
      this.nudMarginsTop.TabIndex = 21;
      this.nudMarginsTop.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      // 
      // pictureBox3
      // 
      this.pictureBox3.Image = global::EhLib.WinForms.Properties.Resources.PageMargins;
      this.pictureBox3.Location = new System.Drawing.Point(103, 51);
      this.pictureBox3.Name = "pictureBox3";
      this.pictureBox3.Size = new System.Drawing.Size(107, 141);
      this.pictureBox3.TabIndex = 13;
      this.pictureBox3.TabStop = false;
      // 
      // tpHeaderFooter
      // 
      this.tpHeaderFooter.Controls.Add(this.rtbPageFooterLeft);
      this.tpHeaderFooter.Controls.Add(this.rtbPageFooterCenter);
      this.tpHeaderFooter.Controls.Add(this.rtbPageHeaderLeft);
      this.tpHeaderFooter.Controls.Add(this.rtbPageHeaderCenter);
      this.tpHeaderFooter.Controls.Add(this.rtbPageFooterRight);
      this.tpHeaderFooter.Controls.Add(this.bSetFont);
      this.tpHeaderFooter.Controls.Add(this.rtbPageHeaderRight);
      this.tpHeaderFooter.Controls.Add(this.lPageFooterRight);
      this.tpHeaderFooter.Controls.Add(this.lPageFooterCenter);
      this.tpHeaderFooter.Controls.Add(this.lPageFooterLeft);
      this.tpHeaderFooter.Controls.Add(this.lPageHeaderRight);
      this.tpHeaderFooter.Controls.Add(this.lPageHeaderCenter);
      this.tpHeaderFooter.Controls.Add(this.lPageHeaderLeft);
      this.tpHeaderFooter.Controls.Add(this.bInsertLongDate);
      this.tpHeaderFooter.Controls.Add(this.bInsertTime);
      this.tpHeaderFooter.Controls.Add(this.bInsertShortDate);
      this.tpHeaderFooter.Controls.Add(this.bInsertDate);
      this.tpHeaderFooter.Controls.Add(this.bInsertPages);
      this.tpHeaderFooter.Controls.Add(this.bInsertPageNo);
      this.tpHeaderFooter.Controls.Add(this.lPageFooter);
      this.tpHeaderFooter.Controls.Add(this.lPageHeader);
      this.tpHeaderFooter.Controls.Add(this.bevelControl4);
      this.tpHeaderFooter.Controls.Add(this.bevelControl3);
      this.tpHeaderFooter.Location = new System.Drawing.Point(4, 22);
      this.tpHeaderFooter.Name = "tpHeaderFooter";
      this.tpHeaderFooter.Padding = new System.Windows.Forms.Padding(3);
      this.tpHeaderFooter.Size = new System.Drawing.Size(611, 306);
      this.tpHeaderFooter.TabIndex = 2;
      this.tpHeaderFooter.Text = "Header/Footer";
      this.tpHeaderFooter.UseVisualStyleBackColor = true;
      // 
      // rtbPageFooterRight
      // 
      this.rtbPageFooterRight.Location = new System.Drawing.Point(412, 219);
      this.rtbPageFooterRight.Name = "rtbPageFooterRight";
      this.rtbPageFooterRight.Size = new System.Drawing.Size(180, 64);
      this.rtbPageFooterRight.TabIndex = 36;
      this.rtbPageFooterRight.Text = "";
      // 
      // bSetFont
      // 
      this.bSetFont.Focusable = false;
      this.bSetFont.Location = new System.Drawing.Point(21, 16);
      this.bSetFont.Name = "bSetFont";
      this.bSetFont.Size = new System.Drawing.Size(32, 32);
      this.bSetFont.TabIndex = 35;
      this.bSetFont.Text = "Fnt";
      this.bSetFont.UseVisualStyleBackColor = true;
      this.bSetFont.Click += new System.EventHandler(this.bSetFont_Click);
      // 
      // rtbPageHeaderRight
      // 
      this.rtbPageHeaderRight.Location = new System.Drawing.Point(412, 100);
      this.rtbPageHeaderRight.Name = "rtbPageHeaderRight";
      this.rtbPageHeaderRight.Size = new System.Drawing.Size(180, 66);
      this.rtbPageHeaderRight.TabIndex = 34;
      this.rtbPageHeaderRight.Text = "";
      // 
      // lPageFooterRight
      // 
      this.lPageFooterRight.AutoSize = true;
      this.lPageFooterRight.Location = new System.Drawing.Point(409, 202);
      this.lPageFooterRight.Name = "lPageFooterRight";
      this.lPageFooterRight.Size = new System.Drawing.Size(32, 13);
      this.lPageFooterRight.TabIndex = 33;
      this.lPageFooterRight.Text = "Right";
      // 
      // lPageFooterCenter
      // 
      this.lPageFooterCenter.AutoSize = true;
      this.lPageFooterCenter.Location = new System.Drawing.Point(213, 202);
      this.lPageFooterCenter.Name = "lPageFooterCenter";
      this.lPageFooterCenter.Size = new System.Drawing.Size(38, 13);
      this.lPageFooterCenter.TabIndex = 32;
      this.lPageFooterCenter.Text = "Center";
      // 
      // lPageFooterLeft
      // 
      this.lPageFooterLeft.AutoSize = true;
      this.lPageFooterLeft.Location = new System.Drawing.Point(18, 202);
      this.lPageFooterLeft.Name = "lPageFooterLeft";
      this.lPageFooterLeft.Size = new System.Drawing.Size(25, 13);
      this.lPageFooterLeft.TabIndex = 31;
      this.lPageFooterLeft.Text = "Left";
      // 
      // lPageHeaderRight
      // 
      this.lPageHeaderRight.AutoSize = true;
      this.lPageHeaderRight.Location = new System.Drawing.Point(409, 84);
      this.lPageHeaderRight.Name = "lPageHeaderRight";
      this.lPageHeaderRight.Size = new System.Drawing.Size(32, 13);
      this.lPageHeaderRight.TabIndex = 27;
      this.lPageHeaderRight.Text = "Right";
      // 
      // lPageHeaderCenter
      // 
      this.lPageHeaderCenter.AutoSize = true;
      this.lPageHeaderCenter.Location = new System.Drawing.Point(213, 84);
      this.lPageHeaderCenter.Name = "lPageHeaderCenter";
      this.lPageHeaderCenter.Size = new System.Drawing.Size(38, 13);
      this.lPageHeaderCenter.TabIndex = 26;
      this.lPageHeaderCenter.Text = "Center";
      // 
      // lPageHeaderLeft
      // 
      this.lPageHeaderLeft.AutoSize = true;
      this.lPageHeaderLeft.Location = new System.Drawing.Point(18, 84);
      this.lPageHeaderLeft.Name = "lPageHeaderLeft";
      this.lPageHeaderLeft.Size = new System.Drawing.Size(25, 13);
      this.lPageHeaderLeft.TabIndex = 25;
      this.lPageHeaderLeft.Text = "Left";
      // 
      // bInsertLongDate
      // 
      this.bInsertLongDate.Focusable = false;
      this.bInsertLongDate.Location = new System.Drawing.Point(317, 16);
      this.bInsertLongDate.Name = "bInsertLongDate";
      this.bInsertLongDate.Size = new System.Drawing.Size(32, 32);
      this.bInsertLongDate.TabIndex = 21;
      this.bInsertLongDate.Text = "Ps";
      this.bInsertLongDate.UseVisualStyleBackColor = true;
      this.bInsertLongDate.Click += new System.EventHandler(this.bInsertLongDate_Click);
      // 
      // bInsertTime
      // 
      this.bInsertTime.Focusable = false;
      this.bInsertTime.Location = new System.Drawing.Point(355, 16);
      this.bInsertTime.Name = "bInsertTime";
      this.bInsertTime.Size = new System.Drawing.Size(32, 32);
      this.bInsertTime.TabIndex = 20;
      this.bInsertTime.Text = "T";
      this.bInsertTime.UseVisualStyleBackColor = true;
      this.bInsertTime.Click += new System.EventHandler(this.bInsertTime_Click);
      // 
      // bInsertShortDate
      // 
      this.bInsertShortDate.Focusable = false;
      this.bInsertShortDate.Location = new System.Drawing.Point(279, 16);
      this.bInsertShortDate.Name = "bInsertShortDate";
      this.bInsertShortDate.Size = new System.Drawing.Size(32, 32);
      this.bInsertShortDate.TabIndex = 19;
      this.bInsertShortDate.Text = "Ds";
      this.bInsertShortDate.UseVisualStyleBackColor = true;
      this.bInsertShortDate.Click += new System.EventHandler(this.bInsertShortDate_Click);
      // 
      // bInsertDate
      // 
      this.bInsertDate.Focusable = false;
      this.bInsertDate.Location = new System.Drawing.Point(241, 16);
      this.bInsertDate.Name = "bInsertDate";
      this.bInsertDate.Size = new System.Drawing.Size(32, 32);
      this.bInsertDate.TabIndex = 18;
      this.bInsertDate.Text = "D";
      this.bInsertDate.UseVisualStyleBackColor = true;
      this.bInsertDate.Click += new System.EventHandler(this.bInsertDate_Click);
      // 
      // bInsertPages
      // 
      this.bInsertPages.Focusable = false;
      this.bInsertPages.Location = new System.Drawing.Point(143, 16);
      this.bInsertPages.Name = "bInsertPages";
      this.bInsertPages.Size = new System.Drawing.Size(32, 32);
      this.bInsertPages.TabIndex = 17;
      this.bInsertPages.Text = "Ps";
      this.bInsertPages.UseVisualStyleBackColor = true;
      this.bInsertPages.Click += new System.EventHandler(this.bInsertPages_Click);
      // 
      // bInsertPageNo
      // 
      this.bInsertPageNo.Focusable = false;
      this.bInsertPageNo.Location = new System.Drawing.Point(105, 16);
      this.bInsertPageNo.Name = "bInsertPageNo";
      this.bInsertPageNo.Size = new System.Drawing.Size(32, 32);
      this.bInsertPageNo.TabIndex = 16;
      this.bInsertPageNo.Text = "Pn";
      this.bInsertPageNo.UseVisualStyleBackColor = true;
      this.bInsertPageNo.Click += new System.EventHandler(this.bInsertPageNo_Click);
      // 
      // lPageFooter
      // 
      this.lPageFooter.AutoSize = true;
      this.lPageFooter.Location = new System.Drawing.Point(16, 182);
      this.lPageFooter.Name = "lPageFooter";
      this.lPageFooter.Size = new System.Drawing.Size(62, 13);
      this.lPageFooter.TabIndex = 14;
      this.lPageFooter.Text = "Page footer";
      // 
      // lPageHeader
      // 
      this.lPageHeader.AutoSize = true;
      this.lPageHeader.Location = new System.Drawing.Point(16, 59);
      this.lPageHeader.Name = "lPageHeader";
      this.lPageHeader.Size = new System.Drawing.Size(68, 13);
      this.lPageHeader.TabIndex = 12;
      this.lPageHeader.Text = "Page header";
      // 
      // bevelControl4
      // 
      this.bevelControl4.BevelStyle = EhLib.WinForms.BevelStyle.Lowered;
      this.bevelControl4.BevelType = EhLib.WinForms.BevelType.Box;
      this.bevelControl4.HighlightColor = System.Drawing.SystemColors.ButtonHighlight;
      this.bevelControl4.Location = new System.Drawing.Point(105, 189);
      this.bevelControl4.Name = "bevelControl4";
      this.bevelControl4.ShadowColor = System.Drawing.SystemColors.ButtonShadow;
      this.bevelControl4.Size = new System.Drawing.Size(490, 2);
      this.bevelControl4.TabIndex = 15;
      this.bevelControl4.Text = "bevelControl4";
      // 
      // bevelControl3
      // 
      this.bevelControl3.BevelStyle = EhLib.WinForms.BevelStyle.Lowered;
      this.bevelControl3.BevelType = EhLib.WinForms.BevelType.Box;
      this.bevelControl3.HighlightColor = System.Drawing.SystemColors.ButtonHighlight;
      this.bevelControl3.Location = new System.Drawing.Point(105, 66);
      this.bevelControl3.Name = "bevelControl3";
      this.bevelControl3.ShadowColor = System.Drawing.SystemColors.ButtonShadow;
      this.bevelControl3.Size = new System.Drawing.Size(490, 2);
      this.bevelControl3.TabIndex = 13;
      this.bevelControl3.Text = "bevelControl3";
      // 
      // rtbPageHeaderCenter
      // 
      this.rtbPageHeaderCenter.Location = new System.Drawing.Point(216, 100);
      this.rtbPageHeaderCenter.Name = "rtbPageHeaderCenter";
      this.rtbPageHeaderCenter.Size = new System.Drawing.Size(180, 66);
      this.rtbPageHeaderCenter.TabIndex = 37;
      this.rtbPageHeaderCenter.Text = "";
      // 
      // rtbPageHeaderLeft
      // 
      this.rtbPageHeaderLeft.Location = new System.Drawing.Point(19, 100);
      this.rtbPageHeaderLeft.Name = "rtbPageHeaderLeft";
      this.rtbPageHeaderLeft.Size = new System.Drawing.Size(180, 66);
      this.rtbPageHeaderLeft.TabIndex = 38;
      this.rtbPageHeaderLeft.Text = "";
      // 
      // rtbPageFooterCenter
      // 
      this.rtbPageFooterCenter.Location = new System.Drawing.Point(216, 219);
      this.rtbPageFooterCenter.Name = "rtbPageFooterCenter";
      this.rtbPageFooterCenter.Size = new System.Drawing.Size(180, 64);
      this.rtbPageFooterCenter.TabIndex = 39;
      this.rtbPageFooterCenter.Text = "";
      // 
      // rtbPageFooterLeft
      // 
      this.rtbPageFooterLeft.Location = new System.Drawing.Point(21, 218);
      this.rtbPageFooterLeft.Name = "rtbPageFooterLeft";
      this.rtbPageFooterLeft.Size = new System.Drawing.Size(180, 64);
      this.rtbPageFooterLeft.TabIndex = 40;
      this.rtbPageFooterLeft.Text = "";
      // 
      // PageSetupDialog
      // 
      this.AcceptButton = this.bOk;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.CancelButton = this.bCancel;
      this.ClientSize = new System.Drawing.Size(633, 379);
      this.Controls.Add(this.tcPageSetup);
      this.Controls.Add(this.bOk);
      this.Controls.Add(this.bCancel);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Name = "PageSetupDialog";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Page setup";
      this.tcPageSetup.ResumeLayout(false);
      this.tpPage.ResumeLayout(false);
      this.tpPage.PerformLayout();
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudFitToTall)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudFitToWide)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudUpDownScale)).EndInit();
      this.tpMargins.ResumeLayout(false);
      this.tpMargins.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.nudMarginsFooter)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudMarginsHeader)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudMarginsBottom)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudMarginsRight)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudMarginsLeft)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudMarginsTop)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
      this.tpHeaderFooter.ResumeLayout(false);
      this.tpHeaderFooter.PerformLayout();
      this.ResumeLayout(false);

    }

    #endregion

    public System.Windows.Forms.Button bOk;
    public System.Windows.Forms.Button bCancel;
    private System.Windows.Forms.TabControl tcPageSetup;
    private System.Windows.Forms.TabPage tpPage;
    private System.Windows.Forms.Label lOrientation;
    private System.Windows.Forms.TabPage tpMargins;
    private System.Windows.Forms.TabPage tpHeaderFooter;
    private BevelControl bevelControl1;
    private System.Windows.Forms.Label lTall;
    private System.Windows.Forms.Label lPagesWideBy;
    private System.Windows.Forms.NumericUpDown nudFitToTall;
    private System.Windows.Forms.NumericUpDown nudFitToWide;
    private System.Windows.Forms.RadioButton rbFitTo;
    private System.Windows.Forms.NumericUpDown nudUpDownScale;
    private System.Windows.Forms.Label lPercentNormalSize;
    private System.Windows.Forms.RadioButton rbAdjustTo;
    private BevelControl bevelControl2;
    private System.Windows.Forms.Label lScaling;
    private System.Windows.Forms.Label lMarginsFooter;
    private System.Windows.Forms.NumericUpDown nudMarginsFooter;
    private System.Windows.Forms.Label lMarginsHeader;
    private System.Windows.Forms.NumericUpDown nudMarginsHeader;
    private System.Windows.Forms.Label lMarginsBottom;
    private System.Windows.Forms.NumericUpDown nudMarginsBottom;
    private System.Windows.Forms.Label lMarignsRight;
    private System.Windows.Forms.NumericUpDown nudMarginsRight;
    private System.Windows.Forms.Label lMarginsLeft;
    private System.Windows.Forms.NumericUpDown nudMarginsLeft;
    private System.Windows.Forms.Label lMarginsTop;
    private System.Windows.Forms.NumericUpDown nudMarginsTop;
    private System.Windows.Forms.PictureBox pictureBox3;
    private System.Windows.Forms.Label lPageFooterRight;
    private System.Windows.Forms.Label lPageFooterCenter;
    private System.Windows.Forms.Label lPageFooterLeft;
    private System.Windows.Forms.Label lPageHeaderRight;
    private System.Windows.Forms.Label lPageHeaderCenter;
    private System.Windows.Forms.Label lPageHeaderLeft;
    private EhLib.WinForms.ButtonEh bInsertLongDate;
    private EhLib.WinForms.ButtonEh bInsertTime;
    private EhLib.WinForms.ButtonEh bInsertShortDate;
    private EhLib.WinForms.ButtonEh bInsertDate;
    private EhLib.WinForms.ButtonEh bInsertPages;
    private EhLib.WinForms.ButtonEh bInsertPageNo;
    private BevelControl bevelControl4;
    private System.Windows.Forms.Label lPageFooter;
    private BevelControl bevelControl3;
    private System.Windows.Forms.Label lPageHeader;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.RadioButton rbLandscape;
    private System.Windows.Forms.RadioButton rbPortrait;
    private System.Windows.Forms.PictureBox pictureBox2;
    private System.Windows.Forms.PictureBox pictureBox1;
    private ButtonEh bSetFont;
    private System.Windows.Forms.RichTextBox rtbPageHeaderRight;
    private System.Windows.Forms.FontDialog fontDialog1;
    private System.Windows.Forms.RichTextBox rtbPageFooterRight;
    private System.Windows.Forms.RichTextBox rtbPageFooterLeft;
    private System.Windows.Forms.RichTextBox rtbPageFooterCenter;
    private System.Windows.Forms.RichTextBox rtbPageHeaderLeft;
    private System.Windows.Forms.RichTextBox rtbPageHeaderCenter;
  }
}