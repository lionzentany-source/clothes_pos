﻿namespace EhLib.WinForms.Design
{
  partial class DataAxisGridAddBoundBandsDialog
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.bCancel = new System.Windows.Forms.Button();
      this.bOk = new System.Windows.Forms.Button();
      this.AxisBarListBox = new System.Windows.Forms.ListBox();
      this.radioButtonAllColumns = new System.Windows.Forms.RadioButton();
      this.radioButtonNewColumns = new System.Windows.Forms.RadioButton();
      this.textBoxColNameFormat = new EhLib.WinForms.TextBoxEh();
      this.boundLabel1 = new EhLib.WinForms.BoundLabel();
      ((System.ComponentModel.ISupportInitialize)(this.textBoxColNameFormat)).BeginInit();
      this.SuspendLayout();
      // 
      // bCancel
      // 
      this.bCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.bCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.bCancel.Location = new System.Drawing.Point(245, 415);
      this.bCancel.Name = "bCancel";
      this.bCancel.Size = new System.Drawing.Size(75, 23);
      this.bCancel.TabIndex = 0;
      this.bCancel.Text = "Cancel";
      this.bCancel.UseVisualStyleBackColor = true;
      // 
      // bOk
      // 
      this.bOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.bOk.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.bOk.Location = new System.Drawing.Point(160, 415);
      this.bOk.Name = "bOk";
      this.bOk.Size = new System.Drawing.Size(75, 23);
      this.bOk.TabIndex = 1;
      this.bOk.Text = "Ok";
      this.bOk.UseVisualStyleBackColor = true;
      // 
      // AxisBarListBox
      // 
      this.AxisBarListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.AxisBarListBox.FormattingEnabled = true;
      this.AxisBarListBox.Location = new System.Drawing.Point(12, 64);
      this.AxisBarListBox.Name = "AxisBarListBox";
      this.AxisBarListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
      this.AxisBarListBox.Size = new System.Drawing.Size(308, 264);
      this.AxisBarListBox.TabIndex = 2;
      // 
      // radioButtonAllColumns
      // 
      this.radioButtonAllColumns.AutoSize = true;
      this.radioButtonAllColumns.Checked = true;
      this.radioButtonAllColumns.Location = new System.Drawing.Point(12, 12);
      this.radioButtonAllColumns.Name = "radioButtonAllColumns";
      this.radioButtonAllColumns.Size = new System.Drawing.Size(184, 17);
      this.radioButtonAllColumns.TabIndex = 3;
      this.radioButtonAllColumns.TabStop = true;
      this.radioButtonAllColumns.Text = "All Data Properties of DataSource";
      this.radioButtonAllColumns.UseVisualStyleBackColor = true;
      this.radioButtonAllColumns.Click += new System.EventHandler(this.radioButtonAllColumns_Click);
      // 
      // radioButtonNewColumns
      // 
      this.radioButtonNewColumns.AutoSize = true;
      this.radioButtonNewColumns.Location = new System.Drawing.Point(12, 35);
      this.radioButtonNewColumns.Name = "radioButtonNewColumns";
      this.radioButtonNewColumns.Size = new System.Drawing.Size(123, 17);
      this.radioButtonNewColumns.TabIndex = 4;
      this.radioButtonNewColumns.Text = "New Data Properties";
      this.radioButtonNewColumns.UseVisualStyleBackColor = true;
      this.radioButtonNewColumns.Click += new System.EventHandler(this.radioButtonNewColumns_Click);
      // 
      // textBoxColNameFormat
      // 
      this.textBoxColNameFormat.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.textBoxColNameFormat.BoundLabel = this.boundLabel1;
      this.textBoxColNameFormat.Location = new System.Drawing.Point(12, 371);
      this.textBoxColNameFormat.Name = "textBoxColNameFormat";
      this.textBoxColNameFormat.Size = new System.Drawing.Size(307, 20);
      this.textBoxColNameFormat.TabIndex = 5;
      this.textBoxColNameFormat.TabStop = false;
      this.textBoxColNameFormat.Text = "[DataGridName]{DataPropertyName}Column{N}";
      // 
      // boundLabel1
      // 
      this.boundLabel1.AutoSize = true;
      this.boundLabel1.Location = new System.Drawing.Point(12, 342);
      this.boundLabel1.Name = "boundLabel1";
      this.boundLabel1.Size = new System.Drawing.Size(159, 26);
      this.boundLabel1.TabIndex = 6;
      this.boundLabel1.Text = "\r\nColumn name generating format:";
      // 
      // DataAxisGridAddBoundBandsDialog
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(332, 450);
      this.Controls.Add(this.textBoxColNameFormat);
      this.Controls.Add(this.radioButtonNewColumns);
      this.Controls.Add(this.radioButtonAllColumns);
      this.Controls.Add(this.AxisBarListBox);
      this.Controls.Add(this.bOk);
      this.Controls.Add(this.bCancel);
      this.Controls.Add(this.boundLabel1);
      this.Name = "DataAxisGridAddBoundBandsDialog";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "DataGridAddBoundColumnsDialog";
      ((System.ComponentModel.ISupportInitialize)(this.textBoxColNameFormat)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button bCancel;
    private System.Windows.Forms.Button bOk;
    private System.Windows.Forms.ListBox AxisBarListBox;
    private System.Windows.Forms.RadioButton radioButtonAllColumns;
    private System.Windows.Forms.RadioButton radioButtonNewColumns;
    private TextBoxEh textBoxColNameFormat;
    private BoundLabel boundLabel1;
  }
}