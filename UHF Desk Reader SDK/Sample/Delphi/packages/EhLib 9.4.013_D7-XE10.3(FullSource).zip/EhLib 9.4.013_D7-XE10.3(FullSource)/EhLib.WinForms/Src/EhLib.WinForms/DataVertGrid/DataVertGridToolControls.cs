﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace EhLib.WinForms
{
  [AttributeUsage(AttributeTargets.Class)]
  public sealed class DataVertGridRowDesignTimeVisibleAttribute : DesignTimeCollectionEditorItemVisibleAttribute
  {
    public DataVertGridRowDesignTimeVisibleAttribute(bool visible) : base(visible)
    {
    }

    public DataVertGridRowDesignTimeVisibleAttribute()
    {
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2104:DoNotDeclareReadOnlyMutableReferenceTypes")]
    public static readonly DataVertGridRowDesignTimeVisibleAttribute Default = new DataVertGridRowDesignTimeVisibleAttribute(true);
  }

  //[AttributeUsage(AttributeTargets.Class)]
  //public sealed class DataVertGridDataCellDesignTimeVisibleAttribute : DesignTimeCollectionEditorItemVisibleAttribute
  //{
  //  public DataVertGridDataCellDesignTimeVisibleAttribute(bool visible) : base(visible)
  //  {
  //  }

  //  public DataVertGridDataCellDesignTimeVisibleAttribute()
  //  {
  //  }

  //  [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2104:DoNotDeclareReadOnlyMutableReferenceTypes")]
  //  public static readonly DataVertGridDataCellDesignTimeVisibleAttribute Default = new DataVertGridDataCellDesignTimeVisibleAttribute(true);
  //}


  /// <summary>
  /// Collection of extra data cell managers that can be used in DataCellManagerNeeded event handler.
  /// </summary>
  [ListBindable(false)]
  public class DataVertGridServiceCellManagerList : Collection<BaseGridCellManager>
  {
    private readonly DataVertGridEh grid;

    public DataVertGridServiceCellManagerList(DataVertGridEh grid)
    {
      this.grid = grid;
    }

    public new void Add(BaseGridCellManager item)
    {
      base.Add(item);
      item.BoundGrid = grid;
    }
  }

}
