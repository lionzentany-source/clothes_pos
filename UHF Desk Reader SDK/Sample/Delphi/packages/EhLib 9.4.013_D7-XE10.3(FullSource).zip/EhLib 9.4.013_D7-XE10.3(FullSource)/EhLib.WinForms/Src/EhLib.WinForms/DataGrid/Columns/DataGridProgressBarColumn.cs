﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of column in a DataGridEh control that displays progress bar user interface (UI).
  /// </summary>
  [DataGridColumnDesignTimeVisible(true)]
  public class DataGridProgressBarColumn : DataGridColumn
  {

    #region >private consts
    private static readonly object EventKeyDataCellPaint = new object();
    private static readonly object EventKeyDataCellFormatParamsNeeded = new object();
    #endregion <private consts

    #region privates
    #endregion

    #region constructor
    public DataGridProgressBarColumn()
    {

    }
    #endregion

    #region design-time properties
    [DefaultValue(0)]
    public double MinValue
    {
      get
      {
        return DataCell.MinValue;
      }

      set
      {
        DataCell.MinValue = value;
        Invalidate();
      }
    }

    [DefaultValue(100)]
    public double MaxValue
    {
      get
      {
        return DataCell.MaxValue;
      }

      set
      {
        DataCell.MaxValue = value;
        Invalidate();
      }
    }

    //[DefaultValue(Color.Empty)]
    public new Color BackColor
    {
      get
      {
        return DataCell.BackColor;
      }

      set
      {
        DataCell.BackColor = value;
        Invalidate();
      }
    }

    public new Color ForeColor
    {
      get
      {
        return DataCell.ForeColor;
      }

      set
      {
        DataCell.ForeColor = value;
        Invalidate();
      }
    }

    public Color BarFrameColor
    {
      get
      {
        return DataCell.BarFrameColor;
      }

      set
      {
        DataCell.BarFrameColor = value;
        Invalidate();
      }
    }

    public Color BarFillColor
    {
      get
      {
        return DataCell.BarFillColor;
      }

      set
      {
        DataCell.BarFillColor = value;
        Invalidate();
      }
    }

    [DefaultValue(true)]
    public bool ShowText
    {
      get
      {
        return DataCell.ShowText;
      }

      set
      {
        DataCell.ShowText = value;
        Invalidate();
      }
    }

    [DefaultValue(ProgressBarTextType.AsPercent)]
    public ProgressBarTextType TextType
    {
      get
      {
        return DataCell.TextType;
      }

      set
      {
        DataCell.TextType = value;
        Invalidate();
      }
    }

    [DefaultValue(0)]
    public int TextDecimalPlaces
    {
      get
      {
        return DataCell.TextDecimalPlaces;
      }

      set
      {
        DataCell.TextDecimalPlaces = value;
        Invalidate();
      }
    }

    [DefaultValue(false)]
    public new bool AllowShowEditor
    {
      get { return base.AllowShowEditor; }
      set { base.AllowShowEditor = value; }
    }
    #endregion

    #region >events
    /// <summary>
    /// Occurs when a cell in the grid data area needs to be drawn.
    /// </summary>
    public new event EventHandler<DataGridProgressBarDataCellPaintEventArgs> DataCellPaint
    {
      add
      {
        Events.AddHandler(EventKeyDataCellPaint, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellPaint, value);
      }
    }

    /// <summary>
    /// Occurs when a "data" cell paint params like BackColor, Font, etc should be specified.
    /// By default these params are assigned from column properties
    /// </summary>
    public new event EventHandler<DataGridProgressBarDataCellFormatParamsNeededEventArgs> DataCellFormatParamsNeeded
    {
      add
      {
        Events.AddHandler(EventKeyDataCellFormatParamsNeeded, value);
      }
      remove
      {
        Events.RemoveHandler(EventKeyDataCellFormatParamsNeeded, value);
      }
    }
    #endregion <events

    #region run-time properties
    [Browsable(false)]
    public new ProgressBarDataCellManager DataCell
    {
      get { return (ProgressBarDataCellManager)base.InternalCellManager; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public ProgressBarRenderer ProgressBarRenderer
    {
      get
      {
        return DataCell.ProgressBarRenderer;
      }

      set
      {
        DataCell.ProgressBarRenderer = value;
        Invalidate();
      }
    }
    #endregion

    #region public methods
    public override bool DefaultAllowShowEditor()
    {
      return false;
    }
    #endregion

    #region internal methods
    protected override BaseDataCellManager CreateTemplateCell()
    {
      return new ProgressBarDataCellManager();
    }

    //BarFrameColor
    protected internal virtual Color DefaultBarFrameColor()
    {
      return DataCell.DefaultBarFrameColor();
    }

    protected internal virtual bool ShouldSerializeBarFrameColor()
    {
      return DataCell.ShouldSerializeBarFrameColor();
    }

    public virtual void ResetBarFrameColor()
    {
      DataCell.ResetBarFrameColor();
    }

    protected internal void BarFrameColorChanged()
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    //BarFillColor
    public virtual Color DefaultBarFillColor()
    {
      return DataCell.DefaultBarFillColor();
    }

    protected internal virtual bool ShouldSerializeBarFillColor()
    {
      return DataCell.ShouldSerializeBarFillColor();
    }

    public virtual void ResetBarFillColor()
    {
      DataCell.ResetBarFillColor();
    }

    protected internal void BarFillColorChanged()
    {
      if (Grid != null)
        Grid.Invalidate();
    }

    //Other
    protected internal override void HandleDataCellPaintEvent(DataAxisGridDataCellPaintEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellPaint] as EventHandler<DataGridProgressBarDataCellPaintEventArgs>;
      if (eh != null)
      {
        var pbe = e as DataAxisGridProgressBarDataCellPaintEventArgs;
        var ge = new DataGridProgressBarDataCellPaintEventArgs(pbe);
        eh(this, ge);
      }
    }

    protected internal override void HandleFormatParamsNeededEvent(DataAxisGridDataCellFormatParamsNeededEventArgs e)
    {
      var eh = this.Events[EventKeyDataCellFormatParamsNeeded] as EventHandler<DataGridProgressBarDataCellFormatParamsNeededEventArgs>;
      if (eh != null)
      {
        var age = e as DataAxisGridProgressBarDataCellFormatParamsNeededEventArgs;
        var ge = new DataGridProgressBarDataCellFormatParamsNeededEventArgs(age);
        eh(this, ge);
      }
    }
    #endregion
  }

  /// <summary>
  /// Event args for DataCellFormatParamsNeeded event of a DataGridProgressBarColumn control
  /// </summary>
  public class DataGridProgressBarDataCellFormatParamsNeededEventArgs : DataGridDataCellFormatParamsNeededEventArgs
  {
    public DataGridProgressBarDataCellFormatParamsNeededEventArgs(DataAxisGridProgressBarDataCellFormatParamsNeededEventArgs cellEventArgs) : base(cellEventArgs)
    {
      CellArgs = cellEventArgs;
    }

    public new DataAxisGridProgressBarDataCellFormatParamsNeededEventArgs CellArgs { get; internal set; }
  }

  /// <summary>
  /// Event args for DataCellPaint event of a DataGridProgressBarColumn control
  /// </summary>
  public class DataGridProgressBarDataCellPaintEventArgs : DataGridDataCellPaintEventArgs
  {
    public DataGridProgressBarDataCellPaintEventArgs(DataAxisGridProgressBarDataCellPaintEventArgs cellArgs) : base(cellArgs)
    {
      CellArgs = cellArgs;
    }

    public new DataAxisGridProgressBarDataCellPaintEventArgs CellArgs { get; internal set; }
  }

}
