﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System.Drawing;
using System.Windows.Forms;

namespace EhLib.WinForms
{
  class TextBoxEhManager
  {
    #region static fields
    private static TextBoxEhManager _defaultManager;
    #endregion static fields

    public TextBoxEhManager()
    {
    }

    public static TextBoxEhManager DefaultManager
    {
      get
      {
        if (_defaultManager == null)
          _defaultManager = new TextBoxEhManager();
        return _defaultManager;
      }
      set
      {
        _defaultManager = value;
      }
    }

    #region methods
    public virtual void InEditButtonDownDefaultAction(BaseTextBoxEh textBox, EditItem inEditControl, DownEventArgs e)
    {
      TextEditForm ddForm = new TextEditForm();

      ddForm.TextBox.Text = textBox.Text;
      ddForm.ReadOnly = textBox.ReadOnly;

      ddForm.ExecuteNomodal(
        textBox.RectangleToScreen(new Rectangle(new Point(0,0), textBox.Size)), 
        DropDownAlign.Left,
        InEditButtonDownDropDownFormCloseHandler,
        textBox
        );
    }

    protected virtual void InEditButtonDownDropDownFormCloseHandler(object sender, DropDownFormCloseEventArgs e)
    {
      if (e.CloseResult == DialogResult.OK)
      {
        ((TextEditForm) sender).MasterControl.Text = ((TextEditForm) sender).Text;
      }
    }

    #endregion methods
  }

}
