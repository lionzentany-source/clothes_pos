﻿//------------------------------------------------------------------------------
// <copyright file=”*.cs” company=”EhLib Team”>
//     Copyright (c) 2017 Dmitry V. Bolshakov   
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using System.Drawing.Drawing2D;

namespace EhLib.WinForms
{

  /// <summary>
  /// Defines a type of column in a DataGridEh control that displays a graphic.
  /// </summary>
  [DataGridColumnDesignTimeVisible(true)]
  public class DataGridImageColumn : DataGridColumn
  {

    public DataGridImageColumn()
    {

    }

    #region design-time properties

    [DefaultValue(PictureSizeMode.Fit)]
    public PictureSizeMode SizeMode
    {
      get { return DataCell.SizeMode; }
      set { DataCell.SizeMode = value; }
    }

    [DefaultValue(1.0)]
    public double Scale
    {
      get { return DataCell.Scale; }
      set { DataCell.Scale = value; }
    }
    #endregion

    #region run-time properties
    [Browsable(false)]
    public new ImageDataCellManager DataCell
    {
      get { return (ImageDataCellManager)base.InternalCellManager; }
    }
    #endregion

    #region methods
    protected override BaseDataCellManager CreateTemplateCell()
    {
      return new ImageDataCellManager();
    }
    #endregion
  }

  //[DataGridDataCellDesignTimeVisible(true)]
  //public class DataGridImageDataCellManager : DataGridBaseDataCellManager, IImageDataCellManager
  //{
  //  #region privates
  //  //private static readonly Type ImageType = typeof(System.Drawing.Image);
  //  private PictureSizeMode imageLayout = PictureSizeMode.Fit;
  //  private double scale = 1.0f;
  //  #endregion

  //  public DataGridImageDataCellManager()
  //  {
  //  }

  //  #region design-time properties
  //  [DefaultValue(PictureSizeMode.Fit)]
  //  public PictureSizeMode SizeMode
  //  {
  //    get { return imageLayout; }
  //    set
  //    {
  //      if (this.imageLayout != value)
  //      {
  //        imageLayout = value;
  //        Grid.InvalidateGrid();
  //      }
  //    }
  //  }

  //  [DefaultValue(1.0)]
  //  public double Scale
  //  {
  //    get
  //    {
  //      return scale;
  //    }

  //    set
  //    {
  //      if (scale != value)
  //      {
  //        scale = value;
  //        ScaleChanged();
  //      }
  //    }
  //  }
  //  #endregion

  //  #region properties
  //  public new ImageDataCellWorker CellWorker
  //  {
  //    get { return (ImageDataCellWorker)base.CellWorker; }
  //  }
  //  #endregion

  //  #region methods
  //  public Image GetCellValueAsImage(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar)
  //  {
  //    return CellWorker.GetCellValueAsImage(propAxisBar, listItemBar);
  //  }

  //  protected override void PaintForeground(DataAxisGridDataCellPaintEventArgs e)
  //  {
  //    CellWorker.PaintForeground(e);
  //  }

  //  protected internal override int CalcCellHeight(PropertyAxisBar propAxisBar, DataAxisGridListItemBar listItemBar, int cellWidth)
  //  {
  //    if (!HeightOptions.AutoExpand)
  //      return base.CalcCellHeight(propAxisBar, listItemBar, cellWidth);
  //    else
  //      return CellWorker.CalcCellHeight(CalcDefaultRowHeight(), propAxisBar, listItemBar, cellWidth);
  //  }

  //  protected virtual void ScaleChanged()
  //  {
  //    if (Grid != null)
  //      Grid.RowHeightAffectPropertyChanged();
  //  }

  //  protected internal override void PrintCell(
  //    PrintServiceEventArgs e, Rectangle paintRect, int areaColIndex, int areaRowIndex, PrintServiceEventArgs printContext
  //      )
  //  {
  //    CellWorker.PrintCell(e, paintRect, areaColIndex, areaRowIndex, printContext);
  //  }

  //  protected override DataCellWorker CreateDataCellWorker()
  //  {
  //    return new ImageDataCellWorker(this);
  //  }

  //  protected internal override void OnMouseEnter(DataAxisGridDataCellEnterEventArgs e)
  //  {
  //    base.OnMouseEnter(e);
  //    CellWorker.OnMouseEnter(e);
  //  }
  //  #endregion
  //}
}
