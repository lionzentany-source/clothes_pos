Place your fallback fonts here, e.g. NotoNaskhArabic-Regular.ttf
Suggested path: assets/fonts/NotoNaskhArabic-Regular.ttf
Then run: flutter pub get (or just rebuild) so the asset is bundled.

